using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;

namespace WarmWaterLauncher;

/// <summary>
/// 独立安装器窗口：协议、安装位置、进度条、百分比
/// </summary>
public partial class InstallerWindow : Window
{
    private int _currentStep = 1;
    private const int TotalSteps = 4;

    public InstallerWindow()
    {
        InitializeComponent();
        // 默认安装路径
        string defaultPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "WarmWaterLauncher");
        InstallPathBox.Text = defaultPath;
        UpdateDiskSpace();
    }

    private void CloseBtn_Click(object sender, RoutedEventArgs e)
    {
        if (_currentStep == 3)
        {
            System.Windows.MessageBox.Show("正在安装中，无法关闭！", "安装向导", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        var result = System.Windows.MessageBox.Show("确定要退出安装吗？", "安装向导", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (result == MessageBoxResult.Yes)
            Close();
    }

    private void AcceptLicenseCheck_Checked(object sender, RoutedEventArgs e)
    {
        NextBtn.IsEnabled = true;
    }

    private void AcceptLicenseCheck_Unchecked(object sender, RoutedEventArgs e)
    {
        if (_currentStep == 1)
            NextBtn.IsEnabled = false;
    }

    private void BrowseBtn_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog
        {
            Title = "选择安装目录"
        };
        if (dialog.ShowDialog() == true)
        {
            InstallPathBox.Text = dialog.FolderName;
            UpdateDiskSpace();
        }
    }

    private void UpdateDiskSpace()
    {
        try
        {
            string path = InstallPathBox.Text;
            if (string.IsNullOrEmpty(path)) return;
            string root = Path.GetPathRoot(path);
            if (string.IsNullOrEmpty(root)) return;
            var drive = new DriveInfo(root);
            long freeGB = drive.AvailableFreeSpace / (1024 * 1024 * 1024);
            DiskSpaceText.Text = $"当前磁盘可用空间：{freeGB} GB（建议至少保留 2 GB 用于游戏文件）";
        }
        catch
        {
            DiskSpaceText.Text = "";
        }
    }

    private void BackBtn_Click(object sender, RoutedEventArgs e)
    {
        if (_currentStep > 1)
        {
            _currentStep--;
            UpdatePage();
        }
    }

    private async void NextBtn_Click(object sender, RoutedEventArgs e)
    {
        if (_currentStep == 1)
        {
            // 协议页 -> 安装位置页
            _currentStep = 2;
            UpdatePage();
        }
        else if (_currentStep == 2)
        {
            // 安装位置页 -> 安装进度页
            string installPath = InstallPathBox.Text.Trim();
            if (string.IsNullOrEmpty(installPath))
            {
                System.Windows.MessageBox.Show("请选择安装目录！", "安装向导", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _currentStep = 3;
            UpdatePage();
            await StartInstallAsync(installPath);
        }
    }

    private void FinishBtn_Click(object sender, RoutedEventArgs e)
    {
        if (LaunchNowCheck.IsChecked == true)
        {
            // 启动安装好的启动器
            try
            {
                string exePath = Path.Combine(InstallPathBox.Text, "我的世界启动器.exe");
                if (File.Exists(exePath))
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = exePath,
                        UseShellExecute = true,
                        WorkingDirectory = InstallPathBox.Text
                    });
                }
            }
            catch { }
        }
        Close();
    }

    private void UpdatePage()
    {
        // 隐藏所有页面
        PageLicense.Visibility = Visibility.Collapsed;
        PageLocation.Visibility = Visibility.Collapsed;
        PageProgress.Visibility = Visibility.Collapsed;
        PageComplete.Visibility = Visibility.Collapsed;

        // 显示当前页面
        switch (_currentStep)
        {
            case 1:
                PageLicense.Visibility = Visibility.Visible;
                BackBtn.Visibility = Visibility.Collapsed;
                NextBtn.Visibility = Visibility.Visible;
                FinishBtn.Visibility = Visibility.Collapsed;
                NextBtn.IsEnabled = AcceptLicenseCheck.IsChecked == true;
                break;
            case 2:
                PageLocation.Visibility = Visibility.Visible;
                BackBtn.Visibility = Visibility.Visible;
                NextBtn.Visibility = Visibility.Visible;
                FinishBtn.Visibility = Visibility.Collapsed;
                NextBtn.IsEnabled = true;
                NextBtn.Content = "安装";
                break;
            case 3:
                PageProgress.Visibility = Visibility.Visible;
                BackBtn.Visibility = Visibility.Collapsed;
                NextBtn.Visibility = Visibility.Collapsed;
                FinishBtn.Visibility = Visibility.Collapsed;
                break;
            case 4:
                PageComplete.Visibility = Visibility.Visible;
                BackBtn.Visibility = Visibility.Collapsed;
                NextBtn.Visibility = Visibility.Collapsed;
                FinishBtn.Visibility = Visibility.Visible;
                CompletePathText.Text = $"安装位置：{InstallPathBox.Text}";
                break;
        }

        StepText.Text = $"第 {_currentStep} 步 / 共 {TotalSteps} 步";
    }

    /// <summary>
    /// 开始安装
    /// </summary>
    private async Task StartInstallAsync(string installPath)
    {
        try
        {
            // 检查是否有写入权限
            try
            {
                if (!Directory.Exists(installPath))
                    Directory.CreateDirectory(installPath);
                string testFile = Path.Combine(installPath, ".write_test");
                File.WriteAllText(testFile, "test");
                File.Delete(testFile);
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("没有权限写入该目录，请选择其他安装位置（建议选择用户目录下的文件夹），或以管理员身份运行安装器。", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                NextBtn.IsEnabled = true;
                BackBtn.IsEnabled = true;
                // 返回上一步
                _currentStep = 1;
                UpdatePage();
                return;
            }

            // 步骤1：创建目录
            UpdateInstallProgress(5, "正在创建安装目录...", "创建目录结构");
            await Task.Delay(300);
            if (!Directory.Exists(installPath))
                Directory.CreateDirectory(installPath);

            // 创建数据目录
            string dataDir = Path.Combine(installPath, "WarmWaterData");
            if (!Directory.Exists(dataDir))
                Directory.CreateDirectory(dataDir);

            string[] subDirs = { "instances", "versions", "assets", "libraries", "mods", "resourcepacks", "shaderpacks", "saves", "logs", "skins", "caches", "java" };
            for (int i = 0; i < subDirs.Length; i++)
            {
                string dir = Path.Combine(dataDir, subDirs[i]);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);
                UpdateInstallProgress(10 + (i + 1) * 2, $"正在创建数据目录...", subDirs[i]);
                await Task.Delay(50);
            }

            // 步骤2：复制启动器文件
            UpdateInstallProgress(30, "正在复制启动器文件...", "我的世界启动器.exe");
            await Task.Delay(200);

            string sourceExe = Process.GetCurrentProcess().MainModule?.FileName ?? "";
            string destExe = Path.Combine(installPath, "我的世界启动器.exe");

            if (!string.IsNullOrEmpty(sourceExe) && File.Exists(sourceExe) && !sourceExe.Equals(destExe, StringComparison.OrdinalIgnoreCase))
            {
                // 模拟复制进度
                for (int i = 0; i <= 100; i += 5)
                {
                    UpdateInstallProgress((int)(30 + i * 0.4), $"正在复制启动器文件... {i}%", "我的世界启动器.exe");
                    await Task.Delay(30);
                }
                File.Copy(sourceExe, destExe, true);
            }
            else
            {
                // 如果源文件不存在或就是目标文件，创建一个标记
                await Task.Delay(500);
            }

            // 步骤3：创建使用说明
            UpdateInstallProgress(75, "正在创建使用说明...", "使用说明.txt");
            await Task.Delay(200);
            string readmePath = Path.Combine(installPath, "使用说明.txt");
            File.WriteAllText(readmePath, GetReadmeContent());

            // 步骤4：创建快捷方式
            if (DesktopShortcutCheck.IsChecked == true)
            {
                UpdateInstallProgress(85, "正在创建桌面快捷方式...", "桌面快捷方式");
                await Task.Delay(300);
                CreateShortcut(destExe, "温水我的世界启动器", Environment.GetFolderPath(Environment.SpecialFolder.Desktop));
            }

            if (StartMenuCheck.IsChecked == true)
            {
                UpdateInstallProgress(92, "正在创建开始菜单快捷方式...", "开始菜单快捷方式");
                await Task.Delay(300);
                string startMenuPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs", "温水启动器");
                if (!Directory.Exists(startMenuPath))
                    Directory.CreateDirectory(startMenuPath);
                CreateShortcut(destExe, "温水我的世界启动器", startMenuPath);
            }

            // 步骤5：写入注册表（可选）
            UpdateInstallProgress(97, "正在完成安装...", "写入安装信息");
            await Task.Delay(300);
            try
            {
                using var key = Registry.CurrentUser.CreateSubKey(@"Software\WarmWaterLauncher");
                key?.SetValue("InstallPath", installPath);
                key?.SetValue("Version", "1.0 正式版");
            }
            catch { }

            // 完成
            UpdateInstallProgress(100, "安装完成！", "安装向导已完成");
            await Task.Delay(500);

            _currentStep = 4;
            UpdatePage();
        }
        catch (Exception ex)
        {
            System.Windows.MessageBox.Show($"安装失败：{ex.Message}", "安装错误", MessageBoxButton.OK, MessageBoxImage.Error);
            _currentStep = 2;
            UpdatePage();
        }
    }

    private void UpdateInstallProgress(int percent, string status, string detail)
    {
        Dispatcher.Invoke(() =>
        {
            InstallProgressBar.Value = Math.Min(100, Math.Max(0, percent));
            InstallPercentText.Text = $"{Math.Min(100, Math.Max(0, percent))}%";
            InstallStatusText.Text = status;
            InstallDetailText.Text = detail;
        });
    }

    /// <summary>
    /// 创建快捷方式
    /// </summary>
    private void CreateShortcut(string targetPath, string shortcutName, string shortcutDir)
    {
        try
        {
            string shortcutPath = Path.Combine(shortcutDir, $"{shortcutName}.lnk");
            // 使用 PowerShell 创建快捷方式
            var ps = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = $"-Command \"$s=(New-Object -COM WScript.Shell).CreateShortcut('{shortcutPath}');$s.TargetPath='{targetPath}';$s.WorkingDirectory='{Path.GetDirectoryName(targetPath)}';$s.Save()\"",
                UseShellExecute = false,
                CreateNoWindow = true
            };
            Process.Start(ps)?.WaitForExit(3000);
        }
        catch { }
    }

    private string GetReadmeContent()
    {
        return @"温水我的世界启动器 v1.0 正式版 使用说明
================================

【软件介绍】
本软件是基于 PCL（Plain Craft Launcher）开源代码和 AI 帮助制作的 Minecraft 启动器。
绿色免安装，无广告无捆绑。

【功能特点】
- 账号系统：离线账号创建、多账号切换（正版登录暂未开放审批）
- 版本管理：一键安装原版/快照/远古版/愚人节版本
- 加载器：Forge、Fabric、Quilt、OptiFine 一键安装
- 模组管理：Modrinth 在线搜索下载、模组依赖检测
- 整合包：CurseForge、Modrinth 整合包导入导出
- 联机玩法：局域网联机、内网穿透跨网络联机
- 皮肤管理：自定义皮肤、披风、3D 预览
- 下载管理：多线程下载、断点续传、下载队列管理
- 崩溃诊断：自动解析崩溃报告、智能修复建议
- AI 助手：分析崩溃报告、解答游戏问题
- 界面主题：深色/浅色主题、自定义背景、多语言

【使用方法】
1. 双击运行 我的世界启动器.exe
2. 首次启动请阅读并同意用户协议
3. 到「下载」页面下载游戏版本
4. 到「实例管理」创建游戏实例
5. 到「账号」页面创建或登录账号
6. 回到主页点击「启动游戏」

【注意事项】
- 启动游戏需要安装对应版本的 Java
- 启动器会自动检测并下载适配的 Java
- 游戏文件默认保存在 WarmWaterData 目录
- 建议将启动器放在非系统盘，预留足够空间

【技术支持】
如遇到问题，请查看启动器内的帮助文档，或查看日志文件。

================================
温水启动器开发团队
版本：v1.0 正式版
";
    }
}
