using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

/// <summary>点击下载版本后显示的安装窗口：选择目标实例、加载器及加载器版本。</summary>
public partial class VersionInstallDialog : Window
{
    public sealed class LoaderChoice : INotifyPropertyChanged
    {
        public string Key { get; init; } = "";
        public string Name { get; init; } = "";
        public string IconPath { get; init; } = "";
        private string _statusText = "检测中...";
        public string StatusText
        {
            get => _statusText;
            set { _statusText = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(StatusText))); }
        }
        public bool Installed { get; set; }
        public event PropertyChangedEventHandler? PropertyChanged;
    }

    private readonly VersionMeta _version;
    private readonly GameInstance? _currentInstance;
    private readonly string _defaultLoader;
    private readonly ObservableCollection<LoaderChoice> _choices = new();
    private readonly Dictionary<string, List<LoaderVersion>> _versions = new(StringComparer.OrdinalIgnoreCase);
    private bool _loading;
    private bool _suppressLoaderEvent;

    public LoaderVersion? SelectedLoaderVersion { get; private set; }
    public string? SelectedLoaderType { get; private set; }

    public bool CreateNewInstance
    {
        get
        {
            if (_currentInstance == null) return true;
            if (_currentInstance.VersionId == _version.Id) return false;
            return NewInstanceRadio.IsChecked != false;
        }
    }

    public VersionInstallDialog(VersionMeta version, GameInstance? currentInstance, string defaultLoader)
    {
        InitializeComponent();
        _version = version;
        _currentInstance = currentInstance;
        _defaultLoader = LoaderCatalog.Normalize(defaultLoader);

        TitleText.Text = $"安装 {version.Id}";
        SubtitleText.Text = $"{version.TypeName} · 选择要安装的模组加载器（可选）";
        VersionIcon.Source = new System.Windows.Media.Imaging.BitmapImage(
            new Uri(VersionIconPath(version.Type), UriKind.Relative));

        foreach (var key in new[] { "fabric", "forge", "quilt", "optifine" })
        {
            _choices.Add(new LoaderChoice
            {
                Key = key,
                Name = LoaderCatalog.DisplayName(key),
                IconPath = LoaderCatalog.IconPath(key)
            });
        }
        LoaderList.ItemsSource = _choices;

        ConfigureTarget();
        Loaded += async (_, _) => await LoadAvailabilityAsync();
    }

    private static string VersionIconPath(VersionType type) => type switch
    {
        VersionType.Snapshot => "/Resources/icon_snapshot.png",
        VersionType.OldBeta or VersionType.OldAlpha => "/Resources/icon_old.png",
        VersionType.AprilFools => "/Resources/icon_aprilfools.png",
        _ => "/Resources/icon_release.png"
    };

    private void ConfigureTarget()
    {
        if (_currentInstance == null)
        {
            TargetPanel.Visibility = Visibility.Collapsed;
            TargetHintText.Text = "将创建一个新的游戏实例。";
            return;
        }

        if (_currentInstance.VersionId == _version.Id)
        {
            TargetPanel.Visibility = Visibility.Collapsed;
            TargetHintText.Text = $"将安装到当前实例：{_currentInstance.Name}";
            return;
        }

        TargetPanel.Visibility = Visibility.Visible;
        NewInstanceRadio.IsChecked = true;
        CurrentInstanceRadio.Content = $"覆盖当前实例（{_currentInstance.VersionId}）";
        TargetHintText.Text = "推荐创建新实例，避免覆盖已有版本的存档和模组。";
    }

    private async Task LoadAvailabilityAsync()
    {
        if (_loading) return;
        _loading = true;
        RetryLoadersBtn.IsEnabled = false;
        LoaderStatusText.Text = "正在检测 Forge / Fabric / Quilt / OptiFine 的可用版本...";
        foreach (var c in _choices) c.StatusText = "检测中...";

        var tasks = _choices.Select(async choice =>
        {
            try
            {
                var versions = await App.Services.Loaders.GetAvailableAsync(choice.Key, _version.Id);
                _versions[choice.Key] = versions;
                bool installed = _currentInstance != null
                    && _currentInstance.VersionId == _version.Id
                    && string.Equals(_currentInstance.LoaderType, choice.Key, StringComparison.OrdinalIgnoreCase);
                choice.Installed = installed;
                choice.StatusText = versions.Count == 0
                    ? "该版本不可用"
                    : $"{versions.Count} 个可选" + (installed ? " · 已安装" : "");
            }
            catch
            {
                _versions[choice.Key] = new List<LoaderVersion>();
                choice.StatusText = "检测失败";
            }
        }).ToList();

        try
        {
            await Task.WhenAll(tasks);
        }
        finally
        {
            _loading = false;
            RetryLoadersBtn.IsEnabled = true;
        }

        int available = _choices.Count(c => _versions.TryGetValue(c.Key, out var v) && v.Count > 0);
        LoaderStatusText.Text = available > 0
            ? $"已检测到 {available} 种可用加载器。选择加载器后可进一步选择具体版本；取消选择会重新检测。"
            : "没有检测到可用的加载器，仍可只安装原版游戏。";

        // 优先选择已安装的加载器，其次使用下载页的默认设置
        LoaderChoice? preferred = _choices.FirstOrDefault(c => c.Installed);
        if (preferred == null && _defaultLoader is "fabric" or "forge" or "quilt" or "optifine")
            preferred = _choices.FirstOrDefault(c => c.Key == _defaultLoader && _versions.TryGetValue(c.Key, out var v) && v.Count > 0);

        _suppressLoaderEvent = true;
        LoaderList.SelectedItem = preferred;
        _suppressLoaderEvent = false;
        if (preferred != null) SelectLoader(preferred);
        else ClearLoaderSelection(keepStatus: true);
    }

    private void LoaderList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressLoaderEvent) return;
        if (LoaderList.SelectedItem is LoaderChoice choice)
            SelectLoader(choice);
        else
            ClearLoaderSelection(keepStatus: true);
    }

    private void SelectLoader(LoaderChoice choice)
    {
        SelectedLoaderType = choice.Key;
        SelectedLoaderVersion = null;
        SelectedLoaderText.Text = $"{choice.Name} 加载器";
        SelectedLoaderHint.Text = choice.Installed
            ? "当前实例已安装该加载器，可重新选择版本覆盖"
            : (_currentInstance?.LoaderType is string oldType && oldType != "none" && oldType != choice.Key
                ? $"安装后会替换当前 {LoaderCatalog.DisplayName(oldType)} 加载器"
                : "请选择该加载器支持的版本");

        if (_versions.TryGetValue(choice.Key, out var versions) && versions.Count > 0)
        {
            LoaderVersionCombo.ItemsSource = versions;
            LoaderVersionCombo.SelectedIndex = 0;
            SelectedLoaderVersion = versions[0];
            InstallBtn.Content = $"下载并安装 {choice.Name}";
            LoaderStatusText.Text = $"已选择 {choice.Name}，共 {versions.Count} 个版本可选。";
        }
        else
        {
            LoaderVersionCombo.ItemsSource = null;
            InstallBtn.Content = "下载并安装原版";
            LoaderStatusText.Text = $"{choice.Name} 没有适用于 {_version.Id} 的版本，请选择其他加载器或取消选择。";
        }
    }

    private void ClearLoaderSelection(bool keepStatus)
    {
        SelectedLoaderType = null;
        SelectedLoaderVersion = null;
        LoaderVersionCombo.ItemsSource = null;
        SelectedLoaderText.Text = "不安装加载器";
        SelectedLoaderHint.Text = "只安装原版游戏";
        InstallBtn.Content = "下载并安装原版";
        if (!keepStatus) LoaderStatusText.Text = "已取消加载器选择，将只安装原版游戏。";
    }

    private void LoaderVersionCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        SelectedLoaderVersion = LoaderVersionCombo.SelectedItem as LoaderVersion;
    }

    private void ClearLoader_Click(object sender, RoutedEventArgs e)
    {
        _suppressLoaderEvent = true;
        LoaderList.SelectedItem = null;
        _suppressLoaderEvent = false;
        ClearLoaderSelection(keepStatus: false);
        // 取消某个加载器后重新检测全部加载器，更新其他加载器是否可下载
        _ = LoadAvailabilityAsync();
    }

    private void RetryLoaders_Click(object sender, RoutedEventArgs e) => _ = LoadAvailabilityAsync();

    private void Install_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedLoaderType != null && SelectedLoaderVersion == null)
        {
            MessageBox.Show("请选择加载器版本，或点击「取消此加载器」只安装原版。", "安装游戏版本",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        DialogResult = true;
        Close();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }
}
