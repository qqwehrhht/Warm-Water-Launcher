using System.Globalization;
using System.Windows.Data;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Converters;

/// <summary>
/// 将 VersionType 枚举转换为字符串，用于方块图标配色
/// </summary>
public class VersionTypeToStringConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is VersionType vt)
        {
            return vt.ToString().ToLowerInvariant();
        }
        return "release";
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is string s && Enum.TryParse<VersionType>(s, true, out var vt))
            return vt;
        return VersionType.Release;
    }
}
