using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace WarmWaterLauncher.Services;

/// <summary>CurseForge 模组信息</summary>
public class CurseForgeMod
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("slug")] public string Slug { get; set; } = "";
    [JsonPropertyName("summary")] public string Summary { get; set; } = "";
    [JsonPropertyName("downloadCount")] public long DownloadCount { get; set; }
    [JsonPropertyName("logo")] public CurseForgeAsset? Logo { get; set; }
    [JsonPropertyName("categories")] public List<CurseForgeCategory> Categories { get; set; } = new();
    [JsonPropertyName("authors")] public List<CurseForgeAuthor> Authors { get; set; } = new();
    [JsonPropertyName("latestFilesIndexes")] public List<CurseForgeFileIndex> LatestFilesIndexes { get; set; } = new();
    [JsonPropertyName("dateReleased")] public string? DateReleased { get; set; }
    [JsonPropertyName("dateModified")] public string? DateModified { get; set; }
    [JsonPropertyName("gameVersionLatestFiles")] public List<CurseForgeGameVersionFile>? GameVersionLatestFiles { get; set; }

    /// <summary>图标URL</summary>
    [JsonIgnore] public string? IconUrl => Logo?.ThumbnailUrl ?? Logo?.Url;
    /// <summary>作者名</summary>
    [JsonIgnore] public string AuthorName => Authors.Count > 0 ? Authors[0].Name : "未知";
    /// <summary>分类显示</summary>
    [JsonIgnore] public string CategoryDisplay => Categories.Count > 0 ? string.Join(" · ", Categories.Take(3).Select(c => c.Name)) : "";
    /// <summary>下载量格式化</summary>
    [JsonIgnore] public string DownloadsDisplay => DownloadCount >= 1000000 ? $"{DownloadCount / 1000000.0:F1}M" : DownloadCount >= 1000 ? $"{DownloadCount / 1000.0:F1}K" : DownloadCount.ToString();
    /// <summary>来源标识</summary>
    [JsonIgnore] public string Source => "CurseForge";
}

public class CurseForgeAsset
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("modId")] public int ModId { get; set; }
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("description")] public string Description { get; set; } = "";
    [JsonPropertyName("thumbnailUrl")] public string? ThumbnailUrl { get; set; }
    [JsonPropertyName("url")] public string? Url { get; set; }
}

public class CurseForgeCategory
{
    [JsonPropertyName("categoryId")] public int CategoryId { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("url")] public string? Url { get; set; }
    [JsonPropertyName("avatarUrl")] public string? AvatarUrl { get; set; }
}

public class CurseForgeAuthor
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("url")] public string? Url { get; set; }
}

public class CurseForgeFileIndex
{
    [JsonPropertyName("gameVersion")] public string GameVersion { get; set; } = "";
    [JsonPropertyName("fileId")] public int FileId { get; set; }
    [JsonPropertyName("filename")] public string Filename { get; set; } = "";
    [JsonPropertyName("releaseType")] public int ReleaseType { get; set; }
    [JsonPropertyName("gameVersionTypeId")] public int GameVersionTypeId { get; set; }
    [JsonPropertyName("modLoader")] public int? ModLoader { get; set; }
}

public class CurseForgeGameVersionFile
{
    [JsonPropertyName("gameVersion")] public string GameVersion { get; set; } = "";
    [JsonPropertyName("projectFileId")] public int ProjectFileId { get; set; }
    [JsonPropertyName("projectFileName")] public string ProjectFileName { get; set; } = "";
    [JsonPropertyName("fileType")] public int FileType { get; set; }
}

public class CurseForgeFile
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("modId")] public int ModId { get; set; }
    [JsonPropertyName("fileName")] public string FileName { get; set; } = "";
    [JsonPropertyName("displayName")] public string DisplayName { get; set; } = "";
    [JsonPropertyName("downloadUrl")] public string? DownloadUrl { get; set; }
    [JsonPropertyName("fileLength")] public long FileLength { get; set; }
    [JsonPropertyName("gameVersions")] public List<string> GameVersions { get; set; } = new();
    [JsonPropertyName("releaseType")] public int ReleaseType { get; set; }
    [JsonPropertyName("fileStatus")] public int FileStatus { get; set; }
    [JsonPropertyName("fileDate")] public string? FileDate { get; set; }
    [JsonPropertyName("downloadCount")] public long DownloadCount { get; set; }
    [JsonPropertyName("fileFingerprint")] public long FileFingerprint { get; set; }
    [JsonPropertyName("hashes")] public List<CurseForgeHash>? Hashes { get; set; }
    [JsonPropertyName("sortableGameVersions")] public List<CurseForgeSortableGameVersion>? SortableGameVersions { get; set; }
}

public class CurseForgeHash
{
    [JsonPropertyName("value")] public string Value { get; set; } = "";
    [JsonPropertyName("algo")] public int Algo { get; set; } // 1=SHA1, 2=MD5
}

public class CurseForgeSortableGameVersion
{
    [JsonPropertyName("gameVersionName")] public string GameVersionName { get; set; } = "";
    [JsonPropertyName("gameVersionPadded")] public string GameVersionPadded { get; set; } = "";
    [JsonPropertyName("gameVersion")] public string GameVersion { get; set; } = "";
    [JsonPropertyName("gameVersionReleaseDate")] public string GameVersionReleaseDate { get; set; } = "";
    [JsonPropertyName("gameVersionTypeId")] public int GameVersionTypeId { get; set; }
}

/// <summary>CurseForge API 服务（需要 API Key）</summary>
public class CurseForgeApi
{
    private readonly SettingsService _settings;
    private readonly DownloadService _dl;
    public const string Base = "https://api.curseforge.com/v1";
    public const int GameIdMinecraft = 432; // Minecraft 的游戏ID

    // CurseForge 官方 API 需要用户自己的 API Key（免费申请）
    public string ApiKey => _settings.Config.Advanced.CurseForgeApiKey ?? "";
    public bool HasCustomKey => !string.IsNullOrEmpty(_settings.Config.Advanced.CurseForgeApiKey);
    public bool IsConfigured => HasCustomKey;

    public CurseForgeApi(SettingsService settings, DownloadService dl)
    {
        _settings = settings;
        _dl = dl;
    }

    /// <summary>设置 API Key</summary>
    public void SetApiKey(string apiKey)
    {
        _settings.Config.Advanced.CurseForgeApiKey = apiKey;
        _settings.Save();
    }

    private HttpClient CreateClient()
    {
        var client = _dl.Http.Client;
        client.DefaultRequestHeaders.Remove("x-api-key");
        client.DefaultRequestHeaders.Add("x-api-key", ApiKey);
        client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
        return client;
    }

    /// <summary>搜索模组（使用官方API，需要API Key）</summary>
    public async Task<List<CurseForgeMod>> SearchAsync(string query, string gameVersion = "", string modLoaderType = "",
        string categoryId = "", string sortField = "2", int limit = 50, CancellationToken ct = default)
    {
        if (!IsConfigured) return new List<CurseForgeMod>();
        try
        {
            var client = CreateClient();
            string url = $"{Base}/mods/search?gameId={GameIdMinecraft}&searchFilter={Uri.EscapeDataString(query)}&pageSize={limit}&sortField={sortField}&sortOrder=desc";
            if (!string.IsNullOrEmpty(gameVersion)) url += $"&gameVersion={Uri.EscapeDataString(gameVersion)}";
            if (!string.IsNullOrEmpty(modLoaderType)) url += $"&modLoaderType={modLoaderType}";
            if (!string.IsNullOrEmpty(categoryId)) url += $"&categoryId={categoryId}";

            using var resp = await client.GetAsync(url, ct);
            if (!resp.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine($"CurseForge API HTTP {(int)resp.StatusCode}");
                return new List<CurseForgeMod>();
            }
            var json = await resp.Content.ReadAsStringAsync(ct);
            if (string.IsNullOrEmpty(json)) return new List<CurseForgeMod>();

            using var doc = JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty("data", out var data)) return new List<CurseForgeMod>();
            return JsonSerializer.Deserialize<List<CurseForgeMod>>(data.GetRawText(), SettingsService.JsonOpts) ?? new();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"CurseForge search error: {ex.Message}");
            return new List<CurseForgeMod>();
        }
    }

    /// <summary>创建网页客户端（模拟浏览器）</summary>
    private HttpClient CreateWebClient()
    {
        var client = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
        client.DefaultRequestHeaders.UserAgent.Clear();
        client.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        client.DefaultRequestHeaders.Accept.ParseAdd("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
        client.DefaultRequestHeaders.AcceptLanguage.ParseAdd("zh-CN,zh;q=0.9,en;q=0.8");
        return client;
    }

    /// <summary>解析CurseForge搜索页面HTML</summary>
    private List<CurseForgeMod> ParseSearchPage(string html, int limit)
    {
        var results = new List<CurseForgeMod>();
        try
        {
            // 方法1：从内嵌JSON中提取（CurseForge页面可能包含__NEXT_DATA__或类似的JSON）
            var jsonMatch = System.Text.RegularExpressions.Regex.Match(html,
                @"<script[^>]*id=""__NEXT_DATA__""[^>]*>(.*?)</script>",
                System.Text.RegularExpressions.RegexOptions.Singleline);
            if (jsonMatch.Success)
            {
                try
                {
                    using var doc = System.Text.Json.JsonDocument.Parse(jsonMatch.Groups[1].Value);
                    var mods = ExtractModsFromJson(doc.RootElement);
                    if (mods.Count > 0) return mods.Take(limit).ToList();
                }
                catch { }
            }

            // 方法2：从window.__INITIAL_STATE__或类似变量中提取
            jsonMatch = System.Text.RegularExpressions.Regex.Match(html,
                @"window\.__[A-Z_]+__\s*=\s*({.*?});\s*</script>",
                System.Text.RegularExpressions.RegexOptions.Singleline);
            if (jsonMatch.Success)
            {
                try
                {
                    using var doc = System.Text.Json.JsonDocument.Parse(jsonMatch.Groups[1].Value);
                    var mods = ExtractModsFromJson(doc.RootElement);
                    if (mods.Count > 0) return mods.Take(limit).ToList();
                }
                catch { }
            }

            // 方法3：从HTML项目卡片中提取（服务器端渲染）
            // CurseForge搜索结果中每个项目有 data-project-id 或类似属性
            var cardPattern = new System.Text.RegularExpressions.Regex(
                @"<(?:div|article|a)[^>]*(?:data-project-id|data-id)=""(\d+)""[^>]*>(.*?)</(?:div|article|a)>",
                System.Text.RegularExpressions.RegexOptions.Singleline);
            foreach (System.Text.RegularExpressions.Match m in cardPattern.Matches(html))
            {
                if (results.Count >= limit) break;
                int id = int.TryParse(m.Groups[1].Value, out int pid) ? pid : 0;
                string cardHtml = m.Groups[2].Value;
                var mod = ParseModCard(cardHtml, id);
                if (mod != null) results.Add(mod);
            }

            // 方法4：从所有指向mc-mods的链接中提取
            if (results.Count == 0)
            {
                var linkPattern = new System.Text.RegularExpressions.Regex(
                    @"<a[^>]*href=""/minecraft/mc-mods/([^""?#]+)""[^>]*>(.*?)</a>",
                    System.Text.RegularExpressions.RegexOptions.Singleline);
                var seenSlugs = new HashSet<string>();
                foreach (System.Text.RegularExpressions.Match m in linkPattern.Matches(html))
                {
                    if (results.Count >= limit) break;
                    string slug = m.Groups[1].Value;
                    if (seenSlugs.Contains(slug)) continue;
                    seenSlugs.Add(slug);
                    string cardHtml = m.Groups[2].Value;
                    var mod = ParseModCard(cardHtml, 0);
                    if (mod != null)
                    {
                        mod.Slug = slug;
                        results.Add(mod);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"CurseForge parse error: {ex.Message}");
        }
        return results;
    }

    /// <summary>从JSON中递归提取模组列表</summary>
    private List<CurseForgeMod> ExtractModsFromJson(System.Text.Json.JsonElement element)
    {
        var results = new List<CurseForgeMod>();
        try
        {
            if (element.ValueKind == System.Text.Json.JsonValueKind.Object)
            {
                // 检查是否是模组对象
                if (element.TryGetProperty("id", out var id) &&
                    (element.TryGetProperty("slug", out _) || element.TryGetProperty("name", out _)))
                {
                    var mod = new CurseForgeMod
                    {
                        Id = id.TryGetInt32(out int i) ? i : 0,
                        Slug = element.TryGetProperty("slug", out var s) ? s.GetString() ?? "" : "",
                        Name = element.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "",
                        Summary = element.TryGetProperty("summary", out var sum) ? sum.GetString() ?? "" : "",
                        DownloadCount = element.TryGetProperty("downloadCount", out var dl) ? dl.GetInt64() : 0
                    };
                    if (element.TryGetProperty("logo", out var logo) && logo.ValueKind == System.Text.Json.JsonValueKind.Object)
                    {
                        mod.Logo = new CurseForgeAsset
                        {
                            Url = logo.TryGetProperty("url", out var u) ? u.GetString() : null,
                            ThumbnailUrl = logo.TryGetProperty("thumbnailUrl", out var t) ? t.GetString() : null
                        };
                    }
                    if (element.TryGetProperty("categories", out var cats) && cats.ValueKind == System.Text.Json.JsonValueKind.Array)
                    {
                        foreach (var cat in cats.EnumerateArray())
                        {
                            mod.Categories.Add(new CurseForgeCategory
                            {
                                Name = cat.TryGetProperty("name", out var cn) ? cn.GetString() ?? "" : ""
                            });
                        }
                    }
                    if (element.TryGetProperty("authors", out var authors) && authors.ValueKind == System.Text.Json.JsonValueKind.Array)
                    {
                        foreach (var author in authors.EnumerateArray())
                        {
                            mod.Authors.Add(new CurseForgeAuthor
                            {
                                Name = author.TryGetProperty("name", out var an) ? an.GetString() ?? "" : ""
                            });
                        }
                    }
                    if (!string.IsNullOrEmpty(mod.Name)) results.Add(mod);
                }
                // 递归搜索子属性
                foreach (var prop in element.EnumerateObject())
                {
                    results.AddRange(ExtractModsFromJson(prop.Value));
                }
            }
            else if (element.ValueKind == System.Text.Json.JsonValueKind.Array)
            {
                foreach (var item in element.EnumerateArray())
                {
                    results.AddRange(ExtractModsFromJson(item));
                }
            }
        }
        catch { }
        return results;
    }

    /// <summary>解析单个模组卡片HTML</summary>
    private CurseForgeMod? ParseModCard(string cardHtml, int id)
    {
        try
        {
            // 提取名称
            var nameMatch = System.Text.RegularExpressions.Regex.Match(cardHtml,
                @"<(?:h\d|span|div)[^>]*class=""[^""]*(?:name|title)[^""]*""[^>]*>(.*?)</(?:h\d|span|div)>",
                System.Text.RegularExpressions.RegexOptions.Singleline | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (!nameMatch.Success)
            {
                nameMatch = System.Text.RegularExpressions.Regex.Match(cardHtml,
                    @"<(?:h\d)[^>]*>(.*?)</h\d>",
                    System.Text.RegularExpressions.RegexOptions.Singleline);
            }
            string name = nameMatch.Success ? System.Net.WebUtility.HtmlDecode(nameMatch.Groups[1].Value.Trim()) : "";

            // 提取描述
            var descMatch = System.Text.RegularExpressions.Regex.Match(cardHtml,
                @"<p[^>]*>(.*?)</p>",
                System.Text.RegularExpressions.RegexOptions.Singleline);
            string desc = descMatch.Success ? System.Net.WebUtility.HtmlDecode(descMatch.Groups[1].Value.Trim()) : "";

            // 提取图标
            var iconMatch = System.Text.RegularExpressions.Regex.Match(cardHtml,
                @"<img[^>]*src=""([^""]+)""",
                System.Text.RegularExpressions.RegexOptions.Singleline);
            string? icon = iconMatch.Success ? iconMatch.Groups[1].Value : null;

            // 提取下载量
            long downloads = 0;
            var dlMatch = System.Text.RegularExpressions.Regex.Match(cardHtml,
                @"([\d,.]+)\s*(M|K|B|万|亿)?\s*(?:下载|downloads?)",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (dlMatch.Success)
            {
                string numStr = dlMatch.Groups[1].Value.Replace(",", "");
                if (double.TryParse(numStr, out double num))
                {
                    string unit = dlMatch.Groups[2].Value.ToUpper();
                    downloads = unit switch
                    {
                        "K" => (long)(num * 1000),
                        "M" => (long)(num * 1000000),
                        "B" => (long)(num * 1000000000),
                        "万" => (long)(num * 10000),
                        "亿" => (long)(num * 100000000),
                        _ => (long)num
                    };
                }
            }

            if (string.IsNullOrEmpty(name) && string.IsNullOrEmpty(desc)) return null;

            return new CurseForgeMod
            {
                Id = id,
                Name = name,
                Summary = desc,
                DownloadCount = downloads,
                Logo = icon != null ? new CurseForgeAsset { Url = icon, ThumbnailUrl = icon } : null,
                Categories = new List<CurseForgeCategory>(),
                Authors = new List<CurseForgeAuthor>()
            };
        }
        catch { return null; }
    }

    /// <summary>获取模组文件列表（通过网页解析）</summary>
    public async Task<List<CurseForgeFile>> GetFilesAsync(int modId, string gameVersion = "", string modLoaderType = "", CancellationToken ct = default)
    {
        // 如果有modId，用官方API；否则返回空（网页解析文件列表较复杂）
        if (modId > 0 && HasCustomKey)
        {
            try
            {
                var client = CreateClient();
                string url = $"{Base}/mods/{modId}/files?pageSize=50";
                if (!string.IsNullOrEmpty(gameVersion)) url += $"&gameVersion={Uri.EscapeDataString(gameVersion)}";
                if (!string.IsNullOrEmpty(modLoaderType)) url += $"&modLoaderType={modLoaderType}";

                using var resp = await client.GetAsync(url, ct);
                if (!resp.IsSuccessStatusCode) return new List<CurseForgeFile>();
                var json = await resp.Content.ReadAsStringAsync(ct);
                if (string.IsNullOrEmpty(json)) return new List<CurseForgeFile>();

                using var doc = JsonDocument.Parse(json);
                if (!doc.RootElement.TryGetProperty("data", out var data)) return new List<CurseForgeFile>();
                return JsonSerializer.Deserialize<List<CurseForgeFile>>(data.GetRawText(), SettingsService.JsonOpts) ?? new();
            }
            catch { return new List<CurseForgeFile>(); }
        }
        return new List<CurseForgeFile>();
    }

    /// <summary>获取单个文件详情</summary>
    public async Task<CurseForgeFile?> GetFileAsync(int modId, int fileId, CancellationToken ct = default)
    {
        if (!IsConfigured) return null;

        try
        {
            var client = CreateClient();
            string url = $"{Base}/mods/{modId}/files/{fileId}";
            using var resp = await client.GetAsync(url, ct);
            if (!resp.IsSuccessStatusCode) return null;
            var json = await resp.Content.ReadAsStringAsync(ct);
            if (string.IsNullOrEmpty(json)) return null;

            using var doc = JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty("data", out var data)) return null;
            return JsonSerializer.Deserialize<CurseForgeFile>(data.GetRawText(), SettingsService.JsonOpts);
        }
        catch { return null; }
    }

    /// <summary>获取下载URL（有些文件需要通过下载URL接口获取）</summary>
    public async Task<string?> GetDownloadUrlAsync(int modId, int fileId, CancellationToken ct = default)
    {
        if (!IsConfigured) return null;

        try
        {
            var client = CreateClient();
            string url = $"{Base}/mods/{modId}/files/{fileId}/download-url";
            using var resp = await client.GetAsync(url, ct);
            if (!resp.IsSuccessStatusCode) return null;
            var json = await resp.Content.ReadAsStringAsync(ct);
            if (string.IsNullOrEmpty(json)) return null;

            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("data", out var data))
                return data.GetString();
        }
        catch { }
        return null;
    }

    /// <summary>测试 API 连接</summary>
    public async Task<(bool success, string message)> TestConnectionAsync(CancellationToken ct = default)
    {
        if (!IsConfigured) return (false, "未配置 CurseForge API Key");

        try
        {
            var client = CreateClient();
            string url = $"{Base}/mods/search?gameId={GameIdMinecraft}&searchFilter=jei&pageSize=1";
            using var resp = await client.GetAsync(url, ct);
            if (resp.IsSuccessStatusCode) return (true, "连接成功");
            if ((int)resp.StatusCode == 403) return (false, "API Key 无效或无权限（HTTP 403）");
            if ((int)resp.StatusCode == 429) return (false, "请求过于频繁（HTTP 429）");
            return (false, $"HTTP {(int)resp.StatusCode}");
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    /// <summary>ModLoader 类型映射</summary>
    public static string? GetModLoaderType(string loader)
    {
        return loader.ToLower() switch
        {
            "forge" => "1",
            "fabric" => "4",
            "quilt" => "5",
            "neoforge" => "6",
            _ => null
        };
    }

    /// <summary>排序字段映射</summary>
    public static string GetSortField(string sort)
    {
        return sort.ToLower() switch
        {
            "downloads" => "2",      // 下载量
            "updated" => "3",        // 最近更新
            "newest" => "4",         // 最新发布
            "name" => "5",           // 名称
            "author" => "6",         // 作者
            "total_downloads" => "7",// 总下载量
            _ => "2"                 // 默认下载量
        };
    }
}
