using System;
using System.Collections.Generic;
using System.Linq;

namespace WarmWaterLauncher.Models
{
    /// <summary>
    /// 里程碑定义
    /// </summary>
    public class Milestone
    {
        public int Id { get; set; }
        public int LaunchCount { get; set; }
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public string Icon { get; set; } = "🏆";
        public string Reward { get; set; } = "";
        public bool IsUnlocked { get; set; }
        public DateTime? UnlockedAt { get; set; }

        public string UnlockedText => IsUnlocked ? "已达成" : "未达成";
        public string ProgressText => IsUnlocked ? $"已于 {UnlockedAt:yyyy-MM-dd} 达成" : $"还需启动 {LaunchCount - App.Services.Settings.Config.General.GameLaunchCount} 次";
    }

    /// <summary>
    /// 里程碑服务
    /// </summary>
    public static class MilestoneService
    {
        /// <summary>
        /// 所有里程碑定义
        /// </summary>
        public static readonly List<Milestone> AllMilestones = new()
        {
            new Milestone { Id = 1, LaunchCount = 1, Title = "初次启程", Description = "第一次启动我的世界", Icon = "🌱", Reward = "解锁启动器基础功能" },
            new Milestone { Id = 2, LaunchCount = 5, Title = "初出茅庐", Description = "累计启动5次游戏", Icon = "🌿", Reward = "解锁浅色主题" },
            new Milestone { Id = 3, LaunchCount = 10, Title = "新手玩家", Description = "累计启动10次游戏", Icon = "🎮", Reward = "解锁自定义主题色" },
            new Milestone { Id = 4, LaunchCount = 20, Title = "冒险者", Description = "累计启动20次游戏", Icon = "⚔️", Reward = "解锁更多背景图片" },
            new Milestone { Id = 5, LaunchCount = 30, Title = "探索者", Description = "累计启动30次游戏", Icon = "🗺️", Reward = "解锁启动音效" },
            new Milestone { Id = 6, LaunchCount = 40, Title = "勇士", Description = "累计启动40次游戏", Icon = "🗡️", Reward = "解锁更多图标" },
            new Milestone { Id = 7, LaunchCount = 50, Title = "资深玩家", Description = "累计启动50次游戏", Icon = "🛡️", Reward = "解锁隐藏主题" },
            new Milestone { Id = 8, LaunchCount = 60, Title = "精英玩家", Description = "累计启动60次游戏", Icon = "💠", Reward = "解锁高级背景" },
            new Milestone { Id = 9, LaunchCount = 70, Title = "大师玩家", Description = "累计启动70次游戏", Icon = "🎖️", Reward = "解锁专属头像框" },
            new Milestone { Id = 10, LaunchCount = 80, Title = "宗师玩家", Description = "累计启动80次游戏", Icon = "🏅", Reward = "解锁动态主题" },
            new Milestone { Id = 11, LaunchCount = 90, Title = "传奇新手", Description = "累计启动90次游戏", Icon = "🎗️", Reward = "解锁传奇边框" },
            new Milestone { Id = 12, LaunchCount = 100, Title = "百次成就", Description = "累计启动100次游戏", Icon = "💯", Reward = "解锁启动器背景音乐" },
            new Milestone { Id = 13, LaunchCount = 150, Title = "百五达人", Description = "累计启动150次游戏", Icon = "🎯", Reward = "解锁高级外观设置" },
            new Milestone { Id = 14, LaunchCount = 200, Title = "双百达人", Description = "累计启动200次游戏", Icon = "🏆", Reward = "解锁VIP主题" },
            new Milestone { Id = 15, LaunchCount = 250, Title = "二百五勇士", Description = "累计启动250次游戏", Icon = "⚜️", Reward = "解锁专属启动动画" },
            new Milestone { Id = 16, LaunchCount = 300, Title = "三百勇士", Description = "累计启动300次游戏", Icon = "🏰", Reward = "解锁高级启动动画" },
            new Milestone { Id = 17, LaunchCount = 400, Title = "四百豪杰", Description = "累计启动400次游戏", Icon = "👑", Reward = "解锁王者主题" },
            new Milestone { Id = 18, LaunchCount = 500, Title = "半千之境", Description = "累计启动500次游戏", Icon = "💎", Reward = "解锁至尊主题" },
            new Milestone { Id = 19, LaunchCount = 600, Title = "六百巅峰", Description = "累计启动600次游戏", Icon = "🌟", Reward = "解锁巅峰主题" },
            new Milestone { Id = 20, LaunchCount = 700, Title = "七百神话", Description = "累计启动700次游戏", Icon = "🌈", Reward = "解锁神话主题" },
            new Milestone { Id = 21, LaunchCount = 800, Title = "八百传说", Description = "累计启动800次游戏", Icon = "🔥", Reward = "解锁传说主题" },
            new Milestone { Id = 22, LaunchCount = 900, Title = "九百至尊", Description = "累计启动900次游戏", Icon = "👑", Reward = "解锁至尊主题+动态背景" },
            new Milestone { Id = 23, LaunchCount = 1000, Title = "千次传奇", Description = "累计启动1000次游戏", Icon = "🏆", Reward = "解锁传奇主题+专属图标" },
            new Milestone { Id = 24, LaunchCount = 1500, Title = "千五英雄", Description = "累计启动1500次游戏", Icon = "⚔️", Reward = "解锁英雄主题" },
            new Milestone { Id = 25, LaunchCount = 2000, Title = "两千神话", Description = "累计启动2000次游戏", Icon = "🌈", Reward = "解锁神话主题+全部功能" },
            new Milestone { Id = 26, LaunchCount = 3000, Title = "三千世界", Description = "累计启动3000次游戏", Icon = "🌍", Reward = "解锁世界主题" },
            new Milestone { Id = 27, LaunchCount = 5000, Title = "五千传说", Description = "累计启动5000次游戏", Icon = "🔥", Reward = "解锁传说主题+动态背景" },
            new Milestone { Id = 28, LaunchCount = 10000, Title = "万次至尊", Description = "累计启动10000次游戏", Icon = "💎", Reward = "解锁至尊主题+全部功能" },
        };

        /// <summary>
        /// 获取所有里程碑（带解锁状态）
        /// </summary>
        public static List<Milestone> GetAllMilestones()
        {
            int launchCount = App.Services.Settings.Config.General.GameLaunchCount;
            var unlockedIds = App.Services.Settings.Config.General.UnlockedMilestones ?? new List<int>();
            var unlockedDates = App.Services.Settings.Config.General.MilestoneUnlockDates ?? new Dictionary<int, DateTime>();

            return AllMilestones.Select(m => new Milestone
            {
                Id = m.Id,
                LaunchCount = m.LaunchCount,
                Title = m.Title,
                Description = m.Description,
                Icon = m.Icon,
                Reward = m.Reward,
                IsUnlocked = unlockedIds.Contains(m.Id) || launchCount >= m.LaunchCount,
                UnlockedAt = unlockedDates.ContainsKey(m.Id) ? unlockedDates[m.Id] : (launchCount >= m.LaunchCount ? DateTime.Now : null)
            }).ToList();
        }

        /// <summary>
        /// 检查新达成的里程碑
        /// </summary>
        public static List<Milestone> CheckNewMilestones()
        {
            int launchCount = App.Services.Settings.Config.General.GameLaunchCount;
            var unlockedIds = App.Services.Settings.Config.General.UnlockedMilestones ?? new List<int>();
            var newOnes = new List<Milestone>();

            foreach (var m in AllMilestones)
            {
                if (launchCount >= m.LaunchCount && !unlockedIds.Contains(m.Id))
                {
                    unlockedIds.Add(m.Id);
                    if (App.Services.Settings.Config.General.MilestoneUnlockDates == null)
                        App.Services.Settings.Config.General.MilestoneUnlockDates = new Dictionary<int, DateTime>();
                    App.Services.Settings.Config.General.MilestoneUnlockDates[m.Id] = DateTime.Now;
                    newOnes.Add(m);
                }
            }

            App.Services.Settings.Config.General.UnlockedMilestones = unlockedIds;
            App.Services.Settings.Save();

            return newOnes;
        }

        /// <summary>
        /// 获取已解锁里程碑数量
        /// </summary>
        public static int GetUnlockedCount()
        {
            return GetAllMilestones().Count(m => m.IsUnlocked);
        }

        /// <summary>
        /// 获取下一个里程碑
        /// </summary>
        public static Milestone? GetNextMilestone()
        {
            int launchCount = App.Services.Settings.Config.General.GameLaunchCount;
            return AllMilestones.FirstOrDefault(m => m.LaunchCount > launchCount);
        }
    }
}
