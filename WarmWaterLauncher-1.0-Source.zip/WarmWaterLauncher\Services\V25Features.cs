using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace WarmWaterLauncher.Services;

// ==================== 基岩版启动服务 ====================
/// <summary>
/// Minecraft 基岩版（Windows 10/11 版）启动服务
/// </summary>
public class BedrockService
{
    /// <summary>检查基岩版是否已安装</summary>
    public bool IsBedrockInstalled()
    {
        try
        {
            // 方法1：检查应用包
            using var key = Registry.CurrentUser.OpenSubKey(@"Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\Repository\Packages");
            if (key != null)
            {
                foreach (var subKeyName in key.GetSubKeyNames())
                {
                    if (subKeyName.Contains("Microsoft.MinecraftUWP", StringComparison.OrdinalIgnoreCase))
                        return true;
                }
            }

            // 方法2：检查常见安装路径
            string[] paths =
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Packages", "Microsoft.MinecraftUWP_8wekyb3d8bbwe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                    "Minecraft Bedrock Edition"),
            };
            return paths.Any(Directory.Exists);
        }
        catch { return false; }
    }

    /// <summary>获取基岩版安装信息</summary>
    public BedrockInfo? GetBedrockInfo()
    {
        try
        {
            var info = new BedrockInfo();
            info.Installed = IsBedrockInstalled();

            // 尝试获取版本号
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\Repository\Packages");
                if (key != null)
                {
                    foreach (var subKeyName in key.GetSubKeyNames())
                    {
                        if (subKeyName.Contains("Microsoft.MinecraftUWP", StringComparison.OrdinalIgnoreCase))
                        {
                            var parts = subKeyName.Split('_');
                            if (parts.Length >= 2)
                                info.Version = parts[1];
                            break;
                        }
                    }
                }
            }
            catch { }

            // 获取游戏数据目录
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            info.DataDir = Path.Combine(localAppData, "Packages", "Microsoft.MinecraftUWP_8wekyb3d8bbwe", "LocalState", "games", "com.mojang");
            info.SavesDir = Path.Combine(info.DataDir, "minecraftWorlds");
            info.ResourcePacksDir = Path.Combine(info.DataDir, "resource_packs");
            info.BehaviorPacksDir = Path.Combine(info.DataDir, "behavior_packs");

            return info;
        }
        catch { return null; }
    }

    /// <summary>启动基岩版</summary>
    public bool LaunchBedrock()
    {
        try
        {
            // 方法1：通过协议启动
            var psi = new ProcessStartInfo
            {
                FileName = "minecraft://",
                UseShellExecute = true
            };
            Process.Start(psi);
            return true;
        }
        catch
        {
            try
            {
                // 方法2：通过 explorer 启动
                Process.Start("explorer.exe", "shell:appsFolder\\Microsoft.MinecraftUWP_8wekyb3d8bbwe!App");
                return true;
            }
            catch { return false; }
        }
    }

    /// <summary>打开基岩版商店页面</summary>
    public void OpenStorePage()
    {
        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "ms-windows-store://pdp/?ProductId=9NBLGGH2JHXJ",
                UseShellExecute = true
            });
        }
        catch { }
    }

    /// <summary>打开基岩版数据目录</summary>
    public void OpenDataDir()
    {
        var info = GetBedrockInfo();
        if (info != null && Directory.Exists(info.DataDir))
            Process.Start("explorer.exe", info.DataDir);
    }

    /// <summary>打开基岩版存档目录</summary>
    public void OpenSavesDir()
    {
        var info = GetBedrockInfo();
        if (info != null && Directory.Exists(info.SavesDir))
            Process.Start("explorer.exe", info.SavesDir);
    }
}

public class BedrockInfo
{
    public bool Installed { get; set; }
    public string Version { get; set; } = "未知";
    public string DataDir { get; set; } = "";
    public string SavesDir { get; set; } = "";
    public string ResourcePacksDir { get; set; } = "";
    public string BehaviorPacksDir { get; set; } = "";
}

// ==================== 游戏目录清理服务 ====================
public class CleanupService
{
    /// <summary>扫描可清理的文件</summary>
    public CleanupResult Scan()
    {
        var result = new CleanupResult();
        try
        {
            string gameRoot = App.Services.Settings.GameRoot;
            string dataDir = SettingsService.GetDataDir();

            // 1. 旧版本备份（versions 目录中的旧版本）
            // 2. 下载缓存
            string cacheDir = Path.Combine(dataDir, "cache");
            if (Directory.Exists(cacheDir))
            {
                long size = GetDirSize(cacheDir);
                result.Items.Add(new CleanupItem { Name = "下载缓存", Path = cacheDir, Size = size, Type = "cache" });
            }

            // 3. 日志文件
            string logDir = Path.Combine(dataDir, "logs");
            if (Directory.Exists(logDir))
            {
                long size = GetDirSize(logDir);
                result.Items.Add(new CleanupItem { Name = "日志文件", Path = logDir, Size = size, Type = "logs" });
            }

            // 4. 崩溃报告
            string crashDir = Path.Combine(dataDir, "crashes");
            if (Directory.Exists(crashDir))
            {
                long size = GetDirSize(crashDir);
                result.Items.Add(new CleanupItem { Name = "崩溃报告", Path = crashDir, Size = size, Type = "crashes" });
            }

            // 5. 临时文件
            string tempDir = Path.Combine(dataDir, "temp");
            if (Directory.Exists(tempDir))
            {
                long size = GetDirSize(tempDir);
                result.Items.Add(new CleanupItem { Name = "临时文件", Path = tempDir, Size = size, Type = "temp" });
            }

            // 6. 旧的更新包
            string updateDir = Path.Combine(dataDir, "updates");
            if (Directory.Exists(updateDir))
            {
                long size = GetDirSize(updateDir);
                result.Items.Add(new CleanupItem { Name = "旧更新包", Path = updateDir, Size = size, Type = "updates" });
            }

            // 7. 游戏版本中的 natives 临时解压目录
            string versionsDir = Path.Combine(gameRoot, "versions");
            if (Directory.Exists(versionsDir))
            {
                foreach (var dir in Directory.GetDirectories(versionsDir))
                {
                    string nativesDir = Path.Combine(dir, Path.GetFileName(dir) + "-natives");
                    if (Directory.Exists(nativesDir))
                    {
                        long size = GetDirSize(nativesDir);
                        result.Items.Add(new CleanupItem { Name = $"原生库临时文件 ({Path.GetFileName(dir)})", Path = nativesDir, Size = size, Type = "natives" });
                    }
                }
            }

            result.TotalSize = result.Items.Sum(i => i.Size);
        }
        catch { }
        return result;
    }

    /// <summary>清理选中的项目</summary>
    public async Task<(int cleanedCount, long cleanedSize)> CleanAsync(List<CleanupItem> items)
    {
        int count = 0;
        long size = 0;
        await Task.Run(() =>
        {
            foreach (var item in items)
            {
                try
                {
                    if (Directory.Exists(item.Path))
                    {
                        long itemSize = GetDirSize(item.Path);
                        Directory.Delete(item.Path, true);
                        count++;
                        size += itemSize;
                    }
                }
                catch { }
            }
        });
        return (count, size);
    }

    private long GetDirSize(string path)
    {
        try
        {
            return Directory.GetFiles(path, "*", SearchOption.AllDirectories)
                .Sum(f => new FileInfo(f).Length);
        }
        catch { return 0; }
    }
}

public class CleanupResult
{
    public List<CleanupItem> Items { get; set; } = new();
    public long TotalSize { get; set; }
    public string TotalSizeText => TotalSize >= 1024 * 1024 ? $"{TotalSize / 1024.0 / 1024.0:F1} MB" : $"{TotalSize / 1024.0:F0} KB";
}

public class CleanupItem
{
    public string Name { get; set; } = "";
    public string Path { get; set; } = "";
    public long Size { get; set; }
    public string Type { get; set; } = "";
    public bool Selected { get; set; } = true;
    public string SizeText => Size >= 1024 * 1024 ? $"{Size / 1024.0 / 1024.0:F1} MB" : $"{Size / 1024.0:F0} KB";
}

// ==================== 配置导出导入服务 ====================
public class ConfigService
{
    /// <summary>导出启动器配置</summary>
    public bool ExportConfig(string savePath)
    {
        try
        {
            string dataDir = SettingsService.GetDataDir();
            string configFile = Path.Combine(dataDir, "config.json");
            string accountsFile = Path.Combine(dataDir, "accounts.json");

            using var zip = ZipFile.Open(savePath, ZipArchiveMode.Create);
            if (File.Exists(configFile))
                zip.CreateEntryFromFile(configFile, "config.json");
            if (File.Exists(accountsFile))
                zip.CreateEntryFromFile(accountsFile, "accounts.json");

            // 添加导出信息
            var entry = zip.CreateEntry("export_info.json");
            using var writer = new StreamWriter(entry.Open());
            writer.Write(JsonSerializer.Serialize(new
            {
                ExportTime = DateTime.Now,
                Version = "1.0 正式版",
                Launcher = "温水启动器"
            }, SettingsService.JsonOpts));
            return true;
        }
        catch { return false; }
    }

    /// <summary>导入启动器配置</summary>
    public bool ImportConfig(string zipPath)
    {
        try
        {
            string dataDir = SettingsService.GetDataDir();
            Directory.CreateDirectory(dataDir);

            using var zip = ZipFile.OpenRead(zipPath);
            foreach (var entry in zip.Entries)
            {
                if (entry.FullName.EndsWith(".json") && entry.FullName != "export_info.json")
                {
                    string targetPath = Path.Combine(dataDir, entry.FullName);
                    entry.ExtractToFile(targetPath, true);
                }
            }
            return true;
        }
        catch { return false; }
    }
}

// ==================== 实验功能服务 ====================
public class ExperimentalFeatures
{
    public static readonly Dictionary<string, string> Features = new()
    {
        { "bedrock_launch", "基岩版启动（实验性）" },
        { "game_overlay", "游戏内覆盖层（FPS显示）" },
        { "auto_update_mods", "模组自动更新检测" },
        { "global_shortcuts", "全局快捷键" },
        { "window_transparency", "窗口透明度调节" },
        { "startup_sound", "启动音效" },
        { "quick_launch_bar", "快捷启动栏" },
        { "version_favorites", "版本收藏" },
        { "playtime_ranking", "游戏时间排行榜" },
        { "config_sync", "配置云同步（实验性）" }
    };

    public static bool IsEnabled(string featureId)
    {
        try
        {
            var enabled = App.Services.Settings.Config.General.ExperimentalFeatures ?? "";
            return enabled.Split(',', StringSplitOptions.RemoveEmptyEntries).Contains(featureId);
        }
        catch { return false; }
    }

    public static void SetEnabled(string featureId, bool enabled)
    {
        try
        {
            var list = (App.Services.Settings.Config.General.ExperimentalFeatures ?? "")
                .Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
            if (enabled && !list.Contains(featureId))
                list.Add(featureId);
            else if (!enabled)
                list.Remove(featureId);
            App.Services.Settings.Config.General.ExperimentalFeatures = string.Join(",", list);
            App.Services.Settings.Save();
        }
        catch { }
    }
}
