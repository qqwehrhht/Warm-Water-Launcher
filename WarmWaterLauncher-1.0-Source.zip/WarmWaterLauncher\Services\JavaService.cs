using System.Diagnostics;
using System.Text.Json;

namespace WarmWaterLauncher.Services;

public class JavaInfo
{
    public string Path { get; set; } = "";
    public int Major { get; set; }
    public string Version { get; set; } = "";
    public string Name => $"{Path}  (Java {Major})";
}

/// <summary>Java 检测与下载服务</summary>
public class JavaService
{
    private readonly SettingsService _settings;
    private readonly DownloadService _dl;
    public JavaService(SettingsService settings, DownloadService dl)
    {
        _settings = settings;
        _dl = dl;
    }

    /// <summary>自动检测系统 Java</summary>
    public List<JavaInfo> DetectAll()
    {
        var result = new List<JavaInfo>();
        var seen = new HashSet<string>();

        void Add(string path)
        {
            if (string.IsNullOrEmpty(path) || !File.Exists(path)) return;
            var full = Path.GetFullPath(path);
            if (!seen.Add(full)) return;
            var info = GetInfo(full);
            if (info != null) result.Add(info);
        }

        // 1. JAVA_HOME
        try
        {
            var home = Environment.GetEnvironmentVariable("JAVA_HOME");
            if (!string.IsNullOrEmpty(home))
            {
                Add(Path.Combine(home, "bin", "java.exe"));
                Add(Path.Combine(home, "bin", "java"));
            }
        }
        catch { }

        // 2. PATH 中的 java
        try
        {
            var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (var dir in pathEnv.Split(';', StringSplitOptions.RemoveEmptyEntries))
            {
                Add(Path.Combine(dir.Trim('"'), "java.exe"));
                Add(Path.Combine(dir.Trim('"'), "java"));
            }
        }
        catch { }

        // 3. 常见安装目录（Minecraft 自带 JRE / Oracle / Adoptium / Zulu）
        var candidates = new List<string>();
        string[] roots =
        {
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            Path.Combine(_settings.GameRoot, "runtime"),
            @"C:\Program Files (x86)\Minecraft Launcher\runtime",
            @"C:\Program Files\Java",
            @"C:\Program Files\Eclipse Adoptium",
            @"C:\Program Files\Microsoft\jdk"
        };
        foreach (var root in roots)
        {
            if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) continue;
            try
            {
                foreach (var d in Directory.GetDirectories(root))
                {
                    candidates.Add(Path.Combine(d, "bin", "java.exe"));
                    candidates.Add(Path.Combine(d, "bin", "java"));
                    if (d.Contains("runtime"))
                    {
                        foreach (var sub in Directory.GetDirectories(d))
                        {
                            candidates.Add(Path.Combine(sub, "bin", "java.exe"));
                            candidates.Add(Path.Combine(sub, "bin", "java"));
                        }
                    }
                }
            }
            catch { }
        }
        foreach (var c in candidates) Add(c);

        // 4. 启动器已下载的 Java
        var dlDir = Path.Combine(SettingsService.GetDataDir(), "java");
        if (Directory.Exists(dlDir))
        {
            foreach (var sub in Directory.GetDirectories(dlDir))
                Add(Path.Combine(sub, "bin", "java.exe"));
        }

        return result.OrderByDescending(j => j.Major).ToList();
    }

    public JavaInfo? GetInfo(string javaPath)
    {
        try
        {
            var psi = new ProcessStartInfo(javaPath, "-version")
            {
                RedirectStandardError = true,
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using var p = Process.Start(psi);
            if (p == null) return null;
            string output = p.StandardError.ReadToEnd() + p.StandardOutput.ReadToEnd();
            p.WaitForExit(5000);
            var m = System.Text.RegularExpressions.Regex.Match(output, "\"(\\d+)(?:\\.(\\d+))?");
            int major = m.Success ? int.Parse(m.Groups[1].Value) : 0;
            if (major == 1 && m.Groups[2].Success) major = int.Parse(m.Groups[2].Value);
            var verLine = output.Split('\n').FirstOrDefault(l => l.Contains("version"));
            return new JavaInfo { Path = javaPath, Major = major, Version = verLine?.Trim() ?? javaPath };
        }
        catch { return null; }
    }

    /// <summary>根据 Minecraft 版本号返回所需最低 Java 大版本</summary>
    public static int RequiredForMc(string versionId)
    {
        if (string.IsNullOrEmpty(versionId)) return 21;
        // 尝试匹配标准版本号 1.x.x
        var m = System.Text.RegularExpressions.Regex.Match(versionId, @"^(?:1\.)?(\d+)(?:\.(\d+))?");
        if (!m.Success) return 21;
        int minor = int.Parse(m.Groups[1].Value);
        int patch = m.Groups[2].Success ? int.Parse(m.Groups[2].Value) : 0;
        // 根据 Minecraft 版本与 Java 版本对应关系
        // 1.17 → Java 16
        // 1.18-1.20.4 → Java 17
        // 1.20.5-1.20.6 → Java 21
        // 1.21+ → Java 21
        // 1.21.4+ / 1.22+ → Java 23 (预计)
        // 1.26+ / 新版本 → Java 25 (预计)
        if (minor >= 26) return 25;          // 1.26+ / 26.x
        if (minor >= 22) return 23;          // 1.22-1.25
        if (minor > 20 || (minor == 20 && patch >= 5)) return 21; // 1.20.5+ / 1.21+
        if (minor == 18 || minor == 19 || minor == 20) return 17; // 1.18-1.20.4
        if (minor == 17) return 16;                               // 1.17
        return 8;                                                 // ≤1.16
    }

    /// <summary>从多个源下载 Java（Adoptium API / 直接二进制 / 微软 OpenJDK），返回解压后的 java.exe 路径</summary>
    public async Task<string?> DownloadJavaAsync(int major, IProgress<(string, double)>? progress, CancellationToken ct = default)
    {
        string javaDir = Path.Combine(SettingsService.GetDataDir(), "java", "jre" + major);
        string javaExe = Path.Combine(javaDir, "bin", "java.exe");
        if (File.Exists(javaExe)) return javaExe;

        // 第一步：通过 Adoptium API 获取实际下载链接（JSON 很小，访问较快）
        string? officialJreLink = null;
        string? officialJdkLink = null;
        try
        {
            progress?.Report(("正在获取 Java 下载信息...", 0.02));
            // 获取 JRE
            string apiJre = $"https://api.adoptium.net/v3/assets/latest/{major}/hotspot?architecture=x64&image_type=jre&os=windows&vendor=eclipse";
            var jsonJre = await _dl.Http.GetStringAsync(apiJre, ct);
            if (!string.IsNullOrEmpty(jsonJre))
            {
                using var doc = JsonDocument.Parse(jsonJre);
                var arr = doc.RootElement.EnumerateArray().FirstOrDefault();
                if (arr.ValueKind != JsonValueKind.Undefined &&
                    arr.TryGetProperty("binary", out var binary) &&
                    binary.TryGetProperty("package", out var pkg) &&
                    pkg.ValueKind != JsonValueKind.Null)
                {
                    officialJreLink = pkg.TryGetProperty("link", out var lk) ? lk.GetString() : null;
                }
            }
            // 获取 JDK（JRE 不存在时降级）
            string apiJdk = $"https://api.adoptium.net/v3/assets/latest/{major}/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse";
            var jsonJdk = await _dl.Http.GetStringAsync(apiJdk, ct);
            if (!string.IsNullOrEmpty(jsonJdk))
            {
                using var doc = JsonDocument.Parse(jsonJdk);
                var arr = doc.RootElement.EnumerateArray().FirstOrDefault();
                if (arr.ValueKind != JsonValueKind.Undefined &&
                    arr.TryGetProperty("binary", out var binary) &&
                    binary.TryGetProperty("package", out var pkg) &&
                    pkg.ValueKind != JsonValueKind.Null)
                {
                    officialJdkLink = pkg.TryGetProperty("link", out var lk) ? lk.GetString() : null;
                }
            }
        }
        catch { }

        // 第二步：构建所有可用的下载源（国内镜像优先）
        var sources = new List<(string url, string label, bool isJdk)>();

        // 辅助函数：为官方 GitHub 链接生成国内镜像
        void AddGithubMirrors(string? officialUrl, string label, bool isJdk)
        {
            if (string.IsNullOrEmpty(officialUrl)) return;
            // 国内 GitHub 加速镜像（按优先级）
            var mirrors = new[]
            {
                "https://ghproxy.com/",
                "https://mirror.ghproxy.com/",
                "https://gh.api.99988866.xyz/",
                "https://ghps.cc/",
                "https://gh.con.sh/"
            };
            foreach (var m in mirrors)
                sources.Add((m + officialUrl, label + "（" + m.Replace("https://", "").TrimEnd('/') + "）", isJdk));
            // 官方源放最后
            sources.Add((officialUrl, label + "（官方）", isJdk));
        }

        // JRE 优先
        AddGithubMirrors(officialJreLink, "Adoptium JRE", false);
        // JDK 降级
        AddGithubMirrors(officialJdkLink, "Adoptium JDK", true);

        // 微软 OpenJDK（仅支持 11/17/21，国内访问较快）
        if (major == 11 || major == 17 || major == 21)
            sources.Add(($"https://aka.ms/download-jdk/microsoft-jdk-{major}-windows-x64.zip", "微软 OpenJDK", true));

        // Azul Zulu（备用，CDN 国内可访问）
        sources.Add(($"https://cdn.azul.com/zulu/bin/zulu{major}.0.0-ca-jre{major}.0.0-win_x64.zip", "Azul Zulu JRE", false));

        // Adoptium 直接 API（302 重定向，最后备用）
        sources.Add(($"https://api.adoptium.net/v3/binary/latest/{major}/ga/windows/x64/jre/hotspot/normal/eclipse", "Adoptium API JRE", false));
        sources.Add(($"https://api.adoptium.net/v3/binary/latest/{major}/ga/windows/x64/jdk/hotspot/normal/eclipse", "Adoptium API JDK", true));

        if (sources.Count == 0)
        {
            progress?.Report(("没有可用的 Java 下载源", 1));
            return null;
        }

        // 第三步：逐个尝试下载源
        string tmp = Path.Combine(Path.GetTempPath(), "ww_java_" + major + ".zip");
        bool downloaded = false;
        string usedSource = "";
        bool isJdkDownload = true;

        for (int i = 0; i < sources.Count; i++)
        {
            var (url, label, isJdk) = sources[i];
            usedSource = label;
            isJdkDownload = isJdk;
            progress?.Report(($"正在从 {label} 下载 Java {major}（{i + 1}/{sources.Count}）...", 0.05 + (double)i / sources.Count * 0.3));

            try
            {
                if (File.Exists(tmp)) try { File.Delete(tmp); } catch { }
                bool ok = await _dl.DownloadFileAsync(url, tmp, null, ct);
                if (ok && File.Exists(tmp) && new FileInfo(tmp).Length > 10 * 1024 * 1024) // >10MB 才算成功
                {
                    downloaded = true;
                    break;
                }
            }
            catch { }
        }

        if (!downloaded)
        {
            progress?.Report(($"Java {major} 下载失败，所有源均不可用。请检查网络或手动下载 Java 后在设置中指定路径。", 1));
            return null;
        }

        progress?.Report(($"正在解压 Java（{usedSource}）...", 0.6));
        try
        {
            string extractDir = Path.Combine(Path.GetTempPath(), "ww_java_extract_" + major);
            if (Directory.Exists(extractDir)) Directory.Delete(extractDir, true);
            Directory.CreateDirectory(extractDir);
            System.IO.Compression.ZipFile.ExtractToDirectory(tmp, extractDir);
            // 找到包含 bin/java.exe 的目录
            string? foundDir = null;
            foreach (var dir in Directory.GetDirectories(extractDir, "*", SearchOption.AllDirectories))
            {
                if (File.Exists(Path.Combine(dir, "bin", "java.exe")))
                {
                    foundDir = dir;
                    break;
                }
            }
            if (foundDir == null && File.Exists(Path.Combine(extractDir, "bin", "java.exe")))
                foundDir = extractDir;

            if (foundDir == null)
            {
                progress?.Report(("Java 解压失败：未找到 java.exe", 1));
                return null;
            }

            // 复制到目标目录
            if (Directory.Exists(javaDir)) Directory.Delete(javaDir, true);
            Directory.CreateDirectory(Directory.GetParent(javaDir)!.FullName);
            CopyDirectory(foundDir, javaDir);

            // 清理临时文件
            try { Directory.Delete(extractDir, true); } catch { }
            try { File.Delete(tmp); } catch { }

            progress?.Report(($"Java {major} 安装完成（{(isJdkDownload ? "JDK" : "JRE")}）", 1));
            return javaExe;
        }
        catch (Exception ex)
        {
            progress?.Report(($"Java 解压失败：{ex.Message}", 1));
            return null;
        }
    }

    private static void CopyDirectory(string src, string dst)
    {
        Directory.CreateDirectory(dst);
        foreach (var file in Directory.GetFiles(src))
            File.Copy(file, Path.Combine(dst, Path.GetFileName(file)), true);
        foreach (var dir in Directory.GetDirectories(src))
            CopyDirectory(dir, Path.Combine(dst, Path.GetFileName(dir)));
    }
}
