using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class CrashDialog : Window
{
    private readonly CrashAnalysis _crash;

    public CrashDialog(CrashAnalysis crash)
    {
        InitializeComponent();
        _crash = crash;
        LoadCrashInfo();
    }

    private void LoadCrashInfo()
    {
        try
        {
            // 崩溃类型
            CrashTypeText.Text = GetCrashTypeName(_crash.CrashType);

            // 崩溃原因
            CauseText.Text = string.IsNullOrEmpty(_crash.Cause) ? "未知原因" : _crash.Cause;
            if (CauseText.Text.Length > 300)
                CauseText.Text = CauseText.Text.Substring(0, 300) + "...";

            // 版本信息
            VersionText.Text = string.IsNullOrEmpty(_crash.GameVersion) ? "-" : _crash.GameVersion;
            LoaderText.Text = string.IsNullOrEmpty(_crash.LoaderVersion) ? "-" : _crash.LoaderVersion;
            JavaText.Text = string.IsNullOrEmpty(_crash.JavaVersion) ? "-" : _crash.JavaVersion;

            // 可疑模组
            if (_crash.SuspiciousMods != null && _crash.SuspiciousMods.Count > 0)
            {
                SuspectModsPanel.Visibility = Visibility.Visible;
                SuspectModsText.Text = string.Join(", ", _crash.SuspiciousMods.Take(10));
            }

            // 解决方案
            bool hasAdvice = !string.IsNullOrEmpty(_crash.Advice) &&
                             _crash.CrashType != CrashType.Unknown &&
                             !_crash.Advice.Contains("未找到崩溃日志");

            if (hasAdvice)
            {
                AdviceText.Text = _crash.Advice;
            }
            else
            {
                // 没有解决方案，显示崩溃日志关键行
                AdviceBorder.Visibility = Visibility.Collapsed;
                LogBorder.Visibility = Visibility.Visible;
                LogText.Text = ExtractKeyLogLines(_crash.Text);
            }
        }
        catch (Exception ex)
        {
            CauseText.Text = "解析崩溃信息时出错: " + ex.Message;
        }
    }

    /// <summary>从崩溃日志中提取关键行（异常、错误、Caused by等）</summary>
    private static string ExtractKeyLogLines(string crashText)
    {
        if (string.IsNullOrEmpty(crashText)) return "（无崩溃日志）";

        var lines = crashText.Split('\n');
        var keyLines = lines.Where(l =>
        {
            var lower = l.ToLowerInvariant();
            return lower.Contains("exception") ||
                   lower.Contains("error") ||
                   lower.Contains("caused by") ||
                   lower.Contains("fatal") ||
                   lower.Contains("crash") ||
                   lower.Contains("unsupportedclassversion") ||
                   lower.Contains("outofmemory") ||
                   lower.Contains("noclassdeffound") ||
                   lower.Contains("classnotfound") ||
                   lower.Contains("zip exception") ||
                   lower.Contains("could not") ||
                   lower.Contains("failed") ||
                   lower.Contains("at net.minecraft") ||
                   lower.Contains("at com.mojang") ||
                   (lower.Contains("at ") && lower.Contains(".jar"));
        }).Take(30).ToList();

        if (keyLines.Count == 0)
        {
            // 如果没有匹配到关键行，显示最后20行
            keyLines = lines.Skip(Math.Max(0, lines.Length - 20)).Take(20).ToList();
        }

        return string.Join("\n", keyLines.Select(l => l.TrimEnd()));
    }

    private static string GetCrashTypeName(CrashType type)
    {
        return type switch
        {
            CrashType.OutOfMemory => "内存不足",
            CrashType.JavaVersionMismatch => "Java 版本不匹配",
            CrashType.GraphicsIssue => "显卡/渲染问题",
            CrashType.ModConflict => "模组冲突",
            CrashType.ModCrash => "模组崩溃",
            CrashType.CorruptedFiles => "文件损坏",
            CrashType.LoaderIssue => "加载器问题",
            CrashType.OptiFineConflict => "OptiFine 冲突",
            CrashType.JvmCrash => "JVM 致命错误",
            _ => "未知崩溃类型"
        };
    }

    private void CopyLog_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string log = _crash.Text;
            if (string.IsNullOrEmpty(log)) log = "（无崩溃日志）";
            Clipboard.SetText(log);
            MessageBox.Show("崩溃日志已复制到剪贴板", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("复制失败: " + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Close_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}
