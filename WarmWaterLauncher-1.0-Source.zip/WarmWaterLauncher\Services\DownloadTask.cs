using System;
using System.ComponentModel;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace WarmWaterLauncher.Services;

/// <summary>下载状态</summary>
public enum DownloadStatus
{
    Waiting,      // 等待中
    Downloading,  // 下载中
    Paused,       // 已暂停
    Completed,    // 已完成
    Failed,       // 失败
    Canceled      // 已取消
}

/// <summary>单个下载任务</summary>
public class DownloadTask : INotifyPropertyChanged
{
    public string Id { get; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "";
    public string Url { get; set; } = "";
    public string SavePath { get; set; } = "";
    public string? ExpectedSha1 { get; set; }

    private long _totalBytes;
    public long TotalBytes
    {
        get => _totalBytes;
        set { _totalBytes = value; OnPropertyChanged(nameof(TotalBytes)); OnPropertyChanged(nameof(TotalSizeText)); OnPropertyChanged(nameof(Progress)); }
    }

    private long _downloadedBytes;
    public long DownloadedBytes
    {
        get => _downloadedBytes;
        set { _downloadedBytes = value; OnPropertyChanged(nameof(DownloadedBytes)); OnPropertyChanged(nameof(DownloadedSizeText)); OnPropertyChanged(nameof(Progress)); OnPropertyChanged(nameof(SpeedText)); }
    }

    private DownloadStatus _status = DownloadStatus.Waiting;
    public DownloadStatus Status
    {
        get => _status;
        set { _status = value; OnPropertyChanged(nameof(Status)); OnPropertyChanged(nameof(StatusText)); OnPropertyChanged(nameof(IsDownloading)); OnPropertyChanged(nameof(IsWaiting)); OnPropertyChanged(nameof(IsActive)); OnPropertyChanged(nameof(IsCompleted)); OnPropertyChanged(nameof(IsFailed)); }
    }

    private string? _errorMessage;
    public string? ErrorMessage
    {
        get => _errorMessage;
        set { _errorMessage = value; OnPropertyChanged(nameof(ErrorMessage)); }
    }

    public DateTime StartTime { get; private set; }
    public DateTime? EndTime { get; private set; }

    private CancellationTokenSource? _cts;
    private readonly HttpClient _http;

    public event PropertyChangedEventHandler? PropertyChanged;
    public event EventHandler? Completed;
    public event EventHandler? Failed;

    public DownloadTask(string name, string url, string savePath, string? expectedSha1 = null)
    {
        Name = name;
        Url = url;
        SavePath = savePath;
        ExpectedSha1 = expectedSha1;
        _http = new HttpClient { Timeout = TimeSpan.FromMinutes(30) };
    }

    // ===== 计算属性 =====
    private double _manualProgress = -1; // -1表示自动计算，>=0表示手动设置

    public double Progress
    {
        get
        {
            if (_manualProgress >= 0)
                return Math.Min(100, Math.Max(0, _manualProgress));
            if (TotalBytes <= 0)
            {
                // 没有Content-Length时，用已下载字节数估算进度（至少显示一些进度）
                if (DownloadedBytes > 0)
                {
                    // 估算：假设文件大小至少是已下载的1.5倍，给一个递增的进度
                    double estimated = Math.Min(95, (double)DownloadedBytes / (DownloadedBytes * 1.5 + 1024 * 1024) * 100);
                    return Math.Max(1, estimated); // 至少显示1%
                }
                return 0;
            }
            double pct = (double)DownloadedBytes / TotalBytes * 100;
            return Math.Min(100, Math.Max(0, pct));
        }
    }

    /// <summary>手动设置进度（0-100），用于虚拟任务</summary>
    public void SetManualProgress(double pct)
    {
        _manualProgress = pct;
        OnPropertyChanged(nameof(Progress));
    }
    public bool IsDownloading => Status == DownloadStatus.Downloading;
    public bool IsWaiting => Status == DownloadStatus.Waiting;
    public bool IsActive => Status == DownloadStatus.Downloading || Status == DownloadStatus.Waiting;
    public bool IsCompleted => Status == DownloadStatus.Completed;
    public bool IsFailed => Status == DownloadStatus.Failed || Status == DownloadStatus.Canceled;

    public string StatusText => Status switch
    {
        DownloadStatus.Waiting => "等待中",
        DownloadStatus.Downloading => "下载中",
        DownloadStatus.Paused => "已暂停",
        DownloadStatus.Completed => "已完成",
        DownloadStatus.Failed => "失败",
        DownloadStatus.Canceled => "已取消",
        _ => Status.ToString()
    };

    public string TotalSizeText => FormatSize(TotalBytes);
    public string DownloadedSizeText => FormatSize(DownloadedBytes);

    private long _lastSampleBytes;
    private DateTime _lastSampleTime = DateTime.Now;
    private double _currentSpeed;

    public string SpeedText
    {
        get
        {
            if (Status != DownloadStatus.Downloading) return "";
            return FormatSize((long)_currentSpeed) + "/s";
        }
    }

    public string RemainingTimeText
    {
        get
        {
            if (Status != DownloadStatus.Downloading || _currentSpeed <= 0) return "";
            long remaining = TotalBytes - DownloadedBytes;
            double seconds = remaining / _currentSpeed;
            if (seconds > 3600) return $"{(int)(seconds / 3600)}时{(int)(seconds % 3600 / 60)}分";
            if (seconds > 60) return $"{(int)(seconds / 60)}分{(int)(seconds % 60)}秒";
            return $"{(int)seconds}秒";
        }
    }

    // ===== 方法 =====
    public async Task StartAsync()
    {
        if (Status == DownloadStatus.Downloading) return;
        _cts = new CancellationTokenSource();
        Status = DownloadStatus.Downloading;
        StartTime = DateTime.Now;
        _lastSampleBytes = 0;
        _lastSampleTime = DateTime.Now;

        try
        {
            // 确保目录存在
            string? dir = Path.GetDirectoryName(SavePath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            // 最多重试3次
            int maxRetries = 3;
            for (int retry = 0; retry < maxRetries; retry++)
            {
                try
                {
                    using var response = await _http.GetAsync(Url, HttpCompletionOption.ResponseHeadersRead, _cts.Token);
                    response.EnsureSuccessStatusCode();
                    var contentLength = response.Content.Headers.ContentLength;
                    if (contentLength.HasValue && contentLength.Value > 0)
                        TotalBytes = contentLength.Value;

                    using var contentStream = await response.Content.ReadAsStreamAsync(_cts.Token);
                    using var fileStream = new FileStream(SavePath, FileMode.Create, FileAccess.Write, FileShare.None, 1048576); // 1MB缓冲区

                    var buffer = new byte[262144]; // 256KB缓冲区
                    int bytesRead;
                    while ((bytesRead = await contentStream.ReadAsync(buffer, _cts.Token)) > 0)
                    {
                        await fileStream.WriteAsync(buffer.AsMemory(0, bytesRead), _cts.Token);
                        DownloadedBytes += bytesRead;

                        // 如果没有Content-Length，不更新TotalBytes，Progress属性会用估算方式显示进度

                        // 计算速度（每秒采样一次）
                        var now = DateTime.Now;
                        if ((now - _lastSampleTime).TotalSeconds >= 1)
                        {
                            _currentSpeed = (DownloadedBytes - _lastSampleBytes) / (now - _lastSampleTime).TotalSeconds;
                            _lastSampleBytes = DownloadedBytes;
                            _lastSampleTime = now;
                            OnPropertyChanged(nameof(SpeedText));
                            OnPropertyChanged(nameof(RemainingTimeText));
                        }
                    }
                    break; // 下载成功，跳出重试循环
                }
                catch (Exception ex) when (retry < maxRetries - 1)
                {
                    // 下载失败，等待后重试
                    ErrorMessage = $"下载中断，正在重试（{retry + 1}/{maxRetries}）...";
                    OnPropertyChanged(nameof(ErrorMessage));
                    try { if (File.Exists(SavePath)) File.Delete(SavePath); } catch { }
                    DownloadedBytes = 0;
                    await Task.Delay(2000 * (retry + 1)); // 递增等待时间
                }
            }

            EndTime = DateTime.Now;

            // 校验SHA1
            if (!string.IsNullOrEmpty(ExpectedSha1))
            {
                string actualSha1 = ComputeSha1(SavePath);
                if (!string.Equals(actualSha1, ExpectedSha1, StringComparison.OrdinalIgnoreCase))
                {
                    Status = DownloadStatus.Failed;
                    ErrorMessage = $"文件校验失败（期望 {ExpectedSha1}，实际 {actualSha1}）";
                    Failed?.Invoke(this, EventArgs.Empty);
                    return;
                }
            }

            Status = DownloadStatus.Completed;
            Completed?.Invoke(this, EventArgs.Empty);
        }
        catch (OperationCanceledException)
        {
            Status = DownloadStatus.Canceled;
            try { if (File.Exists(SavePath)) File.Delete(SavePath); } catch { }
        }
        catch (Exception ex)
        {
            Status = DownloadStatus.Failed;
            ErrorMessage = ex.Message;
            Failed?.Invoke(this, EventArgs.Empty);
        }
    }

    public void Cancel()
    {
        _cts?.Cancel();
    }

    public void OpenFolder()
    {
        try
        {
            string? dir = Path.GetDirectoryName(SavePath);
            if (!string.IsNullOrEmpty(dir) && Directory.Exists(dir))
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = false });
        }
        catch { }
    }

    public void OpenFile()
    {
        try
        {
            if (File.Exists(SavePath))
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(SavePath) { UseShellExecute = true });
        }
        catch { }
    }

    private static string FormatSize(long bytes)
    {
        if (bytes >= 1073741824) return $"{bytes / 1073741824.0:F2} GB";
        if (bytes >= 1048576) return $"{bytes / 1048576.0:F2} MB";
        if (bytes >= 1024) return $"{bytes / 1024.0:F1} KB";
        return $"{bytes} B";
    }

    private static string ComputeSha1(string path)
    {
        using var sha1 = System.Security.Cryptography.SHA1.Create();
        using var stream = File.OpenRead(path);
        byte[] hash = sha1.ComputeHash(stream);
        return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
    }

    protected void OnPropertyChanged(string name) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
