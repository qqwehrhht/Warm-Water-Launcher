using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using WarmWaterLauncher.Services;
namespace WarmWaterLauncher.Pages;
public partial class PageSettings : UserControl, IActivatePage
{
    private bool _loading;
    private string _currentPanel = "general";
    private DispatcherTimer? _perfTimer;

    public PageSettings()
    {
        InitializeComponent();
    }

    public void OnActivate()
    {
        _loading = true;
        var s = App.Services.Settings.Config;

        // ===== 通用 =====
        GameRootText.Text = App.Services.Settings.GameRoot;
        PortableBox.IsChecked = s.General.Portable;
        LaunchAnimBox.IsChecked = s.General.EnableLaunchAnimation;
        CurrentVersionText.Text = $"当前版本 v{App.Services.Updater.CurrentVersion}";
        foreach (var item in LaunchAnimTypeCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == s.General.LaunchAnimationType)
                LaunchAnimTypeCombo.SelectedItem = ci;
        MinimizeOnLaunchBox.IsChecked = s.General.MinimizeOnLaunch;
        AutoLogsBox.IsChecked = s.General.AutoSwitchToLogsOnGameWindow;
        MinimizeToTrayBox.IsChecked = s.General.MinimizeToTray;
        foreach (var item in LangCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == s.General.Language)
                LangCombo.SelectedItem = item;

        // 主题模式
        ThemeDarkBtn.BorderBrush = s.General.Theme == "light" ? Brushes.Transparent : (Brush)FindResource("AccentBrush");
        ThemeLightBtn.BorderBrush = s.General.Theme == "light" ? (Brush)FindResource("AccentBrush") : Brushes.Transparent;

        // ===== 1.0 正式版 新功能 =====
        foreach (var item in GamePresetCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == s.General.GamePreset)
                GamePresetCombo.SelectedItem = ci;
        LaunchCountdownBox.Text = s.General.LaunchCountdown.ToString();
        EyeCareBox.IsChecked = s.General.EyeCareMode;
        StartupSoundBox.IsChecked = s.General.EnableStartupSound;
        BedrockPathBox.Text = s.General.BedrockPath ?? "";
        // 1.0 正式版 新功能加载
        try
        {
            var sf = App.Services.FeaturesV1.SmallFeatures;
            var ov = App.Services.FeaturesV1.LoadOverlayConfig();
            var pc = App.Services.FeaturesV1.LoadPreloadConfig();
            var pv = App.Services.FeaturesV1.LoadPrivacyConfig();
            OverlayBox.IsChecked = ov.Enabled;
            PreloadBox.IsChecked = pc.Enabled;
            PasswordLockBox.IsChecked = pv.PasswordLockEnabled;
            PrivacyModeBox.IsChecked = pv.PrivacyMode;
            AcrylicBox.IsChecked = sf.EnableAcrylicEffect;
            CompactModeBox.IsChecked = sf.CompactMode;
            LargeIconsBox.IsChecked = sf.LargeIcons;
            AutoRetryBox.IsChecked = sf.AutoRetryOnFail;
            VerifyAfterBox.IsChecked = sf.VerifyAfterDownload;
            NotifyCompleteBox.IsChecked = sf.NotificationOnComplete;
            AutoJavaSelectBox.IsChecked = sf.AutoSelectJava;
            WarnLowMemBox.IsChecked = sf.WarnOnLowMemory;
            ShowLaunchTimerBox.IsChecked = sf.ShowLaunchTimer;
            AutoModUpdateBox.IsChecked = sf.AutoCheckModUpdates;
            ModConflictWarnBox.IsChecked = sf.WarnOnModConflict;
            BackupModChangeBox.IsChecked = sf.BackupBeforeModChange;
            AutoUpdateBox.IsChecked = sf.AutoCheckUpdates;
            AutoCleanTempBox.IsChecked = sf.AutoCleanTemp;
            ConfirmDeleteBox.IsChecked = sf.ConfirmOnDelete;
            HotkeysBox.IsChecked = sf.EnableHotkeys;
            DevModeBox.IsChecked = sf.DeveloperMode;
        }
        catch { }

        // ===== 启动 =====
        foreach (var item in MaxMemCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == s.Launch.MaxMemory.ToString())
                MaxMemCombo.SelectedItem = item;
        MinMemBox.Text = s.Launch.MinMemory.ToString();
        JvmArgsBox.Text = s.Launch.JvmArgs;
        GameArgsBox.Text = s.Launch.GameArgs;
        WinWidthBox.Text = s.Launch.WinWidth.ToString();
        WinHeightBox.Text = s.Launch.WinHeight.ToString();
        FullscreenBox.IsChecked = s.Launch.Fullscreen;
        DirectBox.Text = s.Launch.DirectConnect ?? "";
        foreach (var item in IsolationCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == s.Launch.IsolationMode)
                IsolationCombo.SelectedItem = item;
        UpdateMemBar();

        // ===== 下载 =====
        foreach (var item in DownloadSourceCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == s.Download.Source)
                DownloadSourceCombo.SelectedItem = item;
        ThreadsSlider.Value = s.Download.Threads;
        ThreadsText.Text = $" {s.Download.Threads} 线程";
        MultiPartBox.IsChecked = s.Download.EnableMultiPart;
        PartSizeBox.Text = s.Download.PartSizeMB.ToString();
        TimeoutBox.Text = s.Download.TimeoutSeconds.ToString();
        RetryBox.Text = s.Download.RetryCount.ToString();
        SpeedLimitBox.Text = s.Download.SpeedLimitKBps.ToString();
        VerifyHashBox.IsChecked = s.Download.VerifyHash;
        AutoJavaBox.IsChecked = s.Download.AutoDownloadJava;
        ModrinthApiBox.Text = s.Download.ModrinthApi;
        CurseForgeKeyBox.Text = s.Download.CurseForgeApiKey;

        // ===== 外观 =====
        CurrentThemeText.Text = $"当前：{s.General.Theme}";
        BgOpacitySlider.Value = s.General.BackgroundOpacity;
        BgOpacityText.Text = $"{s.General.BackgroundOpacity}%";
        SoundBox.IsChecked = s.General.EnableSound;
        var hidden = (s.General.HiddenModules ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries);
        HideMods.IsChecked = hidden.Contains("mods");
        HideResources.IsChecked = hidden.Contains("resource");
        HideJava.IsChecked = hidden.Contains("java");
        HideLogs.IsChecked = hidden.Contains("logs");
        HideDownload.IsChecked = hidden.Contains("download");

        // ===== 高级 =====
        foreach (var item in GcCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == s.Advanced.GcType)
                GcCombo.SelectedItem = item;
        MetaspaceBox.Text = s.Advanced.MetaspaceSize.ToString();
        LargePagesBox.IsChecked = s.Advanced.UseLargePages;
        CompressedOopsBox.IsChecked = s.Advanced.UseCompressedOops;
        CheckJavaBox.IsChecked = s.Advanced.CheckJavaVersion;
        CheckIntegrityBox.IsChecked = s.Advanced.CheckFileIntegrity;
        LowMemBox.Text = s.Advanced.LowMemoryWarningMB.ToString();
        foreach (var item in ProxyTypeCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == s.Advanced.ProxyType)
                ProxyTypeCombo.SelectedItem = item;
        ProxyAddressBox.Text = s.Advanced.ProxyAddress ?? "";
        foreach (var item in LogLevelCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == s.Advanced.LogLevel)
                LogLevelCombo.SelectedItem = item;
        DebugModeBox.IsChecked = s.Advanced.DebugMode;
        CurseForgeApiKeyBox.Password = s.Advanced.CurseForgeApiKey ?? "";

        // ===== 关于 =====
        VersionText.Text = " v1.0.0";
        SysInfoText.Text = $"操作系统：{Environment.OSVersion}\n" +
                           $"运行时：.NET {Environment.Version}\n" +
                           $"处理器：{Environment.ProcessorCount} 核\n" +
                           $"物理内存：{GetTotalMemoryGB()} GB\n" +
                           $"数据目录：{Services.SettingsService.GetDataDir()}";

        _loading = false;
        SwitchPanel("general");
        StartPerfMonitor();
    }

    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    private struct MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    [System.Runtime.InteropServices.DllImport("kernel32.dll")]
    private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);

    private static string GetTotalMemoryGB()
    {
        try
        {
            var mem = new MEMORYSTATUSEX { dwLength = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(MEMORYSTATUSEX)) };
            if (GlobalMemoryStatusEx(ref mem))
                return (mem.ullTotalPhys / 1024.0 / 1024 / 1024).ToString("0.0");
        }
        catch { }
        return "—";
    }

    private void StartPerfMonitor()
    {
        if (_perfTimer != null) return;
        _perfTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _perfTimer.Tick += (_, _) =>
        {
            try
            {
                var proc = System.Diagnostics.Process.GetCurrentProcess();
                PerfText.Text = $"内存 {proc.WorkingSet64 / 1024 / 1024} MB";
                PerfText2.Text = $"CPU {proc.TotalProcessorTime.TotalSeconds:0.0}s · 线程 {proc.Threads.Count}";
            }
            catch { }
        };
        _perfTimer.Start();
    }

    private void SwitchPanel(string tag)
    {
        _currentPanel = tag;
        PanelGeneral.Visibility = tag == "general" ? Visibility.Visible : Visibility.Collapsed;
        PanelLaunch.Visibility = tag == "launch" ? Visibility.Visible : Visibility.Collapsed;
        PanelDownload.Visibility = tag == "download" ? Visibility.Visible : Visibility.Collapsed;
        PanelAppearance.Visibility = tag == "appearance" ? Visibility.Visible : Visibility.Collapsed;
        PanelAdvanced.Visibility = tag == "advanced" ? Visibility.Visible : Visibility.Collapsed;
        PanelAbout.Visibility = tag == "about" ? Visibility.Visible : Visibility.Collapsed;
        if (tag == "about") LoadStats();

        // 更新导航按钮选中态
        foreach (var btn in new[] { NavGeneral, NavLaunch, NavDownload, NavAppearance, NavAdvanced, NavAbout })
        {
            btn.Style = (string)btn.Tag == tag ? (Style)FindResource("NavBtnActive") : (Style)FindResource("NavBtn");
        }
        ContentScroll.ScrollToTop();
    }

    private void Nav_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button btn && btn.Tag is string tag)
            SwitchPanel(tag);
    }

    private void UpdateMemBar()
    {
        if (MaxMemCombo.SelectedItem is ComboBoxItem ci && int.TryParse(ci.Tag?.ToString(), out var maxMem))
        {
            var totalMem = GetTotalMemoryGB();
            if (double.TryParse(totalMem, out var totalGB))
            {
                var pct = Math.Min(100, (maxMem / 1024.0 / totalGB) * 100);
                MemBar.Width = pct * 4.5; // 最大宽度约450
                MemBarText.Text = $"{maxMem} MB / {totalGB * 1024:0} MB 物理内存";
            }
        }
    }

    // ===== 保存：通用 =====
    private void SaveGeneral_Click(object sender, RoutedEventArgs e)
    {
        var s = App.Services.Settings.Config;
        s.General.Portable = PortableBox.IsChecked == true;
        s.General.EnableLaunchAnimation = LaunchAnimBox.IsChecked == true;
        if (LaunchAnimTypeCombo.SelectedItem is ComboBoxItem animType)
            s.General.LaunchAnimationType = animType.Tag?.ToString() ?? "default";
        s.General.MinimizeOnLaunch = MinimizeOnLaunchBox.IsChecked == true;
        s.General.AutoSwitchToLogsOnGameWindow = AutoLogsBox.IsChecked == true;
        s.General.MinimizeToTray = MinimizeToTrayBox.IsChecked == true;
        if (LangCombo.SelectedItem is ComboBoxItem lang)
        {
            s.General.Language = lang.Tag?.ToString() ?? "zh-CN";
            Services.Lang.Set(s.General.Language);
            if (App.MainWin is MainWindow mw) mw.ApplyLanguage();
        }
        // 1.0 正式版 新功能
        if (GamePresetCombo.SelectedItem is ComboBoxItem preset)
            s.General.GamePreset = preset.Tag?.ToString() ?? "balanced";
        if (int.TryParse(LaunchCountdownBox.Text, out var cd))
            s.General.LaunchCountdown = Math.Max(0, Math.Min(30, cd));
        s.General.EyeCareMode = EyeCareBox.IsChecked == true;
        s.General.EnableStartupSound = StartupSoundBox.IsChecked == true;
        s.General.BedrockPath = BedrockPathBox.Text;
        // 1.0 正式版 新功能保存
        try
        {
            var sf = App.Services.FeaturesV1.SmallFeatures;
            var ov = App.Services.FeaturesV1.LoadOverlayConfig();
            var pc = App.Services.FeaturesV1.LoadPreloadConfig();
            var pv = App.Services.FeaturesV1.LoadPrivacyConfig();
            ov.Enabled = OverlayBox.IsChecked == true;
            App.Services.FeaturesV1.SaveOverlayConfig(ov);
            pc.Enabled = PreloadBox.IsChecked == true;
            App.Services.FeaturesV1.SavePreloadConfig(pc);
            pv.PasswordLockEnabled = PasswordLockBox.IsChecked == true;
            pv.PrivacyMode = PrivacyModeBox.IsChecked == true;
            App.Services.FeaturesV1.SavePrivacyConfig(pv);
            sf.EnableAcrylicEffect = AcrylicBox.IsChecked == true;
            sf.CompactMode = CompactModeBox.IsChecked == true;
            sf.LargeIcons = LargeIconsBox.IsChecked == true;
            sf.AutoRetryOnFail = AutoRetryBox.IsChecked == true;
            sf.VerifyAfterDownload = VerifyAfterBox.IsChecked == true;
            sf.NotificationOnComplete = NotifyCompleteBox.IsChecked == true;
            sf.AutoSelectJava = AutoJavaSelectBox.IsChecked == true;
            sf.WarnOnLowMemory = WarnLowMemBox.IsChecked == true;
            sf.ShowLaunchTimer = ShowLaunchTimerBox.IsChecked == true;
            sf.AutoCheckModUpdates = AutoModUpdateBox.IsChecked == true;
            sf.WarnOnModConflict = ModConflictWarnBox.IsChecked == true;
            sf.BackupBeforeModChange = BackupModChangeBox.IsChecked == true;
            sf.AutoCheckUpdates = AutoUpdateBox.IsChecked == true;
            sf.AutoCleanTemp = AutoCleanTempBox.IsChecked == true;
            sf.ConfirmOnDelete = ConfirmDeleteBox.IsChecked == true;
            sf.EnableHotkeys = HotkeysBox.IsChecked == true;
            sf.DeveloperMode = DevModeBox.IsChecked == true;
            App.Services.FeaturesV1.SaveSmallFeatures();
        }
        catch { }
        // 应用护眼模式
        if (App.MainWin is MainWindow mw2) mw2.SetEyeCareMode(s.General.EyeCareMode);
        App.Services.Settings.Save();
        GeneralSaveStatus.Text = "通用设置已保存。";
    }

    // ===== 1.0 正式版 新功能方法 =====
    private void BrowseBedrock_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "可执行文件 (*.exe)|*.exe|所有文件 (*.*)|*.*",
            Title = "选择 Minecraft 基岩版 exe"
        };
        if (dlg.ShowDialog() == true)
            BedrockPathBox.Text = dlg.FileName;
    }

    private void ExportConfig_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.SaveFileDialog
        {
            Filter = "压缩包 (*.zip)|*.zip",
            FileName = $"温水启动器配置备份_{DateTime.Now:yyyyMMdd_HHmmss}.zip",
            Title = "导出配置"
        };
        if (dlg.ShowDialog() == true)
        {
            bool ok = App.Services.Backup.ExportConfig(dlg.FileName);
            BackupStatus.Text = ok ? $"配置已导出到：{dlg.FileName}" : "导出失败，请检查权限。";
        }
    }

    private void ImportConfig_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "压缩包 (*.zip)|*.zip",
            Title = "导入配置"
        };
        if (dlg.ShowDialog() == true)
        {
            var r = MessageBox.Show("导入配置将覆盖当前配置，确定继续吗？", "导入配置", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r != MessageBoxResult.Yes) return;
            bool ok = App.Services.Backup.ImportConfig(dlg.FileName);
            BackupStatus.Text = ok ? "配置已导入，重启启动器后生效。" : "导入失败，请检查文件格式。";
        }
    }

    // ===== 保存：启动 =====
    private void SaveLaunch_Click(object sender, RoutedEventArgs e)
    {
        var s = App.Services.Settings.Config;
        if (MaxMemCombo.SelectedItem is ComboBoxItem max && int.TryParse(max.Tag?.ToString(), out var maxMem))
            s.Launch.MaxMemory = maxMem;
        if (int.TryParse(MinMemBox.Text, out var minMem))
            s.Launch.MinMemory = minMem;
        s.Launch.JvmArgs = JvmArgsBox.Text;
        s.Launch.GameArgs = GameArgsBox.Text;
        if (int.TryParse(WinWidthBox.Text, out var ww) && int.TryParse(WinHeightBox.Text, out var wh))
        {
            s.Launch.WinWidth = ww; s.Launch.WinHeight = wh;
        }
        s.Launch.Fullscreen = FullscreenBox.IsChecked == true;
        s.Launch.DirectConnect = string.IsNullOrWhiteSpace(DirectBox.Text) ? null : DirectBox.Text.Trim();
        if (IsolationCombo.SelectedItem is ComboBoxItem iso)
            s.Launch.IsolationMode = iso.Tag?.ToString() ?? "half";
        App.Services.Settings.Save();
        LaunchSaveStatus.Text = "启动设置已保存。";
        UpdateMemBar();
    }

    // ===== 保存：下载 =====
    private void SaveDownload_Click(object sender, RoutedEventArgs e)
    {
        var s = App.Services.Settings.Config;
        if (DownloadSourceCombo.SelectedItem is ComboBoxItem src)
            s.Download.Source = src.Tag?.ToString() ?? "bmclapi";
        s.Download.Threads = (int)ThreadsSlider.Value;
        s.Download.EnableMultiPart = MultiPartBox.IsChecked == true;
        if (int.TryParse(PartSizeBox.Text, out var ps)) s.Download.PartSizeMB = ps;
        if (int.TryParse(TimeoutBox.Text, out var to)) s.Download.TimeoutSeconds = to;
        if (int.TryParse(RetryBox.Text, out var rc)) s.Download.RetryCount = rc;
        if (int.TryParse(SpeedLimitBox.Text, out var sl)) s.Download.SpeedLimitKBps = sl;
        s.Download.VerifyHash = VerifyHashBox.IsChecked == true;
        s.Download.AutoDownloadJava = AutoJavaBox.IsChecked == true;
        s.Download.ModrinthApi = ModrinthApiBox.Text;
        s.Download.CurseForgeApiKey = CurseForgeKeyBox.Text;
        App.Services.Settings.Save();
        DownloadSaveStatus.Text = "下载设置已保存。部分设置需重启生效。";
    }

    private void ThreadsSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_loading || ThreadsText == null) return;
        ThreadsText.Text = $" {(int)e.NewValue} 线程";
    }

    // ===== 保存：外观 =====
    private void SaveAppearance_Click(object sender, RoutedEventArgs e)
    {
        var s = App.Services.Settings.Config;
        s.General.EnableSound = SoundBox.IsChecked == true;
        var hidden = new List<string>();
        if (HideMods.IsChecked == true) hidden.Add("mods");
        if (HideResources.IsChecked == true) hidden.Add("resource");
        if (HideJava.IsChecked == true) hidden.Add("java");
        if (HideLogs.IsChecked == true) hidden.Add("logs");
        if (HideDownload.IsChecked == true) hidden.Add("download");
        s.General.HiddenModules = string.Join(",", hidden);
        App.Services.Settings.Save();
        AppearanceSaveStatus.Text = "外观设置已保存。功能模块隐藏将在重启后生效。";
    }

    private void ThemeColor_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (sender is Border border && border.Tag is string colorHex)
        {
            try
            {
                var col = (Color)ColorConverter.ConvertFromString(colorHex);
                var name = border.Child is TextBlock tb ? tb.Text : "自定义";
                App.Services.Settings.Config.General.AccentColor = colorHex;
                App.ApplyAccent(col);
                CurrentThemeText.Text = $"当前：{name}";
            }
            catch { }
        }
    }

    /// <summary>主题模式切换（深色/浅色）</summary>
    private void ThemeMode_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (sender is Border border && border.Tag is string theme)
        {
            App.Services.Settings.Config.General.ThemeMode = theme;
            App.Services.Settings.Save();
            ThemeDarkBtn.BorderBrush = theme == "dark" ? (Brush)FindResource("AccentBrush") : Brushes.Transparent;
            ThemeLightBtn.BorderBrush = theme == "light" ? (Brush)FindResource("AccentBrush") : Brushes.Transparent;
            App.ApplyTheme(theme);

            var result = MessageBox.Show(
                "主题已切换为" + (theme == "light" ? "浅色" : "深色") + "主题。\n\n" +
                "为了让所有界面完全生效，建议立即重启启动器。\n\n" +
                "是否立即重启？",
                "主题切换", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                App.Restart();
            }
        }
    }

    private void PickBg_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = "图片|*.png;*.jpg;*.jpeg;*.bmp" };
        if (dlg.ShowDialog() == true)
        {
            App.Services.Settings.Config.General.BackgroundImage = dlg.FileName;
            App.Services.Settings.Save();
            ApplyBackground();
        }
    }

    private void ResetBg_Click(object sender, RoutedEventArgs e)
    {
        App.Services.Settings.Config.General.BackgroundImage = null;
        App.Services.Settings.Save();
        ApplyBackground();
    }

    private void ApplyBackground()
    {
        if (App.MainWin is MainWindow mw) mw.SetBackground(App.Services.Settings.Config.General.BackgroundImage);
    }

    private void BgOpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_loading || BgOpacityText == null) return;
        var val = (int)e.NewValue;
        App.Services.Settings.Config.General.BackgroundOpacity = val;
        BgOpacityText.Text = $"{val}%";
        if (App.MainWin is MainWindow mw) mw.SetBackgroundOpacity(val);
    }

    // ===== 保存：高级 =====
    private void SaveAdvanced_Click(object sender, RoutedEventArgs e)
    {
        var s = App.Services.Settings.Config;
        if (GcCombo.SelectedItem is ComboBoxItem gc)
            s.Advanced.GcType = gc.Tag?.ToString() ?? "G1";
        if (int.TryParse(MetaspaceBox.Text, out var ms)) s.Advanced.MetaspaceSize = ms;
        s.Advanced.UseLargePages = LargePagesBox.IsChecked == true;
        s.Advanced.UseCompressedOops = CompressedOopsBox.IsChecked == true;
        s.Advanced.CheckJavaVersion = CheckJavaBox.IsChecked == true;
        s.Advanced.CheckFileIntegrity = CheckIntegrityBox.IsChecked == true;
        if (int.TryParse(LowMemBox.Text, out var lm)) s.Advanced.LowMemoryWarningMB = lm;
        if (ProxyTypeCombo.SelectedItem is ComboBoxItem pt)
            s.Advanced.ProxyType = pt.Tag?.ToString() ?? "none";
        s.Advanced.ProxyAddress = string.IsNullOrWhiteSpace(ProxyAddressBox.Text) ? null : ProxyAddressBox.Text.Trim();
        if (LogLevelCombo.SelectedItem is ComboBoxItem ll)
            s.Advanced.LogLevel = ll.Tag?.ToString() ?? "info";
        s.Advanced.DebugMode = DebugModeBox.IsChecked == true;
        s.Advanced.CurseForgeApiKey = CurseForgeApiKeyBox.Password;
        App.Services.CurseForge.SetApiKey(CurseForgeApiKeyBox.Password);
        App.Services.Settings.Save();
        AdvancedSaveStatus.Text = "高级设置已保存。";
    }

    private void ApplyCurseForgeKey_Click(object sender, RoutedEventArgs e)
    {
        // 打开CurseForge API Key申请页面
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("https://console.curseforge.com/#/api-keys") { UseShellExecute = true });
        CurseForgeStatus.Text = "已打开申请页面。步骤：1. 登录/注册 2. 点击「Create API Key」3. 复制Key 4. 粘贴到上方输入框 5. 点击保存高级设置";
    }

    private async void TestCurseForge_Click(object sender, RoutedEventArgs e)
    {
        string key = CurseForgeApiKeyBox.Password.Trim();
        if (string.IsNullOrEmpty(key))
        {
            CurseForgeStatus.Text = "请先输入 API Key";
            return;
        }
        App.Services.CurseForge.SetApiKey(key);
        CurseForgeStatus.Text = "正在测试连接...";
        var (success, message) = await App.Services.CurseForge.TestConnectionAsync();
        CurseForgeStatus.Text = success ? "✅ 连接成功！可以使用 CurseForge 模组源了。" : $"❌ 连接失败：{message}";
    }

    // ===== 关于 =====
    private UpdateInfo? _latestUpdate;

    private void LoadStats()
    {
        try
        {
            var cfg = App.Services.Settings.Config.General;
            LaunchCountText.Text = cfg.GameLaunchCount.ToString();
            var allInstances = App.Services.Instances.Instances;
            InstanceCountText.Text = allInstances.Count.ToString();
            int modCount = 0;
            foreach (var instItem in allInstances)
            {
                try { modCount += App.Services.Mods.ListMods(instItem).Count; } catch { }
            }
            ModCountText.Text = modCount.ToString();
            if (!string.IsNullOrEmpty(cfg.LastLaunchTime))
                LastLaunchText.Text = "上次启动：" + cfg.LastLaunchTime;
            else
                LastLaunchText.Text = "上次启动：从未启动";
        }
        catch { }
    }

    private void RunInstaller_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var installer = new SimpleInstallerWindow();
            installer.Owner = Window.GetWindow(this);
            installer.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show("打开安装器失败：" + ex.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void CheckUpdate_Click(object sender, RoutedEventArgs e)
    {
        var s = App.Services.Settings.Config;
        UpdateStatus.Text = "正在检查更新...";
        AutoUpdateBtn.Visibility = Visibility.Collapsed;
        _latestUpdate = null;
        try
        {
            var info = await App.Services.Updater.CheckUpdateAsync(s.General.UpdateUrl);
            if (info == null)
            {
                UpdateStatus.Text = "检查更新失败，请检查网络或稍后重试";
                return;
            }
            CurrentVersionText.Text = $"当前版本 v{App.Services.Updater.CurrentVersion}";
            if (info.HasUpdate)
            {
                _latestUpdate = info;
                string dateText = info.PublishDate.HasValue ? info.PublishDate.Value.ToString("yyyy-MM-dd") : "未知日期";
                UpdateStatus.Text = $"发现新版本 v{info.LatestVersion}（发布于 {dateText}，大小 {info.FileSizeText}）\n{info.ReleaseName}";
                if (!string.IsNullOrEmpty(info.DownloadUrl))
                    AutoUpdateBtn.Visibility = Visibility.Visible;
                else if (!string.IsNullOrEmpty(info.PageUrl))
                    UpdateStatus.Text += "\n请前往发布页下载：" + info.PageUrl;
            }
            else
            {
                UpdateStatus.Text = $"当前 v{App.Services.Updater.CurrentVersion} 已是最新版本。";
            }
        }
        catch (Exception ex)
        {
            UpdateStatus.Text = "检查更新失败：" + ex.Message;
        }
    }

    private async void AutoUpdate_Click(object sender, RoutedEventArgs e)
    {
        if (_latestUpdate == null) return;
        var result = MessageBox.Show($"即将下载并安装更新 v{_latestUpdate.LatestVersion}\n更新过程中启动器会自动关闭，更新完成后自动重启。\n\n是否继续？", "一键更新", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (result != MessageBoxResult.Yes) return;

        UpdateStatus.Text = "正在下载更新文件...";
        AutoUpdateBtn.IsEnabled = false;
        try
        {
            bool ok = await App.Services.Updater.AutoUpdateAsync(_latestUpdate);
            if (ok)
            {
                UpdateStatus.Text = "更新程序已启动，启动器即将关闭...";
                await Task.Delay(500);
                Application.Current.Shutdown();
            }
            else
            {
                UpdateStatus.Text = "自动更新失败，请手动下载更新";
                AutoUpdateBtn.IsEnabled = true;
            }
        }
        catch (Exception ex)
        {
            UpdateStatus.Text = "更新失败：" + ex.Message;
            AutoUpdateBtn.IsEnabled = true;
        }
    }

    private void ShowAgreement_Click(object sender, RoutedEventArgs e)
    {
        var agreement = "温水启动器 用户协议\n\n" +
            "本软件是利用 PCL（Plain Craft Launcher）的开源代码、和 AI 的帮助制作的 Minecraft 启动器。\n\n" +
            "使用本软件即表示您同意以下条款：\n" +
            "1. 本软件仅供个人学习和娱乐使用。\n" +
            "2. 禁止盗用此启动器的代码或界面设计。\n" +
            "3. 禁止利用此启动器进行非法获得收益的操作。\n" +
            "4. 本软件不提供任何担保，使用风险由用户自行承担。\n" +
            "5. Minecraft 是 Mojang AB 的注册商标，本软件与 Mojang 无任何关联。";
        MessageBox.Show(agreement, "用户协议", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void PickRoot_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFolderDialog { Title = "选择游戏根目录" };
        if (dlg.ShowDialog() == true)
        {
            App.Services.Settings.Config.General.GameRoot = dlg.FolderName;
            App.Services.Settings.Save();
            GameRootText.Text = App.Services.Settings.GameRoot;
        }
    }

    private static int CompareVersion(string a, string b)
    {
        var pa = a.Split('.').Select(x => int.TryParse(x, out var n) ? n : 0).ToArray();
        var pb = b.Split('.').Select(x => int.TryParse(x, out var n) ? n : 0).ToArray();
        for (int i = 0; i < Math.Max(pa.Length, pb.Length); i++)
        {
            int x = i < pa.Length ? pa[i] : 0;
            int y = i < pb.Length ? pb[i] : 0;
            if (x != y) return x.CompareTo(y);
        }
        return 0;
    }


    private void SetPassword_Click(object sender, RoutedEventArgs e)
    {
        var pwd = PwdSetBox.Password;
        if (string.IsNullOrEmpty(pwd) || pwd.Length < 4)
        {
            PwdStatus.Text = "密码至少4位";
            return;
        }
        App.Services.Settings.Config.General.PasswordHash = PasswordDialog.HashPassword(pwd);
        App.Services.Settings.Save();
        PwdSetBox.Password = "";
        PwdStatus.Text = "密码已设置，下次启动生效";
    }

    private void ClearPassword_Click(object sender, RoutedEventArgs e)
    {
        App.Services.Settings.Config.General.PasswordHash = "";
        App.Services.Settings.Save();
        PwdSetBox.Password = "";
        PwdStatus.Text = "密码已清除";
    }
}
