using System.Text.Json.Serialization;

namespace WarmWaterLauncher.Models;

/// <summary>全局配置（JSON 序列化，存储在数据目录 config.json）</summary>
public class AppConfig
{
    public GeneralSettings General { get; set; } = new();
    public LaunchSettings Launch { get; set; } = new();
    public DownloadSettings Download { get; set; } = new();
    public AdvancedSettings Advanced { get; set; } = new();
    public List<Account> Accounts { get; set; } = new();
    public List<GameInstance> Instances { get; set; } = new();
    public List<ServerEntry> Servers { get; set; } = new();
    public string? CurrentAccountId { get; set; }
    public string? CurrentInstanceId { get; set; }
}

public class GeneralSettings
{
    /// <summary>游戏根目录（空 = 使用便携数据目录下的 .minecraft）</summary>
    public string? GameRoot { get; set; }
    /// <summary>便携模式：数据全部存在启动器同目录</summary>
    public bool Portable { get; set; } = true;
    /// <summary>主题名称</summary>
    public string Theme { get; set; } = "经典绿";
    /// <summary>强调色</summary>
    public string AccentColor { get; set; } = "#FF6BC05C";
    /// <summary>自定义背景图路径</summary>
    public string? BackgroundImage { get; set; }
    /// <summary>背景模糊透明度 0-100</summary>
    public int BackgroundOpacity { get; set; } = 40;
    /// <summary>启动声音</summary>
    public bool EnableSound { get; set; } = true;
    /// <summary>是否已同意用户协议</summary>
    public bool AgreedToUserAgreement { get; set; } = false;
    /// <summary>游戏启动总次数</summary>
    public int GameLaunchCount { get; set; } = 0;
    public List<int> UnlockedMilestones { get; set; } = new();
    public Dictionary<int, DateTime> MilestoneUnlockDates { get; set; } = new();
    /// <summary>上次提醒的启动次数（避免重复提醒）</summary>
    public int LastRemindedLaunchCount { get; set; } = 0;
    /// <summary>上次启动时间</summary>
    public string? LastLaunchTime { get; set; }
    /// <summary>下载源: mojang / bmclapi / mcim</summary>
    public string DownloadSource { get; set; } = "bmclapi";
    /// <summary>并发下载线程数</summary>
    public int DownloadThreads { get; set; } = 32;
    /// <summary>语言: zh-CN / en-US / zh-TW</summary>
    public string Language { get; set; } = "zh-CN";
    /// <summary>隐藏的功能模块（逗号分隔）</summary>
    public string HiddenModules { get; set; } = "";
    /// <summary>启动器更新检测地址（GitHub Releases API 或自建 JSON：{"tag_name":"v1.0.1"}）</summary>
    public string UpdateUrl { get; set; } = "";
    /// <summary>窗口宽度</summary>
    public double WinWidth { get; set; } = 1180;
    /// <summary>窗口高度</summary>
    public double WinHeight { get; set; } = 760;
    /// <summary>启动动画</summary>
    public bool EnableLaunchAnimation { get; set; } = true;
    /// <summary>启动后最小化启动器</summary>
    public bool MinimizeOnLaunch { get; set; } = false;
    /// <summary>关闭启动器时最小化到托盘</summary>
    public bool MinimizeToTray { get; set; } = false;
    /// <summary>启动器密码锁（SHA256哈希，空表示不启用）</summary>
    public string PasswordHash { get; set; } = "";
    /// <summary>启动动画类型: default / pcl / minimal / none</summary>
    public string LaunchAnimationType { get; set; } = "default";
    /// <summary>显示游戏时间统计</summary>
    public bool ShowPlayTime { get; set; } = true;
    /// <summary>显示成就通知</summary>
    public bool ShowAchievementNotifications { get; set; } = true;
    /// <summary>实验功能（逗号分隔的功能ID）</summary>
    public string ExperimentalFeatures { get; set; } = "";
    /// <summary>窗口透明度（0-100，100为不透明）</summary>
    public int WindowOpacity { get; set; } = 100;
    /// <summary>启用启动音效</summary>
    public bool EnableStartupSound { get; set; } = false;
    /// <summary>收藏的版本（逗号分隔）</summary>
    public string FavoriteVersions { get; set; } = "";
    /// <summary>基岩版安装路径</summary>
    public string BedrockPath { get; set; } = "";
    /// <summary>游戏参数预设: performance / balanced / lowpower / custom</summary>
    public string GamePreset { get; set; } = "balanced";
    /// <summary>护眼模式</summary>
    public bool EyeCareMode { get; set; } = false;
    /// <summary>启动倒计时秒数（0表示不倒计时）</summary>
    public int LaunchCountdown { get; set; } = 0;
    /// <summary>检测到游戏窗口后自动切换到日志页</summary>
    public bool AutoSwitchToLogsOnGameWindow { get; set; } = true;
    /// <summary>主题模式: dark / light</summary>
    public string ThemeMode { get; set; } = "light";
}
public class DownloadSettings
{
    /// <summary>下载源: bmclapi / mcim / mojang</summary>
    public string Source { get; set; } = "bmclapi";
    /// <summary>并发下载线程数</summary>
    public int Threads { get; set; } = 16;
    /// <summary>单文件分片下载</summary>
    public bool EnableMultiPart { get; set; } = true;
    /// <summary>分片大小 MB</summary>
    public int PartSizeMB { get; set; } = 8;
    /// <summary>下载超时秒</summary>
    public int TimeoutSeconds { get; set; } = 60;
    /// <summary>重试次数</summary>
    public int RetryCount { get; set; } = 3;
    /// <summary>下载完成校验</summary>
    public bool VerifyHash { get; set; } = true;
    /// <summary>自动下载对应 Java</summary>
    public bool AutoDownloadJava { get; set; } = true;
    /// <summary>下载限速 KB/s（0=不限速）</summary>
    public int SpeedLimitKBps { get; set; } = 0;
    /// <summary>Modrinth API 地址</summary>
    public string ModrinthApi { get; set; } = "https://api.modrinth.com/v2";
    /// <summary>CurseForge API Key</summary>
    public string CurseForgeApiKey { get; set; } = "";
}
public class AdvancedSettings
{
    /// <summary>GC 类型: G1 / ZGC / Shenandoah / Serial</summary>
    public string GcType { get; set; } = "G1";
    /// <summary>启用大页内存</summary>
    public bool UseLargePages { get; set; } = false;
    /// <summary>启用压缩指针</summary>
    public bool UseCompressedOops { get; set; } = true;
    /// <summary>Metaspace 大小 MB</summary>
    public int MetaspaceSize { get; set; } = 256;
    /// <summary>日志级别: off / info / debug</summary>
    public string LogLevel { get; set; } = "info";
    /// <summary>启动前检查 Java 版本</summary>
    public bool CheckJavaVersion { get; set; } = true;
    /// <summary>启动前检查文件完整性</summary>
    public bool CheckFileIntegrity { get; set; } = true;
    /// <summary>内存不足警告阈值 MB</summary>
    public int LowMemoryWarningMB { get; set; } = 1024;
    /// <summary>预加载资源</summary>
    public bool PreloadResources { get; set; } = false;
    /// <summary>调试模式（输出详细日志）</summary>
    public bool DebugMode { get; set; } = false;
    /// <summary>代理地址（如 127.0.0.1:7890）</summary>
    public string? ProxyAddress { get; set; }
    /// <summary>代理类型: none / http / socks5</summary>
    public string ProxyType { get; set; } = "none";
    /// <summary>AI API 密钥</summary>
    public string AIApiKey { get; set; } = "";
    /// <summary>AI API 地址</summary>
    public string AIApiBase { get; set; } = "https://api.openai.com/v1";
    /// <summary>AI 模型</summary>
    public string AIModel { get; set; } = "gpt-3.5-turbo";
    /// <summary>启用AI助手（实验功能）</summary>
    public bool EnableAIAssistant { get; set; } = false;
    /// <summary>CurseForge API Key</summary>
    public string CurseForgeApiKey { get; set; } = "";
}

public class LaunchSettings
{
    /// <summary>最大内存 MB</summary>
    public int MaxMemory { get; set; } = 4096;
    /// <summary>最小内存 MB</summary>
    public int MinMemory { get; set; } = 512;
    /// <summary>额外 JVM 参数</summary>
    public string JvmArgs { get; set; } = "";
    /// <summary>游戏附加参数</summary>
    public string GameArgs { get; set; } = "";
    /// <summary>版本隔离模式: global / half / full</summary>
    public string IsolationMode { get; set; } = "global";
    /// <summary>游戏分辨率（空=默认）</summary>
    public string Resolution { get; set; } = "";
    /// <summary>是否全屏</summary>
    public bool Fullscreen { get; set; } = false;
    /// <summary>窗口宽度</summary>
    public int WinWidth { get; set; } = 854;
    /// <summary>窗口高度</summary>
    public int WinHeight { get; set; } = 480;
    /// <summary>服务端（直连 IP:端口）</summary>
    public string? DirectConnect { get; set; }
    /// <summary>使用的 Java 路径（空=自动）</summary>
    public string? JavaPath { get; set; }
}

/// <summary>账号</summary>
public class Account
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    /// <summary>offline / microsoft</summary>
    public string Type { get; set; } = "offline";
    public string Name { get; set; } = "";
    public string Uuid { get; set; } = "";
    public string? AccessToken { get; set; }
    public string? RefreshToken { get; set; }
    public long ExpiresAt { get; set; }
    /// <summary>头像图片 URL（正版账号自动获取，离线账号使用本地皮肤生成）</summary>
    public string? AvatarUrl { get; set; }
    /// <summary>头像图片（运行时加载，不保存到配置）</summary>
    [JsonIgnore]
    public System.Windows.Media.Imaging.BitmapImage? AvatarImage { get; set; }
    /// <summary>离线账号自定义皮肤路径（本地保存）</summary>
    public string? SkinPath { get; set; }
    /// <summary>离线账号自定义披风路径</summary>
    public string? CapePath { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime LastUsed { get; set; } = DateTime.Now;
    /// <summary>第三方皮肤站 API 地址</summary>
    public string? ThirdPartyApi { get; set; }
    /// <summary>第三方皮肤站登录邮箱</summary>
    public string? ThirdPartyEmail { get; set; }
    [JsonIgnore] public string DisplayName => Type switch
    {
        "offline" => Name + "（离线）",
        "microsoft" => Name + "（正版）",
        "thirdparty" => Name + "（第三方）",
        _ => Name
    };
}

/// <summary>游戏实例</summary>
public class GameInstance
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "";
    /// <summary>绑定的 Minecraft 版本 ID（如 1.20.1）</summary>
    public string VersionId { get; set; } = "";
    /// <summary>加载器类型: none / forge / fabric / quilt / optifine / fabric+optifine ...</summary>
    public string LoaderType { get; set; } = "none";
    /// <summary>加载器版本</summary>
    public string? LoaderVersion { get; set; }
    public string Description { get; set; } = "";
    /// <summary>独立游戏目录（完全隔离时使用）</summary>
    public string? CustomGameDir { get; set; }
    /// <summary>实例内自定义隔离标识</summary>
    public string? IsolateKey { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime LastPlayed { get; set; } = DateTime.MinValue;
    /// <summary>累计游玩次数</summary>
    public int PlayCount { get; set; }
    /// <summary>图标路径</summary>
    public string? IconPath { get; set; }
}

/// <summary>服务器列表条目</summary>
public class ServerEntry
{
    public string Name { get; set; } = "";
    public string Address { get; set; } = "";
    public string? Version { get; set; }
    public string? Description { get; set; }
    public DateTime AddedAt { get; set; } = DateTime.Now;
}

/// <summary>版本隔离模式枚举</summary>
public enum IsolationMode
{
    Global,   // 全局共享：所有实例共用版本/存档/模组
    Half,     // 半隔离：版本全局共享，存档/模组/配置按实例隔离
    Full      // 完全隔离：版本、存档、模组全部按实例隔离
}

public static class IsolationModeHelper
{
    public static IsolationMode Parse(string s) => s switch
    {
        "global" => IsolationMode.Global,
        "full" => IsolationMode.Full,
        _ => IsolationMode.Half
    };
    public static string Name(IsolationMode m) => m switch
    {
        IsolationMode.Global => "全局共享（版本/存档/模组全部共用）",
        IsolationMode.Full => "完全隔离（版本/存档/模组全部独立）",
        _ => "半隔离（版本共用，存档/模组/配置独立）"
    };
}
