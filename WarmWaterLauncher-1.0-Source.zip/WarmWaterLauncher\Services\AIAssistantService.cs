using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WarmWaterLauncher.Services;

/// <summary>
/// AI助手服务：分析崩溃报告、解答使用问题
/// </summary>
public class AIAssistantService
{
    private readonly DownloadService _dl;
    private string _apiKey = "";
    private string _apiBase = "https://api.openai.com/v1";
    private string _model = "gpt-3.5-turbo";

    public bool IsConfigured => !string.IsNullOrEmpty(_apiKey);

    public AIAssistantService(DownloadService dl)
    {
        _dl = dl;
        // 从配置加载
        try
        {
            _apiKey = App.Services.Settings.Config.Advanced.AIApiKey ?? "";
            _apiBase = App.Services.Settings.Config.Advanced.AIApiBase ?? "https://api.openai.com/v1";
            _model = App.Services.Settings.Config.Advanced.AIModel ?? "gpt-3.5-turbo";
        }
        catch { }
    }

    public void UpdateConfig(string apiKey, string apiBase, string model)
    {
        _apiKey = apiKey ?? "";
        _apiBase = string.IsNullOrEmpty(apiBase) ? "https://api.openai.com/v1" : apiBase.TrimEnd('/');
        _model = string.IsNullOrEmpty(model) ? "gpt-3.5-turbo" : model;
        try
        {
            App.Services.Settings.Config.Advanced.AIApiKey = _apiKey;
            App.Services.Settings.Config.Advanced.AIApiBase = _apiBase;
            App.Services.Settings.Config.Advanced.AIModel = _model;
            App.Services.Settings.Save();
        }
        catch { }
    }

    /// <summary>发送聊天请求</summary>
    public async Task<string> ChatAsync(string userMessage, string? systemPrompt = null, IProgress<string>? streamProgress = null)
    {
        if (string.IsNullOrEmpty(_apiKey))
            return "错误：请先在设置中配置 AI API 密钥。";

        try
        {
            var messages = new List<object>();
            if (!string.IsNullOrEmpty(systemPrompt))
                messages.Add(new { role = "system", content = systemPrompt });
            messages.Add(new { role = "user", content = userMessage });

            var requestBody = new
            {
                model = _model,
                messages = messages,
                temperature = 0.7,
                max_tokens = 2000
            };

            string json = JsonSerializer.Serialize(requestBody);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");

            using var request = new HttpRequestMessage(HttpMethod.Post, $"{_apiBase}/chat/completions");
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _apiKey);
            request.Content = content;

            using var resp = await _dl.Http.Client.SendAsync(request);
            string respBody = await resp.Content.ReadAsStringAsync();

            if (!resp.IsSuccessStatusCode)
                return $"API 请求失败（HTTP {(int)resp.StatusCode}）：{respBody}";

            using var doc = JsonDocument.Parse(respBody);
            if (doc.RootElement.TryGetProperty("choices", out var choices) &&
                choices.GetArrayLength() > 0 &&
                choices[0].TryGetProperty("message", out var msg) &&
                msg.TryGetProperty("content", out var contentEl))
            {
                return contentEl.GetString() ?? "AI 返回了空内容。";
            }
            return "无法解析 AI 响应：" + respBody;
        }
        catch (Exception ex)
        {
            return $"请求异常：{ex.Message}";
        }
    }

    /// <summary>分析崩溃报告</summary>
    public async Task<string> AnalyzeCrashAsync(string crashReport)
    {
        string systemPrompt = @"你是一个 Minecraft 启动器技术支持助手。请分析用户提供的崩溃报告，给出：
1. 崩溃的根本原因（用中文）
2. 可能的解决方案（分点列出，具体可操作）
3. 预防建议
请用中文回答，格式清晰，不要太技术化，让普通玩家能看懂。";

        string userMessage = $"请分析以下 Minecraft 崩溃报告：\n\n{crashReport}";
        return await ChatAsync(userMessage, systemPrompt);
    }

    /// <summary>解答使用问题</summary>
    public async Task<string> AnswerQuestionAsync(string question)
    {
        string systemPrompt = @"你是一个 Minecraft 启动器（温水启动器）的使用助手。请用中文回答用户的问题，涵盖：
- 如何下载和安装游戏版本
- 如何下载和配置 Java
- 如何安装 Forge/Fabric/Quilt 加载器
- 如何安装和管理模组
- 如何配置启动参数（内存、JVM参数等）
- 如何联机
- 常见问题排查
回答要具体、可操作，分点列出，让新手也能看懂。";

        return await ChatAsync(question, systemPrompt);
    }

    /// <summary>生成预设问题列表</summary>
    public static List<string> GetPresetQuestions()
    {
        return new List<string>
        {
            "如何下载和安装 Minecraft 游戏？",
            "如何下载和配置 Java？",
            "如何安装 Forge 加载器？",
            "如何安装 Fabric 加载器？",
            "如何下载和安装模组？",
            "游戏启动失败怎么办？",
            "游戏很卡如何优化？",
            "如何分配更多内存给游戏？",
            "如何和朋友联机玩？",
            "游戏崩溃了如何解决？",
            "如何安装光影包？",
            "如何切换游戏语言为中文？"
        };
    }
}
