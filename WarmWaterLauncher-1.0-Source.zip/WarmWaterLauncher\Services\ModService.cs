using System.Text.Json;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

public class ModEntry
{
    public string FileName { get; set; } = "";
    public string FullPath { get; set; } = "";
    public bool Enabled { get; set; } = true;
    public long Size { get; set; }
    public DateTime Modified { get; set; }
    public string? ModId { get; set; }
    public string? DisplayName { get; set; }
    public string? Description { get; set; }
    public string? Version { get; set; }
    public List<string> Dependencies { get; set; } = new();
    public string? ProjectId { get; set; }   // modrinth id
}

/// <summary>模组管理：导入、启停、删除、元信息、依赖检测、批量、更新检测</summary>
public class ModService
{
    private readonly SettingsService _settings;
    private readonly ModrinthApi _modrinth;
    private readonly InstanceService _instances;
    public ModService(SettingsService settings, ModrinthApi modrinth, InstanceService instances)
    {
        _settings = settings;
        _modrinth = modrinth;
        _instances = instances;
    }

    /// <summary>实例的 mods 目录</summary>
    public string GetModsDir(GameInstance inst)
    {
        var gameDir = _instances.GetInstanceGameDir(inst);
        string dir = Path.Combine(gameDir, "mods");
        Directory.CreateDirectory(dir);
        return dir;
    }

    /// <summary>列出实例的全部模组（含 disabled 后缀）</summary>
    public List<ModEntry> ListMods(GameInstance inst)
    {
        string dir = GetModsDir(inst);
        var result = new List<ModEntry>();
        if (!Directory.Exists(dir)) return result;
        // 同时搜索 .jar 和 .jar.disabled 文件
        var files = Directory.GetFiles(dir, "*.jar")
            .Concat(Directory.GetFiles(dir, "*.jar.disabled"))
            .Distinct()
            .ToList();
        foreach (var f in files)
        {
            var name = Path.GetFileName(f);
            bool enabled = !name.EndsWith(".disabled");
            var entry = new ModEntry
            {
                FileName = enabled ? name : name[..^".disabled".Length],
                FullPath = f,
                Enabled = enabled,
                Size = new FileInfo(f).Length,
                Modified = File.GetLastWriteTime(f)
            };
            FillMetadata(entry);
            result.Add(entry);
        }
        return result.OrderByDescending(m => m.Enabled).ThenBy(m => m.FileName).ToList();
    }

    /// <summary>读取 jar 内的 fabric.mod.json / mods.toml 元信息</summary>
    private void FillMetadata(ModEntry entry)
    {
        try
        {
            using var zip = System.IO.Compression.ZipFile.OpenRead(entry.FullPath);
            // Fabric / Quilt
            foreach (var name in new[] { "fabric.mod.json", "quilt.mod.json" })
            {
                var e = zip.GetEntry(name);
                if (e == null) continue;
                using var sr = new StreamReader(e.Open());
                using var doc = JsonDocument.Parse(sr.ReadToEnd());
                var root = doc.RootElement;
                entry.ModId = root.TryGetProperty("id", out var id) ? id.GetString() : null;
                entry.DisplayName = root.TryGetProperty("name", out var nm) ? nm.GetString() : entry.ModId;
                entry.Description = root.TryGetProperty("description", out var ds) ? ds.GetString() : null;
                entry.Version = root.TryGetProperty("version", out var ver) ? ver.GetString() : null;
                if (root.TryGetProperty("depends", out var deps))
                {
                    foreach (var d in deps.EnumerateObject())
                        entry.Dependencies.Add(d.Name);
                }
                if (entry.ModId?.StartsWith("modrinth:") == true)
                {
                    entry.ProjectId = entry.ModId["modrinth:".Length..];
                    entry.ModId = null;
                }
                return;
            }
            // Forge mods.toml
            var toml = zip.GetEntry("META-INF/mods.toml");
            if (toml != null)
            {
                using var sr = new StreamReader(toml.Open());
                var text = sr.ReadToEnd();
                var idM = System.Text.RegularExpressions.Regex.Match(text, @"modId\s*=\s*""([^""]+)""");
                if (idM.Success) entry.ModId = idM.Groups[1].Value;
                var dm = System.Text.RegularExpressions.Regex.Match(text, @"displayName\s*=\s*""([^""]+)""");
                if (dm.Success) entry.DisplayName = dm.Groups[1].Value;
                var ver = System.Text.RegularExpressions.Regex.Match(text, @"version\s*=\s*""([^""]+)""");
                if (ver.Success) entry.Version = ver.Groups[1].Value;
                // 依赖
                var depM = System.Text.RegularExpressions.Regex.Match(text, @"\[\[dependencies\.([^\]]+)\]\]");
                if (depM.Success) entry.Dependencies.Add(depM.Groups[1].Value);
                return;
            }
            // mcmod.info (旧版 forge)
            var mcmod = zip.GetEntry("mcmod.info");
            if (mcmod != null)
            {
                using var sr = new StreamReader(mcmod.Open());
                var text = sr.ReadToEnd();
                var arr = JsonDocument.Parse(text);
                var first = arr.RootElement.EnumerateArray().FirstOrDefault();
                if (first.ValueKind == JsonValueKind.Object)
                {
                    entry.DisplayName = first.TryGetProperty("name", out var n) ? n.GetString() : null;
                    entry.Description = first.TryGetProperty("description", out var d) ? d.GetString() : null;
                    entry.ModId = first.TryGetProperty("modid", out var mid) ? mid.GetString() : null;
                    entry.Version = first.TryGetProperty("version", out var v) ? v.GetString() : null;
                }
            }
        }
        catch { }
    }

    /// <summary>启用/禁用模组（重命名 .disabled）</summary>
    public void SetEnabled(ModEntry mod, bool enabled)
    {
        if (mod.Enabled == enabled) return;
        string newPath = enabled
            ? mod.FullPath[..^".disabled".Length]
            : mod.FullPath + ".disabled";
        File.Move(mod.FullPath, newPath);
        mod.Enabled = enabled;
        mod.FullPath = newPath;
        mod.FileName = enabled ? Path.GetFileName(newPath) : Path.GetFileName(newPath)[..^".disabled".Length];
    }

    public void Delete(ModEntry mod)
    {
        if (File.Exists(mod.FullPath)) File.Delete(mod.FullPath);
    }

    /// <summary>批量启停</summary>
    public void SetAllEnabled(List<ModEntry> mods, bool enabled)
    {
        foreach (var m in mods) SetEnabled(m, enabled);
    }

    /// <summary>拖拽/选择导入模组文件到实例 mods 目录</summary>
    public List<string> Import(List<string> files, GameInstance inst)
    {
        string dir = GetModsDir(inst);
        var copied = new List<string>();
        foreach (var f in files)
        {
            if (!File.Exists(f)) continue;
            string dest = Path.Combine(dir, Path.GetFileName(f));
            File.Copy(f, dest, true);
            copied.Add(dest);
        }
        return copied;
    }

    /// <summary>依赖检测：列出缺失的依赖</summary>
    public List<string> CheckMissingDependencies(GameInstance inst)
    {
        var mods = ListMods(inst).Where(m => m.Enabled).ToList();
        var ids = mods.Where(m => m.ModId != null).Select(m => m.ModId!).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var missing = new List<string>();
        foreach (var m in mods)
        {
            foreach (var dep in m.Dependencies)
            {
                var key = dep.Trim();
                if (key.StartsWith("minecraft") || key.StartsWith("java")) continue;
                if (!ids.Contains(key))
                    missing.Add($"{m.DisplayName ?? m.FileName} 需要依赖: {key}");
            }
        }
        return missing.Distinct().ToList();
    }

    /// <summary>冲突检测：同名 mod 重复</summary>
    public List<string> CheckConflicts(GameInstance inst)
    {
        var mods = ListMods(inst).Where(m => m.Enabled).ToList();
        var result = new List<string>();
        var groups = mods.GroupBy(m => m.ModId ?? m.FileName, StringComparer.OrdinalIgnoreCase);
        foreach (var g in groups.Where(g => g.Count() > 1))
            result.Add($"检测到 {g.Key} 的多个版本: {string.Join("、", g.Select(m => m.FileName))}");
        return result;
    }

    /// <summary>模组更新检测（基于 Modrinth）</summary>
    public async Task<List<(ModEntry mod, string latest, string latestVer)>> CheckUpdatesAsync(GameInstance inst, string gameVersion)
    {
        var result = new List<(ModEntry, string, string)>();
        foreach (var m in ListMods(inst).Where(m => m.Enabled && m.ProjectId != null))
        {
            try
            {
                var versions = await _modrinth.GetVersionsAsync(m.ProjectId!, gameVersion);
                var latest = versions.FirstOrDefault();
                if (latest == null) continue;
                var latestNum = latest.VersionNumber;
                if (latestNum != m.Version)
                    result.Add((m, latest.Name + " " + latestNum, latestNum));
            }
            catch { }
        }
        return result;
    }

    /// <summary>下载模组文件到实例 mods 目录（带进度，IProgress 为百分比 0-100）</summary>
    public async Task<bool> DownloadAsync(AppServices services, string url, string dest, string? sha1,
        IProgress<int>? progress = null)
    {
        try
        {
            int last = -1;
            Action<string, long, long, double> handler = (_, _, _, pct) =>
            {
                int p = (int)(pct * 100);
                if (progress != null && p != last) { progress.Report(p); last = p; }
            };
            services.Download.Progress += handler;
            try
            {
                return await services.Download.DownloadFileAsync(url, dest, sha1);
            }
            finally { services.Download.Progress -= handler; }
        }
        catch { return false; }
    }
}
