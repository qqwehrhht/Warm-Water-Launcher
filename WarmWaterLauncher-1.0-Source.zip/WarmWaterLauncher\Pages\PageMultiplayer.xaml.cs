using System.Collections.ObjectModel;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageMultiplayer : UserControl, IActivatePage
{
    public ObservableCollection<RoomInfo> Rooms { get; set; } = new();
    public ObservableCollection<ServerEntry> Servers { get; set; } = new();

    public PageMultiplayer()
    {
        InitializeComponent();
        RoomList.ItemsSource = Rooms;
        ServerList.ItemsSource = Servers;
    }

    public void OnActivate()
    {
        LoadServers();
        RefreshRooms_Click(null!, null!);
        DetectIp();
        LoadThirdPartyTools();
    }

    private void LoadThirdPartyTools()
    {
        var tools = NatTraversalService.ThirdPartyTools.Select(t => new ThirdPartyToolVM
        {
            Name = t.Name,
            Description = t.Description,
            Url = t.Url
        }).ToList();
        ThirdPartyToolList.ItemsSource = tools;
    }

    private void DetectIp()
    {
        try
        {
            var ip = GetLocalIP();
            if (ip != null)
                MyIpText.Text = ip;
            else
                MyIpText.Text = "未检测到";
        }
        catch { MyIpText.Text = "检测失败"; }
    }

    private void CopyIp_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Clipboard.SetText(MyIpText.Text);
            MessageBox.Show("IP 地址已复制到剪贴板", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch { }
    }

    private void LoadServers()
    {
        Servers.Clear();
        foreach (var s in App.Services.Settings.Config.Servers)
            Servers.Add(s);
        NoServerText.Visibility = Servers.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private async void RefreshRooms_Click(object sender, RoutedEventArgs e)
    {
        Rooms.Clear();
        NoRoomText.Text = "正在扫描局域网...";
        try
        {
            // 扫描局域网内的 Minecraft 服务器（端口 25565-25575）
            var localIp = GetLocalIP();
            if (localIp != null)
            {
                var scanTask = Task.Run(() => ScanLanAsync(localIp));
                var rooms = await Task.WhenAny(scanTask, Task.Delay(3000));
                if (rooms == scanTask)
                {
                    foreach (var r in scanTask.Result)
                        Rooms.Add(r);
                }
            }
        }
        catch { }
        NoRoomText.Text = Rooms.Count == 0 ? "暂无房间，点击右侧创建房间" : "";
        NoRoomText.Visibility = Rooms.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private static string? GetLocalIP()
    {
        try
        {
            using var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, 0);
            socket.Connect("8.8.8.8", 65530);
            var endPoint = socket.LocalEndPoint as IPEndPoint;
            return endPoint?.Address.ToString();
        }
        catch { return null; }
    }

    private async Task<List<RoomInfo>> ScanLanAsync(string localIp)
    {
        var results = new List<RoomInfo>();
        var prefix = localIp.Substring(0, localIp.LastIndexOf('.') + 1);
        var tasks = new List<Task>();
        for (int i = 1; i < 255; i++)
        {
            string ip = prefix + i;
            tasks.Add(Task.Run(async () =>
            {
                try
                {
                    using var client = new TcpClient();
                    var connect = client.ConnectAsync(ip, 25565);
                    var done = await Task.WhenAny(connect, Task.Delay(500));
                    if (done == connect && client.Connected)
                    {
                        lock (results)
                            results.Add(new RoomInfo { Name = $"Minecraft 服务器 ({ip})", Address = $"{ip}:25565", Info = "局域网服务器" });
                    }
                }
                catch { }
            }));
        }
        await Task.WhenAll(tasks);
        return results;
    }

    private async void CreateRoom_Click(object sender, RoutedEventArgs e)
    {
        var inst = App.Services.Instances.Current;
        if (inst == null) { MessageBox.Show("请先选择实例", "温水启动器"); return; }
        var acct = App.Services.Accounts.Current;
        if (acct == null) { MessageBox.Show("请先创建账号", "温水启动器"); return; }
        var ip = GetLocalIP() ?? "你的IP";
        App.Services.Settings.Config.Launch.DirectConnect = "";
        App.Services.Settings.Save();

        var result = MessageBox.Show($"游戏将自动启动！\n\n启动后请按以下步骤创建房间：\n1. 进入你的世界\n2. 按 Esc → 对局域网开放\n3. 点击「创建一个局域网世界」\n4. 聊天框会显示端口号\n\n你的 IP：{ip}\n把 IP:端口 告诉好友即可加入。\n\n是否立即启动游戏？",
            "创建房间", MessageBoxButton.YesNo, MessageBoxImage.Information);
        if (result != MessageBoxResult.Yes) return;

        // 跳转到主页并自动启动游戏
        if (App.MainWin is MainWindow mainWin)
            await mainWin.NavigateToAndLaunch();
    }

    private async void JoinRoom_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is RoomInfo room)
        {
            var inst = App.Services.Instances.Current;
            if (inst == null) { MessageBox.Show("请先选择实例", "温水启动器"); return; }
            var acct = App.Services.Accounts.Current;
            if (acct == null) { MessageBox.Show("请先创建账号", "温水启动器"); return; }

            App.Services.Settings.Config.Launch.DirectConnect = room.Address;
            App.Services.Settings.Save();

            var result = MessageBox.Show($"已设置直连服务器：{room.Address}\n\n是否立即启动游戏并连接？", "加入房间", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result != MessageBoxResult.Yes) return;

            // 跳转到主页并自动启动游戏
            if (App.MainWin is MainWindow mainWin)
                await mainWin.NavigateToAndLaunch();
        }
    }

    private void AddServer_Click(object sender, RoutedEventArgs e)
    {
        string name = ServerNameBox.Text.Trim();
        string addr = ServerAddrBox.Text.Trim();
        if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(addr))
        {
            MessageBox.Show("请填写服务器名称和地址", "温水启动器");
            return;
        }
        var server = new ServerEntry { Name = name, Address = addr };
        App.Services.Settings.Config.Servers.Add(server);
        App.Services.Settings.Save();
        Servers.Add(server);
        ServerNameBox.Text = "";
        NoServerText.Visibility = Visibility.Collapsed;
    }

    private async void ConnectServer_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is ServerEntry server)
        {
            var inst = App.Services.Instances.Current;
            if (inst == null) { MessageBox.Show("请先选择实例", "温水启动器"); return; }
            var acct = App.Services.Accounts.Current;
            if (acct == null) { MessageBox.Show("请先创建账号", "温水启动器"); return; }

            App.Services.Settings.Config.Launch.DirectConnect = server.Address;
            App.Services.Settings.Save();

            var result = MessageBox.Show($"已设置直连服务器：{server.Address}\n\n是否立即启动游戏并连接？", "连接服务器", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (result != MessageBoxResult.Yes) return;

            if (App.MainWin is MainWindow mainWin)
                await mainWin.NavigateToAndLaunch();
        }
    }

    private async void PingServer_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is ServerEntry server)
        {
            var btn = sender as Button;
            if (btn != null) { btn.IsEnabled = false; btn.Content = "Ping中..."; }
            try
            {
                var parts = server.Address.Split(':');
                string host = parts[0];
                int port = parts.Length > 1 && int.TryParse(parts[1], out var p) ? p : 25565;
                var status = await App.Services.ServerPing.PingAsync(host, port);
                UpdateServerStatusUI(server, status);
            }
            catch { }
            finally
            {
                if (btn != null) { btn.IsEnabled = true; btn.Content = "Ping"; }
            }
        }
    }

    private async void PingAllServers_Click(object sender, RoutedEventArgs e)
    {
        var btn = sender as Button;
        if (btn != null) { btn.IsEnabled = false; btn.Content = "Ping中..."; }
        try
        {
            foreach (var server in Servers.ToList())
            {
                try
                {
                    var parts = server.Address.Split(':');
                    string host = parts[0];
                    int port = parts.Length > 1 && int.TryParse(parts[1], out var p) ? p : 25565;
                    var status = await App.Services.ServerPing.PingAsync(host, port, 3000);
                    UpdateServerStatusUI(server, status);
                }
                catch { }
            }
        }
        finally
        {
            if (btn != null) { btn.IsEnabled = true; btn.Content = "全部Ping"; }
        }
    }

    private void UpdateServerStatusUI(ServerEntry server, ServerStatus status)
    {
        Dispatcher.Invoke(() =>
        {
            // 找到对应的 UI 元素并更新
            var container = ServerList.ItemContainerGenerator.ContainerFromItem(server);
            if (container == null)
            {
                // 如果找不到容器，刷新列表
                ServerList.ItemsSource = null;
                ServerList.ItemsSource = Servers;
                return;
            }
            // 简单方式：通过状态文本更新
            server.Description = status.Online
                ? $"{status.VersionName} · {status.OnlinePlayers}/{status.MaxPlayers}人 · {status.LatencyText}"
                : "离线";
            // 触发 UI 更新
            ServerList.ItemsSource = null;
            ServerList.ItemsSource = Servers;
        });
    }

    private void DeleteServer_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is ServerEntry server)
        {
            App.Services.Settings.Config.Servers.Remove(server);
            App.Services.Settings.Save();
            Servers.Remove(server);
            NoServerText.Visibility = Servers.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }
    }

    #region 内网穿透
    private void CheckTailscale_Click(object sender, RoutedEventArgs e)
    {
        var installed = App.Services.Nat.IsTailscaleInstalled();
        if (!installed)
        {
            TailscaleStatusPanel.Visibility = Visibility.Visible;
            TailscaleStateText.Text = "未安装";
            TailscaleStateText.Foreground = (Brush)FindResource("WarnBrush");
            TailscaleIpText.Text = "-";
            TailscalePeersText.Text = "请先下载安装 Tailscale";
            DownloadTailscaleBtn.Visibility = Visibility.Visible;
            LoginTailscaleBtn.Visibility = Visibility.Collapsed;
            return;
        }

        var status = App.Services.Nat.GetTailscaleStatus();
        TailscaleStatusPanel.Visibility = Visibility.Visible;
        if (status == null)
        {
            TailscaleStateText.Text = "未登录";
            TailscaleStateText.Foreground = (Brush)FindResource("WarnBrush");
            TailscaleIpText.Text = "-";
            TailscalePeersText.Text = "请点击「登录 Tailscale」进行登录";
            LoginTailscaleBtn.Visibility = Visibility.Visible;
        }
        else
        {
            TailscaleStateText.Text = status.Online ? "已连接" : "未连接";
            TailscaleStateText.Foreground = status.Online ? (Brush)FindResource("AccentBrush") : (Brush)FindResource("WarnBrush");
            TailscaleIpText.Text = status.TailscaleIp;
            var onlinePeers = status.Peers.Where(p => p.Online).ToList();
            TailscalePeersText.Text = onlinePeers.Count > 0
                ? $"在线设备 ({onlinePeers.Count}): {string.Join(", ", onlinePeers.Select(p => p.HostName + "(" + p.TailscaleIp + ")"))}"
                : "暂无在线设备，好友登录同一账号后会显示在这里";
            LoginTailscaleBtn.Visibility = status.Online ? Visibility.Collapsed : Visibility.Visible;
        }
    }

    private void CopyTailscaleIp_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Clipboard.SetText(TailscaleIpText.Text);
            MessageBox.Show("Tailscale IP 已复制到剪贴板", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch { }
    }

    private async void DownloadTailscale_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.SaveFileDialog
        {
            FileName = "Tailscale-Setup.exe",
            Filter = "安装程序|*.exe"
        };
        if (dlg.ShowDialog() != true) return;

        DownloadTailscaleBtn.IsEnabled = false;
        DownloadTailscaleBtn.Content = "下载中...";
        try
        {
            var progress = new Progress<int>(p => DownloadTailscaleBtn.Content = $"下载中 {p}%");
            bool ok = await App.Services.Nat.DownloadTailscaleAsync(dlg.FileName, progress);
            if (ok)
            {
                var r = MessageBox.Show("Tailscale 下载完成！是否立即安装？", "下载完成", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (r == MessageBoxResult.Yes)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(dlg.FileName) { UseShellExecute = true });
            }
            else
            {
                MessageBox.Show("下载失败，请手动从官网下载", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("下载异常: " + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            DownloadTailscaleBtn.IsEnabled = true;
            DownloadTailscaleBtn.Content = "下载 Tailscale";
        }
    }

    private void OpenTailscaleWebsite_Click(object sender, RoutedEventArgs e)
    {
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(NatTraversalService.TailscaleWebsite) { UseShellExecute = true });
    }

    private void LoginTailscale_Click(object sender, RoutedEventArgs e)
    {
        bool ok = App.Services.Nat.StartTailscaleLogin();
        if (ok)
            MessageBox.Show("已启动 Tailscale 登录，请在浏览器中完成登录。登录后点击「检测状态」查看连接情况。", "登录 Tailscale", MessageBoxButton.OK, MessageBoxImage.Information);
        else
            MessageBox.Show("启动失败，请确保 Tailscale 已正确安装", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
    }

    private async void TryUpnp_Click(object sender, RoutedEventArgs e)
    {
        if (!int.TryParse(UpnpPortBox.Text, out int port) || port < 1 || port > 65535)
        {
            MessageBox.Show("请输入有效的端口号 (1-65535)", "错误", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        UpnpResultText.Text = "正在尝试 UPnP 端口映射...";
        try
        {
            var result = await App.Services.Nat.TryUpnpPortForwardAsync(port, "Minecraft Server");
            if (result != null && result.Success)
            {
                UpnpResultText.Text = $"映射成功！\n公网地址：{result.PublicIp}:{result.ExternalPort}\n内网地址：{result.InternalIp}:{result.InternalPort}\n好友可通过公网地址连接。注意：部分路由器/网络不支持 UPnP，如失败请使用 Tailscale 方案。";
            }
            else
            {
                UpnpResultText.Text = "UPnP 映射失败。你的路由器可能不支持 UPnP，或已禁用 UPnP。建议使用 Tailscale 方案（推荐）。";
            }
        }
        catch (Exception ex)
        {
            UpnpResultText.Text = "映射异常: " + ex.Message;
        }
    }

    private void OpenToolWebsite_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is string url && !string.IsNullOrEmpty(url))
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true });
    }
    #endregion
}

public class ThirdPartyToolVM
{
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string Url { get; set; } = "";
}

public class RoomInfo
{
    public string Name { get; set; } = "";
    public string Address { get; set; } = "";
    public string Info { get; set; } = "";
}
