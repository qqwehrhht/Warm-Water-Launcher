using System.IO.Compression;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

/// <summary>实例管理：多实例、三种隔离模式、复制、重命名、删除、导出</summary>
public class InstanceService
{
    private readonly SettingsService _settings;
    public InstanceService(SettingsService settings) => _settings = settings;

    public List<GameInstance> Instances => _settings.Config.Instances;

    public GameInstance? Current
    {
        get
        {
            var id = _settings.Config.CurrentInstanceId;
            return Instances.FirstOrDefault(i => i.Id == id) ?? Instances.FirstOrDefault();
        }
    }

    public GameInstance Create(string name, string versionId, string description = "")
    {
        name = name.Trim();
        if (string.IsNullOrEmpty(name)) throw new Exception("实例名称不能为空");
        var inst = new GameInstance { Name = name, VersionId = versionId, Description = description };
        Instances.Add(inst);
        _settings.Config.CurrentInstanceId = inst.Id;
        _settings.Save();
        return inst;
    }

    public void Delete(GameInstance inst)
    {
        // 删除实例目录（完全隔离时）
        try
        {
            if (!string.IsNullOrEmpty(inst.CustomGameDir) && Directory.Exists(inst.CustomGameDir))
                Directory.Delete(inst.CustomGameDir, true);
        }
        catch { }
        Instances.Remove(inst);
        if (_settings.Config.CurrentInstanceId == inst.Id)
            _settings.Config.CurrentInstanceId = Instances.FirstOrDefault()?.Id;
        _settings.Save();
    }

    public void Rename(GameInstance inst, string newName)
    {
        if (string.IsNullOrWhiteSpace(newName)) throw new Exception("名称不能为空");
        inst.Name = newName.Trim();
        _settings.Save();
    }

    /// <summary>复制实例（深拷贝配置，可选复制游戏目录）</summary>
    public GameInstance Clone(GameInstance src, string newName, bool copyFiles)
    {
        var clone = new GameInstance
        {
            Name = newName.Trim(),
            VersionId = src.VersionId,
            LoaderType = src.LoaderType,
            LoaderVersion = src.LoaderVersion,
            Description = src.Description,
            IsolateKey = src.IsolateKey
        };
        if (copyFiles && !string.IsNullOrEmpty(src.CustomGameDir) && Directory.Exists(src.CustomGameDir))
        {
            var newDir = Path.Combine(Path.GetDirectoryName(src.CustomGameDir)!, Sanitize(newName));
            CopyDir(src.CustomGameDir, newDir);
            clone.CustomGameDir = newDir;
        }
        Instances.Add(clone);
        _settings.Save();
        return clone;
    }

    /// <summary>导出备份为 zip</summary>
    public string Export(GameInstance inst, string zipPath)
    {
        string tmp = Path.Combine(Path.GetTempPath(), "ww_export_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(tmp);
        try
        {
            // 写入实例配置
            var cfg = new { inst.Id, inst.Name, inst.VersionId, inst.LoaderType, inst.LoaderVersion, inst.Description, inst.PlayCount };
            File.WriteAllText(Path.Combine(tmp, "instance.json"),
                System.Text.Json.JsonSerializer.Serialize(cfg, SettingsService.JsonOpts));
            // 写入游戏目录
            var gameDir = GetInstanceGameDir(inst);
            if (Directory.Exists(gameDir))
                CopyDir(gameDir, Path.Combine(tmp, "game"));
            if (File.Exists(zipPath)) File.Delete(zipPath);
            ZipFile.CreateFromDirectory(tmp, zipPath);
            return zipPath;
        }
        finally
        {
            try { Directory.Delete(tmp, true); } catch { }
        }
    }

    /// <summary>导入备份 zip</summary>
    public GameInstance? Import(string zipPath, string? newName = null)
    {
        string tmp = Path.Combine(Path.GetTempPath(), "ww_import_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(tmp);
        try
        {
            ZipFile.ExtractToDirectory(zipPath, tmp);
            var cfgPath = Path.Combine(tmp, "instance.json");
            if (!File.Exists(cfgPath)) return null;
            var cfg = System.Text.Json.JsonSerializer.Deserialize<InstanceCfg>(File.ReadAllText(cfgPath), SettingsService.JsonOpts);
            if (cfg == null) return null;
            var inst = new GameInstance
            {
                Name = newName ?? cfg.Name ?? Path.GetFileNameWithoutExtension(zipPath),
                VersionId = cfg.VersionId ?? "",
                LoaderType = cfg.LoaderType ?? "none",
                LoaderVersion = cfg.LoaderVersion,
                Description = cfg.Description ?? "",
                PlayCount = cfg.PlayCount
            };
            var gameDir = Path.Combine(GetIsolationRoot(), Sanitize(inst.Name));
            if (Directory.Exists(Path.Combine(tmp, "game")))
                CopyDir(Path.Combine(tmp, "game"), gameDir);
            inst.CustomGameDir = gameDir;
            Instances.Add(inst);
            _settings.Save();
            return inst;
        }
        finally
        {
            try { Directory.Delete(tmp, true); } catch { }
        }
    }

    private class InstanceCfg
    {
        public string? Name { get; set; }
        public string? VersionId { get; set; }
        public string? LoaderType { get; set; }
        public string? LoaderVersion { get; set; }
        public string? Description { get; set; }
        public int PlayCount { get; set; }
    }

    /// <summary>隔离根目录：instances 文件夹</summary>
    public string GetIsolationRoot()
    {
        string root = Path.Combine(_settings.GameRoot, "instances");
        Directory.CreateDirectory(root);
        return root;
    }

    public static string Sanitize(string name)
    {
        foreach (var c in Path.GetInvalidFileNameChars())
            name = name.Replace(c, '_');
        return name.Trim();
    }

    /// <summary>根据隔离模式计算实例的实际游戏目录</summary>
    public string GetInstanceGameDir(GameInstance inst)
    {
        var mode = IsolationModeHelper.Parse(_settings.Config.Launch.IsolationMode);
        return mode switch
        {
            IsolationMode.Global => _settings.GameRoot,
            IsolationMode.Full => inst.CustomGameDir ??= Path.Combine(GetIsolationRoot(), Sanitize(inst.Name)),
            _ => inst.CustomGameDir ??= Path.Combine(GetIsolationRoot(), Sanitize(inst.Name))
        };
    }

    /// <summary>实例的版本目录（完全隔离时使用实例内 versions）</summary>
    public string GetInstanceVersionsDir(GameInstance inst)
    {
        var mode = IsolationModeHelper.Parse(_settings.Config.Launch.IsolationMode);
        if (mode == IsolationMode.Global || mode == IsolationMode.Half)
            return _settings.GlobalVersionsDir;
        return Path.Combine(GetInstanceGameDir(inst), "versions");
    }

    /// <summary>确保实例所需版本文件就位（完全隔离时从全局复制）</summary>
    public void EnsureVersionFiles(GameInstance inst, string versionId)
    {
        var mode = IsolationModeHelper.Parse(_settings.Config.Launch.IsolationMode);
        if (mode != IsolationMode.Full) return;
        var srcDir = _settings.GlobalVersionsDir;
        var dstDir = Path.Combine(GetInstanceGameDir(inst), "versions", versionId);
        if (Directory.Exists(Path.Combine(srcDir, versionId)) && !Directory.Exists(dstDir))
            CopyDir(Path.Combine(srcDir, versionId), dstDir);
    }

    public static void CopyDir(string src, string dst)
    {
        Directory.CreateDirectory(dst);
        foreach (var file in Directory.GetFiles(src))
            File.Copy(file, Path.Combine(dst, Path.GetFileName(file)), true);
        foreach (var dir in Directory.GetDirectories(src))
            CopyDir(dir, Path.Combine(dst, Path.GetFileName(dir)));
    }

    /// <summary>快捷打开实例目录/日志目录</summary>
    public void OpenInExplorer(string path)
    {
        if (Directory.Exists(path))
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", path) { UseShellExecute = true });
    }
}
