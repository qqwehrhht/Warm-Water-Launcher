using System.IO;
using System.Windows;
using System.Windows.Media;
using WarmWaterLauncher.Models;
using System.Text.Json;
using System.Windows.Media.Imaging;

namespace WarmWaterLauncher.Services;

/// <summary>皮肤管理服务：皮肤库、预览、快速切换</summary>
public class SkinService
{
    private readonly SettingsService _settings;

    public SkinService(SettingsService settings) => _settings = settings;

    /// <summary>皮肤库目录</summary>
    public string SkinLibraryDir => Path.Combine(SettingsService.GetDataDir(), "skins");

    /// <summary>披风库目录</summary>
    public string CapeLibraryDir => Path.Combine(SettingsService.GetDataDir(), "capes");

    /// <summary>内置默认皮肤列表</summary>
    public static readonly (string Name, string Type)[] DefaultSkins =
    {
        ("Steve（经典）", "steve"),
        ("Alex（细臂）", "alex"),
    };

    /// <summary>初始化皮肤库目录</summary>
    public void EnsureDirs()
    {
        Directory.CreateDirectory(SkinLibraryDir);
        Directory.CreateDirectory(CapeLibraryDir);
    }

    /// <summary>获取皮肤库中的所有皮肤</summary>
    public List<SkinItem> GetSkinLibrary()
    {
        EnsureDirs();
        var list = new List<SkinItem>();

        // 添加默认皮肤
        list.Add(new SkinItem { Name = "Steve（经典）", FileName = "steve.png", IsDefault = true, Type = SkinType.Steve });
        list.Add(new SkinItem { Name = "Alex（细臂）", FileName = "alex.png", IsDefault = true, Type = SkinType.Alex });

        // 添加用户皮肤库中的皮肤
        foreach (var file in Directory.GetFiles(SkinLibraryDir, "*.png"))
        {
            var item = new SkinItem
            {
                Name = Path.GetFileNameWithoutExtension(file),
                FileName = Path.GetFileName(file),
                FullPath = file,
                IsDefault = false,
                Type = DetectSkinType(file)
            };
            list.Add(item);
        }
        return list;
    }

    /// <summary>获取披风库中的所有披风</summary>
    public List<CapeItem> GetCapeLibrary()
    {
        EnsureDirs();
        var list = new List<CapeItem>();
        list.Add(new CapeItem { Name = "无披风", FileName = "", IsDefault = true });
        foreach (var file in Directory.GetFiles(CapeLibraryDir, "*.png"))
        {
            list.Add(new CapeItem
            {
                Name = Path.GetFileNameWithoutExtension(file),
                FileName = Path.GetFileName(file),
                FullPath = file,
                IsDefault = false
            });
        }
        return list;
    }

    /// <summary>导入皮肤到皮肤库</summary>
    public string? ImportSkin(string sourcePath, string? customName = null)
    {
        try
        {
            EnsureDirs();
            if (!File.Exists(sourcePath)) return null;
            string name = customName ?? Path.GetFileNameWithoutExtension(sourcePath);
            string dest = Path.Combine(SkinLibraryDir, name + ".png");
            File.Copy(sourcePath, dest, true);
            return dest;
        }
        catch { return null; }
    }

    /// <summary>导入披风到披风库</summary>
    public string? ImportCape(string sourcePath, string? customName = null)
    {
        try
        {
            EnsureDirs();
            if (!File.Exists(sourcePath)) return null;
            string name = customName ?? Path.GetFileNameWithoutExtension(sourcePath);
            string dest = Path.Combine(CapeLibraryDir, name + ".png");
            File.Copy(sourcePath, dest, true);
            return dest;
        }
        catch { return null; }
    }

    /// <summary>为当前账号应用皮肤</summary>
    public bool ApplySkin(Account acct, SkinItem skin)
    {
        try
        {
            if (skin.IsDefault)
            {
                // 默认皮肤：清除自定义皮肤路径
                acct.SkinPath = null;
            }
            else if (!string.IsNullOrEmpty(skin.FullPath) && File.Exists(skin.FullPath))
            {
                acct.SkinPath = skin.FullPath;
            }
            _settings.Save();
            return true;
        }
        catch { return false; }
    }

    /// <summary>为当前账号应用披风</summary>
    public bool ApplyCape(Account acct, CapeItem cape)
    {
        try
        {
            if (cape.IsDefault || string.IsNullOrEmpty(cape.FullPath))
            {
                acct.CapePath = null;
            }
            else if (File.Exists(cape.FullPath))
            {
                acct.CapePath = cape.FullPath;
            }
            _settings.Save();
            return true;
        }
        catch { return false; }
    }

    /// <summary>删除皮肤库中的皮肤</summary>
    public bool DeleteSkin(SkinItem skin)
    {
        try
        {
            if (skin.IsDefault) return false;
            if (!string.IsNullOrEmpty(skin.FullPath) && File.Exists(skin.FullPath))
                File.Delete(skin.FullPath);
            return true;
        }
        catch { return false; }
    }

    /// <summary>检测皮肤类型（Steve 粗臂 / Alex 细臂）</summary>
    public SkinType DetectSkinType(string filePath)
    {
        try
        {
            var bmp = new BitmapImage(new Uri(filePath));
            // 64x64 是新版格式，64x32 是旧版格式
            // Alex 皮肤在 64x64 格式中手臂区域有特定像素，但简单判断用文件名或默认
            return SkinType.Steve;
        }
        catch { return SkinType.Steve; }
    }

    /// <summary>直接加载原始皮肤图片（最清晰，不重新渲染）</summary>
    public BitmapImage? LoadRawSkin(string? skinPath)
    {
        try
        {
            if (string.IsNullOrEmpty(skinPath) || !File.Exists(skinPath)) return null;
            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.UriSource = new Uri(skinPath);
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.EndInit();
            bmp.Freeze();
            return bmp;
        }
        catch { return null; }
    }

    /// <summary>生成皮肤预览（正面）</summary>
    public BitmapSource? GenerateSkinPreview(string? skinPath, int scale = 8)
    {
        try
        {
            if (string.IsNullOrEmpty(skinPath) || !File.Exists(skinPath))
                return GenerateDefaultPreview(scale);

            var skin = new BitmapImage(new Uri(skinPath));
            int w = skin.PixelWidth;
            int h = skin.PixelHeight;

            // 创建预览画布（头部+身体+手臂+腿）
            int previewW = 16 * scale;
            int previewH = 32 * scale;
            var visual = new DrawingVisual();
            using (var dc = visual.RenderOpen())
            {
                // 背景透明
                // 头部 (8x8) 位置 (4, 0)
                DrawRegion(dc, skin, 8, 8, 8, 8, 4 * scale, 0, scale);
                // 身体 (8x12) 位置 (4, 8)
                DrawRegion(dc, skin, 20, 20, 8, 12, 4 * scale, 8 * scale, scale);
                // 左臂 (4x12) 位置 (0, 8)
                DrawRegion(dc, skin, 44, 20, 4, 12, 0, 8 * scale, scale);
                // 右臂 (4x12) 位置 (12, 8)
                DrawRegion(dc, skin, 36, 52, 4, 12, 12 * scale, 8 * scale, scale);
                // 左腿 (4x12) 位置 (4, 20)
                DrawRegion(dc, skin, 4, 20, 4, 12, 4 * scale, 20 * scale, scale);
                // 右腿 (4x12) 位置 (8, 20)
                DrawRegion(dc, skin, 20, 52, 4, 12, 8 * scale, 20 * scale, scale);
            }

            var bmp = new RenderTargetBitmap(previewW, previewH, 96, 96, System.Windows.Media.PixelFormats.Pbgra32);
            bmp.Render(visual);
            return bmp;
        }
        catch
        {
            return GenerateDefaultPreview(scale);
        }
    }

    private void DrawRegion(DrawingContext dc, BitmapImage skin, int srcX, int srcY, int srcW, int srcH, int dstX, int dstY, int scale)
    {
        try
        {
            var cropped = new CroppedBitmap(skin, new Int32Rect(srcX, srcY, srcW, srcH));
            // 使用最近邻插值，保持像素艺术的清晰边缘
            RenderOptions.SetBitmapScalingMode(cropped, BitmapScalingMode.NearestNeighbor);
            dc.DrawImage(cropped, new System.Windows.Rect(dstX, dstY, srcW * scale, srcH * scale));
        }
        catch { }
    }

    /// <summary>生成默认 Steve 预览</summary>
    public BitmapSource GenerateDefaultPreview(int scale = 8)
    {
        int previewW = 16 * scale;
        int previewH = 32 * scale;
        var visual = new DrawingVisual();
        using (var dc = visual.RenderOpen())
        {
            // 简单的 Steve 颜色块预览
            var skinColor = new SolidColorBrush(System.Windows.Media.Color.FromRgb(177, 130, 89));
            var shirtColor = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 114, 178));
            var pantsColor = new SolidColorBrush(System.Windows.Media.Color.FromRgb(65, 65, 130));
            var hairColor = new SolidColorBrush(System.Windows.Media.Color.FromRgb(60, 37, 15));

            // 头
            dc.DrawRectangle(skinColor, null, new System.Windows.Rect(4 * scale, 0, 8 * scale, 8 * scale));
            dc.DrawRectangle(hairColor, null, new System.Windows.Rect(4 * scale, 0, 8 * scale, 3 * scale));
            // 身体
            dc.DrawRectangle(shirtColor, null, new System.Windows.Rect(4 * scale, 8 * scale, 8 * scale, 12 * scale));
            // 手臂
            dc.DrawRectangle(shirtColor, null, new System.Windows.Rect(0, 8 * scale, 4 * scale, 12 * scale));
            dc.DrawRectangle(shirtColor, null, new System.Windows.Rect(12 * scale, 8 * scale, 4 * scale, 12 * scale));
            // 腿
            dc.DrawRectangle(pantsColor, null, new System.Windows.Rect(4 * scale, 20 * scale, 4 * scale, 12 * scale));
            dc.DrawRectangle(pantsColor, null, new System.Windows.Rect(8 * scale, 20 * scale, 4 * scale, 12 * scale));
        }
        var bmp = new RenderTargetBitmap(previewW, previewH, 96, 96, System.Windows.Media.PixelFormats.Pbgra32);
        bmp.Render(visual);
        return bmp;
    }
}

#region 模型
public enum SkinType { Steve, Alex }

public class SkinItem
{
    public string Name { get; set; } = "";
    public string FileName { get; set; } = "";
    public string? FullPath { get; set; }
    public bool IsDefault { get; set; }
    public SkinType Type { get; set; }
    public string TypeName => Type == SkinType.Alex ? "细臂" : "粗臂";
}

public class CapeItem
{
    public string Name { get; set; } = "";
    public string FileName { get; set; } = "";
    public string? FullPath { get; set; }
    public bool IsDefault { get; set; }
}
#endregion
