using System.Text.Json;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

public class ResourceEntry
{
    public string Name { get; set; } = "";
    public string FullPath { get; set; } = "";
    public bool Enabled { get; set; } = true;
    public long Size { get; set; }
    public string? Description { get; set; }
    public string? PackFormat { get; set; }
}

/// <summary>资源管理：材质包、光影、存档、服务器</summary>
public class ResourceService
{
    private readonly SettingsService _settings;
    private readonly InstanceService _instances;
    public ResourceService(SettingsService settings, InstanceService instances)
    {
        _settings = settings;
        _instances = instances;
    }

    // ---- 材质包 / 资源包 ----
    public List<ResourceEntry> ListResourcePacks(GameInstance inst)
    {
        var dir = Path.Combine(_instances.GetInstanceGameDir(inst), "resourcepacks");
        return ListPacks(dir);
    }

    // ---- 光影包 ----
    public List<ResourceEntry> ListShaderPacks(GameInstance inst)
    {
        var dir = Path.Combine(_instances.GetInstanceGameDir(inst), "shaderpacks");
        return ListPacks(dir);
    }

    private List<ResourceEntry> ListPacks(string dir)
    {
        var result = new List<ResourceEntry>();
        if (!Directory.Exists(dir)) return result;
        foreach (var f in Directory.GetFiles(dir).Where(f => f.EndsWith(".zip") || f.EndsWith(".jar")))
        {
            bool enabled = !f.EndsWith(".disabled");
            string display = enabled ? Path.GetFileName(f) : Path.GetFileName(f)[..^".disabled".Length];
            var entry = new ResourceEntry
            {
                Name = display,
                FullPath = f,
                Enabled = enabled,
                Size = new FileInfo(f).Length
            };
            ReadPackMeta(entry);
            result.Add(entry);
        }
        // 文件夹形式（已解压材质包）
        foreach (var d in Directory.GetDirectories(dir))
        {
            if (d.EndsWith(".disabled")) continue;
            result.Add(new ResourceEntry { Name = Path.GetFileName(d), FullPath = d, Enabled = true });
        }
        return result;
    }

    private void ReadPackMeta(ResourceEntry entry)
    {
        try
        {
            using var zip = System.IO.Compression.ZipFile.OpenRead(entry.FullPath);
            var e = zip.GetEntry("pack.mcmeta");
            if (e == null) return;
            using var sr = new StreamReader(e.Open());
            using var doc = JsonDocument.Parse(sr.ReadToEnd());
            var pack = doc.RootElement.GetProperty("pack");
            entry.Description = pack.TryGetProperty("description", out var d) ? d.GetString() : null;
            entry.PackFormat = pack.TryGetProperty("pack_format", out var pf) ? pf.ToString() : null;
        }
        catch { }
    }

    public void TogglePack(ResourceEntry entry)
    {
        if (entry.Enabled)
        {
            if (Directory.Exists(entry.FullPath)) Directory.Move(entry.FullPath, entry.FullPath + ".disabled");
            else File.Move(entry.FullPath, entry.FullPath + ".disabled");
        }
        else
        {
            if (Directory.Exists(entry.FullPath + ".disabled")) Directory.Move(entry.FullPath + ".disabled", entry.FullPath);
            else File.Move(entry.FullPath + ".disabled", entry.FullPath);
        }
        entry.Enabled = !entry.Enabled;
    }

    public void DeleteResource(ResourceEntry entry)
    {
        if (Directory.Exists(entry.FullPath)) Directory.Delete(entry.FullPath, true);
        else if (File.Exists(entry.FullPath)) File.Delete(entry.FullPath);
    }

    // ---- 存档 ----
    public List<ResourceEntry> ListSaves(GameInstance inst)
    {
        var dir = Path.Combine(_instances.GetInstanceGameDir(inst), "saves");
        var result = new List<ResourceEntry>();
        if (!Directory.Exists(dir)) return result;
        foreach (var d in Directory.GetDirectories(dir))
        {
            long size = 0;
            try { size = DirSize(d); } catch { }
            string? desc = null, levelType = null;
            try
            {
                var lvl = Path.Combine(d, "level.dat");
                if (File.Exists(lvl))
                {
                    // level.dat 是 gzip 的 NBT，只读首段获取 LevelName
                    desc = ReadLevelName(d);
                }
            }
            catch { }
            result.Add(new ResourceEntry { Name = Path.GetFileName(d), FullPath = d, Enabled = true, Size = size, Description = desc });
        }
        return result.OrderByDescending(s => s.Size).ToList();
    }

    private static string ReadLevelName(string saveDir)
    {
        try
        {
            var lvl = Path.Combine(saveDir, "level.dat");
            if (!File.Exists(lvl)) return "";
            using var fs = File.OpenRead(lvl);
            using var gz = new System.IO.Compression.GZipStream(fs, System.IO.Compression.CompressionMode.Decompress);
            // NBT: 直接搜索可读文本中的 LevelName
            using var reader = new StreamReader(gz, System.Text.Encoding.UTF8);
            var text = reader.ReadToEnd();
            var m = System.Text.RegularExpressions.Regex.Match(text, "LevelName.{1,20}?([\\u4e00-\\u9fa5\\w ]{1,60})");
            if (m.Success) return m.Groups[1].Value.Trim();
        }
        catch { }
        return "";
    }

    private static long DirSize(string dir)
    {
        long size = 0;
        foreach (var f in Directory.GetFiles(dir, "*", SearchOption.AllDirectories))
        {
            try { size += new FileInfo(f).Length; } catch { }
        }
        return size;
    }

    /// <summary>格式化大小</summary>
    public static string FormatSize(long bytes)
    {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024.0).ToString("0.0") + " KB";
        if (bytes < 1024 * 1024 * 1024) return (bytes / 1024.0 / 1024.0).ToString("0.0") + " MB";
        return (bytes / 1024.0 / 1024.0 / 1024.0).ToString("0.00") + " GB";
    }

    // ---- 服务器列表 ----
    public List<ServerEntry> Servers => _settings.Config.Servers;
    public void AddServer(string name, string address, string? version, string? desc)
    {
        _settings.Config.Servers.Add(new ServerEntry { Name = name, Address = address, Version = version, Description = desc });
        _settings.Save();
    }
    public void RemoveServer(ServerEntry s)
    {
        _settings.Config.Servers.Remove(s);
        _settings.Save();
    }
}
