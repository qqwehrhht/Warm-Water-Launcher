using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace WarmWaterLauncher.Services;

/// <summary>微软账号 OAuth 登录服务（正版登录，设备代码流）</summary>
public class MicrosoftAuthService
{
    private readonly DownloadService _dl;
    // 使用 Prism Launcher 公开的 Azure AD 客户端 ID（支持设备代码流，第三方应用，无需预授权）
    private const string ClientId = "c36a9fb6-4f2a-41ff-90bd-ae7cc92031eb";
    private const string Scope = "XboxLive.signin offline_access";

    public MicrosoftAuthService(DownloadService dl) => _dl = dl;

    /// <summary>启动微软登录流程（设备代码流，和 PCL 一样的登录方式）</summary>
    public async Task<MicrosoftAccount?> LoginAsync(IProgress<string>? progress = null, CancellationToken ct = default)
    {
        try
        {
            progress?.Report("正在获取登录验证码...");

            // 1. 请求设备代码
            var deviceCode = await RequestDeviceCodeAsync();
            if (deviceCode == null)
            {
                progress?.Report("获取登录验证码失败，请检查网络连接");
                return null;
            }

            // 2. 显示设备代码并打开浏览器
            string code = deviceCode.UserCode;
            string uri = deviceCode.VerificationUri;
            progress?.Report($"请在浏览器中打开：{uri}\n输入验证码：{code}\n\n代码 {deviceCode.ExpiresIn / 60} 分钟内有效，完成登录后启动器将自动检测。");

            // 自动打开浏览器
            try { Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true }); } catch { }

            // 3. 轮询等待登录完成
            var msToken = await PollForTokenAsync(deviceCode.DeviceCode, deviceCode.Interval, progress, ct);
            if (msToken == null)
            {
                progress?.Report("登录超时或被取消，请重试");
                return null;
            }

            // 4. 完成后续登录流程
            return await CompleteLoginWithTokenAsync(msToken, progress);
        }
        catch (OperationCanceledException)
        {
            progress?.Report("登录已取消");
            return null;
        }
        catch (Exception ex)
        {
            progress?.Report("登录异常: " + ex.Message);
            return null;
        }
    }

    private async Task<MicrosoftAccount?> CompleteLoginWithTokenAsync(MsTokenResponse msToken, IProgress<string>? progress)
    {
        try
        {
            progress?.Report("正在验证 Xbox Live 身份...");
            var xblToken = await AuthenticateXboxLiveAsync(msToken.AccessToken);
            if (xblToken == null) { progress?.Report("Xbox Live 验证失败"); return null; }

            progress?.Report("正在获取 Minecraft 访问令牌...");
            var xstsToken = await AuthenticateXstsAsync(xblToken.Token);
            if (xstsToken == null) { progress?.Report("XSTS 验证失败（可能账号未购买 Minecraft）"); return null; }

            var mcToken = await GetMinecraftTokenAsync(xstsToken.DisplayClaims.UserHash, xstsToken.Token);
            if (mcToken == null) { progress?.Report("获取 Minecraft 令牌失败"); return null; }

            progress?.Report("正在获取玩家档案...");
            var profile = await GetMinecraftProfileAsync(mcToken.AccessToken);
            if (profile == null) { progress?.Report("获取玩家档案失败（可能账号未购买 Minecraft）"); return null; }

            progress?.Report($"登录成功！欢迎 {profile.Name}");
            // 使用 Crafatar 服务获取头像（通过 UUID）
            string avatarUrl = $"https://crafatar.com/avatars/{profile.Id}?size=128&overlay";
            return new MicrosoftAccount
            {
                Name = profile.Name,
                Uuid = profile.Id,
                AccessToken = mcToken.AccessToken,
                RefreshToken = msToken.RefreshToken,
                ExpiresAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds() + mcToken.ExpiresIn,
                Type = "microsoft",
                AvatarUrl = avatarUrl
            };
        }
        catch (Exception ex)
        {
            progress?.Report("登录异常: " + ex.Message);
            return null;
        }
    }

    /// <summary>刷新微软账号令牌</summary>
    public async Task<bool> RefreshTokenAsync(MicrosoftAccount account)
    {
        try
        {
            var msToken = await RefreshMicrosoftTokenAsync(account.RefreshToken);
            if (msToken == null) return false;
            var xblToken = await AuthenticateXboxLiveAsync(msToken.AccessToken);
            if (xblToken == null) return false;
            var xstsToken = await AuthenticateXstsAsync(xblToken.Token);
            if (xstsToken == null) return false;
            var mcToken = await GetMinecraftTokenAsync(xstsToken.DisplayClaims.UserHash, xstsToken.Token);
            if (mcToken == null) return false;
            account.AccessToken = mcToken.AccessToken;
            account.RefreshToken = msToken.RefreshToken ?? account.RefreshToken;
            account.ExpiresAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds() + mcToken.ExpiresIn;
            return true;
        }
        catch { return false; }
    }

    #region 设备代码流 API
    private async Task<DeviceCodeResponse?> RequestDeviceCodeAsync()
    {
        try
        {
            var content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["client_id"] = ClientId,
                ["scope"] = Scope
            });
            var resp = await _dl.Http.Client.PostAsync(
                "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode", content);
            if (!resp.IsSuccessStatusCode)
            {
                var err = await resp.Content.ReadAsStringAsync();
                Debug.WriteLine("RequestDeviceCodeAsync error: " + resp.StatusCode + " - " + err);
                return null;
            }
            var json = await resp.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<DeviceCodeResponse>(json, SettingsService.JsonOpts);
        }
        catch (Exception ex)
        {
            Debug.WriteLine("RequestDeviceCodeAsync exception: " + ex.Message);
            return null;
        }
    }

    private async Task<MsTokenResponse?> PollForTokenAsync(string deviceCode, int interval,
        IProgress<string>? progress, CancellationToken ct)
    {
        int maxAttempts = 180; // 最多轮询 180 次（约 15 分钟）
        for (int i = 0; i < maxAttempts; i++)
        {
            ct.ThrowIfCancellationRequested();
            await Task.Delay(interval * 1000, ct);
            try
            {
                var content = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"] = "urn:ietf:params:oauth:grant-type:device_code",
                    ["client_id"] = ClientId,
                    ["device_code"] = deviceCode
                });
                var resp = await _dl.Http.Client.PostAsync(
                    "https://login.microsoftonline.com/consumers/oauth2/v2.0/token", content);
                var json = await resp.Content.ReadAsStringAsync();
                if (resp.IsSuccessStatusCode)
                    return JsonSerializer.Deserialize<MsTokenResponse>(json, SettingsService.JsonOpts);

                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("error", out var errorEl))
                {
                    string error = errorEl.GetString() ?? "";
                    if (error == "authorization_pending") continue;
                    if (error == "slow_down") { interval += 2; continue; }
                    if (error == "expired_token") { progress?.Report("验证码已过期，请重新登录"); return null; }
                    if (error == "access_denied") { progress?.Report("用户拒绝了授权"); return null; }
                    progress?.Report($"登录错误: {error}");
                    return null;
                }
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                Debug.WriteLine("PollForTokenAsync error: " + ex.Message);
                // 网络错误，继续重试
            }
        }
        return null;
    }
    #endregion

    #region 令牌刷新 API
    private async Task<MsTokenResponse?> RefreshMicrosoftTokenAsync(string refreshToken)
    {
        try
        {
            var content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["client_id"] = ClientId,
                ["refresh_token"] = refreshToken,
                ["grant_type"] = "refresh_token",
                ["scope"] = Scope
            });
            var resp = await _dl.Http.Client.PostAsync(
                "https://login.microsoftonline.com/consumers/oauth2/v2.0/token", content);
            resp.EnsureSuccessStatusCode();
            var json = await resp.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<MsTokenResponse>(json, SettingsService.JsonOpts);
        }
        catch { return null; }
    }
    #endregion

    #region Xbox Live / Minecraft API
    private async Task<XblResponse?> AuthenticateXboxLiveAsync(string msAccessToken)
    {
        try
        {
            var body = new
            {
                Properties = new { AuthMethod = "RPS", SiteName = "user.auth.xboxlive.com", RpsTicket = "d=" + msAccessToken },
                RelyingParty = "http://auth.xboxlive.com",
                TokenType = "JWT"
            };
            var json = JsonSerializer.Serialize(body);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var resp = await _dl.Http.Client.PostAsync("https://user.auth.xboxlive.com/user/authenticate", content);
            resp.EnsureSuccessStatusCode();
            var respJson = await resp.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<XblResponse>(respJson, SettingsService.JsonOpts);
        }
        catch (Exception ex)
        {
            Debug.WriteLine("AuthenticateXboxLiveAsync error: " + ex.Message);
            return null;
        }
    }

    private async Task<XstsResponse?> AuthenticateXstsAsync(string xblToken)
    {
        try
        {
            var body = new
            {
                Properties = new { SandboxId = "RETAIL", UserTokens = new[] { xblToken } },
                RelyingParty = "rp://api.minecraftservices.com/",
                TokenType = "JWT"
            };
            var json = JsonSerializer.Serialize(body);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var resp = await _dl.Http.Client.PostAsync("https://xsts.auth.xboxlive.com/xsts/authorize", content);
            if (!resp.IsSuccessStatusCode) return null;
            var respJson = await resp.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<XstsResponse>(respJson, SettingsService.JsonOpts);
        }
        catch { return null; }
    }

    private async Task<McTokenResponse?> GetMinecraftTokenAsync(string userHash, string xstsToken)
    {
        try
        {
            var body = new { identityToken = $"XBL3.0 x={userHash};{xstsToken}" };
            var json = JsonSerializer.Serialize(body);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var resp = await _dl.Http.Client.PostAsync("https://api.minecraftservices.com/authentication/login_with_xbox", content);
            resp.EnsureSuccessStatusCode();
            var respJson = await resp.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<McTokenResponse>(respJson, SettingsService.JsonOpts);
        }
        catch { return null; }
    }

    private async Task<McProfile?> GetMinecraftProfileAsync(string mcAccessToken)
    {
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, "https://api.minecraftservices.com/minecraft/profile");
            req.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", mcAccessToken);
            var resp = await _dl.Http.Client.SendAsync(req);
            resp.EnsureSuccessStatusCode();
            var json = await resp.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<McProfile>(json, SettingsService.JsonOpts);
        }
        catch { return null; }
    }
    #endregion
}

#region 响应模型
public class MicrosoftAccount
{
    public string Name { get; set; } = "";
    public string Uuid { get; set; } = "";
    public string AccessToken { get; set; } = "";
    public string RefreshToken { get; set; } = "";
    public long ExpiresAt { get; set; }
    public string Type { get; set; } = "microsoft";
    public string? AvatarUrl { get; set; }
}

public class DeviceCodeResponse
{
    [System.Text.Json.Serialization.JsonPropertyName("user_code")] public string UserCode { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("device_code")] public string DeviceCode { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("verification_uri")] public string VerificationUri { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("expires_in")] public int ExpiresIn { get; set; }
    [System.Text.Json.Serialization.JsonPropertyName("interval")] public int Interval { get; set; } = 5;
    [System.Text.Json.Serialization.JsonPropertyName("message")] public string Message { get; set; } = "";
}

public class MsTokenResponse
{
    [System.Text.Json.Serialization.JsonPropertyName("access_token")] public string AccessToken { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("refresh_token")] public string? RefreshToken { get; set; }
    [System.Text.Json.Serialization.JsonPropertyName("expires_in")] public int ExpiresIn { get; set; }
}

public class XblResponse
{
    [System.Text.Json.Serialization.JsonPropertyName("Token")] public string Token { get; set; } = "";
}

public class XstsResponse
{
    [System.Text.Json.Serialization.JsonPropertyName("Token")] public string Token { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("DisplayClaims")] public XstsDisplayClaims DisplayClaims { get; set; } = new();
}

public class XstsDisplayClaims
{
    [System.Text.Json.Serialization.JsonPropertyName("xui")] public List<XuiClaim> Xui { get; set; } = new();
    public string UserHash => Xui.Count > 0 ? Xui[0].Uhs : "";
}

public class XuiClaim
{
    [System.Text.Json.Serialization.JsonPropertyName("uhs")] public string Uhs { get; set; } = "";
}

public class McTokenResponse
{
    [System.Text.Json.Serialization.JsonPropertyName("access_token")] public string AccessToken { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("expires_in")] public int ExpiresIn { get; set; }
}

public class McProfile
{
    [System.Text.Json.Serialization.JsonPropertyName("id")] public string Id { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("name")] public string Name { get; set; } = "";
}
#endregion
