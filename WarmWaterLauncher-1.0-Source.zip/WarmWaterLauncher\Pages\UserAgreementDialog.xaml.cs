using System.Windows;

namespace WarmWaterLauncher.Pages;

public partial class UserAgreementDialog : Window
{
    public bool Agreed { get; private set; }

    public UserAgreementDialog()
    {
        InitializeComponent();
    }

    private void Agree_Click(object sender, RoutedEventArgs e)
    {
        Agreed = true;
        DialogResult = true;
        Close();
    }

    private void Disagree_Click(object sender, RoutedEventArgs e)
    {
        Agreed = false;
        var result = MessageBox.Show("你确定不同意用户协议吗？\n\n不同意将无法使用本启动器，程序将自动退出。",
            "确认退出", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (result == MessageBoxResult.Yes)
        {
            DialogResult = false;
            Close();
        }
    }
}
