using System.Windows;

namespace WarmWaterLauncher.Pages;

public partial class DirectConnectDialog : Window
{
    public string Address { get; private set; } = "";

    public DirectConnectDialog()
    {
        InitializeComponent();
        // 预填当前值
        var cur = App.Services.Settings.Config.Launch.DirectConnect;
        if (!string.IsNullOrEmpty(cur)) AddrBox.Text = cur;
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(AddrBox.Text))
        {
            MessageBox.Show("请输入服务器地址", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        Address = AddrBox.Text.Trim();
        DialogResult = true;
    }
}
