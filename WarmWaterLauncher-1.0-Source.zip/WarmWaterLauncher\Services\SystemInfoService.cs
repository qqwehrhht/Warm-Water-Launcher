using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32;

namespace WarmWaterLauncher.Services;

/// <summary>系统信息检测服务</summary>
public class SystemInfoService
{
    /// <summary>Windows 版本枚举</summary>
    public enum WindowsVersion
    {
        Unknown,
        WindowsXP,
        WindowsVista,
        Windows7,
        Windows8,
        Windows81,
        Windows10,
        Windows11,
        WindowsServer
    }

    /// <summary>系统信息</summary>
    public class SysInfo
    {
        public WindowsVersion Version { get; set; } = WindowsVersion.Unknown;
        public string VersionString { get; set; } = "未知";
        public string BuildNumber { get; set; } = "";
        public bool Is64Bit { get; set; }
        public long TotalMemoryMB { get; set; }
        public long AvailableMemoryMB { get; set; }
        public string CpuName { get; set; } = "未知";
        public int CpuCores { get; set; }
        public int CpuLogicalProcessors { get; set; }
        public string GpuName { get; set; } = "未知";
        public long GpuMemoryMB { get; set; }
        public string DotNetVersion { get; set; } = "";
        public bool IsSupported { get; set; }
        public string SupportMessage { get; set; } = "";
        public List<string> Optimizations { get; set; } = new();
    }

    [DllImport("kernel32.dll")]
    private static extern void GetNativeSystemInfo(ref SYSTEM_INFO lpSystemInfo);

    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);

    [StructLayout(LayoutKind.Sequential)]
    private struct SYSTEM_INFO
    {
        public ushort wProcessorArchitecture;
        public ushort wReserved;
        public uint dwPageSize;
        public IntPtr lpMinimumApplicationAddress;
        public IntPtr lpMaximumApplicationAddress;
        public UIntPtr dwActiveProcessorMask;
        public uint dwNumberOfProcessors;
        public uint dwProcessorType;
        public uint dwAllocationGranularity;
        public ushort wProcessorLevel;
        public ushort wProcessorRevision;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    /// <summary>检测系统信息</summary>
    public SysInfo Detect()
    {
        var info = new SysInfo();
        try
        {
            // Windows 版本
            var os = Environment.OSVersion;
            info.BuildNumber = os.Version.Build.ToString();
            info.Is64Bit = Environment.Is64BitOperatingSystem;

            // 解析版本
            int major = os.Version.Major;
            int minor = os.Version.Minor;
            int build = os.Version.Build;

            if (major == 5)
            {
                info.Version = minor == 1 ? WindowsVersion.WindowsXP : WindowsVersion.WindowsVista;
            }
            else if (major == 6)
            {
                if (minor == 0) info.Version = WindowsVersion.WindowsVista;
                else if (minor == 1) info.Version = WindowsVersion.Windows7;
                else if (minor == 2) info.Version = WindowsVersion.Windows8;
                else if (minor == 3) info.Version = WindowsVersion.Windows81;
            }
            else if (major == 10)
            {
                // Windows 11 是 build 22000+
                info.Version = build >= 22000 ? WindowsVersion.Windows11 : WindowsVersion.Windows10;
            }

            info.VersionString = info.Version switch
            {
                WindowsVersion.WindowsXP => "Windows XP",
                WindowsVersion.WindowsVista => "Windows Vista",
                WindowsVersion.Windows7 => "Windows 7",
                WindowsVersion.Windows8 => "Windows 8",
                WindowsVersion.Windows81 => "Windows 8.1",
                WindowsVersion.Windows10 => "Windows 10",
                WindowsVersion.Windows11 => "Windows 11",
                WindowsVersion.WindowsServer => "Windows Server",
                _ => $"未知 (NT {major}.{minor})"
            };

            // 内存
            var mem = new MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>() };
            if (GlobalMemoryStatusEx(ref mem))
            {
                info.TotalMemoryMB = (long)(mem.ullTotalPhys / 1024 / 1024);
                info.AvailableMemoryMB = (long)(mem.ullAvailPhys / 1024 / 1024);
            }

            // CPU / GPU (注册表方式，避免 System.Management 依赖)
            try
            {
                // CPU 名称从注册表读取
                using (var key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0"))
                {
                    if (key != null)
                    {
                        info.CpuName = key.GetValue("ProcessorNameString")?.ToString()?.Trim() ?? "未知";
                    }
                }
                info.CpuCores = Environment.ProcessorCount;
                info.CpuLogicalProcessors = Environment.ProcessorCount;
            }
            catch { }

            try
            {
                // GPU 名称从注册表读取
                using (var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000"))
                {
                    if (key != null)
                    {
                        info.GpuName = key.GetValue("DriverDesc")?.ToString()?.Trim() ?? "未知";
                    }
                }
            }
            catch { }

            // .NET 版本
            info.DotNetVersion = RuntimeInformation.FrameworkDescription;

            // 支持性判断
            EvaluateSupport(info);
        }
        catch (Exception ex)
        {
            info.SupportMessage = $"系统检测异常：{ex.Message}";
        }
        return info;
    }

    private void EvaluateSupport(SysInfo info)
    {
        var unsupported = new[] { WindowsVersion.WindowsXP, WindowsVersion.WindowsVista, WindowsVersion.Windows7, WindowsVersion.Windows8, WindowsVersion.Windows81 };

        if (Array.Exists(unsupported, v => v == info.Version))
        {
            info.IsSupported = false;
            info.SupportMessage = $"⚠️ 你的系统是 {info.VersionString}，本启动器基于 .NET 8 开发，最低要求 Windows 10 (1607+)。\n\n" +
                $"在 {info.VersionString} 上可能无法启动或运行异常。\n\n" +
                $"建议：\n" +
                $"1. 升级到 Windows 10 或 Windows 11\n" +
                $"2. 或使用支持旧系统的启动器（如 PCL2、HMCL）";
            info.Optimizations.Add("系统版本过低，建议升级");
        }
        else
        {
            info.IsSupported = true;
            info.SupportMessage = $"✅ 系统 {info.VersionString} 兼容本启动器";
        }

        // 内存优化建议
        if (info.TotalMemoryMB > 0)
        {
            if (info.TotalMemoryMB < 4096)
            {
                info.Optimizations.Add($"内存仅 {info.TotalMemoryMB}MB，建议游戏内存设为 1024-2048MB");
                info.Optimizations.Add("关闭后台程序释放内存");
            }
            else if (info.TotalMemoryMB < 8192)
            {
                info.Optimizations.Add($"内存 {info.TotalMemoryMB}MB，建议游戏内存设为 2048-4096MB");
            }
            else
            {
                info.Optimizations.Add($"内存 {info.TotalMemoryMB}MB，建议游戏内存设为 4096-8192MB");
            }
        }

        // CPU 优化建议
        if (info.CpuCores > 0 && info.CpuCores <= 2)
        {
            info.Optimizations.Add($"CPU 仅 {info.CpuCores} 核，建议关闭启动器动画效果");
            info.Optimizations.Add("游戏内降低渲染距离和粒子效果");
        }

        // 低版本系统专属优化
        if (info.Version == WindowsVersion.Windows7 || info.Version == WindowsVersion.Windows8 || info.Version == WindowsVersion.Windows81)
        {
            info.Optimizations.Add("【旧系统优化】自动禁用硬件加速动画");
            info.Optimizations.Add("【旧系统优化】自动降低 UI 渲染质量");
            info.Optimizations.Add("【旧系统优化】建议使用 BMCLAPI 国内镜像下载");
        }

        // 磁盘空间检查（在数据目录所在盘）
        try
        {
            string dataDir = SettingsService.GetDataDir();
            string root = Path.GetPathRoot(dataDir) ?? "C:\\";
            var drive = new DriveInfo(root);
            long freeGB = drive.AvailableFreeSpace / 1024 / 1024 / 1024;
            if (freeGB < 5)
            {
                info.Optimizations.Add($"⚠️ {root} 盘剩余空间仅 {freeGB}GB，建议清理磁盘（Minecraft 版本+模组可能需要 5-20GB）");
            }
        }
        catch { }
    }

    /// <summary>获取系统信息摘要（用于日志）</summary>
    public string GetSummary(SysInfo info)
    {
        var sb = new StringBuilder();
        sb.AppendLine("=== 系统信息 ===");
        sb.AppendLine($"系统：{info.VersionString} (Build {info.BuildNumber}) {(info.Is64Bit ? "64位" : "32位")}");
        sb.AppendLine($"CPU：{info.CpuName} ({info.CpuCores}核/{info.CpuLogicalProcessors}线程)");
        sb.AppendLine($"内存：{info.TotalMemoryMB}MB 总计 / {info.AvailableMemoryMB}MB 可用");
        sb.AppendLine($"显卡：{info.GpuName} ({info.GpuMemoryMB}MB)");
        sb.AppendLine($".NET：{info.DotNetVersion}");
        sb.AppendLine($"支持状态：{(info.IsSupported ? "✅ 兼容" : "⚠️ 不兼容")}");
        if (info.Optimizations.Count > 0)
        {
            sb.AppendLine("优化建议：");
            foreach (var opt in info.Optimizations)
                sb.AppendLine($"  - {opt}");
        }
        return sb.ToString();
    }
}
