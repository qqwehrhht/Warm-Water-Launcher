using System.Text.Json;
using System.Text.Json.Serialization;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

/// <summary>版本清单条目</summary>
public class VersionListEntry
{
    public string Id { get; set; } = "";
    public string Type { get; set; } = "";
    public string Url { get; set; } = "";
    public string? ReleaseTime { get; set; }
}

public enum VersionType { Release, Snapshot, OldBeta, OldAlpha, AprilFools, Other }

/// <summary>版本元数据（用于下载页展示）</summary>
public class VersionMeta
{
    public string Id { get; set; } = "";
    public VersionType Type { get; set; }
    public string TypeName => Type switch
    {
        VersionType.Release => "正式版",
        VersionType.Snapshot => "快照版",
        VersionType.OldBeta => "远古版 Beta",
        VersionType.OldAlpha => "远古版 Alpha",
        VersionType.AprilFools => "愚人节版",
        _ => "其他"
    };
    public string? ReleaseTime { get; set; }
    /// <summary>是否已被用户收藏（仅用于下载页展示）</summary>
    [JsonIgnore]
    public bool IsFavorite { get; set; }
    [JsonIgnore]
    public string FavoriteGlyph => IsFavorite ? "★" : "☆";
}

/// <summary>单个版本 JSON 的解析模型</summary>
public class VersionJson
{
    [JsonPropertyName("id")] public string Id { get; set; } = "";
    [JsonPropertyName("type")] public string? Type { get; set; }
    [JsonPropertyName("mainClass")] public string MainClass { get; set; } = "";
    [JsonPropertyName("minecraftArguments")] public string? MinecraftArguments { get; set; }
    [JsonPropertyName("arguments")] public ArgumentsJson? Arguments { get; set; }
    [JsonPropertyName("assets")] public string Assets { get; set; } = "";
    [JsonPropertyName("assetIndex")] public DownloadableJson? AssetIndex { get; set; }
    [JsonPropertyName("downloads")] public DownloadsJson? Downloads { get; set; }
    [JsonPropertyName("libraries")] public List<LibraryJson> Libraries { get; set; } = new();
    [JsonPropertyName("javaVersion")] public JavaVersionJson? JavaVersion { get; set; }
    [JsonPropertyName("logging")] public object? Logging { get; set; }
    [JsonPropertyName("incremental")] public bool Incremental { get; set; }
    [JsonPropertyName("inheritsFrom")] public string? InheritsFrom { get; set; }
}

public class ArgumentsJson
{
    [JsonPropertyName("game")] public JsonElement? Game { get; set; }
    [JsonPropertyName("jvm")] public JsonElement? Jvm { get; set; }
}

public class DownloadsJson
{
    [JsonPropertyName("client")] public DownloadableJson? Client { get; set; }
    [JsonPropertyName("server")] public DownloadableJson? Server { get; set; }
    [JsonPropertyName("client_mappings")] public DownloadableJson? ClientMappings { get; set; }
    [JsonPropertyName("server_mappings")] public DownloadableJson? ServerMappings { get; set; }
}

public class DownloadableJson
{
    [JsonPropertyName("url")] public string Url { get; set; } = "";
    [JsonPropertyName("sha1")] public string? Sha1 { get; set; }
    [JsonPropertyName("size")] public long Size { get; set; }
    [JsonPropertyName("path")] public string? Path { get; set; }
}

public class JavaVersionJson
{
    [JsonPropertyName("majorVersion")] public int MajorVersion { get; set; }
    [JsonPropertyName("component")] public string Component { get; set; } = "jre-legacy";
}

public class LibraryJson
{
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("downloads")] public LibraryDownloadsJson? Downloads { get; set; }
    [JsonPropertyName("rules")] public List<RuleJson>? Rules { get; set; }
    [JsonPropertyName("extract")] public ExtractJson? Extract { get; set; }
    [JsonPropertyName("natives")] public Dictionary<string, string>? Natives { get; set; }
    [JsonIgnore] public bool IsNative => Natives != null;
}

public class LibraryDownloadsJson
{
    [JsonPropertyName("artifact")] public DownloadableJson? Artifact { get; set; }
    [JsonPropertyName("classifiers")] public Dictionary<string, DownloadableJson>? Classifiers { get; set; }
}

public class RuleJson
{
    [JsonPropertyName("action")] public string Action { get; set; } = "allow";
    [JsonPropertyName("os")] public OsRuleJson? Os { get; set; }
    [JsonPropertyName("features")] public Dictionary<string, bool>? Features { get; set; }
}

public class OsRuleJson
{
    [JsonPropertyName("name")] public string? Name { get; set; }
    [JsonPropertyName("version")] public string? Version { get; set; }
    [JsonPropertyName("arch")] public string? Arch { get; set; }
}

public class ExtractJson
{
    [JsonPropertyName("exclude")] public List<string>? Exclude { get; set; }
}

/// <summary>游戏文件校验/安装状态</summary>
public class VersionFile
{
    public string Url { get; set; } = "";
    public string Path { get; set; } = "";
    public string? Sha1 { get; set; }
    public long Size { get; set; }
}

/// <summary>版本下载与解析服务</summary>
public class VersionService
{
    private readonly SettingsService _settings;
    private readonly DownloadService _dl;
    private DownloadManagerService? _dm;

    public VersionService(SettingsService settings, DownloadService dl)
    {
        _settings = settings;
        _dl = dl;
    }

    public void SetDownloadManager(DownloadManagerService dm) => _dm = dm;

    public const string MojangManifest = "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";
    public const string BmclapiManifest = "https://bmclapi2.bangbang93.com/mc/game/version_manifest_v2.json";

    public string ManifestUrl => _settings.Config.Download.Source switch
    {
        "mojang" => MojangManifest,
        "mcim" => "https://download.mcimirror.top/mc/game/version_manifest_v2.json",
        _ => BmclapiManifest
    };

    /// <summary>获取版本清单，按类型分组（多源自动回退）</summary>
    public async Task<List<VersionMeta>> GetVersionListAsync()
    {
        var list = new List<VersionMeta>();
        string? json = null;
        var sources = new List<string> { ManifestUrl };
        if (!sources.Contains(MojangManifest)) sources.Add(MojangManifest);
        if (!sources.Contains(BmclapiManifest)) sources.Add(BmclapiManifest);
        foreach (var src in sources)
        {
            json = await _dl.Http.GetStringAsync(src);
            if (!string.IsNullOrEmpty(json)) break;
        }
        if (string.IsNullOrEmpty(json)) return list;
        try
        {
            using var doc = JsonDocument.Parse(json);
            var versions = doc.RootElement.GetProperty("versions").EnumerateArray();
            foreach (var v in versions)
            {
                var id = v.GetProperty("id").GetString() ?? "";
                var type = v.GetProperty("type").GetString() ?? "";
                var time = v.TryGetProperty("releaseTime", out var rt) ? rt.GetString() : null;
                var vType = type switch
                {
                    "release" => VersionType.Release,
                    "snapshot" => IsAprilFools(id) ? VersionType.AprilFools : VersionType.Snapshot,
                    "old_beta" => VersionType.OldBeta,
                    "old_alpha" => VersionType.OldAlpha,
                    _ => VersionType.Other
                };
                list.Add(new VersionMeta { Id = id, Type = vType, ReleaseTime = time });
            }
        }
        catch { }
        return list;
    }

    private static bool IsAprilFools(string id)
    {
        var s = id.ToLowerInvariant();
        // 已知愚人节版本
        string[] fools = { "1.rv-pre1", "3d shareware v1.34", "20w14infinite", "22w13oneblockatatime", "23w13a_or_b", "24w14potato" };
        if (fools.Contains(s)) return true;
        return s.Contains("april") || s.Contains("fools");
    }

    /// <summary>获取版本 JSON 内容并缓存</summary>
    public async Task<VersionJson?> GetVersionJsonAsync(string versionId)
    {
        string cacheDir = Path.Combine(SettingsService.GetDataDir(), "versioncache");
        Directory.CreateDirectory(cacheDir);
        string cachePath = Path.Combine(cacheDir, versionId + ".json");
        string? raw = null;

        // 1. 优先从缓存读取
        if (File.Exists(cachePath) && new FileInfo(cachePath).Length > 100)
            raw = File.ReadAllText(cachePath);

        // 2. 如果缓存没有，检查本地已安装的版本目录（包括带加载器的版本）
        if (string.IsNullOrEmpty(raw))
        {
            var localPaths = new[]
            {
                Path.Combine(_settings.GlobalVersionsDir, versionId, versionId + ".json"),
                Path.Combine(_settings.GameRoot, "versions", versionId, versionId + ".json"),
            };
            foreach (var lp in localPaths)
            {
                if (File.Exists(lp) && new FileInfo(lp).Length > 100)
                {
                    try
                    {
                        raw = File.ReadAllText(lp);
                        // 保存到缓存
                        try { File.WriteAllText(cachePath, raw); } catch { }
                        break;
                    }
                    catch { }
                }
            }
        }

        if (string.IsNullOrEmpty(raw))
        {
            // 多源回退：清单 URL → BMCLAPI 直连 → Mojang 直连
            string? versionUrl = null;
            var manifestCandidates = new List<string> { ManifestUrl };
            if (!manifestCandidates.Contains(BmclapiManifest)) manifestCandidates.Add(BmclapiManifest);
            if (!manifestCandidates.Contains(MojangManifest)) manifestCandidates.Add(MojangManifest);
            foreach (var mu in manifestCandidates)
            {
                var mjson = await _dl.Http.GetStringAsync(mu);
                if (string.IsNullOrEmpty(mjson)) continue;
                try
                {
                    using var doc = JsonDocument.Parse(mjson);
                    foreach (var v in doc.RootElement.GetProperty("versions").EnumerateArray())
                    {
                        if (v.GetProperty("id").GetString() == versionId)
                        {
                            versionUrl = v.GetProperty("url").GetString();
                            break;
                        }
                    }
                }
                catch { }
                if (versionUrl != null) break;
            }

            var jsonCandidates = new List<string>();
            if (versionUrl != null) jsonCandidates.Add(_dl.Mirror(versionUrl));
            // BMCLAPI 直连版本 JSON 接口（会 302 重定向）
            jsonCandidates.Add($"https://bmclapi2.bangbang93.com/version/{versionId}/json");
            // MCIM 镜像
            jsonCandidates.Add($"https://download.mcimirror.top/version/{versionId}/json");
            // 官方直连（通过清单中的 URL 格式构造）
            if (versionUrl != null) jsonCandidates.Add(versionUrl);

            foreach (var jc in jsonCandidates)
            {
                raw = await _dl.Http.GetStringAsync(jc);
                if (!string.IsNullOrEmpty(raw) && raw.StartsWith('{')) break;
            }
            if (!string.IsNullOrEmpty(raw) && raw.StartsWith('{'))
            {
                try { File.WriteAllText(cachePath, raw); } catch { }
            }
        }

        if (string.IsNullOrEmpty(raw) || !raw.StartsWith('{')) return null;
        try
        {
            return JsonSerializer.Deserialize<VersionJson>(raw, SettingsService.JsonOpts);
        }
        catch { return null; }
    }

    /// <summary>获取版本 JSON 的下载地址（通过清单）</summary>
    public async Task<string?> GetVersionJsonUrlAsync(string versionId)
    {
        var raw = await _dl.Http.GetStringAsync(ManifestUrl);
        if (string.IsNullOrEmpty(raw)) return null;
        using var doc = JsonDocument.Parse(raw);
        foreach (var v in doc.RootElement.GetProperty("versions").EnumerateArray())
        {
            if (v.GetProperty("id").GetString() == versionId)
                return v.GetProperty("url").GetString();
        }
        return null;
    }

    /// <summary>当前已安装的版本（versions 目录下含 version.json 的）</summary>
    /// <summary>获取已安装的版本列表</summary>
    /// <param name="includeLoader">是否包含带加载器的版本（如 1.20.1-forge-47.2.0）</param>
    public List<string> GetInstalledVersions(bool includeLoader = false)
    {
        var dirs = new List<string>();
        // 检查全局版本目录
        if (Directory.Exists(_settings.GlobalVersionsDir))
            dirs.AddRange(Directory.GetDirectories(_settings.GlobalVersionsDir));
        // 检查游戏根目录下的 versions 目录
        var gameVersionsDir = Path.Combine(_settings.GameRoot, "versions");
        if (Directory.Exists(gameVersionsDir))
            dirs.AddRange(Directory.GetDirectories(gameVersionsDir).Where(d => !dirs.Contains(d)));

        var versions = dirs
            .Where(d => File.Exists(Path.Combine(d, Path.GetFileName(d) + ".json")))
            .Select(Path.GetFileName)
            .Where(v => v != null)
            .Select(v => v!)
            .ToList();

        if (!includeLoader)
        {
            // 过滤掉带加载器的版本（包含 -forge-、-fabric-、-quilt-、-OptiFine- 等）
            var loaderKeywords = new[] { "-forge-", "-fabric-", "-quilt-", "-OptiFine-", "-optifine-", "forge-", "fabric-loader-", "quilt-loader-" };
            versions = versions.Where(v => !loaderKeywords.Any(k => v.Contains(k, StringComparison.OrdinalIgnoreCase))).ToList();
        }

        return versions.OrderByDescending(x => x).ToList();
    }

    /// <summary>版本目录（全局）</summary>
    public string VersionDir(string versionId) => Path.Combine(_settings.GlobalVersionsDir, versionId);

    /// <summary>下载并安装一个版本（版本 JSON + 客户端 jar + 所有库文件 + 所有资源文件），确保文件完整</summary>
    public async Task<bool> DownloadVersionAsync(string versionId, IProgress<(string desc, double pct, int ok, int total)>? progress)
    {
        try
        {
            var vj = await GetVersionJsonAsync(versionId);
            if (vj == null)
            {
                progress?.Report(("版本 JSON 获取失败，请检查网络或更换下载源", 0, 0, 0));
                return false;
            }

            string dir = VersionDir(versionId);
            Directory.CreateDirectory(dir);
            string jsonPath = Path.Combine(dir, versionId + ".json");

            // 写入版本 JSON
            if (!File.Exists(jsonPath) || new FileInfo(jsonPath).Length < 100)
            {
                try
                {
                    string raw = JsonSerializer.Serialize(vj, SettingsService.JsonOpts);
                    File.WriteAllText(jsonPath, raw);
                }
                catch
                {
                    string cachePath = Path.Combine(SettingsService.GetDataDir(), "versioncache", versionId + ".json");
                    if (File.Exists(cachePath)) File.Copy(cachePath, jsonPath, true);
                }
            }

            // 1. 下载客户端 jar（带完整性校验，接入全局下载管理器）
            string jarPath = Path.Combine(dir, versionId + ".jar");
            if (!IsValidJar(jarPath) && vj.Downloads?.Client != null)
            {
                progress?.Report(("正在下载客户端文件...", 0.05, 0, 1));
                if (_dm != null)
                {
                    // 使用全局下载管理器
                    var task = _dm.AddTask(
                        name: $"游戏版本 {versionId} 客户端",
                        url: vj.Downloads.Client.Url,
                        savePath: jarPath,
                        expectedSha1: vj.Downloads.Client.Sha1);
                    // 等待下载完成
                    while (task.Status != DownloadStatus.Completed && task.Status != DownloadStatus.Failed && task.Status != DownloadStatus.Canceled)
                    {
                        await Task.Delay(100);
                        if (task.Status == DownloadStatus.Downloading)
                        {
                            progress?.Report(($"正在下载客户端文件... {task.Progress:F0}%", 0.05 + task.Progress * 0.05, 0, 1));
                        }
                    }
                    if (task.Status != DownloadStatus.Completed || !IsValidJar(jarPath))
                    {
                        progress?.Report(("客户端文件下载失败，请检查网络后重试", 0, 0, 1));
                        return false;
                    }
                }
                else
                {
                    // 回退到旧的下载方式
                    bool ok = await _dl.DownloadFileAsync(vj.Downloads.Client.Url, jarPath, vj.Downloads.Client.Sha1);
                    if (!ok || !IsValidJar(jarPath))
                    {
                        progress?.Report(("客户端文件下载失败，正在重试...", 0.05, 0, 1));
                        try { File.Delete(jarPath); } catch { }
                        ok = await _dl.DownloadFileAsync(vj.Downloads.Client.Url, jarPath, vj.Downloads.Client.Sha1);
                        if (!ok || !IsValidJar(jarPath))
                        {
                            progress?.Report(("客户端文件下载失败，请检查网络后重试", 0, 0, 1));
                            return false;
                        }
                    }
                }
            }
            progress?.Report(("客户端下载完成", 0.1, 1, 1));

            // 2. 收集所有需要下载的文件（库文件 + 资源文件）
            var allFiles = new List<(string url, string path, string? sha1)>();
            const string OsName = "windows";
            const string OsArch = "x64";

            // 2.1 库文件
            progress?.Report(("正在收集库文件列表...", 0.12, 0, 0));
            foreach (var lib in vj.Libraries)
            {
                // 检查规则（OS 过滤）
                if (lib.Rules != null && lib.Rules.Count > 0)
                {
                    bool allow = false;
                    foreach (var rule in lib.Rules)
                    {
                        bool? osOk = null;
                        if (rule.Os != null)
                        {
                            bool ok = true;
                            if (rule.Os.Name != null && rule.Os.Name != OsName) ok = false;
                            if (rule.Os.Arch != null && rule.Os.Arch != OsArch) ok = false;
                            osOk = ok;
                        }
                        bool match = osOk == null || osOk.Value;
                        if (rule.Action == "allow" && match) allow = true;
                        if (rule.Action == "disallow" && match) allow = false;
                    }
                    if (!allow) continue;
                }

                if (lib.IsNative)
                {
                    // natives: 按 OS 取 classifier
                    if (lib.Natives != null && lib.Natives.TryGetValue(OsName, out var nativeKey))
                    {
                        var classifier = nativeKey.Replace("${arch}", OsArch);
                        var d = lib.Downloads?.Classifiers?.FirstOrDefault(kv => kv.Key == classifier).Value;
                        // 兼容模糊匹配
                        if (d == null && lib.Downloads?.Classifiers != null)
                        {
                            foreach (var kv in lib.Downloads.Classifiers)
                            {
                                if (kv.Key.Replace("\"", "").Equals(classifier, StringComparison.OrdinalIgnoreCase))
                                { d = kv.Value; break; }
                            }
                        }
                        if (d != null)
                        {
                            string jarPath2 = Path.Combine(_settings.LibrariesDir, ClassifierPath(lib.Name, classifier));
                            allFiles.Add((d.Url, jarPath2, d.Sha1));
                        }
                    }
                }
                else
                {
                    var artifact = lib.Downloads?.Artifact;
                    if (artifact != null)
                    {
                        string path = Path.Combine(_settings.LibrariesDir, ArtifactPath(lib.Name));
                        allFiles.Add((artifact.Url, path, artifact.Sha1));
                    }
                    else
                    {
                        // 无 artifact 信息时，从名称推断
                        string path = Path.Combine(_settings.LibrariesDir, ArtifactPath(lib.Name));
                        var guessUrl = "https://libraries.minecraft.net/" + ArtifactPath(lib.Name).Replace('\\', '/');
                        allFiles.Add((guessUrl, path, null));
                    }
                }
            }

            // 2.2 资产索引与资源文件
            progress?.Report(("正在收集资源文件列表...", 0.15, 0, 0));
            string assetsDir = _settings.AssetsDir;
            string assetIndexDir = Path.Combine(assetsDir, "indexes");
            string assetObjectsDir = Path.Combine(assetsDir, "objects");
            Directory.CreateDirectory(assetIndexDir);
            Directory.CreateDirectory(assetObjectsDir);
            string assetIndexPath = Path.Combine(assetIndexDir, vj.Assets + ".json");

            // 先下载资产索引
            if (vj.AssetIndex != null && (!File.Exists(assetIndexPath) || new FileInfo(assetIndexPath).Length < 100))
            {
                progress?.Report(("正在下载资产索引...", 0.17, 0, 1));
                bool idxOk = await _dl.DownloadFileAsync(vj.AssetIndex.Url, assetIndexPath, vj.AssetIndex.Sha1);
                if (!idxOk || !File.Exists(assetIndexPath))
                {
                    // 重试一次
                    try { File.Delete(assetIndexPath); } catch { }
                    idxOk = await _dl.DownloadFileAsync(vj.AssetIndex.Url, assetIndexPath, vj.AssetIndex.Sha1);
                    if (!idxOk || !File.Exists(assetIndexPath))
                    {
                        progress?.Report(("资产索引下载失败，资源文件将不完整", 0.2, 0, 1));
                    }
                }
            }

            // 解析资产索引，生成资源文件下载列表
            int assetCount = 0;
            if (File.Exists(assetIndexPath))
            {
                try
                {
                    using var doc = JsonDocument.Parse(File.ReadAllText(assetIndexPath));
                    if (doc.RootElement.TryGetProperty("objects", out var objects))
                    {
                        foreach (var obj in objects.EnumerateObject())
                        {
                            if (!obj.Value.TryGetProperty("hash", out var hashEl)) continue;
                            var hash = hashEl.GetString();
                            if (string.IsNullOrEmpty(hash) || hash.Length < 2) continue;
                            string objPath = Path.Combine(assetObjectsDir, hash[..2], hash);
                            if (!File.Exists(objPath) || !DownloadService.VerifySha1(objPath, hash))
                            {
                                allFiles.Add(("https://resources.download.minecraft.net/" + hash[..2] + "/" + hash, objPath, hash));
                                assetCount++;
                            }
                        }
                    }
                }
                catch { }
            }

            // 3. 过滤已存在且校验通过的文件（包括 jar/zip 完整性检查）
            int beforeCount = allFiles.Count;
            allFiles = allFiles.Where(t =>
            {
                if (!File.Exists(t.path)) return true;
                // 有 sha1 时校验哈希
                if (t.sha1 != null && !DownloadService.VerifySha1(t.path, t.sha1)) return true;
                // 无 sha1 时检查文件大小和 jar/zip 完整性
                try
                {
                    var fi = new FileInfo(t.path);
                    if (fi.Length < 100) return true;
                    // 检查 jar/zip 文件是否有效
                    if (t.path.EndsWith(".jar", StringComparison.OrdinalIgnoreCase) ||
                        t.path.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                    {
                        return !IsValidJar(t.path);
                    }
                }
                catch { return true; }
                return false;
            }).ToList();
            int skipped = beforeCount - allFiles.Count;

            progress?.Report(($"需要下载 {allFiles.Count} 个文件（{skipped} 个已存在跳过，其中资源文件 {assetCount} 个）", 0.2, 0, allFiles.Count));

            // 4. 多轮下载，确保所有文件完整（接入全局下载任务队列，用户可见进度）
            int maxRounds = 3;
            for (int round = 1; round <= maxRounds; round++)
            {
                // 每轮开始前重新检查所有文件，过滤已存在且完整的
                allFiles = allFiles.Where(t =>
                {
                    if (!File.Exists(t.path)) return true;
                    if (t.sha1 != null && !DownloadService.VerifySha1(t.path, t.sha1)) return true;
                    try
                    {
                        var fi = new FileInfo(t.path);
                        if (fi.Length < 100) return true;
                        if (t.path.EndsWith(".jar", StringComparison.OrdinalIgnoreCase) ||
                            t.path.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                            return !IsValidJar(t.path);
                    }
                    catch { return true; }
                    return false;
                }).ToList();

                if (allFiles.Count == 0)
                {
                    progress?.Report(($"所有文件已下载完整（第 {round} 轮检查通过）", 0.9, 0, 0));
                    break;
                }

                progress?.Report(($"第 {round}/{maxRounds} 轮下载：需要下载 {allFiles.Count} 个文件（已加入下载队列）", 0.2 + (round - 1) * 0.25, 0, allFiles.Count));

                if (_dm != null)
                {
                    // 接入全局下载任务队列：每个文件作为一个独立任务，用户可在右下角查看进度
                    var tasks = new List<DownloadTask>();
                    foreach (var (url, path, sha1) in allFiles)
                    {
                        string fname = Path.GetFileName(path);
                        var task = _dm.AddTask(
                            name: $"[版本{versionId}] {fname}",
                            url: url,
                            savePath: path,
                            expectedSha1: sha1);
                        tasks.Add(task);
                    }

                    // 等待所有任务完成（内部含失败自动重试）
                    await _dm.WaitAllAsync(tasks);

                    // 轮询更新总进度
                    int total = tasks.Count;
                    var watch = System.Diagnostics.Stopwatch.StartNew();
                    while (watch.Elapsed < TimeSpan.FromMinutes(30))
                    {
                        int done = tasks.Count(t => t.Status is DownloadStatus.Completed or DownloadStatus.Failed or DownloadStatus.Canceled);
                        double pct = 0.2 + (round - 1) * 0.25 + 0.25 * (double)done / total;
                        progress?.Report(($"第 {round} 轮下载 {done}/{total}（下载队列中）", Math.Min(0.95, pct), done, total));
                        if (done >= total) break;
                        await Task.Delay(500);
                    }
                }
                else
                {
                    // 回退：分批次静默下载
                    int batchSize = 32;
                    int totalBatches = (allFiles.Count + batchSize - 1) / batchSize;
                    int downloadedCount = 0;
                    for (int batch = 0; batch < totalBatches; batch++)
                    {
                        var batchFiles = allFiles.Skip(batch * batchSize).Take(batchSize).ToList();
                        var dlProgress = new Progress<(string desc, double pct, int ok, int total)>(p =>
                        {
                            double overallPct = 0.2 + (round - 1) * 0.25 + 0.25 * (double)(downloadedCount + p.ok) / allFiles.Count;
                            progress?.Report(($"第 {round} 轮下载 {downloadedCount + p.ok}/{allFiles.Count}", Math.Min(0.95, overallPct), downloadedCount + p.ok, allFiles.Count));
                        });
                        await _dl.DownloadManyAsync(batchFiles, dlProgress);
                        downloadedCount += batchFiles.Count;
                    }
                }

                // 本轮下载完成后，检查还有多少文件不完整
                var stillMissing = allFiles.Where(t =>
                {
                    if (!File.Exists(t.path)) return true;
                    if (t.sha1 != null && !DownloadService.VerifySha1(t.path, t.sha1)) return true;
                    try
                    {
                        var fi = new FileInfo(t.path);
                        if (fi.Length < 100) return true;
                        if (t.path.EndsWith(".jar", StringComparison.OrdinalIgnoreCase) ||
                            t.path.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                            return !IsValidJar(t.path);
                    }
                    catch { return true; }
                    return false;
                }).ToList();

                if (stillMissing.Count == 0)
                {
                    progress?.Report(($"第 {round} 轮下载完成，所有文件完整", 0.9, 0, 0));
                    break;
                }
                else if (round == maxRounds)
                {
                    progress?.Report(($"警告：仍有 {stillMissing.Count} 个文件下载失败（可能缺少部分资源），不影响游戏启动", 0.95, 0, 0));
                }
                else
                {
                    progress?.Report(($"第 {round} 轮下载完成，还有 {stillMissing.Count} 个文件不完整，准备下一轮重试...", 0.9, 0, 0));
                    await Task.Delay(1000);
                }
            }

            // 5. 最终校验：检查所有关键文件是否存在
            progress?.Report(("正在校验文件完整性...", 0.98, 0, 0));
            progress?.Report(("正在校验文件完整性...", 0.98, 0, 0));
            var brokenFiles = new List<string>();

            // 检查客户端 jar
            if (!IsValidJar(jarPath)) brokenFiles.Add("客户端 jar");

            // 检查所有库文件
            foreach (var lib in vj.Libraries)
            {
                if (lib.Rules != null)
                {
                    bool allow = false;
                    foreach (var rule in lib.Rules)
                    {
                        bool? osOk = null;
                        if (rule.Os != null)
                        {
                            bool ok = true;
                            if (rule.Os.Name != null && rule.Os.Name != OsName) ok = false;
                            if (rule.Os.Arch != null && rule.Os.Arch != OsArch) ok = false;
                            osOk = ok;
                        }
                        bool match = osOk == null || osOk.Value;
                        if (rule.Action == "allow" && match) allow = true;
                        if (rule.Action == "disallow" && match) allow = false;
                    }
                    if (!allow) continue;
                }

                if (!lib.IsNative)
                {
                    string path = Path.Combine(_settings.LibrariesDir, ArtifactPath(lib.Name));
                    if (!File.Exists(path) || !IsValidJar(path))
                    {
                        // 只记录有下载信息的库文件
                        if (lib.Downloads?.Artifact != null)
                            brokenFiles.Add(lib.Name);
                    }
                }
            }

            if (brokenFiles.Count > 0)
            {
                progress?.Report(($"校验发现 {brokenFiles.Count} 个文件损坏或缺失：{string.Join(", ", brokenFiles.Take(5))}...", 0, 0, 0));
                return false;
            }

            progress?.Report(($"版本 {versionId} 安装完成！所有游戏文件已下载完整并通过校验。", 1, allFiles.Count, allFiles.Count));
            return true;
        }
        catch (Exception ex)
        {
            progress?.Report(($"下载异常：{ex.Message}", 0, 0, 0));
            return false;
        }
    }

    /// <summary>检查 jar/zip 文件是否有效（zip END header 校验）</summary>
    private static bool IsValidJar(string path)
    {
        try
        {
            if (!File.Exists(path)) return false;
            var fi = new FileInfo(path);
            if (fi.Length < 22) return false; // zip 文件至少 22 字节
            using var fs = File.OpenRead(path);
            fs.Seek(-22, SeekOrigin.End);
            byte[] header = new byte[4];
            fs.Read(header, 0, 4);
            // zip END header 签名: PK\x05\x06
            return header[0] == 0x50 && header[1] == 0x4B && header[2] == 0x05 && header[3] == 0x06;
        }
        catch { return false; }
    }

    private static string ArtifactPath(string libName)
    {
        var parts = libName.Split(':');
        if (parts.Length < 3) return libName.Replace(':', '/') + ".jar";
        string group = parts[0].Replace('.', '/');
        string artifact = parts[1];
        string version = parts[2];
        string classifier = parts.Length > 3 ? "-" + parts[3] : "";
        return Path.Combine(group, artifact, version, artifact + "-" + version + classifier + ".jar");
    }

    private static string ClassifierPath(string libName, string classifier)
    {
        var parts = libName.Split(':');
        string group = parts[0].Replace('.', '/');
        string artifact = parts[1];
        string version = parts[2];
        return Path.Combine(group, artifact, version, artifact + "-" + version + "-" + classifier + ".jar");
    }
}
