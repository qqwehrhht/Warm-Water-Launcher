using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class DownloadPanel : UserControl
{
    private readonly DispatcherTimer _updateTimer;
    private bool _spinnerAnimating;

    public DownloadPanel()
    {
        InitializeComponent();
        TaskList.ItemsSource = App.Services.DownloadManager.Tasks;

        // 定时刷新总进度（因为总进度需要手动计算）
        _updateTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
        _updateTimer.Tick += (_, _) => UpdateStats();
        _updateTimer.Start();

        App.Services.DownloadManager.TasksChanged += (_, _) => UpdateStats();
        UpdateStats();
    }

    private void UpdateStats()
    {
        var dm = App.Services.DownloadManager;
        ActiveCountText.Text = dm.ActiveCount > 0 ? $"{dm.ActiveCount}个进行中" : $"{dm.CompletedCount}个已完成";
        OverallStatusText.Text = dm.StatusSummary;
        OverallPercentText.Text = dm.OverallProgressText;
        OverallProgressBar.Value = dm.OverallProgress;

        bool active = dm.ActiveCount > 0;
        TaskSpinner.Visibility = active ? Visibility.Visible : Visibility.Collapsed;
        if (active && !_spinnerAnimating)
        {
            TaskSpinnerRotate.BeginAnimation(System.Windows.Media.RotateTransform.AngleProperty,
                new System.Windows.Media.Animation.DoubleAnimation
                {
                    From = 0,
                    To = 360,
                    Duration = TimeSpan.FromMilliseconds(900),
                    RepeatBehavior = System.Windows.Media.Animation.RepeatBehavior.Forever
                });
            _spinnerAnimating = true;
        }
        else if (!active && _spinnerAnimating)
        {
            TaskSpinnerRotate.BeginAnimation(System.Windows.Media.RotateTransform.AngleProperty, null);
            _spinnerAnimating = false;
        }
    }

    private void ClearCompleted_Click(object sender, RoutedEventArgs e)
    {
        App.Services.DownloadManager.ClearCompleted();
        UpdateStats();
    }

    private void CancelAll_Click(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show("确定取消所有正在进行的下载任务吗？", "下载管理", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (result == MessageBoxResult.Yes)
        {
            App.Services.DownloadManager.CancelAll();
            UpdateStats();
        }
    }

    private void RemoveTask_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is DownloadTask task)
        {
            App.Services.DownloadManager.RemoveTask(task);
            UpdateStats();
        }
    }

    private void OpenFolder_Click(object sender, MouseButtonEventArgs e)
    {
        if ((sender as TextBlock)?.Tag is DownloadTask task)
        {
            task.OpenFolder();
        }
    }
}
