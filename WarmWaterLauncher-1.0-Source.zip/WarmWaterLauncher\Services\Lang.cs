namespace WarmWaterLauncher.Services;

/// <summary>
/// 轻量多语言服务：简中 / 英文 / 繁中。
/// 覆盖主界面导航、顶栏、账号等核心文案；页面内部细节文案仍以简中为主。
/// </summary>
public static class Lang
{
    private static readonly Dictionary<string, Dictionary<string, string>> _dicts = new()
    {
        ["zh-CN"] = new Dictionary<string, string>
        {
            ["nav.home"] = "主页", ["nav.download"] = "下载", ["nav.instance"] = "实例管理",
            ["nav.mods"] = "资源下载", ["nav.resource"] = "资源管理", ["nav.tools"] = "工具箱",
            ["nav.java"] = "Java 管理",
            ["nav.logs"] = "日志", ["nav.multiplayer"] = "联机玩法", ["nav.skin"] = "皮肤管理", ["nav.settings"] = "设置", ["nav.ai"] = "实验功能", ["nav.help"] = "帮助", ["nav.about"] = "关于与鸣谢",
            ["top.launch"] = "启动", ["top.account"] = "账号",
            ["acct.notLogin"] = "未登录", ["acct.microsoft"] = "微软正版账号", ["acct.offline"] = "离线账号",
            ["brand.title"] = "温水启动器", ["brand.sub"] = "Warm Water Launcher"
        },
        ["en-US"] = new Dictionary<string, string>
        {
            ["nav.home"] = "Home", ["nav.download"] = "Download", ["nav.instance"] = "Instances",
            ["nav.mods"] = "Download", ["nav.resource"] = "Resources", ["nav.tools"] = "Toolbox", ["nav.java"] = "Java",
            ["nav.logs"] = "Logs", ["nav.multiplayer"] = "Multiplayer", ["nav.skin"] = "Skins", ["nav.settings"] = "Settings", ["nav.ai"] = "Experimental", ["nav.help"] = "Help", ["nav.about"] = "About & Credits",
            ["top.launch"] = "Launch", ["top.account"] = "Account",
            ["acct.notLogin"] = "Not signed in", ["acct.microsoft"] = "Microsoft Account", ["acct.offline"] = "Offline Account",
            ["brand.title"] = "Warm Water Launcher", ["brand.sub"] = "Warm Water Launcher"
        },
        ["zh-TW"] = new Dictionary<string, string>
        {
            ["nav.home"] = "主頁", ["nav.download"] = "下載", ["nav.instance"] = "實例管理",
            ["nav.mods"] = "資源下載", ["nav.resource"] = "資源管理", ["nav.tools"] = "工具箱", ["nav.java"] = "Java 管理",
            ["nav.logs"] = "日誌", ["nav.multiplayer"] = "聯機玩法", ["nav.skin"] = "皮膚管理", ["nav.settings"] = "設定", ["nav.ai"] = "實驗功能", ["nav.help"] = "說明", ["nav.about"] = "關於與鳴謝",
            ["top.launch"] = "啟動", ["top.account"] = "帳號",
            ["acct.notLogin"] = "未登入", ["acct.microsoft"] = "微軟正版帳號", ["acct.offline"] = "離線帳號",
            ["brand.title"] = "溫水啟動器", ["brand.sub"] = "Warm Water Launcher"
        }
    };

    public static string Current { get; private set; } = "zh-CN";

    public static void Set(string lang)
    {
        if (!string.IsNullOrEmpty(lang) && _dicts.ContainsKey(lang)) Current = lang;
    }

    public static string T(string key)
    {
        if (_dicts.TryGetValue(Current, out var d) && d.TryGetValue(key, out var v)) return v;
        // 回退简中
        if (_dicts["zh-CN"].TryGetValue(key, out var zh)) return zh;
        return key;
    }

    /// <summary>可用语言列表</summary>
    public static IEnumerable<string> Available => _dicts.Keys;
}
