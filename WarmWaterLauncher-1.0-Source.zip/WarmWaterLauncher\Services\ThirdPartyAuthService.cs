using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.Json;

namespace WarmWaterLauncher.Services;

/// <summary>第三方皮肤站账号登录服务（LittleSkin、Blessing Skin 等）</summary>
public class ThirdPartyAuthService
{
    private readonly DownloadService _dl;

    public ThirdPartyAuthService(DownloadService dl) => _dl = dl;

    /// <summary>内置皮肤站列表</summary>
    public static readonly (string Name, string ApiBase, string AuthUrl)[] BuiltInSkins =
    {
        ("LittleSkin", "https://littleskin.cn/api", "https://littleskin.cn/auth/login"),
        ("Blessing Skin", "https://skin.blessing.studio/api", "https://skin.blessing.studio/auth/login"),
        ("自定义皮肤站", "", ""),
    };

    /// <summary>使用邮箱+密码登录第三方皮肤站（Yggdrasil API）</summary>
    public async Task<ThirdPartyAccount?> LoginAsync(string apiBase, string email, string password,
        IProgress<string>? progress = null, CancellationToken ct = default)
    {
        try
        {
            if (string.IsNullOrEmpty(apiBase) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                progress?.Report("请填写完整的登录信息");
                return null;
            }

            progress?.Report("正在登录皮肤站...");

            // Yggdrasil API: /authserver/authenticate
            string authUrl = apiBase.TrimEnd('/') + "/authserver/authenticate";
            var body = new
            {
                username = email,
                password = password,
                clientToken = Guid.NewGuid().ToString("N"),
                requestUser = true,
                agent = new { name = "Minecraft", version = 1 }
            };
            var json = JsonSerializer.Serialize(body);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var resp = await _dl.Http.Client.PostAsync(authUrl, content, ct);
            if (!resp.IsSuccessStatusCode)
            {
                string err = await resp.Content.ReadAsStringAsync(ct);
                progress?.Report($"登录失败: {resp.StatusCode} - {err}");
                return null;
            }

            var respJson = await resp.Content.ReadAsStringAsync(ct);
            var authResp = JsonSerializer.Deserialize<YggdrasilAuthResponse>(respJson, SettingsService.JsonOpts);
            if (authResp == null || authResp.SelectedProfile == null)
            {
                progress?.Report("登录失败：未获取到玩家档案");
                return null;
            }

            progress?.Report($"登录成功！欢迎 {authResp.SelectedProfile.Name}");

            return new ThirdPartyAccount
            {
                Name = authResp.SelectedProfile.Name,
                Uuid = authResp.SelectedProfile.Id,
                AccessToken = authResp.AccessToken,
                ClientToken = authResp.ClientToken,
                ApiBase = apiBase,
                Email = email,
                Type = "thirdparty"
            };
        }
        catch (Exception ex)
        {
            progress?.Report("登录异常: " + ex.Message);
            return null;
        }
    }

    /// <summary>验证令牌是否有效</summary>
    public async Task<bool> ValidateAsync(ThirdPartyAccount account)
    {
        try
        {
            string url = account.ApiBase.TrimEnd('/') + "/authserver/validate";
            var body = new { accessToken = account.AccessToken, clientToken = account.ClientToken };
            var json = JsonSerializer.Serialize(body);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var resp = await _dl.Http.Client.PostAsync(url, content);
            return resp.IsSuccessStatusCode; // 204 = 有效, 403 = 无效
        }
        catch { return false; }
    }

    /// <summary>刷新令牌</summary>
    public async Task<bool> RefreshAsync(ThirdPartyAccount account)
    {
        try
        {
            string url = account.ApiBase.TrimEnd('/') + "/authserver/refresh";
            var body = new { accessToken = account.AccessToken, clientToken = account.ClientToken, requestUser = true };
            var json = JsonSerializer.Serialize(body);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var resp = await _dl.Http.Client.PostAsync(url, content);
            if (!resp.IsSuccessStatusCode) return false;
            var respJson = await resp.Content.ReadAsStringAsync();
            var authResp = JsonSerializer.Deserialize<YggdrasilAuthResponse>(respJson, SettingsService.JsonOpts);
            if (authResp == null) return false;
            account.AccessToken = authResp.AccessToken;
            if (authResp.SelectedProfile != null)
            {
                account.Name = authResp.SelectedProfile.Name;
                account.Uuid = authResp.SelectedProfile.Id;
            }
            return true;
        }
        catch { return false; }
    }
}

#region 模型
public class ThirdPartyAccount
{
    public string Name { get; set; } = "";
    public string Uuid { get; set; } = "";
    public string AccessToken { get; set; } = "";
    public string ClientToken { get; set; } = "";
    public string ApiBase { get; set; } = "";
    public string Email { get; set; } = "";
    public string Type { get; set; } = "thirdparty";
}

public class YggdrasilAuthResponse
{
    [System.Text.Json.Serialization.JsonPropertyName("accessToken")] public string AccessToken { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("clientToken")] public string ClientToken { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("selectedProfile")] public YggdrasilProfile? SelectedProfile { get; set; }
    [System.Text.Json.Serialization.JsonPropertyName("availableProfiles")] public List<YggdrasilProfile>? AvailableProfiles { get; set; }
}

public class YggdrasilProfile
{
    [System.Text.Json.Serialization.JsonPropertyName("id")] public string Id { get; set; } = "";
    [System.Text.Json.Serialization.JsonPropertyName("name")] public string Name { get; set; } = "";
}
#endregion
