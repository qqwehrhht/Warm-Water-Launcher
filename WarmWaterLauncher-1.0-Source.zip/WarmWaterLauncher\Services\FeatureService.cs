using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WarmWaterLauncher.Services;

// ==================== 成就系统 ====================
public class Achievement
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string Icon { get; set; } = "🏆";
    public bool Unlocked { get; set; }
    public DateTime? UnlockTime { get; set; }
    public int Progress { get; set; }
    public int Target { get; set; } = 1;
}

public class AchievementService
{
    private readonly string _dataPath;
    public List<Achievement> Achievements { get; private set; } = new();
    public event EventHandler<Achievement>? AchievementUnlocked;

    public AchievementService()
    {
        _dataPath = Path.Combine(SettingsService.GetDataDir(), "achievements.json");
        InitDefaults();
        Load();
    }

    private void InitDefaults()
    {
        var defaults = new List<Achievement>
        {
            new() { Id = "first_launch", Name = "初次启程", Description = "第一次启动游戏", Icon = "🚀", Target = 1 },
            new() { Id = "play_1h", Name = "小时玩家", Description = "累计游戏时长达到1小时", Icon = "⏱️", Target = 3600 },
            new() { Id = "play_10h", Name = "资深玩家", Description = "累计游戏时长达到10小时", Icon = "⌛", Target = 36000 },
            new() { Id = "play_100h", Name = "狂热粉丝", Description = "累计游戏时长达到100小时", Icon = "🌟", Target = 360000 },
            new() { Id = "install_5_versions", Name = "版本收藏家", Description = "安装5个不同的游戏版本", Icon = "📦", Target = 5 },
            new() { Id = "install_10_mods", Name = "模组爱好者", Description = "安装10个模组", Icon = "🧩", Target = 10 },
            new() { Id = "create_instance", Name = "实例创造者", Description = "创建第一个游戏实例", Icon = "🎮", Target = 1 },
            new() { Id = "online_play", Name = "联机达人", Description = "第一次进入联机房间", Icon = "🌐", Target = 1 },
            new() { Id = "crash_survivor", Name = "崩溃幸存者", Description = "经历一次游戏崩溃后重新启动", Icon = "💥", Target = 1 },
            new() { Id = "custom_theme", Name = "个性达人", Description = "自定义启动器主题", Icon = "🎨", Target = 1 },
            new() { Id = "backup_save", Name = "安全卫士", Description = "第一次备份存档", Icon = "💾", Target = 1 },
            new() { Id = "screenshot_taker", Name = "摄影师", Description = "截取第一张游戏截图", Icon = "📷", Target = 10 },
            new() { Id = "night_owl", Name = "夜猫子", Description = "在凌晨2点后启动游戏", Icon = "🦉", Target = 1 },
            new() { Id = "early_bird", Name = "早起鸟", Description = "在早上6点前启动游戏", Icon = "🐦", Target = 1 },
            new() { Id = "speed_demon", Name = "速度恶魔", Description = "下载速度达到10MB/s", Icon = "⚡", Target = 1 },
        };
        foreach (var d in defaults)
        {
            if (!Achievements.Any(a => a.Id == d.Id))
                Achievements.Add(d);
        }
    }

    public void Load()
    {
        try
        {
            if (File.Exists(_dataPath))
            {
                var json = File.ReadAllText(_dataPath);
                var saved = JsonSerializer.Deserialize<List<Achievement>>(json, SettingsService.JsonOpts);
                if (saved != null)
                {
                    foreach (var s in saved)
                    {
                        var existing = Achievements.FirstOrDefault(a => a.Id == s.Id);
                        if (existing != null)
                        {
                            existing.Unlocked = s.Unlocked;
                            existing.UnlockTime = s.UnlockTime;
                            existing.Progress = s.Progress;
                        }
                    }
                }
            }
        }
        catch { }
    }

    public void Save()
    {
        try
        {
            var json = JsonSerializer.Serialize(Achievements, SettingsService.JsonOpts);
            File.WriteAllText(_dataPath, json);
        }
        catch { }
    }

    public void UpdateProgress(string id, int progress)
    {
        var ach = Achievements.FirstOrDefault(a => a.Id == id);
        if (ach == null || ach.Unlocked) return;
        ach.Progress = Math.Min(progress, ach.Target);
        if (ach.Progress >= ach.Target)
        {
            ach.Unlocked = true;
            ach.UnlockTime = DateTime.Now;
            AchievementUnlocked?.Invoke(this, ach);
        }
        Save();
    }

    public void Unlock(string id)
    {
        var ach = Achievements.FirstOrDefault(a => a.Id == id);
        if (ach == null || ach.Unlocked) return;
        ach.Unlocked = true;
        ach.UnlockTime = DateTime.Now;
        ach.Progress = ach.Target;
        AchievementUnlocked?.Invoke(this, ach);
        Save();
    }

    public int UnlockedCount => Achievements.Count(a => a.Unlocked);
    public int TotalCount => Achievements.Count;
}

// ==================== 截图管理服务 ====================
// ==================== 性能监控服务 ====================
public class PerformanceMonitor
{
    private readonly Process _process;
    private PerformanceCounter? _cpuCounter;
    private DateTime _lastCheck;
    private TimeSpan _lastCpuTime;

    public PerformanceMonitor()
    {
        _process = Process.GetCurrentProcess();
        _lastCheck = DateTime.Now;
        _lastCpuTime = _process.TotalProcessorTime;
    }

    public (double CpuPercent, long MemoryMB, long Threads) GetStats()
    {
        try
        {
            _process.Refresh();
            var now = DateTime.Now;
            var cpuTime = _process.TotalProcessorTime;
            double cpuUsed = (cpuTime - _lastCpuTime).TotalMilliseconds;
            double total = (now - _lastCheck).TotalMilliseconds * Environment.ProcessorCount;
            double cpuPercent = total > 0 ? cpuUsed / total * 100 : 0;
            _lastCheck = now;
            _lastCpuTime = cpuTime;
            long memoryMB = _process.WorkingSet64 / (1024 * 1024);
            return (Math.Round(cpuPercent, 1), memoryMB, _process.Threads.Count);
        }
        catch { return (0, 0, 0); }
    }
}

// ==================== 新闻公告服务 ====================
public class NewsItem
{
    public string Title { get; set; } = "";
    public string Content { get; set; } = "";
    public DateTime Date { get; set; }
    public string Type { get; set; } = "info"; // info, update, tip
    public string Url { get; set; } = "";
}

public class NewsService
{
    public List<NewsItem> GetBuiltinNews()
    {
        return new List<NewsItem>
        {
            new()
            {
                Title = "温水启动器 1.0 正式版发布！",
                Content = "全新1.0 正式版界面，30+新功能，更流畅的体验！包括成就系统、存档备份、服务器状态、截图管理等。",
                Date = new DateTime(2026, 8, 30),
                Type = "update"
            },
            new()
            {
                Title = "使用小贴士：版本隔离",
                Content = "建议在设置中开启版本隔离，每个实例独立管理mod、配置和存档，避免冲突。",
                Date = new DateTime(2026, 8, 29),
                Type = "tip"
            },
            new()
            {
                Title = "下载慢？试试国内镜像",
                Content = "在设置-下载中选择 BMCLAPI 或 MCIM 镜像源，下载速度更快更稳定。",
                Date = new DateTime(2026, 8, 28),
                Type = "tip"
            },
            new()
            {
                Title = "Java 版本选择建议",
                Content = "Minecraft 1.18-1.20.4 使用 Java 17，1.20.5+ 使用 Java 21，快照版本可能需要更高版本。启动器会自动检测并下载对应版本。",
                Date = new DateTime(2026, 8, 27),
                Type = "tip"
            },
            new()
            {
                Title = "联机功能说明",
                Content = "内置联机功能支持局域网和内网穿透，创建房间后分享IP给好友即可一起游玩。",
                Date = new DateTime(2026, 8, 26),
                Type = "info"
            }
        };
    }
}

// ==================== 崩溃解决方案库 ====================
public class CrashSolution
{
    public string[] Keywords { get; set; } = Array.Empty<string>();
    public string Title { get; set; } = "";
    public string Solution { get; set; } = "";
}

public class CrashSolutionLibrary
{
    public static List<CrashSolution> Solutions = new()
    {
        new()
        {
            Keywords = new[] { "outofmemory", "java heap space", "gc overhead" },
            Title = "内存不足",
            Solution = "1. 打开启动设置，将最大内存调大（建议4096MB或更高）\n2. 关闭其他占用内存的程序\n3. 减少模组数量，特别是大型模组\n4. 添加JVM参数：-XX:+UseG1GC"
        },
        new()
        {
            Keywords = new[] { "unsupportedclassversion", "class file version" },
            Title = "Java版本不兼容",
            Solution = "1. 打开Java管理，下载对应版本的Java\n2. Minecraft 1.18+需要Java 17，1.20.5+需要Java 21\n3. 在启动设置中选择正确的Java路径"
        },
        new()
        {
            Keywords = new[] { "opengl", "glfw", "pixel format", "nvidia", "amd" },
            Title = "显卡/OpenGL问题",
            Solution = "1. 更新显卡驱动到最新版本\n2. 如果使用核显，切换到独立显卡\n3. 关闭光影包或降低画质\n4. 添加JVM参数：-Dorg.lwjgl.opengl.Display.allowSoftwareOpenGL=true"
        },
        new()
        {
            Keywords = new[] { "modloading", "missing dependency", "incompatible", "duplicate" },
            Title = "模组冲突/依赖缺失",
            Solution = "1. 禁用最近添加的模组，逐个排查\n2. 检查模组是否支持当前游戏版本\n3. 确认依赖模组已安装（Fabric API、Cloth Config等）\n4. 删除重复的模组"
        },
        new()
        {
            Keywords = new[] { "file not found", "no such file", "corrupt", "zipfile", "zip end header" },
            Title = "游戏文件损坏",
            Solution = "1. 打开下载页面，重新下载当前游戏版本\n2. 或使用校验修复功能检查文件完整性\n3. 检查杀毒软件是否误删了游戏文件\n4. 将启动器目录加入杀毒软件白名单"
        },
        new()
        {
            Keywords = new[] { "exception_access_violation", "a fatal error", "jvm.dll", "problematic frame" },
            Title = "JVM虚拟机崩溃",
            Solution = "1. 【推荐】更换Java版本，尝试Java 21或Java 17\n2. 更新显卡驱动\n3. 减少分配的内存\n4. 添加JVM参数：-XX:+UseG1GC\n5. 如果是快照版本，建议使用正式版"
        },
        new()
        {
            Keywords = new[] { "optifine", "shadersmod" },
            Title = "OptiFine冲突",
            Solution = "1. 如果使用Fabric，建议用Sodium+Iris替代OptiFine\n2. 如果使用Forge，确保OptiFine版本与Forge版本匹配\n3. 禁用其他光影模组"
        },
        new()
        {
            Keywords = new[] { "fabric-loader", "couldn't locate the game", "game provider" },
            Title = "Fabric加载器问题",
            Solution = "1. 重新安装对应版本的Fabric加载器\n2. 确保游戏版本文件完整（重新下载游戏版本）\n3. 检查Fabric版本是否支持当前游戏版本\n4. 删除versions目录下的Fabric版本文件夹，重新安装"
        },
        new()
        {
            Keywords = new[] { "forge", "fml", "mod loading failed" },
            Title = "Forge加载器问题",
            Solution = "1. 重新安装对应版本的Forge加载器\n2. 确保Forge版本与游戏版本匹配\n3. 删除versions目录下的Forge版本文件夹，重新安装\n4. 检查模组是否支持当前Forge版本"
        },
        new()
        {
            Keywords = new[] { "connection refused", "connection timed out", "unknown host" },
            Title = "网络连接问题",
            Solution = "1. 检查网络连接是否正常\n2. 检查服务器地址和端口是否正确\n3. 检查防火墙是否阻止了Java\n4. 如果是联机房间，确保房主已启动游戏\n5. 尝试使用内网穿透功能"
        }
    };

    public static CrashSolution? FindSolution(string crashText)
    {
        var lower = crashText.ToLowerInvariant();
        foreach (var sol in Solutions)
        {
            if (sol.Keywords.Any(k => lower.Contains(k)))
                return sol;
        }
        return null;
    }
}
