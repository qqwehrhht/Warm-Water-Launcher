using System.Diagnostics;
using System.Text;

namespace WarmWaterLauncher.Services;

/// <summary>FRP 内网穿透服务，支持 Sakurafrp、openfrp、msl frp</summary>
public class FrpService
{
    private readonly DownloadService _dl;
    private Process? _frpcProcess;
    private readonly string _toolsDir;

    public FrpService(DownloadService dl)
    {
        _dl = dl;
        _toolsDir = Path.Combine(SettingsService.GetDataDir(), "tools", "frp");
        Directory.CreateDirectory(_toolsDir);
    }

    #region 三种 FRP 服务配置
    public enum FrpProvider { Sakurafrp, OpenFrp, MslFrp }

    public class FrpConfig
    {
        public FrpProvider Provider { get; set; }
        public string Token { get; set; } = "";
        public string ServerAddr { get; set; } = "";
        public int ServerPort { get; set; } = 7000;
        public string TunnelName { get; set; } = "minecraft";
        public int LocalPort { get; set; } = 25565;
        public int RemotePort { get; set; } = 25565;
        public string LocalIp { get; set; } = "127.0.0.1";
    }

    public static readonly (FrpProvider Provider, string Name, string Website, string ApiDoc, string Desc)[] Providers =
    {
        (FrpProvider.Sakurafrp, "Sakurafrp (樱花穿透)", "https://www.natfrp.com/", "https://doc.natfrp.com/", "国内高速节点，需要注册获取 token 和隧道信息"),
        (FrpProvider.OpenFrp, "openfrp", "https://openfrp.net/", "https://help.openfrp.net/", "免费开源 FRP 服务，国内节点"),
        (FrpProvider.MslFrp, "MSL FRP", "https://www.mslmc.cn/", "https://www.mslmc.cn/frp", "MC 社区 FRP 服务，专为 Minecraft 联机优化"),
    };
    #endregion

    #region frpc 客户端管理
    public string FrpcPath => Path.Combine(_toolsDir, "frpc.exe");
    public string ConfigPath => Path.Combine(_toolsDir, "frpc.toml");

    public bool IsFrpcInstalled() => File.Exists(FrpcPath);

    /// <summary>下载 frpc 客户端（从 GitHub 国内镜像）</summary>
    public async Task<bool> DownloadFrpcAsync(IProgress<(string desc, double pct)>? progress = null)
    {
        try
        {
            // frp 最新 release 下载地址（windows amd64）
            string version = "0.61.0";
            string fileName = $"frp_{version}_windows_amd64.zip";
            string[] mirrors =
            {
                $"https://ghproxy.com/https://github.com/fatedier/frp/releases/download/v{version}/{fileName}",
                $"https://mirror.ghproxy.com/https://github.com/fatedier/frp/releases/download/v{version}/{fileName}",
                $"https://gh.api.99988866.xyz/https://github.com/fatedier/frp/releases/download/v{version}/{fileName}",
                $"https://github.com/fatedier/frp/releases/download/v{version}/{fileName}",
            };

            string zipPath = Path.Combine(_toolsDir, fileName);
            bool ok = false;
            foreach (var url in mirrors)
            {
                try
                {
                    progress?.Report(($"正在从镜像下载 frpc...", 10));
                    ok = await _dl.DownloadFileAsync(url, zipPath, null, default);
                    if (ok && File.Exists(zipPath) && new FileInfo(zipPath).Length > 5 * 1024 * 1024)
                        break;
                }
                catch { continue; }
            }
            if (!ok || !File.Exists(zipPath)) return false;

            progress?.Report(("解压 frpc...", 80));
            // 解压并提取 frpc.exe
            string extractDir = Path.Combine(_toolsDir, "extract");
            if (Directory.Exists(extractDir)) Directory.Delete(extractDir, true);
            System.IO.Compression.ZipFile.ExtractToDirectory(zipPath, extractDir);

            // 找 frpc.exe
            var frpcFiles = Directory.GetFiles(extractDir, "frpc.exe", SearchOption.AllDirectories);
            if (frpcFiles.Length > 0)
            {
                File.Copy(frpcFiles[0], FrpcPath, true);
            }
            try { Directory.Delete(extractDir, true); } catch { }
            try { File.Delete(zipPath); } catch { }

            progress?.Report(("完成", 100));
            return File.Exists(FrpcPath);
        }
        catch { return false; }
    }
    #endregion

    #region 配置生成与启动
    /// <summary>生成 frpc.toml 配置文件</summary>
    public string GenerateConfig(FrpConfig cfg)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"serverAddr = \"{cfg.ServerAddr}\"");
        sb.AppendLine($"serverPort = {cfg.ServerPort}");
        if (!string.IsNullOrEmpty(cfg.Token))
        {
            sb.AppendLine("auth.method = \"token\"");
            sb.AppendLine($"auth.token = \"{cfg.Token}\"");
        }
        sb.AppendLine();
        sb.AppendLine("[[proxies]]");
        sb.AppendLine($"name = \"{cfg.TunnelName}\"");
        sb.AppendLine("type = \"tcp\"");
        sb.AppendLine($"localIP = \"{cfg.LocalIp}\"");
        sb.AppendLine($"localPort = {cfg.LocalPort}");
        sb.AppendLine($"remotePort = {cfg.RemotePort}");
        return sb.ToString();
    }

    public void SaveConfig(FrpConfig cfg)
    {
        File.WriteAllText(ConfigPath, GenerateConfig(cfg), Encoding.UTF8);
    }

    public bool IsRunning => _frpcProcess != null && !_frpcProcess.HasExited;

    public event Action<string>? OnLog;

    /// <summary>启动 frpc</summary>
    public bool Start(FrpConfig cfg)
    {
        try
        {
            if (IsRunning) Stop();
            if (!File.Exists(FrpcPath)) return false;

            SaveConfig(cfg);

            var psi = new ProcessStartInfo
            {
                FileName = FrpcPath,
                Arguments = $"-c \"{ConfigPath}\"",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            _frpcProcess = new Process { StartInfo = psi, EnableRaisingEvents = true };
            _frpcProcess.OutputDataReceived += (_, e) => { if (!string.IsNullOrEmpty(e.Data)) OnLog?.Invoke(e.Data); };
            _frpcProcess.ErrorDataReceived += (_, e) => { if (!string.IsNullOrEmpty(e.Data)) OnLog?.Invoke("[错误] " + e.Data); };
            _frpcProcess.Exited += (_, _) => OnLog?.Invoke("frpc 已退出");
            _frpcProcess.Start();
            _frpcProcess.BeginOutputReadLine();
            _frpcProcess.BeginErrorReadLine();
            return true;
        }
        catch (Exception ex)
        {
            OnLog?.Invoke("启动失败: " + ex.Message);
            return false;
        }
    }

    public void Stop()
    {
        try
        {
            if (_frpcProcess != null && !_frpcProcess.HasExited)
            {
                _frpcProcess.Kill(true);
                _frpcProcess.WaitForExit(3000);
            }
        }
        catch { }
        _frpcProcess = null;
    }

    /// <summary>获取公网连接地址</summary>
    public string GetPublicAddress(FrpConfig cfg)
    {
        if (string.IsNullOrEmpty(cfg.ServerAddr)) return "";
        return $"{cfg.ServerAddr}:{cfg.RemotePort}";
    }
    #endregion
}
