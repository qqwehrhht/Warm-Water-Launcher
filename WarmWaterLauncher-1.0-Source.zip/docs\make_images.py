from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parent
IMG = ROOT / "images"
IMG.mkdir(parents=True, exist_ok=True)

FONT_REG = r"C:\Windows\Fonts\msyh.ttc"
FONT_BOLD = r"C:\Windows\Fonts\msyhbd.ttc"
FONT_MONO = r"C:\Windows\Fonts\consola.ttf"


def font(size, bold=False):
    try:
        return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, size)
    except Exception:
        return ImageFont.truetype(FONT_REG, size)


INK = (23, 33, 30)
INK_SOFT = (71, 85, 80)
MUTED = (138, 149, 143)
MINT = (46, 158, 120)
MINT_DARK = (31, 125, 92)
MINT_DEEP = (21, 59, 48)
MINT_SOFT = (234, 247, 241)
CANVAS = (245, 246, 246)
SURFACE = (255, 255, 255)
HAIR = (231, 235, 232)


def rounded(draw, box, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def shadow_card(base, box, radius=24, blur=32, alpha=46, offset=(0, 16)):
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    x1, y1, x2, y2 = box
    d.rounded_rectangle((x1 + offset[0], y1 + offset[1], x2 + offset[0], y2 + offset[1]),
                        radius=radius, fill=(15, 30, 25, alpha))
    layer = layer.filter(ImageFilter.GaussianBlur(blur))
    base.alpha_composite(layer)


def fit_text(draw, text, fnt, max_width):
    if draw.textlength(text, font=fnt) <= max_width:
        return text
    while text and draw.textlength(text + "…", font=fnt) > max_width:
        text = text[:-1]
    return text + "…"


# ---------------------------------------------------------------- banner
def make_banner():
    W, H = 1600, 430
    im = Image.new("RGBA", (W, H), MINT_DEEP + (255,))
    d = ImageDraw.Draw(im)
    # soft arcs
    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    od.ellipse((-160, 120, 620, 900), fill=(255, 255, 255, 10))
    od.ellipse((1080, -260, 1780, 440), fill=(255, 255, 255, 12))
    od.ellipse((1240, 150, 1720, 630), outline=(158, 232, 206, 34), width=2)
    im = Image.alpha_composite(im, overlay)
    d = ImageDraw.Draw(im)

    logo_path = ROOT.parent / "pcl与温水启动器的源代码" / "WarmWaterLauncher" / "Resources" / "logo_256.png"
    if logo_path.exists():
        logo = Image.open(logo_path).convert("RGBA").resize((72, 72), Image.LANCZOS)
        mask = Image.new("L", (72, 72), 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, 72, 72), radius=18, fill=255)
        im.paste(logo, (64, 58), mask)
        d = ImageDraw.Draw(im)

    d.text((154, 66), "WARM WATER LAUNCHER", font=font(17, True), fill=(157, 232, 205))
    d.text((154, 174), "温水启动器", font=font(66, True), fill=(255, 255, 255))
    tw = d.textlength("温水启动器", font=font(66, True))
    d.text((154 + tw + 16, 198), "1.0 正式版", font=font(40, True), fill=(154, 230, 202))
    d.text((156, 266), "简洁，但不简单。为每一次 Minecraft 启动而生。", font=font(24), fill=(210, 235, 224))
    d.text((156, 305), "WPF  ·  .NET 8  ·  win-x64  ·  self-contained", font=font(15), fill=(140, 201, 180))

    chips = ["极简浅色界面", "下载权限保护", "11 项增强功能"]
    x = 156
    for c in chips:
        w = d.textlength(c, font=font(15, True)) + 32
        rounded(d, (x, 352, x + w, 392), 20, fill=(255, 255, 255, 22), outline=(158, 232, 206, 70))
        d.text((x + 16, 361), c, font=font(15, True), fill=(214, 242, 231))
        x += w + 12

    # right-side summary card
    shadow_card(im, (1150, 104, 1518, 330), radius=22, blur=24, alpha=36)
    d = ImageDraw.Draw(im)
    rounded(d, (1150, 104, 1518, 330), 22, SURFACE)
    d.text((1180, 132), "本地 · 安全 · 轻量", font=font(16, True), fill=MINT_DARK)
    d.text((1180, 174), "一个更安静的", font=font(24, True), fill=INK)
    d.text((1180, 208), "Minecraft 入口", font=font(24, True), fill=INK)
    d.text((1180, 258), "下载需要管理员验证", font=font(14), fill=INK_SOFT)
    d.text((1180, 284), "每次启动重新校验", font=font(14), fill=INK_SOFT)
    d.ellipse((1180, 318, 1188, 326), fill=MINT)
    d.text((1198, 311), "合规、透明、可控", font=font(13), fill=MUTED)

    im.convert("RGB").save(IMG / "banner.png", optimize=True)


# ---------------------------------------------------------------- home screenshot
def make_home():
    src = IMG / "home.png"
    if not src.exists():
        return
    im = Image.open(src).convert("RGB")
    target = 1600
    h = round(im.height * target / im.width)
    im.resize((target, h), Image.LANCZOS).save(IMG / "home-full.png", optimize=True)


# ---------------------------------------------------------------- password gate illustration
def make_gate():
    W, H = 1200, 760
    # blurred home as backdrop
    base = Image.new("RGBA", (W, H), CANVAS + (255,))
    home = IMG / "home.png"
    if home.exists():
        bg = Image.open(home).convert("RGB")
        scale = max(W / bg.width, H / bg.height)
        bg = bg.resize((round(bg.width * scale), round(bg.height * scale)), Image.LANCZOS)
        left = (bg.width - W) // 2
        top = (bg.height - H) // 2
        bg = bg.crop((left, top, left + W, top + H)).filter(ImageFilter.GaussianBlur(13))
        base = Image.alpha_composite(base, bg.convert("RGBA"))
    veil = Image.new("RGBA", (W, H), (12, 27, 22, 108))
    base = Image.alpha_composite(base, veil)
    d = ImageDraw.Draw(base)

    card = (210, 130, 990, 640)
    shadow_card(base, card, radius=28, blur=38, alpha=110, offset=(0, 22))
    d = ImageDraw.Draw(base)
    rounded(d, card, 28, SURFACE)
    d.text((250, 164), "下载功能管理员验证", font=font(27, True), fill=INK)
    d.text((250, 206), "仅授权用户可以下载游戏文件", font=font(14), fill=MUTED)
    # close
    d.text((942, 158), "×", font=font(26), fill=MUTED)
    # lock badge
    d.ellipse((250, 248, 310, 308), fill=MINT_SOFT)
    d.rounded_rectangle((269, 274, 291, 296), 4, fill=MINT_DARK)
    d.arc((272, 259, 288, 281), 180, 360, fill=MINT_DARK, width=3)

    # notice
    rounded(d, (250, 330, 950, 412), 12, MINT_SOFT, (203, 233, 221), 1)
    d.text((270, 348), "为了遵守法律法规，下载游戏功能需要输入", font=font(16), fill=INK_SOFT)
    d.text((270, 374), "管理员密码后才可以使用。", font=font(16, True), fill=INK_SOFT)

    d.text((250, 444), "管理员密码", font=font(13), fill=MUTED)
    rounded(d, (250, 468, 950, 526), 10, (250, 251, 251), (214, 221, 217), 1)
    for i in range(8):
        d.ellipse((272 + i * 22, 491, 282 + i * 22, 501), fill=INK_SOFT)
    d.text((900, 486), "显示", font=font(13), fill=MUTED)

    rounded(d, (640, 556, 736, 598), 9, SURFACE, (214, 221, 217), 1)
    d.text((666, 567), "取消", font=font(14), fill=INK_SOFT)
    rounded(d, (748, 556, 950, 598), 9, MINT)
    d.text((806, 567), "验证并进入", font=font(14, True), fill=(255, 255, 255))

    d.text((250, 602), "连续输错 5 次将锁定 30 秒 · 验证仅在本次运行内有效", font=font(12), fill=MUTED)
    d.text((210, 688), "界面示意 · 实际管理员密码由维护者提供", font=font(13), fill=(225, 236, 231))

    base.convert("RGB").save(IMG / "password-gate.png", optimize=True)


# ---------------------------------------------------------------- feature overview
def make_features():
    W, H = 1440, 1120
    im = Image.new("RGB", (W, H), (250, 251, 251))
    d = ImageDraw.Draw(im)
    # subtle top decorations
    d.ellipse((1050, -260, 1600, 290), fill=(234, 247, 241))
    d.ellipse((-220, 720, 360, 1300), fill=(243, 248, 245))
    d.text((72, 66), "11 项新增能力", font=font(38, True), fill=INK)
    d.text((74, 122), "从下载安全，到日常维护，把每一步都做得更顺手。", font=font(17), fill=MUTED)
    d.text((1190, 72), "WARM WATER 1.0", font=font(13, True), fill=MINT_DARK)

    items = [
        ("01", "下载权限保护", "管理员密码、失败锁定、页面二次遮罩", MINT),
        ("02", "全局命令面板", "Ctrl + K 搜索页面、实例与功能", (74, 144, 226)),
        ("03", "通知中心", "账号 / 实例 / Java / 下载状态一屏掌握", (217, 138, 43)),
        ("04", "一键启动体检", "100 分制检查账号、Java、版本与磁盘", (46, 158, 120)),
        ("05", "智能性能调优", "按物理内存匹配内存与 G1 GC 参数", (127, 106, 204)),
        ("06", "下载镜像测速", "BMCLAPI / Mojang / MCIM 延迟对比", (41, 151, 186)),
        ("07", "启动器配置备份", "配置、账号摘要、实例清单一键导出", (217, 138, 43)),
        ("08", "诊断日志打包", "日志与崩溃信息打包到桌面", (95, 118, 164)),
        ("09", "桌面快捷方式", "自动带图标与工作目录", (46, 158, 120)),
        ("10", "空间清理", "缓存、日志、崩溃报告与临时文件", (214, 112, 84)),
        ("11", "专注模式", "隐藏侧边栏，按 Esc 随时返回", (127, 106, 204)),
    ]

    cols, gap = 3, 18
    card_w = (W - 144 - gap * (cols - 1)) // cols
    card_h = 190
    x0, y0 = 72, 180
    for idx, (num, title, desc, tint) in enumerate(items):
        c, r = idx % cols, idx // cols
        x = x0 + c * (card_w + gap)
        y = y0 + r * (card_h + gap)
        rounded(d, (x, y, x + card_w, y + card_h), 16, SURFACE, HAIR, 1)
        d.ellipse((x + 22, y + 22, x + 52, y + 52), fill=tuple(min(255, v + 226) for v in tint))
        d.text((x + 30, y + 30), num, font=font(11, True), fill=tint)
        d.text((x + 22, y + 72), title, font=font(19, True), fill=INK)
        # wrap description
        words = desc
        line = ""
        lines = []
        fnt = font(13)
        for ch in words:
            if d.textlength(line + ch, font=fnt) > card_w - 44:
                lines.append(line)
                line = ch
            else:
                line += ch
        if line:
            lines.append(line)
        for i, line in enumerate(lines[:2]):
            d.text((x + 22, y + 108 + i * 25), line, font=fnt, fill=MUTED)

    d.text((72, 1058), "温水启动器 1.0 正式版", font=font(15, True), fill=INK_SOFT)
    d.text((1226, 1058), "简洁 · 安全 · 高效", font=font(14), fill=MINT_DARK)
    im.save(IMG / "features.png", optimize=True)


# ---------------------------------------------------------------- access flow
def make_flow():
    W, H = 1440, 500
    im = Image.new("RGB", (W, H), (255, 255, 255))
    d = ImageDraw.Draw(im)
    d.text((72, 54), "下载权限验证流程", font=font(32, True), fill=INK)
    d.text((74, 105), "每次启动器运行期间，需完成一次管理员验证；重启后重新校验。", font=font(15), fill=MUTED)

    steps = [
        ("1", "打开下载", "导航、悬浮下载按钮、快捷入口", (46, 158, 120)),
        ("2", "管理员验证", "输入密码，校验 SHA-256 摘要", (74, 144, 226)),
        ("3", "失败保护", "连续错 5 次锁定 30 秒", (217, 138, 43)),
        ("4", "解锁下载", "会话内有效，页面二次遮罩", (127, 106, 204)),
    ]
    y = 220
    x = 72
    card_w = 296
    for idx, (num, title, desc, tint) in enumerate(steps):
        rounded(d, (x, y, x + card_w, y + 180), 16, (250, 251, 251), HAIR, 1)
        d.ellipse((x + 22, y + 24, x + 56, y + 58), fill=tint)
        d.text((x + 34, y + 32), num, font=font(13, True), fill=(255, 255, 255))
        d.text((x + 22, y + 78), title, font=font(19, True), fill=INK)
        d.text((x + 22, y + 116), desc, font=font(13), fill=MUTED)
        if idx < 3:
            d.line((x + card_w + 12, y + 90, x + card_w + 34, y + 90), fill=(198, 210, 204), width=2)
            d.polygon([(x + card_w + 34, y + 90), (x + card_w + 25, y + 85), (x + card_w + 25, y + 95)], fill=(198, 210, 204))
        x += card_w + 48
    d.text((72, 442), "合规提示：为了遵守法律法规，下载游戏功能需要输入管理员密码后才可以使用。", font=font(14), fill=INK_SOFT)
    im.save(IMG / "access-flow.png", optimize=True)


make_banner()
make_home()
make_gate()
make_features()
make_flow()
print("images generated")
