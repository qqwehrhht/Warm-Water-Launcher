using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Microsoft.Win32;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageLogs : UserControl, IActivatePage
{
    private bool _subscribed;

    public PageLogs()
    {
        InitializeComponent();
    }

    public void OnActivate()
    {
        if (!_subscribed)
        {
            _subscribed = true;
            App.Services.Logs.LogBuffer.CollectionChanged += (_, _) =>
            {
                Dispatcher.BeginInvoke(DispatcherPriority.Background, () =>
                {
                    var count = App.Services.Logs.LogBuffer.Count;
                    LogList.ItemsSource = App.Services.Logs.LogBuffer.ToList();
                    if (AutoScrollBox.IsChecked == true && LogList.Items.Count > 0)
                    {
                        try { LogList.ScrollIntoView(LogList.Items[LogList.Items.Count - 1]); }
                        catch { }
                    }
                });
            };
        }
        CrashStatus.Text = "实时日志会自动显示。若游戏崩溃，点击「分析崩溃报告」自动定位问题模组。";
    }

    private void CopyLog_Click(object sender, RoutedEventArgs e)
    {
        var text = string.Join("\n", App.Services.Logs.LogBuffer);
        if (text.Length == 0)
        {
            // 复制最新日志文件
            var dir = App.Services.Logs.LogDir;
            if (Directory.Exists(dir))
            {
                var f = Directory.GetFiles(dir).OrderByDescending(x => File.GetLastWriteTime(x)).FirstOrDefault();
                if (f != null) text = File.ReadAllText(f);
            }
        }
        // 剪贴板可能被其他程序占用，重试最多5次
        bool copied = false;
        for (int i = 0; i < 5 && !copied; i++)
        {
            try
            {
                Clipboard.SetText(text);
                copied = true;
            }
            catch
            {
                System.Threading.Thread.Sleep(100 * (i + 1));
            }
        }
        if (copied)
            CrashStatus.Text = "日志已复制到剪贴板。";
        else
            CrashStatus.Text = "复制失败：剪贴板被其他程序占用，请稍后重试。";
    }

    private void ClearLog_Click(object sender, RoutedEventArgs e)
    {
        App.Services.Logs.LogBuffer.Clear();
        LogList.ItemsSource = null;
    }

    private void OpenLogDir_Click(object sender, RoutedEventArgs e)
    {
        var dir = App.Services.Logs.LogDir;
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }

    private void AnalyzeCrash_Click(object sender, RoutedEventArgs e)
    {
        var inst = App.Services.Instances.Current;
        if (inst == null) { CrashStatus.Text = "请先选择实例"; return; }
        var gameDir = App.Services.Instances.GetInstanceGameDir(inst);
        var crash = App.Services.Logs.ReadLatestCrashReport(gameDir);
        if (crash == null)
        {
            CrashStatus.Text = "未在游戏目录 crash-reports 中找到崩溃报告。\n（提示：也可在下方日志中手动查找 ERROR 行）";
            return;
        }
        var analysis = App.Services.Logs.AnalyzeCrash(crash);
        // 从解决方案库查找更精准的解决方案
        var solution = CrashSolutionLibrary.FindSolution(crash);
        string solutionText = "";
        if (solution != null)
        {
            solutionText = $"\n\n【精准解决方案 - {solution.Title}】\n{solution.Solution}";
        }
        CrashStatus.Text = $"【崩溃原因】{analysis.Cause}\n【问题模组】{(analysis.SuspiciousMods.Count > 0 ? string.Join("、", analysis.SuspiciousMods) : "未定位到")}\n【建议】{analysis.Advice}{solutionText}";
    }
}
