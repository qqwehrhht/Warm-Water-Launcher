using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class ModVersionDialog : Window
{
    private List<ModrinthVersion> _allVersions = new();
    private List<ModrinthVersion> _filteredVersions = new();
    private int _currentPage = 1;
    private int _pageSize = 20;
    private readonly string _targetVersion;
    private readonly ModrinthApi _api;
    private readonly string _instVersion;
    private readonly string _loader;
    // 已安装模组的 projectId 集合（用于判断前置是否已安装）
    private HashSet<string> _installedProjectIds = new();

    public ModrinthFile? SelectedFile { get; private set; }
    public ModrinthVersion? SelectedVersion { get; private set; }

    public ModVersionDialog(ModrinthMod mod, ModrinthApi api, string instVersion, string searchVersion, string loader = "")
    {
        InitializeComponent();
        ModTitle.Text = mod.Title ?? mod.Slug ?? "模组";
        _targetVersion = string.IsNullOrEmpty(searchVersion) ? instVersion : searchVersion;
        _api = api;
        _instVersion = instVersion;
        _loader = loader ?? "";
        FilterInfo.Text = $"已显示该项目的全部版本。若你的实例是 {_targetVersion}" + (string.IsNullOrEmpty(_loader) ? "" : $" / {_loader}") + "，可在下方按加载器/游戏版本筛选到匹配版本。每个版本会显示前置依赖资源。";

        // 收集当前实例已安装的模组 projectId
        try
        {
            var inst = App.Services.Instances.Current;
            if (inst != null)
            {
                foreach (var m in App.Services.Mods.ListMods(inst))
                {
                    if (!string.IsNullOrEmpty(m.ProjectId))
                        _installedProjectIds.Add(m.ProjectId);
                }
            }
        }
        catch { }

        Loaded += async (_, _) =>
        {
            try
            {
                var all = await api.GetVersionsAsync(mod.ProjectId);
                _allVersions = all.OrderByDescending(v => v.DatePublished).ToList();

                // 批量获取所有版本的前置依赖项目信息（名称、图标）
                await LoadDependencyProjectsAsync();

                // 填充游戏版本下拉框（默认全部版本，不强制当前版本，避免筛选为空导致看不到任何版本）
                var gameVersions = _allVersions.SelectMany(v => v.GameVersions).Distinct().OrderByDescending(v => v, new VersionComparer()).ToList();
                GameVersionCombo.Items.Clear();
                GameVersionCombo.Items.Add(new ComboBoxItem { Content = "全部版本", Tag = "" });
                foreach (var gv in gameVersions)
                {
                    GameVersionCombo.Items.Add(new ComboBoxItem { Content = gv, Tag = gv });
                }
                GameVersionCombo.SelectedIndex = 0;

                // 若当前实例版本存在则提示可快速筛选
                ApplyFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载版本列表失败：{ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        };
    }

    /// <summary>
    /// 批量获取所有版本的前置依赖项目信息（名称、图标），并标记是否已安装
    /// </summary>
    private async Task LoadDependencyProjectsAsync()
    {
        try
        {
            // 收集所有 required 依赖的 project_id
            var depProjectIds = _allVersions
                .SelectMany(v => v.Dependencies)
                .Where(d => d.DependencyType == "required" && !string.IsNullOrEmpty(d.ProjectId))
                .Select(d => d.ProjectId!)
                .Distinct()
                .ToList();
            if (depProjectIds.Count == 0) return;

            // 批量查询项目信息
            var projects = await _api.GetProjectsAsync(depProjectIds);
            foreach (var v in _allVersions)
            {
                foreach (var dep in v.Dependencies)
                {
                    if (!string.IsNullOrEmpty(dep.ProjectId) && projects.TryGetValue(dep.ProjectId, out var proj))
                    {
                        dep.ProjectName = proj.Title ?? proj.Slug ?? dep.ProjectId;
                        dep.IconUrl = proj.IconUrl;
                    }
                    dep.IsInstalled = !string.IsNullOrEmpty(dep.ProjectId) && _installedProjectIds.Contains(dep.ProjectId);
                }
            }
        }
        catch { }
    }

    /// <summary>应用筛选并刷新列表</summary>
    private void ApplyFilters()
    {
        string loader = (LoaderCombo.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "";
        string gameVer = (GameVersionCombo.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "";

        _filteredVersions = _allVersions.Where(v =>
        {
            if (!string.IsNullOrEmpty(loader) && !v.Loaders.Any(l => l.Equals(loader, StringComparison.OrdinalIgnoreCase)))
                return false;
            if (!string.IsNullOrEmpty(gameVer) && !v.GameVersions.Contains(gameVer))
                return false;
            return true;
        }).ToList();

        // 降级：若当前筛选结果为空但存在筛选条件，自动放宽为全部版本，避免用户误以为“没有版本”
        if (_filteredVersions.Count == 0 && (!string.IsNullOrEmpty(loader) || !string.IsNullOrEmpty(gameVer)))
        {
            _filteredVersions = new List<ModrinthVersion>(_allVersions);
            _noVersionHint = $"未找到匹配 {loader}{(string.IsNullOrEmpty(gameVer)?"":"/"+gameVer)} 的版本，已显示全部 {_allVersions.Count} 个版本，请调整筛选。";
        }
        else
        {
            _noVersionHint = _allVersions.Count == 0 ? "该项目暂时没有可下载的版本。" : "";
        }

        _currentPage = 1;
        RefreshPage();
    }

    private string _noVersionHint = "";

    /// <summary>刷新当前页显示</summary>
    private void RefreshPage()
    {
        int total = _filteredVersions.Count;
        int totalPages = Math.Max(1, (int)Math.Ceiling((double)total / _pageSize));
        if (_currentPage > totalPages) _currentPage = totalPages;
        if (_currentPage < 1) _currentPage = 1;

        int skip = (_currentPage - 1) * _pageSize;
        var pageItems = _filteredVersions.Skip(skip).Take(_pageSize).Select(v => new VersionVM(v)).ToList();
        VersionList.ItemsSource = pageItems;

        PageInfo.Text = $"共 {total} 个版本，第 {_currentPage}/{totalPages} 页" + (string.IsNullOrEmpty(_noVersionHint) ? "" : "\n" + _noVersionHint);

        FirstPageBtn.IsEnabled = _currentPage > 1;
        PrevPageBtn.IsEnabled = _currentPage > 1;
        NextPageBtn.IsEnabled = _currentPage < totalPages;
        LastPageBtn.IsEnabled = _currentPage < totalPages;
    }

    private void Filter_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (_allVersions.Count > 0) ApplyFilters();
    }

    private void ResetFilter_Click(object sender, RoutedEventArgs e)
    {
        LoaderCombo.SelectedIndex = 0;
        GameVersionCombo.SelectedIndex = 0;
        ApplyFilters();
    }

    private void PageSize_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (PageSizeCombo.SelectedItem is ComboBoxItem item && int.TryParse(item.Tag?.ToString(), out int size))
        {
            _pageSize = size;
            if (_allVersions.Count > 0) RefreshPage();
        }
    }

    private void FirstPage_Click(object sender, RoutedEventArgs e) { _currentPage = 1; RefreshPage(); }
    private void PrevPage_Click(object sender, RoutedEventArgs e) { _currentPage--; RefreshPage(); }
    private void NextPage_Click(object sender, RoutedEventArgs e) { _currentPage++; RefreshPage(); }
    private void LastPage_Click(object sender, RoutedEventArgs e)
    {
        _currentPage = Math.Max(1, (int)Math.Ceiling((double)_filteredVersions.Count / _pageSize));
        RefreshPage();
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (VersionList.SelectedItem is VersionVM vm)
        {
            // 优先选择 primary 标记的主文件，其次选最大的文件（避免选中错误的小文件导致下载几 KB）
            SelectedFile = ModrinthFileSelector.PickPrimary(vm.Version.Files);
            if (SelectedFile == null)
            {
                MessageBox.Show("该版本没有可下载的文件", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            SelectedVersion = vm.Version;
            DialogResult = true;
        }
        else
        {
            MessageBox.Show("请选择一个版本（且该版本需包含可下载文件）", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}

/// <summary>版本视图模型</summary>
public class VersionVM
{
    public ModrinthVersion Version { get; }
    public VersionVM(ModrinthVersion v) => Version = v;

    /// <summary>前置依赖显示文本（required 类型）</summary>
    public string DependenciesText
    {
        get
        {
            var req = Version.Dependencies.Where(d => d.DependencyType == "required" && !string.IsNullOrEmpty(d.ProjectName)).ToList();
            if (req.Count == 0) return "无前置依赖";
            return string.Join("、", req.Select(d => (d.IsInstalled ? "[已装]" : "[未装]") + d.ProjectName));
        }
    }

    /// <summary>前置依赖列表（用于图标展示）</summary>
    public List<DependencyVM> Dependencies
    {
        get
        {
            return Version.Dependencies
                .Where(d => d.DependencyType == "required")
                .Select(d => new DependencyVM(d))
                .ToList();
        }
    }

    /// <summary>是否有前置依赖</summary>
    public bool HasDependencies => Version.Dependencies.Any(d => d.DependencyType == "required" && !string.IsNullOrEmpty(d.ProjectName));

    /// <summary>是否所有前置都已安装</summary>
    public bool AllDepsInstalled => Version.Dependencies.Where(d => d.DependencyType == "required").All(d => d.IsInstalled);

    public string Name => Version.Name;
    public string VersionNumber => Version.VersionNumber;
    public string LoaderText => Version.Loaders.Count > 0 ? string.Join(", ", Version.Loaders) : "任意";
    public string GameText => Version.GameVersions.Count > 3 ? string.Join(", ", Version.GameVersions.Take(3)) + "..." : string.Join(", ", Version.GameVersions);
    public string DateText
    {
        get
        {
            if (DateTime.TryParse(Version.DatePublished, out DateTime dt))
                return dt.ToString("yyyy-MM-dd");
            return Version.DatePublished ?? "";
        }
    }
    public string FileName
    {
        get
        {
            var f = ModrinthFileSelector.PickPrimary(Version.Files);
            return f != null ? f.Filename : "无文件";
        }
    }
    public string FileSizeText
    {
        get
        {
            var pick = ModrinthFileSelector.PickPrimary(Version.Files);
            if (pick == null) return "";
            long size = pick.Size;
            if (size > 1048576) return $"{size / 1048576.0:F1} MB";
            if (size > 1024) return $"{size / 1024.0:F1} KB";
            return $"{size} B";
        }
    }
    public string ReleaseTypeText
    {
        get
        {
            string? type = Version.VersionType;
            return type?.ToLower() switch
            {
                "release" => "正式版",
                "beta" => "测试版",
                "alpha" => "开发版",
                _ => type ?? ""
            };
        }
    }
}

/// <summary>前置依赖视图模型</summary>
public class DependencyVM
{
    public ModrinthDependency Dependency { get; }
    public DependencyVM(ModrinthDependency d) => Dependency = d;

    public string Name => Dependency.ProjectName ?? Dependency.FileName ?? "未知前置";
    public string IconUrl => Dependency.IconUrl ?? "";
    public bool IsInstalled => Dependency.IsInstalled;
    public string StatusText => Dependency.IsInstalled ? "已安装" : "未安装";
    public string StatusColor => Dependency.IsInstalled ? "#FF6BC05C" : "#FFE0534B";
    public string DepTypeText => Dependency.DependencyType switch
    {
        "required" => "必需",
        "optional" => "可选",
        "incompatible" => "冲突",
        "embedded" => "内置",
        _ => Dependency.DependencyType
    };
}

/// <summary>版本号比较器</summary>
public class VersionComparer : IComparer<string>
{
    public int Compare(string? x, string? y)
    {
        if (x == y) return 0;
        if (string.IsNullOrEmpty(x)) return -1;
        if (string.IsNullOrEmpty(y)) return 1;

        var partsX = x.Split('.');
        var partsY = y.Split('.');
        int len = Math.Min(partsX.Length, partsY.Length);
        for (int i = 0; i < len; i++)
        {
            if (int.TryParse(partsX[i], out int ix) && int.TryParse(partsY[i], out int iy))
            {
                if (ix != iy) return ix.CompareTo(iy);
            }
            else
            {
                int cmp = string.Compare(partsX[i], partsY[i], StringComparison.OrdinalIgnoreCase);
                if (cmp != 0) return cmp;
            }
        }
        return partsX.Length.CompareTo(partsY.Length);
    }
}
