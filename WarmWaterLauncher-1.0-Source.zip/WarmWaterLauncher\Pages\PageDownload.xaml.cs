using System.Windows;
using System.Windows.Controls;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageDownload : UserControl, IActivatePage
{
    private List<VersionMeta> _allVersions = new();
    private System.IO.FileSystemWatcher? _watcher;
    private System.Windows.Threading.DispatcherTimer? _refreshTimer;
    private bool _loadingVersions;
    private bool _reloadPending;
    private bool _suppressComboEvents;

    public PageDownload()
    {
        InitializeComponent();
        Unloaded += (_, _) => { try { if (_watcher != null) _watcher.EnableRaisingEvents = false; } catch { } };
    }

    public void OnActivate()
    {
        ApplyAccessState();
        LoadedOnce();
        StartWatcher();
    }

    private void ApplyAccessState()
    {
        try
        {
            // 下载密码锁已移除，下载页直接可用。
            if (LockBadgeText != null)
            {
                LockBadgeText.Text = "下载已开放";
                LockBadgeText.Foreground = (System.Windows.Media.Brush)FindResource("MintDarkBrush");
            }
        }
        catch { }
    }

    /// <summary>实时监听版本目录变化，下载完成自动刷新已装版本列表</summary>
    private void StartWatcher()
    {
        try
        {
            var dir = App.Services.Settings.GlobalVersionsDir;
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            if (_watcher == null)
            {
                _watcher = new System.IO.FileSystemWatcher(dir)
                {
                    IncludeSubdirectories = true,
                    NotifyFilter = System.IO.NotifyFilters.DirectoryName | System.IO.NotifyFilters.FileName | System.IO.NotifyFilters.LastWrite
                };
                _watcher.Created += OnVersionDirChanged;
                _watcher.Deleted += OnVersionDirChanged;
                _watcher.Renamed += OnVersionDirChanged;
                _refreshTimer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(800) };
                _refreshTimer.Tick += (_, _) => { _refreshTimer.Stop(); RefreshInstalled(); };
            }
            _watcher.EnableRaisingEvents = true;
        }
        catch { }
    }

    private void OnVersionDirChanged(object sender, System.IO.FileSystemEventArgs e)
    {
        Dispatcher.Invoke(() =>
        {
            if (_refreshTimer == null) return;
            _refreshTimer.Stop();
            _refreshTimer.Start();
        });
    }

    private bool _loaded;
    private async void LoadedOnce()
    {
        if (_loadingVersions)
        {
            _reloadPending = true;
            return;
        }
        if (_loaded)
        {
            RefreshInstalled();
            return;
        }

        _loadingVersions = true;
        _loaded = true;
        MainWindow.Get()?.ShowBusy("正在加载版本列表，请稍候...");
        try
        {
            // 初始化下拉框时屏蔽 SelectionChanged，避免反复触发版本列表加载
            _suppressComboEvents = true;
            foreach (var item in SourceCombo.Items)
                if (item is ComboBoxItem ci && ci.Tag?.ToString() == App.Services.Settings.Config.Download.Source)
                    SourceCombo.SelectedItem = item;
            foreach (var item in ThreadCombo.Items)
                if (item is ComboBoxItem ci && ci.Tag?.ToString() == App.Services.Settings.Config.Download.Threads.ToString())
                    ThreadCombo.SelectedItem = item;
            _suppressComboEvents = false;

            DlStatus.Text = "正在获取版本列表...";
            var fetchTask = App.Services.Versions.GetVersionListAsync();
            var completed = await Task.WhenAny(fetchTask, Task.Delay(TimeSpan.FromSeconds(30)));
            if (completed != fetchTask)
            {
                _loaded = false;
                DlStatus.Text = "获取版本列表超时，请检查网络或切换镜像后点击刷新";
                return;
            }
            _allVersions = await fetchTask;
            ApplyFilter();
            DlStatus.Text = $"已获取 {_allVersions.Count} 个版本";
            RefreshInstalled();
        }
        catch (Exception ex)
        {
            _loaded = false;
            DlStatus.Text = "获取版本列表失败：" + ex.Message;
        }
        finally
        {
            _suppressComboEvents = false;
            _loadingVersions = false;
            MainWindow.Get()?.HideBusy();
            if (_reloadPending)
            {
                _reloadPending = false;
                _loaded = false;
                LoadedOnce();
            }
        }
    }

    private void ApplyFilter()
    {
        var favorites = (App.Services.Settings.Config.General.FavoriteVersions ?? "")
            .Split(',', StringSplitOptions.RemoveEmptyEntries)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var v in _allVersions)
            v.IsFavorite = favorites.Contains(v.Id);

        var keyword = (VersionSearchBox?.Text ?? "").Trim();
        var filtered = _allVersions.Where(v =>
        {
            if (!string.IsNullOrEmpty(keyword) &&
                !v.Id.Contains(keyword, StringComparison.OrdinalIgnoreCase) &&
                !v.TypeName.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                return false;

            if (RRelease.IsChecked == true) return v.Type == VersionType.Release;
            if (RSnapshot.IsChecked == true) return v.Type == VersionType.Snapshot;
            if (ROld.IsChecked == true) return v.Type == VersionType.OldBeta || v.Type == VersionType.OldAlpha;
            if (RFools.IsChecked == true) return v.Type == VersionType.AprilFools;
            return true;
        })
        .OrderByDescending(v => v.IsFavorite)
        .ThenByDescending(v => v.ReleaseTime, StringComparer.Ordinal)
        .ToList();

        VersionList.ItemsSource = null;
        VersionList.ItemsSource = filtered;
        if (VersionCountText != null)
            VersionCountText.Text = $"{filtered.Count} 个版本";
    }

    private void Filter_Changed(object sender, RoutedEventArgs e)
    {
        if (_loaded) ApplyFilter();
    }

    private void VersionSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        var text = (sender as TextBox)?.Text ?? "";
        if (VersionSearchHint != null)
            VersionSearchHint.Visibility = string.IsNullOrEmpty(text) ? Visibility.Visible : Visibility.Collapsed;
        if (_loaded) ApplyFilter();
    }

    private void RefreshInstalled()
    {
        var installed = App.Services.Versions.GetInstalledVersions();
        InstalledVersionList.ItemsSource = installed;
        // 加载器安装界面的版本下拉框：列出已安装 + 在线可选全部版本，保证未安装也能先选版本下载加载器
        var prev = McVersionCombo.SelectedItem as string;
        var allVers = new List<string>();
        foreach (var v in _allVersions) allVers.Add(v.Id);
        // 已安装但不在在线列表中的也补上（如加载器版本、离线导入）
        foreach (var v in installed) if (!allVers.Contains(v)) allVers.Add(v);
        McVersionCombo.ItemsSource = allVers;
        if (prev != null && allVers.Contains(prev))
            McVersionCombo.SelectedItem = prev;
        else if (installed.Count > 0)
            McVersionCombo.SelectedItem = installed[0];
        else if (allVers.Count > 0)
            McVersionCombo.SelectedIndex = 0;
    }

    private void SourceCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressComboEvents) return;
        if (SourceCombo.SelectedItem is ComboBoxItem ci)
        {
            App.Services.Settings.Config.Download.Source = ci.Tag?.ToString() ?? "bmclapi";
            App.Services.Settings.Save();
            _loaded = false;
            if (_loadingVersions) _reloadPending = true;
            else LoadedOnce();
        }
    }

    private void ThreadCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressComboEvents) return;
        if (ThreadCombo.SelectedItem is ComboBoxItem ci && int.TryParse(ci.Tag?.ToString(), out var n))
        {
            App.Services.Settings.Config.Download.Threads = n;
            App.Services.Settings.Save();
        }
    }

    private void Refresh_Click(object sender, RoutedEventArgs e)
    {
        _loaded = false;
        if (_loadingVersions) _reloadPending = true;
        else LoadedOnce();
    }

    /// <summary>收藏/取消收藏版本</summary>
    private void FavoriteVersion_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button btn && btn.Tag is VersionMeta v)
        {
            var favorites = (App.Services.Settings.Config.General.FavoriteVersions ?? "")
                .Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
            if (favorites.Contains(v.Id))
            {
                favorites.Remove(v.Id);
                btn.Content = "☆";
                v.IsFavorite = false;
            }
            else
            {
                favorites.Add(v.Id);
                btn.Content = "★";
                v.IsFavorite = true;
            }
            App.Services.Settings.Config.General.FavoriteVersions = string.Join(",", favorites);
            App.Services.Settings.Save();
        }
    }

    private async void InstallVersion_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not VersionMeta vm) return;

        var current = App.Services.Instances.Current;
        string defaultLoader = (AutoLoaderCombo.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "none";
        var dialog = new VersionInstallDialog(vm, current, defaultLoader)
        {
            Owner = Window.GetWindow(this)
        };
        if (dialog.ShowDialog() != true) return;

        bool createNew = dialog.CreateNewInstance;
        string? loaderType = dialog.SelectedLoaderType;
        LoaderVersion? loaderVersion = dialog.SelectedLoaderVersion;
        GameInstance? inst = current;
        if (createNew || inst == null)
        {
            inst = App.Services.Instances.Create("我的世界 " + vm.Id, vm.Id, "由下载页创建");
        }
        if (inst == null) return;

        var btn = sender as Button;
        if (btn == null) return;
        btn.IsEnabled = false;
        DlSpeed.Text = "";

        Action<string, string>? speedHandler = null;
        speedHandler = (url, status) =>
        {
            if (status.Contains("速度") || status.Contains("已下载"))
                Dispatcher.Invoke(() => DlSpeed.Text = status);
        };
        App.Services.Download.TaskStatus += speedHandler;
        MainWindow.Get()?.ShowBusy($"正在下载并安装 {vm.Id}，请稍候...");

        try
        {
            var progress = new Progress<(string desc, double pct, int ok, int total)>(p =>
            {
                DlStatus.Text = p.desc;
                DlProgress.Value = Math.Max(0, Math.Min(100, p.pct * 100));
            });
            DlStatus.Text = "正在下载 " + vm.Id + " ...";
            var ok = await App.Services.Versions.DownloadVersionAsync(vm.Id, progress);
            if (!ok)
            {
                DlStatus.Text = $"版本 {vm.Id} 下载失败，请检查网络或更换下载源";
                return;
            }

            if (inst.VersionId != vm.Id)
            {
                inst.VersionId = vm.Id;
                inst.LoaderType = "none";
                inst.LoaderVersion = null;
                App.Services.Settings.Save();
            }

            if (loaderType != null && loaderVersion != null)
            {
                DlStatus.Text = $"版本 {vm.Id} 安装完成，正在安装 {LoaderCatalog.DisplayName(loaderType)} {loaderVersion.Version}...";
                DlProgress.Value = 60;
                try
                {
                    var loaderProgress = new Progress<(string status, double pct)>(p =>
                    {
                        DlStatus.Text = p.status;
                        DlProgress.Value = 60 + p.pct * 40;
                    });
                    bool loaderOk = await App.Services.Loaders.InstallAsync(inst, loaderType, loaderVersion.Version, loaderProgress);
                    DlStatus.Text = loaderOk
                        ? $"版本 {vm.Id} + {LoaderCatalog.DisplayName(loaderType)} {loaderVersion.Version} 安装完成！"
                        : $"版本 {vm.Id} 安装完成，但 {LoaderCatalog.DisplayName(loaderType)} 加载器安装失败，可在「加载器安装」页面手动安装";
                }
                catch (Exception ex)
                {
                    DlStatus.Text = $"版本 {vm.Id} 安装完成，但加载器安装出错：{ex.Message}";
                }
            }
            else
            {
                DlStatus.Text = $"版本 {vm.Id} 安装完成！";
            }
        }
        finally
        {
            App.Services.Download.TaskStatus -= speedHandler;
            DlSpeed.Text = "";
            btn.IsEnabled = true;
            MainWindow.Get()?.HideBusy();
        }
        RefreshInstalled();
        App.MainWin?.RefreshTopBar();
    }

    private List<LoaderVersion> _loaderVers = new();

    /// <summary>统一加载加载器可用版本并填充下拉框，自动选中第一项</summary>
    private async Task LoadLoaderVersionsAsync()
    {
        if (McVersionCombo.SelectedItem is not string mc) return;
        var type = (LoaderTypeCombo.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "fabric";
        LoaderStatus.Text = "正在获取 " + type + " 可用版本...";
        var vers = await App.Services.Loaders.GetAvailableAsync(type, mc);
        _loaderVers = vers;
        LoaderVerCombo.ItemsSource = vers.Select(v => v.Display).ToList();
        if (vers.Count > 0)
        {
            LoaderVerCombo.SelectedIndex = 0; // 自动选中第一个，让下拉框显示版本号
            LoaderStatus.Text = $"获取到 {vers.Count} 个版本：{vers[0].Display}";
        }
        else
        {
            LoaderVerCombo.SelectedIndex = -1;
            LoaderStatus.Text = $"未找到 {type} 在 {mc} 的可用版本，可尝试「获取可用版本」刷新";
        }
    }

    private async void McVersionCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        LoaderVerCombo.ItemsSource = null;
        _loaderVers = new();
        await LoadLoaderVersionsAsync();
    }

    private async void LoaderTypeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        await LoadLoaderVersionsAsync();
    }

    private async void LoadLoaderVers_Click(object sender, RoutedEventArgs e)
    {
        await LoadLoaderVersionsAsync();
    }

    private async void InstallLoader_Click(object sender, RoutedEventArgs e)
    {
        if (McVersionCombo.SelectedItem is not string mc)
        {
            MessageBox.Show("请先选择已安装的游戏版本", "温水启动器");
            return;
        }
        var type = (LoaderTypeCombo.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "fabric";
        int idx = LoaderVerCombo.SelectedIndex;
        if (idx < 0 || idx >= _loaderVers.Count)
        {
            MessageBox.Show("请选择加载器版本", "温水启动器");
            return;
        }
        var lv = _loaderVers[idx];

        var inst = App.Services.Instances.Current;
        if (inst == null || inst.VersionId != mc)
        {
            var r = MessageBox.Show($"将创建一个使用 {mc} 的实例并安装 {type}，是否继续？", "温水启动器",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (r != MessageBoxResult.Yes) return;
            inst = App.Services.Instances.Create("我的世界 " + mc, mc, "由加载器安装创建");
        }

        InstallLoaderBtn.IsEnabled = false;
        var progress = new Progress<(string status, double pct)>(p =>
        {
            LoaderStatus.Text = p.status;
        });
        MainWindow.Get()?.ShowBusy($"正在安装 {type} {lv.Version}...");
        bool ok;
        try
        {
            ok = await App.Services.Loaders.InstallAsync(inst, type, lv.Version, progress);
        }
        finally
        {
            InstallLoaderBtn.IsEnabled = true;
            MainWindow.Get()?.HideBusy();
        }
        if (ok)
            LoaderStatus.Text = $"{type} {lv.Version} 安装成功！可在「实例管理」中把实例加载器改为 {type} 并启动。";
        RefreshInstalled();
        App.MainWin?.RefreshTopBar();
    }
}
