using System.IO;
using System.Text.Json;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

/// <summary>游戏时间统计与游玩记录服务</summary>
public class PlayTimeService
{
    private readonly string _dataDir;
    private readonly string _recordFile;
    private PlayTimeData _data = new();
    private System.Threading.Timer? _heartbeat;

    public PlayTimeService()
    {
        _dataDir = Path.Combine(SettingsService.GetDataDir(), "playtime");
        Directory.CreateDirectory(_dataDir);
        _recordFile = Path.Combine(_dataDir, "records.json");
        Load();
        // 启动时补全未完成会话
        RecoverUnfinishedSessions();
        // 心跳：每30秒保存一次当前活跃会话
        _heartbeat = new System.Threading.Timer(_ => Heartbeat(), null, TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(30));
    }

    private void Load()
    {
        try
        {
            if (File.Exists(_recordFile))
            {
                var json = File.ReadAllText(_recordFile);
                _data = JsonSerializer.Deserialize<PlayTimeData>(json, SettingsService.JsonOpts) ?? new();
            }
        }
        catch { _data = new(); }
    }

    private void Save()
    {
        try
        {
            var json = JsonSerializer.Serialize(_data, SettingsService.JsonOpts);
            File.WriteAllText(_recordFile, json);
        }
        catch { }
    }

    /// <summary>启动时补全未完成会话（EndTime 为默认值的会话）</summary>
    private void RecoverUnfinishedSessions()
    {
        bool changed = false;
        foreach (var s in _data.Sessions)
        {
            if (s.EndTime == default(DateTime) || s.EndTime.Year < 2000)
            {
                // 用 StartTime + 预估时长（至少5分钟，最多2小时）补全
                var est = s.StartTime.AddMinutes(5);
                s.EndTime = est;
                s.DurationSeconds = Math.Max(0, (int)(est - s.StartTime).TotalSeconds);
                s.Recovered = true;
                changed = true;
            }
        }
        if (changed) Save();
    }

    /// <summary>心跳：更新当前活跃会话的 LastHeartbeat</summary>
    private void Heartbeat()
    {
        try
        {
            var active = _data.Sessions.FirstOrDefault(s => s.EndTime == default(DateTime) || s.EndTime.Year < 2000);
            if (active != null)
            {
                active.LastHeartbeat = DateTime.Now;
                Save();
            }
        }
        catch { }
    }

    /// <summary>开始一次游戏会话</summary>
    public PlaySession StartSession(string instanceId, string instanceName, string versionId, string accountName)
    {
        var session = new PlaySession
        {
            Id = Guid.NewGuid().ToString("N"),
            InstanceId = instanceId,
            InstanceName = instanceName,
            VersionId = versionId,
            AccountName = accountName,
            StartTime = DateTime.Now,
            LastHeartbeat = DateTime.Now
        };
        _data.Sessions.Add(session);
        if (_data.Sessions.Count > 500)
            _data.Sessions.RemoveRange(0, _data.Sessions.Count - 500);
        Save();
        return session;
    }

    /// <summary>结束游戏会话</summary>
    public void EndSession(string sessionId)
    {
        var session = _data.Sessions.FirstOrDefault(s => s.Id == sessionId);
        if (session != null)
        {
            session.EndTime = DateTime.Now;
            session.DurationSeconds = (int)(session.EndTime - session.StartTime).TotalSeconds;
            Save();
        }
    }

    /// <summary>启动器退出时强制结束所有未完成会话</summary>
    public void EndAllActiveSessions()
    {
        bool changed = false;
        foreach (var s in _data.Sessions)
        {
            if (s.EndTime == default(DateTime) || s.EndTime.Year < 2000)
            {
                s.EndTime = DateTime.Now;
                s.DurationSeconds = Math.Max(0, (int)(s.EndTime - s.StartTime).TotalSeconds);
                changed = true;
            }
        }
        if (changed) Save();
        _heartbeat?.Dispose();
    }

    /// <summary>获取总游戏时长（秒）</summary>
    public long GetTotalSeconds() => _data.Sessions.Where(s => s.DurationSeconds > 0).Sum(s => s.DurationSeconds);

    /// <summary>获取指定实例的总游戏时长</summary>
    public long GetInstanceSeconds(string instanceId) =>
        _data.Sessions.Where(s => s.InstanceId == instanceId && s.DurationSeconds > 0).Sum(s => s.DurationSeconds);

    /// <summary>获取今日游戏时长</summary>
    public long GetTodaySeconds()
    {
        var today = DateTime.Today;
        return _data.Sessions.Where(s => s.StartTime >= today && s.DurationSeconds > 0).Sum(s => s.DurationSeconds);
    }

    /// <summary>获取最近N次游玩记录</summary>
    public List<PlaySession> GetRecentSessions(int count = 20) =>
        _data.Sessions.OrderByDescending(s => s.StartTime).Take(count).ToList();

    /// <summary>格式化时长为可读字符串</summary>
    public static string FormatDuration(long seconds)
    {
        if (seconds < 60) return $"{seconds}秒";
        if (seconds < 3600) return $"{seconds / 60}分{seconds % 60}秒";
        var h = seconds / 3600;
        var m = (seconds % 3600) / 60;
        return $"{h}小时{m}分";
    }

    /// <summary>清除所有记录</summary>
    public void ClearAll()
    {
        _data = new();
        Save();
    }
}

public class PlayTimeData
{
    public List<PlaySession> Sessions { get; set; } = new();
}

public class PlaySession
{
    public string Id { get; set; } = "";
    public string InstanceId { get; set; } = "";
    public string InstanceName { get; set; } = "";
    public string VersionId { get; set; } = "";
    public string AccountName { get; set; } = "";
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public int DurationSeconds { get; set; }
    public DateTime LastHeartbeat { get; set; }
    public bool Recovered { get; set; }
}
