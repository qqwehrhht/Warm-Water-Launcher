using System;
using System.IO;
using System.IO.Compression;
using System.Text.Json;

namespace WarmWaterLauncher.Services;

/// <summary>
/// 启动器数据备份与恢复服务
/// </summary>
public class BackupService
{
    /// <summary>导出启动器配置到zip文件</summary>
    public bool ExportConfig(string zipPath)
    {
        try
        {
            if (File.Exists(zipPath)) File.Delete(zipPath);

            using var zip = ZipFile.Open(zipPath, ZipArchiveMode.Create);

            // 导出配置文件
            string configDir = Path.Combine(SettingsService.GetDataDir(), "config");
            if (Directory.Exists(configDir))
            {
                foreach (var file in Directory.GetFiles(configDir, "*.json", SearchOption.AllDirectories))
                {
                    string relPath = Path.GetRelativePath(configDir, file);
                    zip.CreateEntryFromFile(file, "config/" + relPath);
                }
            }

            // 导出账号信息（不含敏感凭证的摘要）
            var accounts = App.Services.Accounts.Accounts;
            string accountsJson = JsonSerializer.Serialize(accounts, new JsonSerializerOptions { WriteIndented = true });
            var entry = zip.CreateEntry("accounts_summary.json");
            using (var sw = new StreamWriter(entry.Open()))
                sw.Write(accountsJson);

            // 导出实例列表
            var instances = App.Services.Instances.Instances;
            string instancesJson = JsonSerializer.Serialize(instances, new JsonSerializerOptions { WriteIndented = true });
            var entry2 = zip.CreateEntry("instances.json");
            using (var sw = new StreamWriter(entry2.Open()))
                sw.Write(instancesJson);

            // 导出版本列表
            var versions = App.Services.Versions.GetInstalledVersions();
            string versionsJson = JsonSerializer.Serialize(versions, new JsonSerializerOptions { WriteIndented = true });
            var entry3 = zip.CreateEntry("versions.json");
            using (var sw = new StreamWriter(entry3.Open()))
                sw.Write(versionsJson);

            // 添加说明文件
            var readme = zip.CreateEntry("README.txt");
            using (var sw = new StreamWriter(readme.Open()))
                sw.Write("温水启动器配置备份\n" +
                         "导出时间：" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\n" +
                         "版本：1.0 正式版\n\n" +
                         "包含：\n" +
                         "- config/ 启动器配置文件\n" +
                         "- accounts_summary.json 账号摘要（不含密码）\n" +
                         "- instances.json 实例列表\n" +
                         "- versions.json 已安装版本列表\n\n" +
                         "使用方法：在启动器设置中选择「导入配置」即可恢复。");

            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>导入启动器配置</summary>
    public bool ImportConfig(string zipPath)
    {
        try
        {
            if (!File.Exists(zipPath)) return false;

            string tempDir = Path.Combine(Path.GetTempPath(), "WarmWaterBackup_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(tempDir);

            try
            {
                ZipFile.ExtractToDirectory(zipPath, tempDir);

                // 恢复配置文件
                string configSrc = Path.Combine(tempDir, "config");
                if (Directory.Exists(configSrc))
                {
                    string configDest = Path.Combine(SettingsService.GetDataDir(), "config");
                    foreach (var file in Directory.GetFiles(configSrc, "*.json", SearchOption.AllDirectories))
                    {
                        string relPath = Path.GetRelativePath(configSrc, file);
                        string destPath = Path.Combine(configDest, relPath);
                        Directory.CreateDirectory(Path.GetDirectoryName(destPath)!);
                        File.Copy(file, destPath, true);
                    }
                }

                // 重新加载配置
                App.Services.Settings.Load();

                return true;
            }
            finally
            {
                try { Directory.Delete(tempDir, true); } catch { }
            }
        }
        catch
        {
            return false;
        }
    }

    /// <summary>导出单个实例（含mods、配置、存档）</summary>
    public bool ExportInstance(string instanceId, string zipPath)
    {
        try
        {
            var inst = App.Services.Instances.Instances.FirstOrDefault(i => i.Id == instanceId);
            if (inst == null) return false;

            if (File.Exists(zipPath)) File.Delete(zipPath);

            string gameDir = App.Services.Instances.GetInstanceGameDir(inst);

            using var zip = ZipFile.Open(zipPath, ZipArchiveMode.Create);

            // 导出实例配置
            string instJson = JsonSerializer.Serialize(inst, new JsonSerializerOptions { WriteIndented = true });
            var entry = zip.CreateEntry("instance.json");
            using (var sw = new StreamWriter(entry.Open()))
                sw.Write(instJson);

            // 导出mods
            string modsDir = Path.Combine(gameDir, "mods");
            if (Directory.Exists(modsDir))
            {
                foreach (var file in Directory.GetFiles(modsDir, "*.jar", SearchOption.TopDirectoryOnly))
                {
                    zip.CreateEntryFromFile(file, "mods/" + Path.GetFileName(file));
                }
            }

            // 导出config
            string configDir = Path.Combine(gameDir, "config");
            if (Directory.Exists(configDir))
            {
                foreach (var file in Directory.GetFiles(configDir, "*.*", SearchOption.AllDirectories))
                {
                    string relPath = Path.GetRelativePath(configDir, file);
                    zip.CreateEntryFromFile(file, "config/" + relPath);
                }
            }

            // 导出resourcepacks
            string rpDir = Path.Combine(gameDir, "resourcepacks");
            if (Directory.Exists(rpDir))
            {
                foreach (var file in Directory.GetFiles(rpDir, "*.*", SearchOption.TopDirectoryOnly))
                {
                    zip.CreateEntryFromFile(file, "resourcepacks/" + Path.GetFileName(file));
                }
            }

            // 导出shaderpacks
            string spDir = Path.Combine(gameDir, "shaderpacks");
            if (Directory.Exists(spDir))
            {
                foreach (var file in Directory.GetFiles(spDir, "*.*", SearchOption.TopDirectoryOnly))
                {
                    zip.CreateEntryFromFile(file, "shaderpacks/" + Path.GetFileName(file));
                }
            }

            // 添加说明
            var readme = zip.CreateEntry("README.txt");
            using (var sw = new StreamWriter(readme.Open()))
                sw.Write($"温水启动器实例备份：{inst.Name}\n" +
                         $"游戏版本：{inst.VersionId}\n" +
                         $"加载器：{inst.LoaderType} {inst.LoaderVersion}\n" +
                         $"导出时间：{DateTime.Now:yyyy-MM-dd HH:mm:ss}\n\n" +
                         "包含：mods、config、resourcepacks、shaderpacks\n" +
                         "使用方法：在实例管理中选择「导入实例」即可恢复。");

            return true;
        }
        catch
        {
            return false;
        }
    }
}
