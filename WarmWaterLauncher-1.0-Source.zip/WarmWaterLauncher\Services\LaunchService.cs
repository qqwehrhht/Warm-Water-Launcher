using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

public class LaunchProgress
{
    public string Status { get; set; } = "";
    public double Percent { get; set; }
    /// <summary>启动流程步骤：1 检查文件，2 Java，3 其他检查，4 启动进程，5 等待游戏窗口。</summary>
    public int Step { get; set; }
    public bool Done { get; set; }
    public string? VersionId { get; set; }
}

public class LaunchResult
{
    public bool Ok { get; set; }
    public string? Error { get; set; }
    public Process? Process { get; set; }
    public long LaunchMs { get; set; }
}

/// <summary>游戏启动器：参数构建、资源装配、进程启动</summary>
public class LaunchService
{
    /// <summary>游戏崩溃事件（UI 层订阅以显示崩溃诊断）</summary>
    public static event EventHandler<CrashAnalysis>? GameCrashed;

    private readonly SettingsService _settings;
    private readonly DownloadService _dl;
    private readonly VersionService _versions;
    private readonly JavaService _java;
    private readonly ModService _mods;
    private readonly LogService _logs;
    private readonly InstanceService _instances;

    public LaunchService(SettingsService settings, DownloadService dl, VersionService versions,
        JavaService java, ModService mods, LogService logs, InstanceService instances)
    {
        _settings = settings;
        _dl = dl;
        _versions = versions;
        _java = java;
        _mods = mods;
        _logs = logs;
        _instances = instances;
    }

    public const string OsName = "windows";
    public const string OsArch = "x64";

    /// <summary>准备并启动游戏</summary>
    public async Task<LaunchResult> LaunchAsync(GameInstance inst, Account account,
        IProgress<LaunchProgress>? progress, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        progress?.Report(new LaunchProgress { Step = 1, Status = "正在检查游戏文件并补全...", Percent = 0.01 });
        // 1. 解析有效版本（含加载器）
        string versionId = inst.VersionId;
        var effectiveId = await ResolveEffectiveVersionAsync(inst);
        if (effectiveId != null) versionId = effectiveId;

        // 2. 获取版本 JSON
        var vj = await _versions.GetVersionJsonAsync(versionId);
        if (vj == null)
        {
            progress?.Report(new LaunchProgress { Status = "版本 JSON 解析失败，请先下载该版本", Done = true });
            return new LaunchResult { Ok = false, Error = "版本 JSON 解析失败，请先下载该版本 " + versionId };
        }

        // 2.1 处理 inheritsFrom：带加载器的版本需要合并原版版本的配置
        string originalVersionId = inst.VersionId;
        if (!string.IsNullOrEmpty(vj.InheritsFrom))
        {
            originalVersionId = vj.InheritsFrom;
            var parentVj = await _versions.GetVersionJsonAsync(vj.InheritsFrom);
            if (parentVj != null)
            {
                progress?.Report(new LaunchProgress { Status = $"正在合并 {vj.InheritsFrom} 版本配置...", Percent = 0.08 });
                // 合并库文件：子版本的库 + 父版本的库（子版本优先）
                var parentLibNames = new HashSet<string>(vj.Libraries.Select(l => l.Name));
                foreach (var lib in parentVj.Libraries)
                {
                    if (!parentLibNames.Contains(lib.Name))
                        vj.Libraries.Add(lib);
                }
                // 合并 assets 和 assetIndex
                if (string.IsNullOrEmpty(vj.Assets) && !string.IsNullOrEmpty(parentVj.Assets))
                    vj.Assets = parentVj.Assets;
                if (vj.AssetIndex == null && parentVj.AssetIndex != null)
                    vj.AssetIndex = parentVj.AssetIndex;
                // 合并 downloads（客户端 jar 来自父版本）
                if (vj.Downloads == null || vj.Downloads.Client == null)
                {
                    if (vj.Downloads == null) vj.Downloads = new DownloadsJson();
                    if (parentVj.Downloads?.Client != null)
                        vj.Downloads.Client = parentVj.Downloads.Client;
                }
                // 合并 javaVersion
                if (vj.JavaVersion == null && parentVj.JavaVersion != null)
                    vj.JavaVersion = parentVj.JavaVersion;
                // 合并 minecraftArguments（如果子版本没有自己的 arguments.game）
                if (vj.Arguments == null && !string.IsNullOrEmpty(parentVj.MinecraftArguments))
                    vj.MinecraftArguments = parentVj.MinecraftArguments;
            }
        }

        // 3. 确保版本文件就位（客户端 jar、版本 json）
        var versionDir = _instances.GetInstanceVersionsDir(inst);
        Directory.CreateDirectory(versionDir);
        string verFolder = Path.Combine(versionDir, versionId);
        Directory.CreateDirectory(verFolder);

        // 从多个可能的目录查找版本文件（全局、游戏根目录、实例目录）
        var possibleVersionDirs = new[]
        {
            Path.Combine(_settings.GlobalVersionsDir, versionId),
            Path.Combine(_settings.GameRoot, "versions", versionId),
            verFolder
        };

        // 复制版本 json 到实例版本目录（隔离模式需要）
        var instVerJson = Path.Combine(verFolder, versionId + ".json");
        if (!File.Exists(instVerJson))
        {
            bool copied = false;
            foreach (var srcDir in possibleVersionDirs)
            {
                var srcJson = Path.Combine(srcDir, versionId + ".json");
                if (File.Exists(srcJson) && srcJson != instVerJson)
                {
                    try { File.Copy(srcJson, instVerJson, true); copied = true; break; } catch { }
                }
            }
            if (!copied)
            {
                try { File.WriteAllText(instVerJson, JsonSerializer.Serialize(vj, SettingsService.JsonOpts)); } catch { }
            }
        }

        // 客户端 jar：带加载器的版本可能没有自己的客户端 jar，需要用原版的
        string clientJar = Path.Combine(verFolder, versionId + ".jar");
        if (!File.Exists(clientJar))
        {
            // 先从其他版本目录复制
            foreach (var srcDir in possibleVersionDirs)
            {
                var srcJar = Path.Combine(srcDir, versionId + ".jar");
                if (File.Exists(srcJar) && srcJar != clientJar && new FileInfo(srcJar).Length > 1000)
                {
                    try { File.Copy(srcJar, clientJar, true); break; } catch { }
                }
            }
        }
        // 如果还是没有，且版本 JSON 中有下载地址，则下载
        if (!File.Exists(clientJar) && vj.Downloads?.Client != null)
        {
            progress?.Report(new LaunchProgress { Step = 1, Status = "正在下载缺失的客户端文件...", Percent = 0.05 });
            bool ok = await _dl.DownloadFileAsync(vj.Downloads.Client.Url, clientJar, vj.Downloads.Client.Sha1, ct);
            if (!ok && !File.Exists(clientJar))
            {
                // 带加载器的版本可能没有客户端下载地址，尝试用原版版本的客户端 jar
                var originalVerDirs = new[]
                {
                    Path.Combine(_settings.GlobalVersionsDir, originalVersionId, originalVersionId + ".jar"),
                    Path.Combine(_settings.GameRoot, "versions", originalVersionId, originalVersionId + ".jar"),
                    Path.Combine(_settings.GlobalVersionsDir, inst.VersionId, inst.VersionId + ".jar"),
                };
                bool copied = false;
                foreach (var origJar in originalVerDirs)
                {
                    if (File.Exists(origJar) && new FileInfo(origJar).Length > 1000)
                    {
                        try { File.Copy(origJar, clientJar, true); copied = true; break; } catch { }
                    }
                }
                if (!copied)
                {
                    return new LaunchResult { Ok = false, Error = $"客户端文件下载失败，且无法从原版版本 {originalVersionId} 复制。请先下载原版版本。" };
                }
            }
        }

        // 4. 下载库文件（含 natives）
        progress?.Report(new LaunchProgress { Step = 1, Status = "正在检查/下载库文件...", Percent = 0.15 });
        var classpathFiles = new List<string>();
        var nativesDir = Path.Combine(verFolder, versionId + "-natives");
        Directory.CreateDirectory(nativesDir);
        var downloadTasks = new List<(string url, string path, string? sha1)>();
        var allLibraries = vj.Libraries.Where(ShouldInclude).ToList();
        var nativeExtract = new List<(string src, string dst)>();

        foreach (var lib in allLibraries)
        {
            if (lib.IsNative)
            {
                // natives: 按 OS 取 classifier，支持旧版 ${arch} 占位符和新版无后缀
                if (lib.Natives != null && lib.Natives.TryGetValue(OsName, out var nativeKey))
                {
                    var classifier = nativeKey.Replace("${arch}", OsArch);
                    var d = lib.Downloads?.Classifiers?.FirstOrDefault(kv => kv.Key == classifier).Value;
                    // 兼容：有些版本 classifiers 中 key 带引号或不同格式，尝试模糊匹配
                    if (d == null && lib.Downloads?.Classifiers != null)
                    {
                        foreach (var kv in lib.Downloads.Classifiers)
                        {
                            if (kv.Key.Replace("\"", "").Equals(classifier, StringComparison.OrdinalIgnoreCase))
                            { d = kv.Value; break; }
                        }
                    }
                    if (d != null)
                    {
                        string jarPath = Path.Combine(_settings.LibrariesDir, ClassifierPath(lib.Name, classifier));
                        downloadTasks.Add((d.Url, jarPath, d.Sha1));
                        nativeExtract.Add((jarPath, classifier));
                    }
                }
            }
            else
            {
                var artifact = lib.Downloads?.Artifact;
                if (artifact != null)
                {
                    string path = Path.Combine(_settings.LibrariesDir, ArtifactPath(lib.Name));
                    downloadTasks.Add((artifact.Url, path, artifact.Sha1));
                    classpathFiles.Add(path);
                }
                else
                {
                    // 无 artifact 信息时，从名称推断
                    string path = Path.Combine(_settings.LibrariesDir, ArtifactPath(lib.Name));
                    classpathFiles.Add(path);
                    var guessUrl = "https://libraries.minecraft.net/" + ArtifactPath(lib.Name).Replace('\\', '/');
                    downloadTasks.Add((guessUrl, path, null));
                }
            }
        }

        // 只下载缺失或损坏的文件
        downloadTasks = downloadTasks.Where(t =>
        {
            if (!File.Exists(t.path)) return true;
            // 有 sha1 时校验哈希
            if (t.sha1 != null && !DownloadService.VerifySha1(t.path, t.sha1)) return true;
            // 无 sha1 时检查文件大小和 jar/zip 完整性
            try
            {
                var fi = new FileInfo(t.path);
                if (fi.Length < 100) return true; // 文件太小，可能损坏
                // 检查 jar/zip 文件是否有效（zip END header）
                if (t.path.EndsWith(".jar", StringComparison.OrdinalIgnoreCase) ||
                    t.path.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                {
                    using var fs = File.OpenRead(t.path);
                    if (fs.Length < 22) return true; // zip 文件至少 22 字节
                    // 检查文件末尾是否有 zip END header 签名 (PK\x05\x06)
                    fs.Seek(-22, SeekOrigin.End);
                    byte[] header = new byte[4];
                    fs.Read(header, 0, 4);
                    if (header[0] != 0x50 || header[1] != 0x4B || header[2] != 0x05 || header[3] != 0x06)
                        return true; // 不是有效的 zip/jar 文件
                }
            }
            catch { return true; } // 读取失败，认为损坏
            return false;
        }).ToList();

        // 如果有需要重新下载的文件，提示用户
        if (downloadTasks.Count > 0)
        {
            progress?.Report(new LaunchProgress { Status = $"发现 {downloadTasks.Count} 个缺失或损坏的文件，正在修复...", Percent = 0.18 });
        }

        // 5. 资产索引与资源（先确保索引存在，再解析索引下载所有资源文件）
        progress?.Report(new LaunchProgress { Step = 1, Status = "正在检查资源文件...", Percent = 0.2 });
        string assetsDir = _settings.AssetsDir;
        string assetIndexDir = Path.Combine(assetsDir, "indexes");
        string assetObjectsDir = Path.Combine(assetsDir, "objects");
        Directory.CreateDirectory(assetIndexDir);
        Directory.CreateDirectory(assetObjectsDir);
        string assetIndexPath = Path.Combine(assetIndexDir, vj.Assets + ".json");
        var assetFiles = new List<(string url, string path, string? sha1)>();

        // 先下载资产索引（如果不存在）
        if (vj.AssetIndex != null && !File.Exists(assetIndexPath))
        {
            progress?.Report(new LaunchProgress { Status = "正在下载资产索引...", Percent = 0.22 });
            bool idxOk = await _dl.DownloadFileAsync(vj.AssetIndex.Url, assetIndexPath, vj.AssetIndex.Sha1, ct);
            if (!idxOk && !File.Exists(assetIndexPath))
                return new LaunchResult { Ok = false, Error = "资产索引下载失败，游戏资源将不完整" };
        }

        // 解析资产索引，生成资源文件下载列表
        if (File.Exists(assetIndexPath))
        {
            try
            {
                using var doc = JsonDocument.Parse(File.ReadAllText(assetIndexPath));
                if (doc.RootElement.TryGetProperty("objects", out var objects))
                {
                    foreach (var obj in objects.EnumerateObject())
                    {
                        if (!obj.Value.TryGetProperty("hash", out var hashEl)) continue;
                        var hash = hashEl.GetString();
                        if (string.IsNullOrEmpty(hash) || hash.Length < 2) continue;
                        string objPath = Path.Combine(assetObjectsDir, hash[..2], hash);
                        if (!File.Exists(objPath) || !DownloadService.VerifySha1(objPath, hash))
                            assetFiles.Add(("https://resources.download.minecraft.net/" + hash[..2] + "/" + hash, objPath, hash));
                    }
                }
            }
            catch (Exception ex)
            {
                progress?.Report(new LaunchProgress { Status = "资产索引解析失败: " + ex.Message, Percent = 0.25 });
            }
        }

        // 6. 并发下载所有文件（库 + 资源）
        var allTasks = downloadTasks.Select(t => (t.url, t.path, t.sha1))
            .Concat(assetFiles.Select(t => (t.url, t.path, t.sha1))).ToList();
        int totalFiles = allTasks.Count;

        if (totalFiles > 0)
        {
            int done = 0;
            var dlProgress = new Progress<(string desc, double pct, int ok, int total)>(p =>
            {
                done = Math.Max(done, p.ok);
                double basePct = 0.25 + 0.5 * (totalFiles > 0 ? (double)Math.Min(p.ok, totalFiles) / totalFiles : 0);
                progress?.Report(new LaunchProgress { Status = $"正在下载游戏文件 {Math.Min(p.ok, totalFiles)}/{totalFiles}...", Percent = basePct });
            });
            var (okCount, failCount) = await _dl.DownloadManyAsync(allTasks, dlProgress, ct);
            if (failCount > 0)
            {
                var missing = allTasks.Where(t => !File.Exists(t.path)).ToList();
                if (missing.Count > 0)
                {
                    // 区分关键文件（库）和非关键文件（资源）
                    var missingLibs = missing.Where(m => m.path.Contains("libraries") || m.path.Contains("versions")).ToList();
                    if (missingLibs.Count > 0)
                        return new LaunchResult { Ok = false, Error = $"有 {missingLibs.Count} 个关键库文件下载失败，请检查网络后重试" };
                    progress?.Report(new LaunchProgress { Status = $"有 {missing.Count} 个资源文件下载失败，游戏可能缺少部分音效/纹理/语言", Percent = 0.75 });
                }
            }
        }

        // 7. 解压 natives
        progress?.Report(new LaunchProgress { Step = 1, Status = "正在解压原生库...", Percent = 0.75 });
        foreach (var (jar, _) in nativeExtract)
        {
            if (!File.Exists(jar)) continue;
            try
            {
                using var zip = System.IO.Compression.ZipFile.OpenRead(jar);
                foreach (var entry in zip.Entries)
                {
                    if (entry.FullName.EndsWith('/')) continue;
                    var name = entry.Name;
                    if (vj.Libraries.Any(l => l.Extract?.Exclude?.Contains(name, StringComparer.OrdinalIgnoreCase) == true)) continue;
                    string dest = Path.Combine(nativesDir, name);
                    if (!File.Exists(dest))
                        System.IO.Compression.ZipFileExtensions.ExtractToFile(entry, dest, true);
                }
            }
            catch { }
        }

        // 8. 选择 Java，版本不够时自动下载
        progress?.Report(new LaunchProgress { Step = 2, Status = "正在检测游戏 Java 环境...", Percent = 0.85 });
        int needMajor = JavaService.RequiredForMc(versionId);
        if (vj.JavaVersion != null) needMajor = vj.JavaVersion.MajorVersion;
        string? javaPath = _settings.Config.Launch.JavaPath;

        // 检查手动设置的 Java 版本是否足够
        bool manualJavaOk = false;
        if (!string.IsNullOrEmpty(javaPath) && File.Exists(javaPath))
        {
            var manualInfo = _java.GetInfo(javaPath);
            int manualMajor = manualInfo?.Major ?? 0;
            manualJavaOk = manualMajor >= needMajor;
            if (!manualJavaOk)
                progress?.Report(new LaunchProgress { Status = $"当前设置的 Java {manualMajor} 版本不够，需要 Java {needMajor}，正在自动查找...", Percent = 0.85 });
        }

        // 如果手动设置的 Java 不够或不存在，自动检测或下载
        if (!manualJavaOk)
        {
            var detected = _java.DetectAll();
            var match = detected.FirstOrDefault(j => j.Major >= needMajor);
            if (match != null)
            {
                javaPath = match.Path;
                progress?.Report(new LaunchProgress { Status = $"使用已检测到的 Java {match.Major}", Percent = 0.86 });
            }
            else
            {
                // 没有足够版本的 Java，自动下载
                progress?.Report(new LaunchProgress { Status = $"未检测到 Java {needMajor}，正在自动下载...", Percent = 0.86 });
                var javaProgress = new Progress<(string status, double pct)>(p =>
                {
                    double overallPct = 0.86 + p.pct * 0.1;
                    progress?.Report(new LaunchProgress { Step = 2, Status = p.status, Percent = Math.Min(0.96, overallPct) });
                });
                try
                {
                    var downloaded = await _java.DownloadJavaAsync(needMajor, javaProgress, ct);
                    if (!string.IsNullOrEmpty(downloaded) && File.Exists(downloaded))
                    {
                        javaPath = downloaded;
                        _settings.Config.Launch.JavaPath = downloaded;
                        _settings.Save();
                        progress?.Report(new LaunchProgress { Status = $"Java {needMajor} 下载完成", Percent = 0.96 });
                    }
                    else
                    {
                        progress?.Report(new LaunchProgress { Status = $"Java {needMajor} 自动下载失败，请手动到 Java 页面下载", Done = true });
                        return new LaunchResult { Ok = false, Error = $"此版本需要 Java {needMajor}，自动下载失败。请在「Java 管理」中手动下载。" };
                    }
                }
                catch (Exception ex)
                {
                    progress?.Report(new LaunchProgress { Status = $"Java 下载异常: {ex.Message}", Done = true });
                    return new LaunchResult { Ok = false, Error = $"Java {needMajor} 下载异常: {ex.Message}" };
                }
            }
        }
        if (string.IsNullOrEmpty(javaPath) || !File.Exists(javaPath))
            return new LaunchResult { Ok = false, Error = "未找到可用的 Java，请在「Java 管理」中下载" };

        // 9. 构建参数
        progress?.Report(new LaunchProgress { Step = 3, Status = "正在进行其他检查并准备启动参数...", Percent = 0.92 });
        var gameDir = _instances.GetInstanceGameDir(inst);
        Directory.CreateDirectory(gameDir);

        // 9.1 自动设置游戏语言为简体中文（首次启动或语言为英文时）
        try
        {
            string optionsPath = Path.Combine(gameDir, "options.txt");
            bool needSetLang = true;
            if (File.Exists(optionsPath))
            {
                var lines = File.ReadAllLines(optionsPath);
                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].StartsWith("lang:"))
                    {
                        if (lines[i].Contains("zh_cn") || lines[i].Contains("zh_CN"))
                            needSetLang = false;
                        else
                            lines[i] = "lang:zh_cn";
                        break;
                    }
                }
                if (needSetLang)
                {
                    // 没有 lang 行或需要修改
                    var newLines = lines.Where(l => !l.StartsWith("lang:")).ToList();
                    newLines.Add("lang:zh_cn");
                    File.WriteAllLines(optionsPath, newLines);
                }
            }
            else
            {
                // options.txt 不存在，创建一个最小化的
                File.WriteAllText(optionsPath, "lang:zh_cn\n");
            }
        }
        catch { }

        // 9.2 应用自定义皮肤（离线账号）
        try
        {
            ApplyCustomSkin(account, assetsDir, vj);
        }
        catch { }

        var launch = await BuildLaunchCommand(vj, versionId, account, gameDir, assetsDir,
            nativesDir, classpathFiles, clientJar, javaPath);

        // 10. 直连服务器
        if (!string.IsNullOrEmpty(_settings.Config.Launch.DirectConnect) && launch.GameArgs is List<string> gargs)
        {
            gargs.Add("--server");
            gargs.Add(ParseServerHost(_settings.Config.Launch.DirectConnect));
            gargs.Add("--port");
            gargs.Add(ParseServerPort(_settings.Config.Launch.DirectConnect));
        }

        // 11. 启动进程
        var psi = new ProcessStartInfo(javaPath)
        {
            WorkingDirectory = gameDir,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        foreach (var a in launch.FullArgs) psi.ArgumentList.Add(a);

        progress?.Report(new LaunchProgress { Step = 4, Status = "正在启动游戏进程...", Percent = 0.98 });
        Process proc;
        try
        {
            proc = Process.Start(psi)!;
        }
        catch (Exception ex)
        {
            return new LaunchResult { Ok = false, Error = "进程启动失败: " + ex.Message };
        }

        // 12. 日志输出
        _logs.AttachGameProcess(proc, versionId);
        sw.Stop();

        // 记录使用统计
        inst.PlayCount++;
        inst.LastPlayed = DateTime.Now;
        _settings.Config.CurrentInstanceId = inst.Id;
        // 更新账户最后使用时间
        try
        {
            var acctForUpdate = App.Services.Accounts.Current;
            if (acctForUpdate != null)
            {
                acctForUpdate.LastUsed = DateTime.Now;
            }
        }
        catch { }
        _settings.Save();

        // 游戏时间统计：开始会话并在进程退出时记录时长
        var acct = App.Services.Accounts.Current;
        var session = App.Services.PlayTime.StartSession(inst.Id, inst.Name, versionId, acct?.Name ?? "未知");
        proc.EnableRaisingEvents = true;
        string gameDirForCrash = gameDir;
        proc.Exited += (_, _) =>
        {
            try { App.Services.PlayTime.EndSession(session.Id); } catch { }
            // 检测游戏运行时长
            int runSeconds = 0;
            try { runSeconds = (int)(DateTime.Now - session.StartTime).TotalSeconds; } catch { }
            // 自动崩溃检测
            try
            {
                int exitCode = 0;
                try { exitCode = proc.ExitCode; } catch { }
                bool crashed = exitCode != 0;
                bool shortRun = runSeconds > 0 && runSeconds < 60;
                if (crashed || shortRun)
                {
                    var crash = App.Services.Logs.DetectCrash(proc, gameDirForCrash, exitCode);
                    if (crash != null)
                    {
                        if (shortRun && exitCode == 0)
                        {
                            crash.Text = "游戏仅运行 " + runSeconds + " 秒后退出，可能存在问题。" + crash.Text;
                            crash.Cause = "游戏异常短时间退出";
                        }
                        try
                        {
                            var crashDir = Path.Combine(SettingsService.GetDataDir(), "crashes");
                            Directory.CreateDirectory(crashDir);
                            var crashFile = Path.Combine(crashDir, "crash_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".json");
                            var crashJson = System.Text.Json.JsonSerializer.Serialize(crash, SettingsService.JsonOpts);
                            File.WriteAllText(crashFile, crashJson);
                        }
                        catch { }
                        try { GameCrashed?.Invoke(null, crash); } catch { }
                    }
                }
            }
            catch { }
            // 检测重复 Mod（同名不同版本）
            try
            {
                string modDir = Path.Combine(gameDirForCrash, "mods");
                if (Directory.Exists(modDir))
                {
                    var jars = Directory.GetFiles(modDir, "*.jar");
                    var nameGroups = jars.GroupBy(f2 =>
                    {
                        var name = Path.GetFileNameWithoutExtension(f2);
                        var idx = name.LastIndexOf('-');
                        return idx > 0 ? name.Substring(0, idx) : name;
                    }).Where(g => g.Count() > 1).ToList();
                    if (nameGroups.Count > 0)
                    {
                        var dupNames = string.Join("、", nameGroups.Select(g => g.Key));
                        try
                        {
                            System.Windows.Application.Current.Dispatcher.Invoke(() =>
                            {
                                System.Windows.MessageBox.Show(
                                    "检测到重复的 Mod（同名不同版本）：" + dupNames + "\n\n这可能导致游戏崩溃或功能异常，建议删除旧版本。",
                                    "Mod 冲突警告",
                                    System.Windows.MessageBoxButton.OK,
                                    System.Windows.MessageBoxImage.Warning);
                            });
                        }
                        catch { }
                    }
                }
            }
            catch { }
        };

        progress?.Report(new LaunchProgress { Step = 5, Status = "游戏进程已启动，正在检测游戏窗口...", Percent = 1.0 });
        return new LaunchResult { Ok = true, Process = proc, LaunchMs = sw.ElapsedMilliseconds, Error = versionId };
    }

    public class LaunchCommand
    {
        public List<string> FullArgs { get; set; } = new();
        public List<string>? GameArgs { get; set; }
    }

    /// <summary>构建完整启动命令</summary>
    public async Task<LaunchCommand> BuildLaunchCommand(VersionJson vj, string versionId, Account account,
        string gameDir, string assetsDir, string nativesDir, List<string> classpathFiles,
        string clientJar, string javaPath)
    {
        var args = new List<string>();
        var gameArgs = new List<string>();

        // 内存
        int maxMem = _settings.Config.Launch.MaxMemory;
        int minMem = _settings.Config.Launch.MinMemory;
        args.Add($"-Xmx{maxMem}M");
        args.Add($"-Xms{minMem}M");

        // 游戏参数预设
        string preset = _settings.Config.General.GamePreset ?? "balanced";
        switch (preset)
        {
            case "performance": // 高性能
                args.Add("-XX:+AggressiveOpts");
                args.Add("-XX:+UseFastAccessorMethods");
                args.Add("-XX:+OptimizeStringConcat");
                args.Add("-Dforge.forceNoStencil=true");
                break;
            case "lowpower": // 省电/低配置
                args.Add("-XX:+UseSerialGC");
                args.Add("-Xincgc");
                args.Add("-Dfml.ignorePatchDiscrepancies=true");
                args.Add("-Dfml.ignoreInvalidMinecraftCertificates=true");
                break;
            case "balanced":
            default:
                // 平衡模式，使用默认参数
                break;
        }

        // 用户自定义 JVM 参数
        if (!string.IsNullOrWhiteSpace(_settings.Config.Launch.JvmArgs))
        {
            foreach (var s in Tokenize(_settings.Config.Launch.JvmArgs))
                if (!s.StartsWith("-Xmx") && !s.StartsWith("-Xms") && IsCompatibleJvmArg(s))
                    args.Add(s);
        }

        // 中文编码支持（防止游戏内中文乱码、音效设备名称乱码）
        args.Add("-Dfile.encoding=UTF-8");
        args.Add("-Dsun.jnu.encoding=UTF-8");
        // natives 路径
        args.Add($"-Djava.library.path={nativesDir}");

        // 日志配置（log4j），供 ${path} 替换
        string? log4jPath = null;
        if (vj.Logging is JsonElement logEl && logEl.TryGetProperty("client", out var client))
        {
            try
            {
                var file = client.GetProperty("file").GetProperty("id").GetString();
                var logUrl = client.GetProperty("file").GetProperty("url").GetString();
                log4jPath = Path.Combine(_settings.AssetsDir, "log_configs", file ?? "client.xml");
                if (!File.Exists(log4jPath) && logUrl != null)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(log4jPath)!);
                    var cfg = await _dl.Http.GetStringAsync(logUrl);
                    if (!string.IsNullOrEmpty(cfg)) File.WriteAllText(log4jPath, cfg);
                }
            }
            catch { }
        }

        // classpath
        classpathFiles.Add(clientJar);
        var cp = string.Join(';', classpathFiles);

        // JVM 参数（来自版本 JSON arguments.jvm，含 -cp ${classpath} 与 ${path} 等占位符）
        var jvmFromJson = GetJvmArgs(vj);
        var userProps = new Dictionary<string, bool> { ["has_custom_resolution"] = _settings.Config.Launch.Resolution.Length > 0 || _settings.Config.Launch.WinWidth > 0 };
        bool hasCpArg = false;
        foreach (var arg in jvmFromJson)
        {
            if (EvaluateRules(arg, userProps, out var values))
            {
                foreach (var v in values)
                {
                    string sub = Substitute(v, account, versionId, gameDir, assetsDir, nativesDir, _settings.Config.Launch.DirectConnect ?? "", vj.Assets)
                        .Replace("${classpath}", cp)
                        .Replace("${path}", log4jPath ?? "")
                        .Replace("${launcher_name}", "WarmWaterLauncher")
                        .Replace("${launcher_version}", "1.0.0");
                    if (sub == "-cp") { hasCpArg = true; args.Add(sub); }
                    else if (!string.IsNullOrEmpty(sub) && IsCompatibleJvmArg(sub)) args.Add(sub);
                }
            }
        }

        // 若版本 JSON 未提供 -cp，则补上 classpath
        if (!hasCpArg)
        {
            args.Add("-cp");
            args.Add(cp);
        }
        args.Add(vj.MainClass);

        // 兜底：若已有 -cp 但缺 log4j（JSON 未含 ${path}），直接追加
        if (log4jPath != null && File.Exists(log4jPath) && !args.Any(a => a.StartsWith("-Dlog4j.configurationFile")))
            args.Add($"-Dlog4j.configurationFile={log4jPath}");

        // 游戏参数
        if (!string.IsNullOrEmpty(vj.MinecraftArguments))
        {
            foreach (var t in Tokenize(Substitute(vj.MinecraftArguments, account, versionId, gameDir, assetsDir, nativesDir, _settings.Config.Launch.DirectConnect ?? "", vj.Assets)))
                gameArgs.Add(t);
        }
        else if (vj.Arguments?.Game != null)
        {
            foreach (var arg in GetGameArgs(vj))
            {
                if (EvaluateRules(arg, userProps, out var values))
                    foreach (var v in values)
                        if (!string.IsNullOrEmpty(v))
                            gameArgs.Add(Substitute(v, account, versionId, gameDir, assetsDir, nativesDir, _settings.Config.Launch.DirectConnect ?? "", vj.Assets));
            }
        }

        // 自定义分辨率
        if (_settings.Config.Launch.WinWidth > 0 && !gameArgs.Contains("--width"))
        {
            gameArgs.Add("--width"); gameArgs.Add(_settings.Config.Launch.WinWidth.ToString());
            gameArgs.Add("--height"); gameArgs.Add(_settings.Config.Launch.WinHeight.ToString());
        }
        if (_settings.Config.Launch.Fullscreen && !gameArgs.Contains("--fullscreen"))
            gameArgs.Add("--fullscreen");

        // 游戏附加参数
        if (!string.IsNullOrWhiteSpace(_settings.Config.Launch.GameArgs))
            foreach (var s in Tokenize(_settings.Config.Launch.GameArgs))
                gameArgs.Add(s);

        args.AddRange(gameArgs);
        return new LaunchCommand { FullArgs = args, GameArgs = gameArgs };
    }

    /// <summary>过滤不兼容的 JVM 参数（某些版本JSON中的参数在新版Java中不被识别）</summary>
    private static bool IsCompatibleJvmArg(string arg)
    {
        if (string.IsNullOrEmpty(arg)) return false;
        // 已知不兼容参数黑名单
        string[] blacklist =
        {
            "--sun-misc-unsafe-memory-access=allow",
            "-Dsun.misc.unsafe.memory.access=allow",
        };
        foreach (var b in blacklist)
            if (arg.Equals(b, StringComparison.OrdinalIgnoreCase)) return false;
        // --sun- 开头的参数通常是 JDK 内部参数，多数版本不支持
        if (arg.StartsWith("--sun-", StringComparison.OrdinalIgnoreCase)) return false;
        return true;
    }

    private List<string> GetJvmArgs(VersionJson vj)
    {
        var result = new List<string>();
        if (vj.Arguments?.Jvm is JsonElement el && el.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in el.EnumerateArray())
            {
                if (item.ValueKind == JsonValueKind.String) result.Add(item.GetString() ?? "");
                else result.Add(item.GetRawText());
            }
        }
        return result;
    }

    private List<string> GetGameArgs(VersionJson vj)
    {
        var result = new List<string>();
        if (vj.Arguments?.Game is JsonElement el && el.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in el.EnumerateArray())
            {
                if (item.ValueKind == JsonValueKind.String) result.Add(item.GetString() ?? "");
                else result.Add(item.GetRawText());
            }
        }
        return result;
    }

    /// <summary>规则评估：返回是否加入及取值（针对对象格式参数）</summary>
    public bool EvaluateRules(string arg, Dictionary<string, bool> features, out List<string> values)
    {
        values = new List<string>();
        // 纯字符串
        if (!arg.StartsWith("{"))
        {
            values.Add(arg);
            return true;
        }
        try
        {
            using var doc = JsonDocument.Parse(arg);
            var root = doc.RootElement;
            // 有 rules 时默认不匹配（排除），仅当 allow 规则实际命中才包含；disallow 命中则排除
            if (root.TryGetProperty("rules", out var rules) && rules.ValueKind == JsonValueKind.Array)
            {
                bool allowed = false;
                foreach (var rule in rules.EnumerateArray())
                {
                    bool? matches = null;
                    if (rule.TryGetProperty("os", out var os))
                    {
                        bool osOk = true;
                        if (os.TryGetProperty("name", out var n) && n.GetString() != OsName) osOk = false;
                        if (os.TryGetProperty("arch", out var a) && a.GetString() != OsArch) osOk = false;
                        matches = osOk;
                    }
                    if (rule.TryGetProperty("features", out var feats))
                    {
                        bool featOk = true;
                        foreach (var f in feats.EnumerateObject())
                            if (features.TryGetValue(f.Name, out var fval) ? fval != f.Value.GetBoolean() : f.Value.GetBoolean())
                                featOk = false;
                        matches = featOk;
                    }
                    if (matches != true) continue;
                    if (rule.TryGetProperty("action", out var action))
                    {
                        if (action.GetString() == "allow") allowed = true;
                        else if (action.GetString() == "disallow") allowed = false;
                    }
                }
                if (!allowed) return false;
            }
            if (root.TryGetProperty("value", out var val))
            {
                if (val.ValueKind == JsonValueKind.String) values.Add(val.GetString() ?? "");
                else if (val.ValueKind == JsonValueKind.Array)
                    foreach (var s in val.EnumerateArray()) values.Add(s.GetString() ?? "");
            }
            return true;
        }
        catch { return false; }
    }

    /// <summary>库文件是否应包含（OS 规则）</summary>
    public bool ShouldInclude(LibraryJson lib)
    {
        if (lib.Rules == null || lib.Rules.Count == 0) return true;
        bool allow = false;
        foreach (var rule in lib.Rules)
        {
            bool? osOk = null;
            if (rule.Os != null)
            {
                bool ok = true;
                if (rule.Os.Name != null && rule.Os.Name != OsName) ok = false;
                if (rule.Os.Arch != null && rule.Os.Arch != OsArch) ok = false;
                osOk = ok;
            }
            bool match = osOk == null || osOk.Value;
            if (rule.Action == "allow" && match) allow = true;
            if (rule.Action == "disallow" && match) allow = false;
        }
        return allow;
    }

    /// <summary>模板替换</summary>
    public string Substitute(string input, Account account, string versionId, string gameDir, string assetsDir,
        string nativesDir, string server, string assetsIndex = "")
    {
        var token = GetToken(account);
        string uuid = account.Uuid;
        string userType = account.Type == "microsoft" ? "msa" : "legacy";
        string type = userType == "msa" ? "msa" : "legacy";
        string result = input
            .Replace("${auth_player_name}", account.Name)
            .Replace("${version_name}", versionId)
            .Replace("${game_directory}", gameDir)
            .Replace("${game_assets}", Path.Combine(assetsDir, "virtual", "legacy"))
            .Replace("${assets_root}", assetsDir)
            .Replace("${assets_index_name}", string.IsNullOrEmpty(assetsIndex) ? versionId : assetsIndex)
            .Replace("${auth_uuid}", uuid)
            .Replace("${auth_access_token}", token ?? "0")
            .Replace("${auth_session}", (token ?? "0") + ":" + uuid)
            .Replace("${user_type}", type)
            .Replace("${version_type}", "release")
            .Replace("${user_properties}", "{}")
            .Replace("${natives_directory}", nativesDir)
            .Replace("${clientid}", uuid)
            .Replace("${auth_xuid}", account.Type == "microsoft" ? "" : "0")
            .Replace("${resolution_width}", (_settings.Config.Launch.WinWidth > 0 ? _settings.Config.Launch.WinWidth : 854).ToString())
            .Replace("${resolution_height}", (_settings.Config.Launch.WinHeight > 0 ? _settings.Config.Launch.WinHeight : 480).ToString())
            .Replace("${quickPlayPath}", "")
            .Replace("${quickPlaySingleplayer}", "")
            .Replace("${quickPlayMultiplayer}", "")
            .Replace("${quickPlayRealms}", "");
        // 注意：${classpath} 不在此处处理，由 BuildLaunchCommand 的 JVM 参数循环单独替换
        return result;
    }

    private string GetToken(Account acct)
    {
        return CryptoService.Decrypt(acct.AccessToken) ?? acct.AccessToken ?? "0";
    }

    public static int ParseMcMajor(string versionId) => JavaService.RequiredForMc(versionId);

    /// <summary>应用自定义皮肤到游戏 assets（离线账号）</summary>
    private void ApplyCustomSkin(Account account, string assetsDir, VersionJson vj)
    {
        if (account == null || string.IsNullOrEmpty(account.SkinPath) || !File.Exists(account.SkinPath))
            return;

        try
        {
            string assetIndexName = string.IsNullOrEmpty(vj.Assets) ? "legacy" : vj.Assets;
            string indexPath = Path.Combine(assetsDir, "indexes", assetIndexName + ".json");
            string objectsDir = Path.Combine(assetsDir, "objects");

            if (!File.Exists(indexPath)) return;
            Directory.CreateDirectory(objectsDir);

            // 读取自定义皮肤并计算 SHA1
            byte[] skinData = File.ReadAllBytes(account.SkinPath);
            string sha1 = BitConverter.ToString(System.Security.Cryptography.SHA1.HashData(skinData)).Replace("-", "").ToLowerInvariant();

            // 复制皮肤到 objects 目录
            string hashPrefix = sha1.Substring(0, 2);
            string objectPath = Path.Combine(objectsDir, hashPrefix, sha1);
            Directory.CreateDirectory(Path.GetDirectoryName(objectPath)!);
            if (!File.Exists(objectPath))
                File.Copy(account.SkinPath, objectPath, true);

            // 修改 asset index，将默认皮肤指向自定义皮肤
            string indexJson = File.ReadAllText(indexPath);
            using var doc = JsonDocument.Parse(indexJson);
            var root = doc.RootElement;
            if (!root.TryGetProperty("objects", out var objects)) return;

            // 需要修改的皮肤路径（覆盖所有版本）
            string[] skinPaths = {
                // 旧版本
                "minecraft:textures/entity/steve.png",
                "minecraft:textures/entity/alex.png",
                // 1.19+ 版本
                "minecraft:textures/entity/player/wide/steve.png",
                "minecraft:textures/entity/player/slim/alex.png",
                // 1.20+ 高版本（可能的新路径）
                "minecraft:textures/entity/player/wide/steve.png",
                "minecraft:textures/entity/player/slim/alex.png",
                "minecraft:textures/entity/player/wide.png",
                "minecraft:textures/entity/player/slim.png",
                // 披风路径
                "minecraft:textures/entity/elytra.png",
            };

            // 构建新的 index JSON
            using var ms = new System.IO.MemoryStream();
            using (var writer = new Utf8JsonWriter(ms, new JsonWriterOptions { Indented = true }))
            {
                writer.WriteStartObject();
                foreach (var prop in root.EnumerateObject())
                {
                    if (prop.Name == "objects")
                    {
                        writer.WritePropertyName("objects");
                        writer.WriteStartObject();
                        foreach (var obj in prop.Value.EnumerateObject())
                        {
                            if (Array.Exists(skinPaths, p => p == obj.Name))
                            {
                                writer.WritePropertyName(obj.Name);
                                writer.WriteStartObject();
                                writer.WriteString("hash", sha1);
                                writer.WriteNumber("size", skinData.Length);
                                writer.WriteEndObject();
                            }
                            else
                            {
                                obj.WriteTo(writer);
                            }
                        }
                        writer.WriteEndObject();
                    }
                    else
                    {
                        prop.WriteTo(writer);
                    }
                }
                writer.WriteEndObject();
            }

            // 备份原 index 并写入新的
            string backupPath = indexPath + ".bak";
            if (!File.Exists(backupPath))
                File.Copy(indexPath, backupPath, true);
            File.WriteAllBytes(indexPath, ms.ToArray());
        }
        catch { }
    }

    public static string ParseServerHost(string address)
    {
        var idx = address.LastIndexOf(':');
        return idx > 0 ? address[..idx] : address;
    }
    public static string ParseServerPort(string address)
    {
        var idx = address.LastIndexOf(':');
        return idx > 0 ? address[(idx + 1)..] : "25565";
    }

    public static List<string> Tokenize(string s)
    {
        var result = new List<string>();
        var cur = new StringBuilder();
        bool inQuote = false;
        foreach (var c in s)
        {
            if (c == '"') inQuote = !inQuote;
            else if (char.IsWhiteSpace(c) && !inQuote)
            {
                if (cur.Length > 0) { result.Add(cur.ToString()); cur.Clear(); }
            }
            else cur.Append(c);
        }
        if (cur.Length > 0) result.Add(cur.ToString());
        return result;
    }

    /// <summary>计算库文件的相对路径（group/artifact/version/name）</summary>
    public static string ArtifactPath(string libName)
    {
        // net.minecraftforge:forge:1.20.1-47.2.0 → net/minecraftforge/forge/1.20.1-47.2.0/forge-1.20.1-47.2.0.jar
        var parts = libName.Split(':');
        if (parts.Length < 3) return libName.Replace(':', '/') + ".jar";
        string group = parts[0].Replace('.', '/');
        string artifact = parts[1];
        string version = parts[2];
        string classifier = parts.Length > 3 ? "-" + parts[3] : "";
        return Path.Combine(group, artifact, version, artifact + "-" + version + classifier + ".jar");
    }

    public static string ClassifierPath(string libName, string classifier)
    {
        var parts = libName.Split(':');
        string group = parts[0].Replace('.', '/');
        string artifact = parts[1];
        string version = parts[2];
        return Path.Combine(group, artifact, version, artifact + "-" + version + "-" + classifier + ".jar");
    }

    /// <summary>解析实例的有效版本（含加载器），已安装则返回实际版本目录 ID</summary>
    public async Task<string?> ResolveEffectiveVersionAsync(GameInstance inst)
    {
        if (inst.LoaderType == "none" || string.IsNullOrEmpty(inst.LoaderVersion))
            return null;
        string mc = inst.VersionId;
        var loaderDir = _instances.GetInstanceVersionsDir(inst);
        var globalDir = _settings.GlobalVersionsDir;

        // 生成所有可能的版本目录名（不同加载器安装器命名不同）
        var candidates = inst.LoaderType switch
        {
            "forge" => new[]
            {
                $"{mc}-forge-{inst.LoaderVersion}",
                $"forge-{mc}-{inst.LoaderVersion}",
                $"{mc}-Forge-{inst.LoaderVersion}",
                $"forge-{mc}-{inst.LoaderVersion}-installer"
            },
            "fabric" => new[]
            {
                $"{mc}-fabric-{inst.LoaderVersion}",
                $"fabric-loader-{inst.LoaderVersion}-{mc}",
                $"fabric-{mc}-{inst.LoaderVersion}"
            },
            "quilt" => new[]
            {
                $"{mc}-quilt-{inst.LoaderVersion}",
                $"quilt-loader-{inst.LoaderVersion}-{mc}",
                $"quilt-{mc}-{inst.LoaderVersion}"
            },
            "optifine" => new[]
            {
                $"{mc}-OptiFine-{inst.LoaderVersion}",
                $"{mc}-optifine-{inst.LoaderVersion}",
                $"OptiFine-{mc}-{inst.LoaderVersion}"
            },
            _ => new[] { mc }
        };

        // 依次检查实例目录和全局目录
        foreach (var candidate in candidates)
        {
            // 检查实例版本目录
            var instPath = Path.Combine(loaderDir, candidate);
            if (Directory.Exists(instPath) && File.Exists(Path.Combine(instPath, candidate + ".json")))
                return candidate;
            // 检查全局版本目录
            var globalPath = Path.Combine(globalDir, candidate);
            if (Directory.Exists(globalPath) && File.Exists(Path.Combine(globalPath, candidate + ".json")))
                return candidate;
        }

        // 如果都没找到，返回 null（启动时会用原版版本）
        return null;
    }

    /// <summary>校验游戏文件完整性（版本 json + jar + 库文件 + 资产索引），返回（检查数, 损坏数）</summary>
    public async Task<(int checkedCount, int brokenCount)> VerifyGameFiles(GameInstance inst)
    {
        string versionId = inst.VersionId;
        var effectiveId = await ResolveEffectiveVersionAsync(inst) ?? versionId;
        var vj = await _versions.GetVersionJsonAsync(effectiveId);
        if (vj == null) return (0, 1);

        int broken = 0, total = 0;
        void Check(string path, string? sha1)
        {
            total++;
            if (!File.Exists(path) || (sha1 != null && !DownloadService.VerifySha1(path, sha1)))
                broken++;
        }

        var versionDir = _instances.GetInstanceVersionsDir(inst);
        Check(Path.Combine(versionDir, effectiveId, effectiveId + ".jar"), vj.Downloads?.Client?.Sha1);

        foreach (var lib in vj.Libraries.Where(ShouldInclude))
        {
            var artifact = lib.Downloads?.Artifact;
            if (artifact != null)
                Check(Path.Combine(_settings.LibrariesDir, ArtifactPath(lib.Name)), artifact.Sha1);
        }

        string assetIndexPath = Path.Combine(_settings.AssetsDir, "indexes", vj.Assets + ".json");
        Check(assetIndexPath, vj.AssetIndex?.Sha1);

        return (total, broken);
    }
}
