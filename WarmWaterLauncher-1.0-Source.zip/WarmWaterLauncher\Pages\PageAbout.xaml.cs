using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageAbout : UserControl, IActivatePage
{
    public PageAbout()
    {
        InitializeComponent();
        var version = Assembly.GetExecutingAssembly().GetName().Version?.ToString(3) ?? "1.0.0";
        BuildInfoText.Text = $"版本 {version} · win-x64 · self-contained · single-file";
    }

    public void OnActivate()
    {
        var version = Assembly.GetExecutingAssembly().GetName().Version?.ToString(3) ?? "1.0.0";
        BuildInfoText.Text = $"版本 {version} · win-x64 · self-contained · single-file";
    }

    private void OpenDataDir_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var dir = SettingsService.GetDataDir();
            Process.Start(new ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
        }
        catch { }
    }

    private void CopyVersion_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var version = Assembly.GetExecutingAssembly().GetName().Version?.ToString(3) ?? "1.0.0";
            Clipboard.SetText($"温水启动器 1.0 正式版 {version}\nWPF / .NET 8 / win-x64 / self-contained / single-file");
            WarmWaterLauncher.MainWindow.Get()?.ShowToast("版本信息已复制", "温水启动器 1.0 正式版 " + version);
        }
        catch { }
    }

    private void OpenChangelog_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var baseDir = AppContext.BaseDirectory;
            var candidates = new[]
            {
                Path.Combine(baseDir, "更新说明_1.0_正式版.md"),
                Path.Combine(baseDir, "..", "更新说明_1.0_正式版.md"),
                Path.Combine(baseDir, "README.md"),
                Path.Combine(baseDir, "..", "README.md")
            };
            var file = candidates.Select(Path.GetFullPath).FirstOrDefault(File.Exists);
            if (file != null)
            {
                Process.Start(new ProcessStartInfo(file) { UseShellExecute = true });
                return;
            }
        }
        catch { }

        MessageBox.Show(
            "温水启动器 1.0 正式版\n\n" +
            "· 全新极简浅色界面\n" +
            "· 下载功能管理员验证\n" +
            "· 五步启动流程与游戏窗口检测\n" +
            "· 11 项增强功能\n" +
            "· 模组预览与加载器安装优化\n\n" +
            "详细说明请查看项目目录中的 README.md。",
            "更新说明",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }
}
