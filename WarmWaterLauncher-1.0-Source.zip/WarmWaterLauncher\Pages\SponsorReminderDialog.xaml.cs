using System;
using System.Diagnostics;
using System.Windows;

namespace WarmWaterLauncher.Pages;

public partial class SponsorReminderDialog : Window
{
    /// <summary>是否选择了继续白嫖</summary>
    public bool ContinueFree { get; private set; }

    public SponsorReminderDialog(int launchCount, bool isOfflineAccount)
    {
        InitializeComponent();

        MilestoneText.Text = $"你已经启动 {launchCount} 次游戏了！";

        if (isOfflineAccount)
        {
            // 离线账户：提醒赞助+购买正版，3个按钮
            MessageText.Text = $"你已经启动了 {launchCount} 次游戏了！\n\n" +
                $"作者开发启动器和我的世界官方都不容易，不要一直白嫖了！\n\n" +
                $"检测到你一直在使用离线账户启动游戏。\n\n" +
                $"希望给作者赞助，也希望购买正版 Minecraft，获得完整的游戏体验！";

            TipText.Text = "赞助作者可以让启动器持续更新、修复bug、增加新功能。\n" +
                "购买正版可以支持Mojang继续开发Minecraft，同时获得正版皮肤、正版联机、Realms等完整功能。";

            OfflineTip.Visibility = Visibility.Visible;
            OfflineTip.Text = "⚠️ 离线账户限制：无法使用正版皮肤、无法进入正版服务器、无法使用Realms、部分服务器可能拒绝离线账户登录。";

            // 显示离线账户按钮（3个选项）
            OfflineButtons.Visibility = Visibility.Visible;
            OfficialContinueBtn.Visibility = Visibility.Collapsed;
        }
        else
        {
            // 正版账户：只提醒赞助，2个按钮
            MessageText.Text = $"你已经启动了 {launchCount} 次游戏了！\n\n" +
                $"作者开发启动器不容易，不要一直白嫖了！\n\n" +
                $"感谢你购买正版 Minecraft 支持官方！\n\n" +
                $"如果觉得这个启动器好用，希望能给作者赞助，你的支持是作者持续更新的最大动力！";

            TipText.Text = "赞助作者可以让启动器持续更新、修复bug、增加新功能。\n" +
                "你的每一份支持都是作者继续开发的动力！";

            OfflineTip.Visibility = Visibility.Collapsed;

            // 隐藏购买正版按钮，只显示2个选项
            OfflineButtons.Visibility = Visibility.Collapsed;
            OfficialContinueBtn.Visibility = Visibility.Visible;
        }
    }

    private void Sponsor_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("https://ifdian.net/a/xiaochengxuyuyaoxi") { UseShellExecute = true });
        }
        catch { }
        ContinueFree = false;
        DialogResult = true;
    }

    private void BuyOfficial_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("https://www.minecraft.net/zh-hans/store/minecraft-java-bedrock-edition-pc") { UseShellExecute = true });
        }
        catch { }
        ContinueFree = false;
        DialogResult = true;
    }

    private void ContinueFree_Click(object sender, RoutedEventArgs e)
    {
        ContinueFree = true;
        MessageBox.Show("好吧，那你继续白嫖吧😎\n\n不过作者还是希望你能在方便的时候支持一下，你的支持是作者更新的动力！",
            "继续白嫖", MessageBoxButton.OK, MessageBoxImage.Information);
        DialogResult = true;
    }
}
