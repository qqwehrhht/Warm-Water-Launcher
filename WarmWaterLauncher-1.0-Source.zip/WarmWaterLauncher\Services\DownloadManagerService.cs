using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace WarmWaterLauncher.Services;

/// <summary>全局下载管理器</summary>
public class DownloadManagerService : INotifyPropertyChanged
{
    public ObservableCollection<DownloadTask> Tasks { get; } = new();

    private int _maxConcurrent = 5;
    public int MaxConcurrent
    {
        get => _maxConcurrent;
        set { _maxConcurrent = value; OnPropertyChanged(nameof(MaxConcurrent)); }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    public event EventHandler? TasksChanged;

    // ===== 统计属性 =====
    public int TotalCount => Tasks.Count;
    public int DownloadingCount => Tasks.Count(t => t.Status == DownloadStatus.Downloading);
    public int WaitingCount => Tasks.Count(t => t.Status == DownloadStatus.Waiting);
    public int CompletedCount => Tasks.Count(t => t.Status == DownloadStatus.Completed);
    public int FailedCount => Tasks.Count(t => t.Status == DownloadStatus.Failed || t.Status == DownloadStatus.Canceled);
    public int ActiveCount => DownloadingCount + WaitingCount;

    public double OverallProgress
    {
        get
        {
            var active = Tasks.Where(t => t.Status == DownloadStatus.Downloading || t.Status == DownloadStatus.Waiting).ToList();
            if (active.Count == 0) return 0;
            // 直接使用每个任务的Progress属性（已经处理了各种情况）
            double totalProgress = 0;
            foreach (var t in active)
            {
                totalProgress += t.Progress;
            }
            return totalProgress / active.Count;
        }
    }

    public string OverallProgressText => $"{OverallProgress:F1}%";
    public string StatusSummary
    {
        get
        {
            if (ActiveCount == 0) return CompletedCount > 0 ? $"{CompletedCount}个已完成" : "无下载任务";
            return $"{DownloadingCount}个下载中 · {WaitingCount}个等待 · 总进度{OverallProgress:F0}%";
        }
    }

    public DownloadManagerService()
    {
        Tasks.CollectionChanged += (_, _) =>
        {
            RefreshStats();
            TasksChanged?.Invoke(this, EventArgs.Empty);
        };
    }

    /// <summary>更新任务栏进度（状态变化和进度变化时调用）</summary>
    private void UpdateTaskbarProgress()
    {
        try
        {
            var win = MainWindow.Get();
            if (win == null) return;
            // 只有正在下载的任务才算活跃（等待中的不算）
            int downloading = DownloadingCount;
            if (downloading > 0)
            {
                bool hasError = Tasks.Any(t => t.Status == DownloadStatus.Failed);
                win.SetTaskbarProgress(OverallProgress, hasError ? "Error" : "Normal");
            }
            else
            {
                // 没有正在下载的任务，清除进度
                win.ClearTaskbarProgress();
            }
        }
        catch { }
    }

    /// <summary>添加下载任务并自动开始</summary>
    public DownloadTask AddTask(string name, string url, string savePath, string? expectedSha1 = null, bool autoStart = true)
    {
        var task = new DownloadTask(name, url, savePath, expectedSha1);
        task.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(DownloadTask.Status))
            {
                RefreshStats();
                // 任务完成后，启动等待中的任务
                if (task.Status == DownloadStatus.Completed || task.Status == DownloadStatus.Failed || task.Status == DownloadStatus.Canceled)
                    StartWaitingTasks();
                // 状态变化时也更新任务栏进度（取消/完成后清除）
                UpdateTaskbarProgress();
            }
            if (e.PropertyName == nameof(DownloadTask.Progress) || e.PropertyName == nameof(DownloadTask.DownloadedBytes))
            {
                OnPropertyChanged(nameof(OverallProgress));
                UpdateTaskbarProgress();
            }
        };

        Tasks.Add(task);

        if (autoStart)
            TryStartTask(task);

        return task;
    }

    /// <summary>尝试启动任务（受并发数限制）</summary>
    private void TryStartTask(DownloadTask task)
    {
        if (task.Status != DownloadStatus.Waiting) return;
        if (DownloadingCount >= MaxConcurrent) return;
        _ = Task.Run(() => task.StartAsync());
    }

    /// <summary>启动等待中的任务</summary>
    private void StartWaitingTasks()
    {
        var waiting = Tasks.Where(t => t.Status == DownloadStatus.Waiting).ToList();
        foreach (var task in waiting)
        {
            if (DownloadingCount >= MaxConcurrent) break;
            TryStartTask(task);
        }
    }

    /// <summary>取消所有任务</summary>
    public void CancelAll()
    {
        foreach (var task in Tasks)
            if (task.Status == DownloadStatus.Downloading || task.Status == DownloadStatus.Waiting)
                task.Cancel();
    }

    /// <summary>清除已完成/失败的任务</summary>
    public void ClearCompleted()
    {
        var toRemove = Tasks.Where(t => t.Status == DownloadStatus.Completed || t.Status == DownloadStatus.Failed || t.Status == DownloadStatus.Canceled).ToList();
        foreach (var task in toRemove)
            Tasks.Remove(task);
    }

    /// <summary>移除单个任务</summary>
    public void RemoveTask(DownloadTask task)
    {
        if (task.Status == DownloadStatus.Downloading)
            task.Cancel();
        Tasks.Remove(task);
    }

    /// <summary>重试失败的任务</summary>
    public void RetryTask(DownloadTask task)
    {
        if (task.Status != DownloadStatus.Failed && task.Status != DownloadStatus.Canceled) return;
        // 创建新任务（因为旧任务已经结束）
        var newTask = AddTask(task.Name, task.Url, task.SavePath, task.ExpectedSha1);
        Tasks.Remove(task);
    }

    /// <summary>等待指定下载任务全部完成；失败/取消的任务自动重试，重试耗尽后放弃（不中断整体）</summary>
    public async Task WaitAllAsync(IEnumerable<DownloadTask> tasks, int maxRetry = 2)
    {
        var pool = tasks?.Where(t => t != null).ToList() ?? new();
        if (pool.Count == 0) return;
        var retries = new Dictionary<DownloadTask, int>();
        var deadline = DateTime.Now.AddMinutes(60);
        while (DateTime.Now < deadline)
        {
            bool allDone = true;
            var newPool = new List<DownloadTask>(pool);
            foreach (var t in pool)
            {
                if (t.Status == DownloadStatus.Completed)
                    continue; // 成功
                if (t.Status is DownloadStatus.Failed or DownloadStatus.Canceled)
                {
                    // 失败：自动重试
                    int n = retries.TryGetValue(t, out var r) ? r : 0;
                    if (n < maxRetry)
                    {
                        retries[t] = n + 1;
                        var nt = AddTask(t.Name, t.Url, t.SavePath, t.ExpectedSha1);
                        newPool.Add(nt);
                        allDone = false;
                    }
                    // else 重试耗尽，放弃该文件
                    continue;
                }
                // 仍在下载/等待中
                allDone = false;
            }
            if (allDone) break;
            pool = newPool;
            await Task.Delay(400);
        }
    }


    private void RefreshStats()
    {
        OnPropertyChanged(nameof(TotalCount));
        OnPropertyChanged(nameof(DownloadingCount));
        OnPropertyChanged(nameof(WaitingCount));
        OnPropertyChanged(nameof(CompletedCount));
        OnPropertyChanged(nameof(FailedCount));
        OnPropertyChanged(nameof(ActiveCount));
        OnPropertyChanged(nameof(OverallProgress));
        OnPropertyChanged(nameof(OverallProgressText));
        OnPropertyChanged(nameof(StatusSummary));
    }

    protected void OnPropertyChanged(string name) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
