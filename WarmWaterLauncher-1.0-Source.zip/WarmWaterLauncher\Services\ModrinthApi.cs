﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace WarmWaterLauncher.Services;

public class ModrinthMod
{
    [JsonPropertyName("id")] public string Id { get; set; } = "";
    [JsonPropertyName("project_id")] public string ProjectId { get; set; } = "";
    [JsonPropertyName("slug")] public string Slug { get; set; } = "";
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("description")] public string Description { get; set; } = "";
    [JsonPropertyName("downloads")] public long Downloads { get; set; }
    [JsonPropertyName("icon_url")] public string? IconUrl { get; set; }
    [JsonPropertyName("categories")] public List<string> Categories { get; set; } = new();
    [JsonPropertyName("versions")] public List<string> Versions { get; set; } = new();
    [JsonPropertyName("latest_version")] public string? LatestVersion { get; set; }
    [JsonPropertyName("author")] public string? Author { get; set; }
    [JsonPropertyName("team")] public string? Team { get; set; }
    [JsonPropertyName("project_type")] public string? ProjectType { get; set; }
    [JsonPropertyName("date_created")] public string? DateCreated { get; set; }
    [JsonPropertyName("date_modified")] public string? DateModified { get; set; }
    [JsonPropertyName("follows")] public long Follows { get; set; }
    [JsonPropertyName("license")] public System.Text.Json.JsonElement? License { get; set; }

    /// <summary>中文显示名（别名 + 原名）</summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public string DisplayName => ModrinthLocalization.GetDisplayName(this);

    /// <summary>分类显示（取前3个分类）</summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public string CategoryDisplay => Categories != null && Categories.Count > 0 ? string.Join(" · ", Categories.Take(3)) : "";

    /// <summary>是否有前置模组（运行时设置）</summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public bool HasDependencies { get; set; }

    /// <summary>作者显示名</summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public string AuthorDisplay => !string.IsNullOrEmpty(Author) ? Author : (!string.IsNullOrEmpty(Team) ? Team : "未知");
}

public class ModrinthVersion
{
    [JsonPropertyName("id")] public string Id { get; set; } = "";
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("version_number")] public string VersionNumber { get; set; } = "";
    [JsonPropertyName("game_versions")] public List<string> GameVersions { get; set; } = new();
    [JsonPropertyName("loaders")] public List<string> Loaders { get; set; } = new();
    [JsonPropertyName("files")] public List<ModrinthFile> Files { get; set; } = new();
    [JsonPropertyName("version_type")] public string? VersionType { get; set; }
    [JsonPropertyName("date_published")] public string? DatePublished { get; set; }
    [JsonPropertyName("dependencies")] public List<ModrinthDependency> Dependencies { get; set; } = new();
}

public class ModrinthFile
{
    [JsonPropertyName("url")] public string Url { get; set; } = "";
    [JsonPropertyName("filename")] public string Filename { get; set; } = "";
    [JsonPropertyName("size")] public long Size { get; set; }
    [JsonPropertyName("primary")] public bool Primary { get; set; }
    [JsonPropertyName("hashes")] public Dictionary<string, string> Hashes { get; set; } = new();
}

/// <summary>从版本文件列表中选择主下载文件：优先 primary 标记，其次最大的文件（.jar/.mrpack 等主文件通常最大）</summary>
public static class ModrinthFileSelector
{
    public static ModrinthFile? PickPrimary(List<ModrinthFile> files)
    {
        if (files == null || files.Count == 0) return null;
        // 1. 优先带 primary 标记的文件
        var primary = files.FirstOrDefault(f => f.Primary);
        if (primary != null) return primary;
        // 2. 其次选择最大的文件（主 .jar/.mrpack 通常最大）
        return files.OrderByDescending(f => f.Size).First();
    }
}

/// <summary>模组版本依赖（前置模组）</summary>
public class ModrinthDependency
{
    [JsonPropertyName("version_id")] public string? VersionId { get; set; }
    [JsonPropertyName("project_id")] public string? ProjectId { get; set; }
    [JsonPropertyName("file_name")] public string? FileName { get; set; }
    [JsonPropertyName("dependency_type")] public string DependencyType { get; set; } = "required"; // required / optional / incompatible / embedded
    /// <summary>依赖的模组名称（需要额外查询获取）</summary>
    public string? ProjectName { get; set; }
    /// <summary>依赖的模组图标URL（需要额外查询获取）</summary>
    public string? IconUrl { get; set; }
    /// <summary>是否已安装</summary>
    public bool IsInstalled { get; set; }
}

/// <summary>Modrinth 开放 API（无需密钥）</summary>
public class ModrinthApi
{
    private readonly SettingsService _settings;
    private readonly DownloadService _dl;
    public const string Base = "https://api.modrinth.com/v2";

    public ModrinthApi(SettingsService settings, DownloadService dl)
    {
        _settings = settings;
        _dl = dl;
    }

    /// <summary>测试 API 连接</summary>
    public async Task<System.Net.Http.HttpResponseMessage> TestConnectionAsync(CancellationToken ct = default)
    {
        string url = $"{Base}/search?query=sodium&limit=1";
        return await _dl.Http.Client.GetAsync(url, ct);
    }

    /// <summary>搜索项目（mod/modpack/resourcepack/shader/datapack）</summary>
    public async Task<List<ModrinthMod>> SearchAsync(string query, string gameVersion = "", string loader = "",
        string category = "", string sort = "relevance", int limit = 50, string projectType = "mod", CancellationToken ct = default)
    {
        var facets = new List<string>();
        if (!string.IsNullOrEmpty(gameVersion)) facets.Add($"[\"versions:{gameVersion}\"]");
        if (!string.IsNullOrEmpty(loader)) facets.Add($"[\"categories:{loader}\"]");
        if (!string.IsNullOrEmpty(category)) facets.Add($"[\"categories:{category}\"]");
        facets.Add($"[\"project_type:{projectType}\"]");
        string url = $"{Base}/search?query={Uri.EscapeDataString(query)}&limit={limit}&index={sort}";
        if (facets.Count > 0) url += "&facets=" + Uri.EscapeDataString("[" + string.Join(",", facets) + "]");
        try
        {
            // 使用独立的HttpClient，确保请求正常
            using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
            http.DefaultRequestHeaders.UserAgent.ParseAdd("WarmWaterLauncher/1.0-beta1 (Minecraft Launcher)");
            http.DefaultRequestHeaders.Accept.ParseAdd("application/json");

            using var resp = await http.GetAsync(url, ct);
            if (!resp.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine($"Modrinth search failed: HTTP {(int)resp.StatusCode}");
                return new List<ModrinthMod>();
            }
            var json = await resp.Content.ReadAsStringAsync(ct);
            if (string.IsNullOrEmpty(json)) return new List<ModrinthMod>();
            using var doc = JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty("hits", out var hits))
                return new List<ModrinthMod>();
            var results = JsonSerializer.Deserialize<List<ModrinthMod>>(hits.GetRawText(), SettingsService.JsonOpts) ?? new();
            System.Diagnostics.Debug.WriteLine($"Modrinth search found {results.Count} results");
            return results;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"Modrinth search error: {ex.Message}");
            return new List<ModrinthMod>();
        }
    }

    /// <summary>获取项目版本列表（筛选游戏版本与加载器）</summary>
    public async Task<List<ModrinthVersion>> GetVersionsAsync(string projectId, string gameVersion = "", string loader = "")
    {
        string url = $"{Base}/project/{projectId}/version";
        if (!string.IsNullOrEmpty(gameVersion)) url += $"?game_versions={Uri.EscapeDataString("[\"" + gameVersion + "\"]")}";
        if (!string.IsNullOrEmpty(loader)) url += (url.Contains('?') ? "&" : "?") + $"loaders={Uri.EscapeDataString("[\"" + loader + "\"]")}";
        var json = await _dl.Http.GetStringAsync(url);
        if (string.IsNullOrEmpty(json)) return new();
        try { return JsonSerializer.Deserialize<List<ModrinthVersion>>(json, SettingsService.JsonOpts) ?? new(); }
        catch { return new(); }
    }

    /// <summary>获取单个模组详情</summary>
    public async Task<ModrinthMod?> GetProjectAsync(string projectId, CancellationToken ct = default)
    {
        try
        {
            string url = $"{Base}/project/{projectId}";
            var json = await _dl.Http.GetStringAsync(url);
            if (string.IsNullOrEmpty(json)) return null;
            var mod = JsonSerializer.Deserialize<ModrinthMod>(json, SettingsService.JsonOpts);
            // /project/{id} 返回的字段是 "id"，而搜索返回的是 "project_id"，需回填确保 ProjectId 有效
            if (mod != null && string.IsNullOrEmpty(mod.ProjectId) && !string.IsNullOrEmpty(mod.Id))
                mod.ProjectId = mod.Id;
            return mod;
        }
        catch { return null; }
    }

    /// <summary>批量获取模组信息（用于获取前置模组名称）</summary>
    public async Task<Dictionary<string, ModrinthMod>> GetProjectsAsync(List<string> projectIds, CancellationToken ct = default)
    {
        var result = new Dictionary<string, ModrinthMod>();
        if (projectIds == null || projectIds.Count == 0) return result;
        try
        {
            string ids = "[" + string.Join(",", projectIds.Select(id => $"\u0022{id}\u0022")) + "]";
            string url = $"{Base}/projects?ids={Uri.EscapeDataString(ids)}";
            var json = await _dl.Http.GetStringAsync(url);
            if (string.IsNullOrEmpty(json)) return result;
            var projects = JsonSerializer.Deserialize<List<ModrinthMod>>(json, SettingsService.JsonOpts) ?? new();
            foreach (var p in projects)
            {
                // /projects 批量端点返回字段是 "id"，回填确保 ProjectId 有效
                if (string.IsNullOrEmpty(p.ProjectId) && !string.IsNullOrEmpty(p.Id))
                    p.ProjectId = p.Id;
                result[p.ProjectId] = p;
            }
        }
        catch { }
        return result;
    }

    /// <summary>获取推荐版本（最新兼容版本）</summary>
    public async Task<ModrinthVersion?> GetRecommendedVersionAsync(string projectId, string gameVersion, string loader, CancellationToken ct = default)
    {
        var versions = await GetVersionsAsync(projectId, gameVersion, loader);
        if (versions.Count == 0)
        {
            // 如果指定加载器没有，尝试不指定加载器
            versions = await GetVersionsAsync(projectId, gameVersion, "");
        }
        // 遍历找到第一个包含可下载文件（url 非空）的版本，跳过 beta / 元版本（无文件）
        return versions.FirstOrDefault(v => v.Files != null && v.Files.Any(f => !string.IsNullOrEmpty(f.Url)))
            ?? versions.FirstOrDefault();
    }

    /// <summary>搜索资源包</summary>
    public Task<List<ModrinthMod>> SearchResourcePacksAsync(string query, string gameVersion = "", string sort = "relevance", int limit = 50, CancellationToken ct = default)
        => SearchAsync(query, gameVersion, "", "", sort, limit, "resourcepack", ct);

    /// <summary>搜索光影包</summary>
    public Task<List<ModrinthMod>> SearchShadersAsync(string query, string gameVersion = "", string sort = "relevance", int limit = 50, CancellationToken ct = default)
        => SearchAsync(query, gameVersion, "", "", sort, limit, "shader", ct);

    /// <summary>搜索数据包</summary>
    public Task<List<ModrinthMod>> SearchDataPacksAsync(string query, string gameVersion = "", string sort = "relevance", int limit = 50, CancellationToken ct = default)
        => SearchAsync(query, gameVersion, "", "", sort, limit, "datapack", ct);

    /// <summary>搜索整合包</summary>
    public Task<List<ModrinthMod>> SearchModpacksAsync(string query, string gameVersion = "", string loader = "", string sort = "relevance", int limit = 50, CancellationToken ct = default)
        => SearchAsync(query, gameVersion, loader, "", sort, limit, "modpack", ct);

    /// <summary>从本地 jar 的 fabric.mod.json / META-INF 读取 Modrinth 项目 ID（用于更新检测）</summary>
    public static string? DetectProjectId(string jarPath)
    {
        try
        {
            using var zip = System.IO.Compression.ZipFile.OpenRead(jarPath);
            foreach (var name in new[] { "fabric.mod.json", "quilt.mod.json" })
            {
                var entry = zip.GetEntry(name);
                if (entry == null) continue;
                using var sr = new StreamReader(entry.Open());
                using var doc = JsonDocument.Parse(sr.ReadToEnd());
                if (doc.RootElement.TryGetProperty("id", out var id) && id.GetString()?.StartsWith("modrinth:") == true)
                    return id.GetString()!["modrinth:".Length..];
            }
        }
        catch { }
        return null;
    }
}
