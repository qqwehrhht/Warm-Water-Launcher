using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace WarmWaterLauncher.Converters;

/// <summary>布尔值转可见性转换器</summary>
public class BoolToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        bool b = value is bool v && v;
        // 如果参数为 "invert"，则反转
        if (parameter is string s && s == "invert")
            b = !b;
        return b ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        return value is Visibility v && v == Visibility.Visible;
    }
}
