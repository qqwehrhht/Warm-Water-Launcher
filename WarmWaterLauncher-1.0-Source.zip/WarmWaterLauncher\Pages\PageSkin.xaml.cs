using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageSkin : UserControl, IActivatePage
{
    public ObservableCollection<SkinItemVM> SkinItems { get; set; } = new();
    public ObservableCollection<CapeItemVM> CapeItems { get; set; } = new();

    public PageSkin()
    {
        InitializeComponent();
        SkinList.ItemsSource = SkinItems;
        CapeList.ItemsSource = CapeItems;
    }

    public void OnActivate()
    {
        LoadAccounts();
        RefreshSkinLibrary();
        RefreshCapeLibrary();
        UpdatePreview();
    }

    private void LoadAccounts()
    {
        AccountCombo.ItemsSource = App.Services.Accounts.Accounts;
        AccountCombo.DisplayMemberPath = "Name";
        AccountCombo.SelectedItem = App.Services.Accounts.Current;
    }

    private void AccountCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (AccountCombo.SelectedItem is Account acct)
        {
            App.Services.Accounts.Switch(acct.Id);
            UpdatePreview();
        }
    }

    private void RefreshSkinLibrary()
    {
        SkinItems.Clear();
        foreach (var skin in App.Services.Skins.GetSkinLibrary())
        {
            var vm = new SkinItemVM
            {
                Name = skin.Name,
                FileName = skin.FileName,
                FullPath = skin.FullPath,
                IsDefault = skin.IsDefault,
                Type = skin.Type,
                
                Preview = skin.IsDefault ? App.Services.Skins.GenerateDefaultPreview(6) : App.Services.Skins.GenerateSkinPreview(skin.FullPath, 6)            };
            SkinItems.Add(vm);
        }
    }

    private void RefreshCapeLibrary()
    {
        CapeItems.Clear();
        foreach (var cape in App.Services.Skins.GetCapeLibrary())
        {
            var vm = new CapeItemVM
            {
                Name = cape.Name,
                FileName = cape.FileName,
                FullPath = cape.FullPath,
                IsDefault = cape.IsDefault,
                Preview = cape.IsDefault ? null : LoadCapePreview(cape.FullPath)
            };
            CapeItems.Add(vm);
        }
    }

    private BitmapImage? LoadCapePreview(string? path)
    {
        try
        {
            if (string.IsNullOrEmpty(path) || !File.Exists(path)) return null;
            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.UriSource = new Uri(path);
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.EndInit();
            return bmp;
        }
        catch { return null; }
    }

    private void UpdatePreview()
    {
        var acct = App.Services.Accounts.Current;
        if (acct == null) return;

        // 皮肤预览（使用生成的正面人物预览，最清晰）
        if (!string.IsNullOrEmpty(acct.SkinPath) && File.Exists(acct.SkinPath))
        {
            var preview = App.Services.Skins.GenerateSkinPreview(acct.SkinPath, 10);
            if (preview != null)
            {
                SkinPreview.Source = preview;
                SkinPreview.Stretch = System.Windows.Media.Stretch.Uniform;
                RenderOptions.SetBitmapScalingMode(SkinPreview, BitmapScalingMode.NearestNeighbor);
            }
            else
            {
                SkinPreview.Source = App.Services.Skins.GenerateDefaultPreview(10);
            }
            CurrentSkinName.Text = Path.GetFileNameWithoutExtension(acct.SkinPath);
            // 检测皮肤类型
            try
            {
                var skinType = App.Services.Skins.DetectSkinType(acct.SkinPath);
                CurrentSkinType.Text = skinType == SkinType.Alex ? "细臂（Alex）· 自定义皮肤" : "粗臂（Steve）· 自定义皮肤";
            }
            catch { CurrentSkinType.Text = "自定义皮肤"; }
        }
        else
        {
            SkinPreview.Source = App.Services.Skins.GenerateDefaultPreview(10);
            CurrentSkinName.Text = "Steve（经典）";
            CurrentSkinType.Text = "粗臂 · 默认皮肤";
        }

        // 披风预览
        if (!string.IsNullOrEmpty(acct.CapePath) && File.Exists(acct.CapePath))
        {
            CapePreview.Source = LoadCapePreview(acct.CapePath);
            CurrentCapeName.Text = Path.GetFileNameWithoutExtension(acct.CapePath);
        }
        else
        {
            CapePreview.Source = null;
            CurrentCapeName.Text = "无披风";
        }
    }

    private void ApplySkin_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not SkinItemVM skin) return;
        var acct = App.Services.Accounts.Current;
        if (acct == null) { MessageBox.Show("请先选择账号", "温水启动器"); return; }

        var skinItem = new SkinItem
        {
            Name = skin.Name,
            FileName = skin.FileName,
            FullPath = skin.FullPath,
            IsDefault = skin.IsDefault,
            Type = skin.Type
        };

        bool ok = App.Services.Skins.ApplySkin(acct, skinItem);
        if (ok)
        {
            UpdatePreview();
            MessageBox.Show($"已为「{acct.Name}」应用皮肤「{skin.Name}」", "应用成功", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        else
        {
            MessageBox.Show("应用皮肤失败", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ApplyCape_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not CapeItemVM cape) return;
        var acct = App.Services.Accounts.Current;
        if (acct == null) { MessageBox.Show("请先选择账号", "温水启动器"); return; }

        var capeItem = new CapeItem
        {
            Name = cape.Name,
            FileName = cape.FileName,
            FullPath = cape.FullPath,
            IsDefault = cape.IsDefault
        };

        bool ok = App.Services.Skins.ApplyCape(acct, capeItem);
        if (ok)
        {
            UpdatePreview();
            MessageBox.Show($"已为「{acct.Name}」应用披风「{cape.Name}」", "应用成功", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        else
        {
            MessageBox.Show("应用披风失败", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ImportSkin_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "皮肤图片|*.png",
            Title = "选择皮肤文件"
        };
        if (dlg.ShowDialog() == true)
        {
            string? dest = App.Services.Skins.ImportSkin(dlg.FileName);
            if (dest != null)
            {
                RefreshSkinLibrary();
                // 自动应用
                var acct = App.Services.Accounts.Current;
                if (acct != null)
                {
                    var skin = new SkinItem { FullPath = dest, IsDefault = false, Name = Path.GetFileNameWithoutExtension(dest) };
                    App.Services.Skins.ApplySkin(acct, skin);
                    UpdatePreview();
                }
                MessageBox.Show("皮肤已导入并应用", "导入成功", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("导入失败，请检查文件格式", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    private void ImportCape_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Filter = "披风图片|*.png",
            Title = "选择披风文件"
        };
        if (dlg.ShowDialog() == true)
        {
            string? dest = App.Services.Skins.ImportCape(dlg.FileName);
            if (dest != null)
            {
                RefreshCapeLibrary();
                var acct = App.Services.Accounts.Current;
                if (acct != null)
                {
                    var cape = new CapeItem { FullPath = dest, IsDefault = false, Name = Path.GetFileNameWithoutExtension(dest) };
                    App.Services.Skins.ApplyCape(acct, cape);
                    UpdatePreview();
                }
                MessageBox.Show("披风已导入并应用", "导入成功", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("导入失败，请检查文件格式", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    private void OpenSkinDir_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            App.Services.Skins.EnsureDirs();
            Process.Start(new ProcessStartInfo("explorer.exe", App.Services.Skins.SkinLibraryDir) { UseShellExecute = true });
        }
        catch { }
    }
}

public class SkinItemVM : SkinItem
{
    public BitmapSource? Preview { get; set; }
}

public class CapeItemVM : CapeItem
{
    public BitmapSource? Preview { get; set; }
}
