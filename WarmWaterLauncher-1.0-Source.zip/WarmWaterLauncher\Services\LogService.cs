using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace WarmWaterLauncher.Services;

/// <summary>游戏日志与崩溃诊断</summary>
public class LogService
{
    private readonly SettingsService _settings;
    public LogService(SettingsService settings) => _settings = settings;

    /// <summary>游戏实时日志（UI 绑定）</summary>
    public ObservableLog LogBuffer { get; } = new();
    public string CurrentGameVersion { get; private set; } = "";

    public string LogDir
    {
        get
        {
            string dir = Path.Combine(SettingsService.GetDataDir(), "logs");
            Directory.CreateDirectory(dir);
            return dir;
        }
    }

    /// <summary>获取日志目录</summary>
    public string GetLogFilePath(string versionId) => Path.Combine(LogDir, $"{versionId}_{DateTime.Now:yyyyMMdd_HHmmss}.log");

    public void AttachGameProcess(Process proc, string versionId)
    {
        CurrentGameVersion = versionId;
        string logFile = GetLogFilePath(versionId);
        var sb = new StringBuilder();

        proc.OutputDataReceived += (_, e) =>
        {
            if (e.Data == null) return;
            LogBuffer.Add(e.Data);
            try { File.AppendAllText(logFile, e.Data + "\n", Encoding.UTF8); } catch { }
        };
        proc.ErrorDataReceived += (_, e) =>
        {
            if (e.Data == null) return;
            LogBuffer.Add("[err] " + e.Data);
            try { File.AppendAllText(logFile, "[err] " + e.Data + "\n", Encoding.UTF8); } catch { }
        };
        proc.BeginOutputReadLine();
        proc.BeginErrorReadLine();
    }

    /// <summary>解析崩溃报告，定位问题并给出解决办法</summary>
    public CrashAnalysis AnalyzeCrash(string crashText)
    {
        var result = new CrashAnalysis { Text = crashText };
        if (string.IsNullOrEmpty(crashText))
        {
            result.Cause = "无崩溃日志";
            result.Advice = "未找到崩溃日志。请检查游戏是否正常退出，或查看日志页面的错误信息。";
            return result;
        }

        var text = crashText.ToLowerInvariant();

        // 提取崩溃原因
        var m = Regex.Match(crashText, @"Caused by: (.+)", RegexOptions.Multiline);
        if (m.Success) result.Cause = m.Groups[1].Value.Trim();
        else
        {
            var m2 = Regex.Match(crashText, @"Description: (.+)", RegexOptions.Multiline);
            result.Cause = m2.Success ? m2.Groups[1].Value.Trim() : "未知原因";
        }

        // 提取崩溃标题
        var titleMatch = Regex.Match(crashText, @"---- Minecraft Crash Report ----[\s\S]*?// (.+)", RegexOptions.Multiline);
        if (titleMatch.Success) result.CrashTitle = titleMatch.Groups[1].Value.Trim();

        // 提取游戏版本和加载器
        var verMatch = Regex.Match(crashText, @"Minecraft Version: (.+)", RegexOptions.IgnoreCase);
        if (verMatch.Success) result.GameVersion = verMatch.Groups[1].Value.Trim();
        var loaderMatch = Regex.Match(crashText, @"(?:Forge|Fabric|Quilt|NeoForge) Version: (.+)", RegexOptions.IgnoreCase);
        if (loaderMatch.Success) result.LoaderVersion = loaderMatch.Groups[1].Value.Trim();
        var javaMatch = Regex.Match(crashText, @"Java Version: (.+)", RegexOptions.IgnoreCase);
        if (javaMatch.Success) result.JavaVersion = javaMatch.Groups[1].Value.Trim();

        // 定位问题模组
        var suspicious = new List<string>();
        foreach (var line in crashText.Split('\n'))
        {
            var mm = Regex.Match(line, @"^\s*(?:at )?([\w.]+?)\$?[\w.]*\.(\w+)\(", RegexOptions.Multiline);
            if (mm.Success)
            {
                var cls = mm.Groups[1].Value.ToLowerInvariant();
                foreach (var kw in new[] { "fabric", "forge", "neoforge", "quilt", "optifine", "shaders", "sodium", "iris", "create", "jei", "modmenu", "cloth_config", "architectury", "geckolib", "citadel", "bookkeeper" })
                {
                    if (cls.Contains(kw) && !suspicious.Contains(kw))
                        suspicious.Add(kw);
                }
            }
            var mmod = Regex.Match(line, @"(?:mod|Mod)\s+([\w-]+)\s+(?:has|is|failed|caused)", RegexOptions.IgnoreCase);
            if (mmod.Success && !suspicious.Contains(mmod.Groups[1].Value))
                suspicious.Add(mmod.Groups[1].Value);
        }

        // 检查 "Suspect Mods"
        var suspects = Regex.Match(crashText, @"suspect(?:ed)? mods?:?\s*(.+)", RegexOptions.IgnoreCase);
        if (suspects.Success)
        {
            foreach (var s in suspects.Groups[1].Value.Split(','))
            {
                var name = s.Trim().Trim('.').Trim();
                if (name.Length > 0 && name.Length < 40 && !suspicious.Contains(name))
                    suspicious.Add(name);
            }
        }

        result.SuspiciousMods = suspicious;

        // ===== 智能诊断：根据崩溃特征给出具体解决办法 =====
        var advice = new System.Text.StringBuilder();

        // 0. JVM 致命错误（JVM 本身崩溃，如 EXCEPTION_ACCESS_VIOLATION）
        if (text.Contains("a fatal error has been detected by the java runtime") || 
            text.Contains("exception_access_violation") || 
            text.Contains("problematic frame") ||
            text.Contains("jvm.dll") ||
            text.Contains("siginfo: exception_access_violation"))
        {
            result.CrashType = CrashType.JvmCrash;
            advice.AppendLine("【JVM 致命错误】Java 虚拟机本身崩溃（不是游戏代码问题）。");
            // 判断是否是着色器编译时崩溃
            bool isShaderCrash = text.Contains("glslcompiler") || text.Contains("shaderc") || 
                                  text.Contains("compileintospv") || text.Contains("renderpearl") ||
                                  text.Contains("pipelinebuilder");
            if (isShaderCrash)
            {
                advice.AppendLine("崩溃发生在着色器编译阶段（Minecraft 新渲染引擎 renderpearl）。");
                advice.AppendLine("解决办法：");
                advice.AppendLine("  1. 【推荐】降低 Java 版本：Java 24/25 的 ScopedValue 新特性可能不稳定，尝试使用 Java 21");
                advice.AppendLine("  2. 更新显卡驱动到最新版本（着色器编译依赖 GPU 驱动）");
                advice.AppendLine("  3. 添加 JVM 参数禁用新特性：-XX:+UnlockDiagnosticVMOptions -XX:-UseScopedValue");
                advice.AppendLine("  4. 如果是快照版本，这是已知问题，建议使用正式版");
                advice.AppendLine("  5. 关闭光影包和高清修复，使用默认画质");
            }
            else
            {
                advice.AppendLine("解决办法：");
                advice.AppendLine("  1. 【推荐】更换 Java 版本：当前 Java 版本可能不稳定，尝试 Java 21 或 Java 17");
                advice.AppendLine("  2. 更新显卡驱动到最新版本");
                advice.AppendLine("  3. 减少分配的内存（过大的内存可能导致 JVM 不稳定）");
                advice.AppendLine("  4. 添加 JVM 参数：-XX:+UseG1GC -XX:+UnlockExperimentalVMOptions");
                advice.AppendLine("  5. 关闭光影包和大型模组");
                advice.AppendLine("  6. 如果是快照版本，建议使用正式版");
            }
        }
        // 1. 内存不足
        else if (text.Contains("outofmemory") || text.Contains("outofmemoryerror") || text.Contains("java heap space"))
        {
            result.CrashType = CrashType.OutOfMemory;
            advice.AppendLine("【内存不足】游戏分配的内存不够。");
            advice.AppendLine("解决办法：");
            advice.AppendLine("  1. 打开「启动设置」，将最大内存调大（建议 4096MB 或更高）");
            advice.AppendLine("  2. 如果电脑内存较小，关闭其他占用内存的程序");
            advice.AppendLine("  3. 减少模组数量，特别是大型模组（如光影、大型整合包）");
            advice.AppendLine("  4. 添加 JVM 参数：-XX:+UseG1GC -XX:+UnlockExperimentalVMOptions");
        }
        // 2. Java 版本不兼容
        else if (text.Contains("unsupportedclassversion") || text.Contains("class file version") || text.Contains("java.lang.unsupportedclassversionerror"))
        {
            result.CrashType = CrashType.JavaVersionMismatch;
            advice.AppendLine("【Java 版本不兼容】模组或加载器需要更高版本的 Java。");
            advice.AppendLine("解决办法：");
            advice.AppendLine("  1. 打开「Java 管理」，下载对应版本的 Java");
            advice.AppendLine("  2. Minecraft 1.18+ 需要 Java 17，1.20.5+ 需要 Java 21");
            advice.AppendLine("  3. 在启动设置中选择正确的 Java 路径");
        }
        // 3. 显卡驱动/OpenGL 问题
        else if (text.Contains("opengl") || text.Contains("glfw") || text.Contains("nvidia") || text.Contains("amd") || text.Contains("graphics") || text.Contains("pixel format"))
        {
            result.CrashType = CrashType.GraphicsIssue;
            advice.AppendLine("【显卡/OpenGL 问题】显卡驱动不支持或 OpenGL 版本过低。");
            advice.AppendLine("解决办法：");
            advice.AppendLine("  1. 更新显卡驱动（NVIDIA/AMD/Intel 官网下载最新驱动）");
            advice.AppendLine("  2. 如果使用核显，切换到独立显卡运行游戏");
            advice.AppendLine("  3. 关闭光影包或降低画质设置");
            advice.AppendLine("  4. 添加 JVM 参数：-Dorg.lwjgl.opengl.Display.allowSoftwareOpenGL=true");
        }
        // 4. 模组冲突/缺失依赖
        else if (text.Contains("modloading") || text.Contains("mod loading") || text.Contains("missing dependency") || text.Contains("requires") || text.Contains("incompatible") || text.Contains("duplicate"))
        {
            result.CrashType = CrashType.ModConflict;
            advice.AppendLine("【模组冲突/依赖缺失】模组之间冲突或缺少依赖模组。");
            advice.AppendLine("解决办法：");
            if (suspicious.Count > 0)
                advice.AppendLine($"  1. 可疑模组：{string.Join("、", suspicious.Take(5))}，先尝试禁用这些模组");
            else
                advice.AppendLine("  1. 打开「模组管理」，禁用最近添加的模组，逐个排查");
            advice.AppendLine("  2. 检查所有模组是否支持当前游戏版本和加载器版本");
            advice.AppendLine("  3. 确认依赖模组已安装（如 Fabric API、Cloth Config、Architectury 等）");
            advice.AppendLine("  4. 删除重复的模组（同一模组不能有两个版本）");
        }
        // 5. 游戏文件损坏
        else if (text.Contains("file not found") || text.Contains("no such file") || text.Contains("corrupt") || text.Contains("invalid") || text.Contains("zipfile"))
        {
            result.CrashType = CrashType.CorruptedFiles;
            advice.AppendLine("【游戏文件损坏】游戏文件缺失或损坏。");
            advice.AppendLine("解决办法：");
            advice.AppendLine("  1. 打开「下载」页面，重新下载当前游戏版本（会覆盖损坏文件）");
            advice.AppendLine("  2. 或使用「校验修复」功能检查游戏文件完整性");
            advice.AppendLine("  3. 检查杀毒软件是否误删了游戏文件，将启动器目录加入白名单");
        }
        // 6. Forge/Fabric 加载器安装失败
        else if (text.Contains("loader") && (text.Contains("failed") || text.Contains("error") || text.Contains("exception")))
        {
            result.CrashType = CrashType.LoaderIssue;
            advice.AppendLine("【加载器问题】Forge/Fabric/Quilt 加载器安装不正确。");
            advice.AppendLine("解决办法：");
            advice.AppendLine("  1. 打开「下载」页面，重新安装对应版本的加载器");
            advice.AppendLine("  2. 确保加载器版本与游戏版本匹配");
            advice.AppendLine("  3. 删除 versions 目录下对应的加载器版本文件夹，重新安装");
        }
        // 7. OptiFine 冲突
        else if (text.Contains("optifine") || text.Contains("shadersmod"))
        {
            result.CrashType = CrashType.OptiFineConflict;
            advice.AppendLine("【OptiFine 冲突】OptiFine 与其他模组或加载器不兼容。");
            advice.AppendLine("解决办法：");
            advice.AppendLine("  1. 如果使用 Fabric，建议用 Sodium + Iris 替代 OptiFine");
            advice.AppendLine("  2. 如果使用 Forge，确保 OptiFine 版本与 Forge 版本匹配");
            advice.AppendLine("  3. 禁用其他光影模组，只保留 OptiFine");
        }
        // 8. 有可疑模组
        else if (suspicious.Count > 0)
        {
            result.CrashType = CrashType.ModCrash;
            advice.AppendLine($"【模组崩溃】可能由以下模组引起：{string.Join("、", suspicious.Take(5))}");
            advice.AppendLine("解决办法：");
            advice.AppendLine("  1. 打开「模组管理」，禁用上述可疑模组");
            advice.AppendLine("  2. 逐个启用模组，找到具体冲突的模组");
            advice.AppendLine("  3. 更新这些模组到最新版本，或反馈给模组作者");
            advice.AppendLine("  4. 检查模组是否需要依赖模组（如 Fabric API）");
        }
        // 9. 未知原因
        else
        {
            result.CrashType = CrashType.Unknown;
            advice.AppendLine("【未知原因】未能自动识别崩溃原因。");
            advice.AppendLine("解决办法：");
            advice.AppendLine("  1. 查看「日志」页面，找到第一条红色 [err] 错误信息");
            advice.AppendLine("  2. 如果是整合包，尝试减少模组数量");
            advice.AppendLine("  3. 更新所有模组到最新版本");
            advice.AppendLine("  4. 重新安装游戏版本和加载器");
            advice.AppendLine("  5. 将崩溃报告（crash-reports 目录下的 .txt 文件）反馈给模组作者或整合包作者");
        }

        // 通用建议
        advice.AppendLine();
        advice.AppendLine("【通用排查步骤】");
        advice.AppendLine("  1. 先备份存档和配置文件");
        advice.AppendLine("  2. 尝试只安装必要的模组，排除模组冲突");
        advice.AppendLine("  3. 确保 Java 版本、游戏版本、加载器版本三者匹配");
        advice.AppendLine("  4. 游戏文件校验修复，确保文件完整");

        result.Advice = advice.ToString();
        return result;
    }

    /// <summary>检测游戏进程是否崩溃，并返回诊断结果</summary>
    public CrashAnalysis? DetectCrash(Process proc, string gameDir, int exitCode)
    {
        try
        {
            // 正常退出码是 0，其他都可能是崩溃
            if (exitCode == 0) return null;

            // 尝试读取最新的崩溃报告
            string? crashText = ReadLatestCrashReport(gameDir);

            // 如果没有崩溃报告，使用日志缓冲区的最后几行
            if (string.IsNullOrEmpty(crashText))
            {
                var lastLines = LogBuffer.Skip(Math.Max(0, LogBuffer.Count - 100)).ToList();
                crashText = string.Join("\n", lastLines);
            }

            var analysis = AnalyzeCrash(crashText);
            analysis.ExitCode = exitCode;
            analysis.CrashTime = DateTime.Now;
            return analysis;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>读取最新崩溃报告文件</summary>
    public string? ReadLatestCrashReport(string gameDir)
    {
        string crashDir = Path.Combine(gameDir, "crash-reports");
        if (!Directory.Exists(crashDir)) return null;
        var file = Directory.GetFiles(crashDir, "*.txt").OrderByDescending(f => File.GetLastWriteTime(f)).FirstOrDefault();
        return file == null ? null : File.ReadAllText(file);
    }
}

public class ObservableLog : System.Collections.ObjectModel.ObservableCollection<string>
{
    private readonly object _lock = new();
    private const int MaxLines = 2000;

    public new void Add(string line)
    {
        lock (_lock)
        {
            base.Add(line);
            while (Count > MaxLines) RemoveAt(0);
        }
    }
}

public enum CrashType
{
    Unknown,
    OutOfMemory,
    JavaVersionMismatch,
    GraphicsIssue,
    ModConflict,
    ModCrash,
    CorruptedFiles,
    LoaderIssue,
    OptiFineConflict,
    JvmCrash
}

public class CrashAnalysis
{
    public string Text { get; set; } = "";
    public string Cause { get; set; } = "";
    public string CrashTitle { get; set; } = "";
    public string GameVersion { get; set; } = "";
    public string LoaderVersion { get; set; } = "";
    public string JavaVersion { get; set; } = "";
    public int ExitCode { get; set; }
    public DateTime CrashTime { get; set; }
    public CrashType CrashType { get; set; } = CrashType.Unknown;
    public List<string> SuspiciousMods { get; set; } = new();
    public string Advice { get; set; } = "";
}
