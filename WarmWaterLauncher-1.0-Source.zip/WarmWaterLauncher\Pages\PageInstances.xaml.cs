using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageInstances : UserControl, IActivatePage
{
    private bool _updating;
    private System.IO.FileSystemWatcher? _watcher;
    private System.Windows.Threading.DispatcherTimer? _refreshTimer;

    public PageInstances()
    {
        InitializeComponent();
        Unloaded += (_, _) => StopWatcher();
    }

    public void OnActivate()
    {
        RefreshList();
        RefreshVersions();
        StartWatcher();
    }

    /// <summary>实时监听版本目录变化，下载完成自动刷新</summary>
    private void StartWatcher()
    {
        try
        {
            var dir = App.Services.Settings.GlobalVersionsDir;
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            if (_watcher == null)
            {
                _watcher = new System.IO.FileSystemWatcher(dir)
                {
                    IncludeSubdirectories = true,
                    NotifyFilter = System.IO.NotifyFilters.DirectoryName | System.IO.NotifyFilters.FileName | System.IO.NotifyFilters.LastWrite
                };
                _watcher.Created += OnVersionDirChanged;
                _watcher.Deleted += OnVersionDirChanged;
                _watcher.Renamed += OnVersionDirChanged;
                _refreshTimer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(800) };
                _refreshTimer.Tick += (_, _) => { _refreshTimer.Stop(); RefreshList(); RefreshVersions(); };
            }
            _watcher.EnableRaisingEvents = true;
        }
        catch { }
    }

    private void StopWatcher()
    {
        try { if (_watcher != null) _watcher.EnableRaisingEvents = false; } catch { }
    }

    private void OnVersionDirChanged(object sender, System.IO.FileSystemEventArgs e)
    {
        // 节流：800ms 内合并多次变化
        Dispatcher.Invoke(() =>
        {
            if (_refreshTimer == null) return;
            _refreshTimer.Stop();
            _refreshTimer.Start();
        });
    }

    private void RefreshList()
    {
        _updating = true;
        var instances = App.Services.Instances.Instances.Select(i => new InstanceVM(i)).ToList();
        InstanceList.ItemsSource = instances;
        var cur = App.Services.Instances.Current;
        if (cur != null)
        {
            var match = instances.FirstOrDefault(v => v.Inst.Id == cur.Id);
            InstanceList.SelectedItem = match;
        }
        _updating = false;
        if (instances.Count > 0) ShowDetail(instances[0].Inst);
        else InstanceStatus.Text = "暂无实例，点击「新建」创建一个";
    }

    private void RefreshVersions()
    {
        var installed = App.Services.Versions.GetInstalledVersions();
        InstVersionCombo.ItemsSource = installed;
        var cur = App.Services.Instances.Current;
        if (cur != null && installed.Contains(cur.VersionId))
            InstVersionCombo.SelectedItem = cur.VersionId;
    }

    private void InstanceList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_updating) return;
        if (InstanceList.SelectedItem is InstanceVM vm)
        {
            App.Services.Settings.Config.CurrentInstanceId = vm.Inst.Id;
            App.Services.Settings.Save();
            ShowDetail(vm.Inst);
            App.MainWin?.RefreshTopBar();
        }
    }

    private void ShowDetail(GameInstance inst)
    {
        _updating = true;
        InstNameBox.Text = inst.Name;
        InstDescBox.Text = inst.Description;
        InstLoaderVerBox.Text = inst.LoaderVersion ?? "";
        foreach (var item in InstLoaderCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == inst.LoaderType)
                InstLoaderCombo.SelectedItem = item;
        foreach (var item in IsolationCombo.Items)
            if (item is ComboBoxItem ci && ci.Tag?.ToString() == App.Services.Settings.Config.Launch.IsolationMode)
                IsolationCombo.SelectedItem = item;
        GameDirText.Text = App.Services.Instances.GetInstanceGameDir(inst);
        _updating = false;
    }

    private void InstNameBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_updating || InstanceList.SelectedItem is not InstanceVM vm) return;
        vm.Inst.Name = InstNameBox.Text;
        App.Services.Settings.Save();
    }

    private void InstDescBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (_updating || InstanceList.SelectedItem is not InstanceVM vm) return;
        vm.Inst.Description = InstDescBox.Text;
        App.Services.Settings.Save();
    }

    private void InstVersionCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_updating || InstanceList.SelectedItem is not InstanceVM vm) return;
        if (InstVersionCombo.SelectedItem is string ver)
        {
            vm.Inst.VersionId = ver;
            App.Services.Settings.Save();
        }
    }

    private void IsolationCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_updating) return;
        if (IsolationCombo.SelectedItem is ComboBoxItem ci)
        {
            App.Services.Settings.Config.Launch.IsolationMode = ci.Tag?.ToString() ?? "half";
            App.Services.Settings.Save();
            if (InstanceList.SelectedItem is InstanceVM vm)
                GameDirText.Text = App.Services.Instances.GetInstanceGameDir(vm.Inst);
        }
    }

    private void Create_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new TextPromptDialog("新建实例", "实例名称：", "我的世界 " + (InstVersionCombo.SelectedItem?.ToString() ?? ""));
        dlg.Owner = App.MainWin;
        if (dlg.ShowDialog() != true) return;
        var version = InstVersionCombo.SelectedItem?.ToString() ?? "";
        if (string.IsNullOrEmpty(version))
        {
            MessageBox.Show("请先到「下载」页安装一个游戏版本，再创建实例。", "温水启动器");
            return;
        }
        var inst = App.Services.Instances.Create(dlg.Value, version);
        MessageBox.Show($"实例「{inst.Name}」创建成功", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information);
        RefreshList();
        App.MainWin?.RefreshTopBar();
    }

    private void Clone_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceList.SelectedItem is not InstanceVM vm) return;
        var dlg = new TextPromptDialog("复制实例", "新实例名称：", vm.Inst.Name + " - 副本");
        dlg.Owner = App.MainWin;
        if (dlg.ShowDialog() != true) return;
        var r = MessageBox.Show("是否同时复制游戏目录（存档/模组等文件）？", "温水启动器",
            MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
        if (r == MessageBoxResult.Cancel) return;
        var clone = App.Services.Instances.Clone(vm.Inst, dlg.Value, r == MessageBoxResult.Yes);
        RefreshList();
        App.MainWin?.RefreshTopBar();
        InstanceStatus.Text = "已复制实例：" + clone.Name;
    }

    private async void BackupWorld_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceList.SelectedItem is not InstanceVM vm) { MessageBox.Show("请先选择实例"); return; }
        var inst = vm.Inst;
        var savesDir = App.Services.WorldBackup.GetSavesDir(App.Services.Instances.GetInstanceGameDir(inst));
        if (savesDir == null) { MessageBox.Show("该实例暂无存档目录"); return; }
        var worlds = App.Services.WorldBackup.ListWorlds(App.Services.Instances.GetInstanceGameDir(inst));
        if (worlds.Count == 0) { MessageBox.Show("该实例暂无存档"); return; }
        // 备份最新的存档（按修改时间排序后的第一个）
        var world = worlds[0];
        if (worlds.Count > 1)
        {
            var names = string.Join("\n", worlds.Select((w, i) => $"{i + 1}. {w.Name} ({w.SizeText})"));
            var result = MessageBox.Show($"将备份最新存档「{world.Name}」\n\n所有存档：\n{names}\n\n点击确定备份最新存档，取消则不备份",
                "备份存档", MessageBoxButton.OKCancel);
            if (result != MessageBoxResult.OK) return;
        }
        var progress = new Progress<string>(msg => InstanceStatus.Text = msg);
        var backup = await App.Services.WorldBackup.BackupWorldAsync(world.Path, null, progress);
        if (backup != null)
            MessageBox.Show($"存档「{world.Name}」备份完成！\n大小：{backup.SizeText}\n位置：{backup.BackupPath}");
    }

    private async void RestoreWorld_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceList.SelectedItem is not InstanceVM vm) { MessageBox.Show("请先选择实例"); return; }
        var inst = vm.Inst;
        var backups = App.Services.WorldBackup.ListBackups();
        if (backups.Count == 0) { MessageBox.Show("暂无备份记录"); return; }
        // 恢复最新的备份
        var backup = backups[0];
        if (backups.Count > 1)
        {
            var names = string.Join("\n", backups.Select((b, i) => $"{i + 1}. {b.WorldName} ({b.CreatedAt:MM-dd HH:mm}, {b.SizeText})"));
            var result = MessageBox.Show($"将恢复最新备份「{backup.WorldName}」({backup.CreatedAt:MM-dd HH:mm})\n\n所有备份：\n{names}\n\n点击确定恢复最新备份，取消则不恢复",
                "恢复存档", MessageBoxButton.OKCancel);
            if (result != MessageBoxResult.OK) return;
        }
        var savesDir = App.Services.WorldBackup.GetSavesDir(App.Services.Instances.GetInstanceGameDir(inst));
        if (savesDir == null) { MessageBox.Show("该实例暂无存档目录"); return; }
        if (MessageBox.Show($"确定要恢复存档「{backup.WorldName}」吗？\n现有同名存档将被重命名备份。",
            "确认恢复", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        var progress = new Progress<string>(msg => InstanceStatus.Text = msg);
        var ok = await App.Services.WorldBackup.RestoreBackupAsync(backup.Id, savesDir, progress);
        MessageBox.Show(ok ? "存档恢复完成！" : "存档恢复失败，请查看状态信息");
    }

    private void OpenSavesDir_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceList.SelectedItem is not InstanceVM vm) return;
        var inst = vm.Inst;
        var savesDir = App.Services.WorldBackup.GetSavesDir(App.Services.Instances.GetInstanceGameDir(inst));
        if (savesDir != null)
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", savesDir) { UseShellExecute = true });
        else
            MessageBox.Show("该实例暂无存档目录");
    }

    private void ViewScreenshots_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceList.SelectedItem is not InstanceVM vm) { MessageBox.Show("请先选择实例"); return; }
        var inst = vm.Inst;
        var shots = App.Services.Screenshots.ListScreenshots(App.Services.Instances.GetInstanceGameDir(inst));
        if (shots.Count == 0) { MessageBox.Show("该实例暂无截图"); return; }
        var info = string.Join("\n", shots.Take(20).Select(s => $"{s.FileName} ({s.SizeText}, {s.DateText})"));
        if (shots.Count > 20) info += $"\n... 共 {shots.Count} 张截图";
        MessageBox.Show(info, $"截图列表（共 {shots.Count} 张）");
    }

    private void OpenScreenshotsDir_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceList.SelectedItem is not InstanceVM vm) return;
        var inst = vm.Inst;
        App.Services.Screenshots.OpenScreenshotFolder(App.Services.Instances.GetInstanceGameDir(inst));
    }

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceList.SelectedItem is not InstanceVM vm) return;
        var r = MessageBox.Show($"确定删除实例「{vm.Inst.Name}」？\n删除后该实例的隔离目录会被移除。", "温水启动器",
            MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (r != MessageBoxResult.Yes) return;
        App.Services.Instances.Delete(vm.Inst);
        RefreshList();
        App.MainWin?.RefreshTopBar();
    }

    private async void ImportModpack_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = "整合包 (*.zip)|*.zip", Title = "选择整合包文件（CurseForge / Modrinth / PCL）" };
        if (dlg.ShowDialog() != true) return;
        try
        {
            ImportModpackBtn.IsEnabled = false;
            InstanceStatus.Text = "正在导入整合包，请稍候...";
            var progress = new Progress<string>(s => InstanceStatus.Text = s);
            var result = await Task.Run(() => App.Services.Modpacks.ImportAsync(dlg.FileName, progress));
            if (result.Ok && result.Instance != null)
            {
                MessageBox.Show(result.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information);
                RefreshList();
                App.MainWin?.RefreshTopBar();
            }
            else
            {
                MessageBox.Show(result.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("整合包导入失败：" + ex.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            ImportModpackBtn.IsEnabled = true;
        }
    }

    private void Export_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceList.SelectedItem is not InstanceVM vm) return;
        var dlg = new SaveFileDialog
        {
            Filter = "实例备份|*.zip",
            FileName = InstanceService.Sanitize(vm.Inst.Name) + ".zip"
        };
        if (dlg.ShowDialog() != true) return;
        try
        {
            var path = App.Services.Instances.Export(vm.Inst, dlg.FileName);
            InstanceStatus.Text = "已导出到：" + path;
        }
        catch (Exception ex)
        {
            InstanceStatus.Text = "导出失败: " + ex.Message;
        }
    }

    private void Import_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = "实例备份|*.zip" };
        if (dlg.ShowDialog() != true) return;
        try
        {
            var inst = App.Services.Instances.Import(dlg.FileName);
            if (inst == null)
            {
                InstanceStatus.Text = "导入失败：备份格式不正确";
                return;
            }
            MessageBox.Show($"实例「{inst.Name}」导入成功", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information);
            RefreshList();
            App.MainWin?.RefreshTopBar();
        }
        catch (Exception ex)
        {
            InstanceStatus.Text = "导入失败: " + ex.Message;
        }
    }

    private void OpenGameDir_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceList.SelectedItem is not InstanceVM vm) return;
        var dir = App.Services.Instances.GetInstanceGameDir(vm.Inst);
        Directory.CreateDirectory(dir);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }
}

public class InstanceVM
{
    public GameInstance Inst { get; }
    public InstanceVM(GameInstance inst) => Inst = inst;
    public string Name => Inst.Name;
    public string DisplayVersion
    {
        get
        {
            var loader = Inst.LoaderType == "none" ? "原版" : Inst.LoaderType + " " + Inst.LoaderVersion;
            return $"版本 {Inst.VersionId} · {loader}" + (string.IsNullOrEmpty(Inst.Description) ? "" : "\n" + Inst.Description);
        }
    }
    public int PlayCount => Inst.PlayCount;
}
