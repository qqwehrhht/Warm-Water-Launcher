using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace WarmWaterLauncher.Services;

/// <summary>Minecraft 服务器状态 Ping 查询服务</summary>
public class ServerPingService
{
    /// <summary>Ping 一个 Minecraft 服务器，返回状态信息</summary>
    public async Task<ServerStatus?> PingAsync(string host, int port = 25565, int timeoutMs = 5000)
    {
        try
        {
            using var client = new TcpClient();
            var connectTask = client.ConnectAsync(host, port);
            var timeoutTask = Task.Delay(timeoutMs);
            if (await Task.WhenAny(connectTask, timeoutTask) == timeoutTask)
                return new ServerStatus { Online = false, Error = "连接超时" };

            using var stream = client.GetStream();
            stream.ReadTimeout = timeoutMs;
            stream.WriteTimeout = timeoutMs;

            // 发送握手包
            var handshake = BuildHandshake(host, port);
            await stream.WriteAsync(handshake, 0, handshake.Length);

            // 发送状态请求包
            var statusReq = new byte[] { 0x01, 0x00 };
            await stream.WriteAsync(statusReq, 0, statusReq.Length);

            // 读取响应
            var buffer = new byte[65536];
            var read = await stream.ReadAsync(buffer, 0, buffer.Length);
            if (read < 5) return new ServerStatus { Online = false, Error = "响应过短" };

            // 解析包长度和包ID
            int offset = 0;
            var (packetLen, _) = ReadVarInt(buffer, offset);
            offset += 1; // 跳过包长度字段（简化处理）
            var (packetId, idLen) = ReadVarInt(buffer, offset);
            offset += idLen;

            if (packetId != 0x00) return new ServerStatus { Online = false, Error = "未知响应包" };

            // 读取 JSON 字符串长度
            var (jsonLen, jsonLenBytes) = ReadVarInt(buffer, offset);
            offset += jsonLenBytes;

            if (offset + jsonLen > read) return new ServerStatus { Online = false, Error = "JSON 数据不完整" };

            var json = Encoding.UTF8.GetString(buffer, offset, jsonLen);
            var status = ParseStatusJson(json);
            status.Online = true;
            status.Host = host;
            status.Port = port;

            // 测量延迟
            var pingStart = DateTime.Now;
            try
            {
                var pingPacket = BuildPingPacket();
                await stream.WriteAsync(pingPacket, 0, pingPacket.Length);
                var pingRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                status.LatencyMs = (int)(DateTime.Now - pingStart).TotalMilliseconds;
            }
            catch { status.LatencyMs = -1; }

            return status;
        }
        catch (Exception ex)
        {
            return new ServerStatus { Online = false, Host = host, Port = port, Error = ex.Message };
        }
    }

    private ServerStatus ParseStatusJson(string json)
    {
        var status = new ServerStatus();
        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            // 版本信息
            if (root.TryGetProperty("version", out var verEl))
            {
                if (verEl.TryGetProperty("name", out var nameEl))
                    status.VersionName = nameEl.GetString() ?? "";
                if (verEl.TryGetProperty("protocol", out var protoEl))
                    status.ProtocolVersion = protoEl.GetInt32();
            }

            // 玩家信息
            if (root.TryGetProperty("players", out var playersEl))
            {
                if (playersEl.TryGetProperty("online", out var onlineEl))
                    status.OnlinePlayers = onlineEl.GetInt32();
                if (playersEl.TryGetProperty("max", out var maxEl))
                    status.MaxPlayers = maxEl.GetInt32();
                if (playersEl.TryGetProperty("sample", out var sampleEl) && sampleEl.ValueKind == JsonValueKind.Array)
                {
                    status.SamplePlayers = new();
                    foreach (var p in sampleEl.EnumerateArray())
                    {
                        if (p.TryGetProperty("name", out var pname))
                            status.SamplePlayers.Add(pname.GetString() ?? "");
                    }
                }
            }

            // MOTD
            if (root.TryGetProperty("description", out var descEl))
            {
                status.Motd = ParseMotd(descEl);
            }

            // 图标
            if (root.TryGetProperty("favicon", out var favEl))
            {
                var fav = favEl.GetString() ?? "";
                if (fav.StartsWith("data:image/png;base64,"))
                    status.FaviconBase64 = fav.Substring("data:image/png;base64,".Length);
            }
        }
        catch { }
        return status;
    }

    private string ParseMotd(JsonElement el)
    {
        try
        {
            if (el.ValueKind == JsonValueKind.String)
                return el.GetString() ?? "";
            if (el.ValueKind == JsonValueKind.Object)
            {
                var sb = new StringBuilder();
                if (el.TryGetProperty("text", out var textEl))
                    sb.Append(textEl.GetString() ?? "");
                if (el.TryGetProperty("extra", out var extraEl) && extraEl.ValueKind == JsonValueKind.Array)
                {
                    foreach (var e in extraEl.EnumerateArray())
                    {
                        if (e.TryGetProperty("text", out var et))
                            sb.Append(et.GetString() ?? "");
                    }
                }
                return sb.ToString().Trim();
            }
        }
        catch { }
        return "";
    }

    private byte[] BuildHandshake(string host, int port)
    {
        using var ms = new MemoryStream();
        // 包ID = 0x00
        WriteVarInt(ms, 0x00);
        // 协议版本（使用较新的版本号以兼容）
        WriteVarInt(ms, 760);
        // 服务器地址
        var hostBytes = Encoding.UTF8.GetBytes(host);
        WriteVarInt(ms, hostBytes.Length);
        ms.Write(hostBytes, 0, hostBytes.Length);
        // 端口
        ms.WriteByte((byte)(port >> 8));
        ms.WriteByte((byte)(port & 0xFF));
        // 下一个状态 = 1（状态查询）
        WriteVarInt(ms, 1);

        var data = ms.ToArray();
        // 加上包长度前缀
        using var result = new MemoryStream();
        WriteVarInt(result, data.Length);
        result.Write(data, 0, data.Length);
        return result.ToArray();
    }

    private byte[] BuildPingPacket()
    {
        using var ms = new MemoryStream();
        WriteVarInt(ms, 0x01); // 包ID
        var payload = BitConverter.GetBytes(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
        ms.Write(payload, 0, payload.Length);
        var data = ms.ToArray();
        using var result = new MemoryStream();
        WriteVarInt(result, data.Length);
        result.Write(data, 0, data.Length);
        return result.ToArray();
    }

    private static void WriteVarInt(MemoryStream ms, int value)
    {
        while ((value & ~0x7F) != 0)
        {
            ms.WriteByte((byte)((value & 0x7F) | 0x80));
            value >>= 7;
        }
        ms.WriteByte((byte)value);
    }

    private static (int value, int bytesRead) ReadVarInt(byte[] buffer, int offset)
    {
        int value = 0;
        int size = 0;
        int b;
        do
        {
            if (offset + size >= buffer.Length) break;
            b = buffer[offset + size];
            value |= (b & 0x7F) << (size * 7);
            size++;
            if (size > 5) break;
        } while ((b & 0x80) == 0x80);
        return (value, size);
    }
}

/// <summary>服务器状态信息</summary>
public class ServerStatus
{
    public bool Online { get; set; }
    public string Host { get; set; } = "";
    public int Port { get; set; } = 25565;
    public string VersionName { get; set; } = "";
    public int ProtocolVersion { get; set; }
    public int OnlinePlayers { get; set; }
    public int MaxPlayers { get; set; }
    public List<string>? SamplePlayers { get; set; }
    public string Motd { get; set; } = "";
    public string? FaviconBase64 { get; set; }
    public int LatencyMs { get; set; } = -1;
    public string Error { get; set; } = "";

    public string LatencyText => LatencyMs < 0 ? "—" : $"{LatencyMs}ms";
    public string PlayersText => Online ? $"{OnlinePlayers}/{MaxPlayers}" : "离线";
}
