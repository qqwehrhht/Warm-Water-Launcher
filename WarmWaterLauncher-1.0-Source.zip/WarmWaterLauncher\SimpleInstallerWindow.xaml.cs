using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace WarmWaterLauncher
{
    public partial class SimpleInstallerWindow : Window
    {
        public SimpleInstallerWindow()
        {
            InitializeComponent();
            // 默认安装路径
            string defaultPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "WarmWaterLauncher");
            InstallPathBox.Text = defaultPath;
            UpdateDiskSpace();
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BrowseBtn_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFolderDialog
            {
                Title = "选择安装目录"
            };
            if (dialog.ShowDialog() == true)
            {
                InstallPathBox.Text = dialog.FolderName;
                UpdateDiskSpace();
            }
        }

        private void UpdateDiskSpace()
        {
            try
            {
                string path = InstallPathBox.Text;
                string root = Path.GetPathRoot(path) ?? "C:\\";
                var drive = new DriveInfo(root);
                double freeGB = drive.AvailableFreeSpace / 1024.0 / 1024.0 / 1024.0;
                DiskSpaceText.Text = $"目标磁盘可用空间：{freeGB:F1} GB（建议预留 2GB 以上）";
            }
            catch
            {
                DiskSpaceText.Text = "";
            }
        }

        private async void InstallBtn_Click(object sender, RoutedEventArgs e)
        {
            string installPath = InstallPathBox.Text.Trim();
            if (string.IsNullOrEmpty(installPath))
            {
                MessageBox.Show("请选择安装位置！", "安装程序", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 检查写入权限
            try
            {
                if (!Directory.Exists(installPath))
                    Directory.CreateDirectory(installPath);
                string testFile = Path.Combine(installPath, ".write_test");
                File.WriteAllText(testFile, "test");
                File.Delete(testFile);
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("没有权限写入该目录，请选择其他位置，或以管理员身份运行安装程序。", "权限不足", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 切换到安装中页面
            InstallPage.Visibility = Visibility.Collapsed;
            ProgressPage.Visibility = Visibility.Visible;
            InstallButtons.Visibility = Visibility.Collapsed;
            ProgressButtons.Visibility = Visibility.Visible;
            InstallBtn.IsEnabled = false;

            // 先在UI线程读取CheckBox值，避免后台线程跨线程访问UI
            bool createDesktopShortcut = DesktopShortcutCheck.IsChecked == true;
            bool createStartMenuShortcut = StartMenuShortcutCheck.IsChecked == true;

            try
            {
                await System.Threading.Tasks.Task.Run(() => DoInstall(installPath, createDesktopShortcut, createStartMenuShortcut));
            }
            catch (Exception ex)
            {
                MessageBox.Show("安装失败：" + ex.Message, "安装错误", MessageBoxButton.OK, MessageBoxImage.Error);
                InstallPage.Visibility = Visibility.Visible;
                ProgressPage.Visibility = Visibility.Collapsed;
                InstallButtons.Visibility = Visibility.Visible;
                ProgressButtons.Visibility = Visibility.Collapsed;
                InstallBtn.IsEnabled = true;
                return;
            }

            // 切换到完成页面
            ProgressPage.Visibility = Visibility.Collapsed;
            CompletePage.Visibility = Visibility.Visible;
            ProgressButtons.Visibility = Visibility.Collapsed;
            CompleteButtons.Visibility = Visibility.Visible;
            CompletePathText.Text = $"安装位置：{installPath}";
        }

        private void DoInstall(string installPath, bool createDesktopShortcut, bool createStartMenuShortcut)
        {
            // 1. 创建目录
            Dispatcher.Invoke(() => { ProgressStatusText.Text = "正在创建目录..."; InstallProgressBar.Value = 10; ProgressPercentText.Text = "10%"; });
            System.Threading.Thread.Sleep(200);
            Directory.CreateDirectory(installPath);

            // 创建数据目录
            string dataDir = Path.Combine(installPath, "WarmWaterData");
            Directory.CreateDirectory(dataDir);
            string[] subDirs = { "instances", "versions", "assets", "libraries", "mods", "resourcepacks", "shaderpacks", "saves", "logs", "skins", "caches", "java" };
            foreach (var dir in subDirs)
                Directory.CreateDirectory(Path.Combine(dataDir, dir));

            // 2. 复制主程序
            Dispatcher.Invoke(() => { ProgressStatusText.Text = "正在复制启动器文件..."; InstallProgressBar.Value = 30; ProgressPercentText.Text = "30%"; });
            System.Threading.Thread.Sleep(300);
            string sourceExe = Process.GetCurrentProcess().MainModule?.FileName ?? "";
            string destExe = Path.Combine(installPath, "我的世界启动器.exe");
            if (File.Exists(sourceExe) && sourceExe != destExe)
                File.Copy(sourceExe, destExe, true);

            // 3. 创建使用说明
            Dispatcher.Invoke(() => { ProgressStatusText.Text = "正在创建使用说明..."; InstallProgressBar.Value = 60; ProgressPercentText.Text = "60%"; });
            System.Threading.Thread.Sleep(200);
            string readme = Path.Combine(installPath, "使用说明.txt");
            File.WriteAllText(readme, "温水我的世界启动器 v1.0 正式版 使用说明\n\n" +
                "1. 双击运行 我的世界启动器.exe\n" +
                "2. 首次启动请阅读并同意用户协议\n" +
                "3. 在下载页面下载游戏版本\n" +
                "4. 在账号页面创建离线账号\n" +
                "5. 点击主页的启动按钮开始游戏\n\n" +
                "如有问题请查看启动器内的帮助文档。\n");

            // 4. 创建快捷方式
            if (createDesktopShortcut)
            {
                Dispatcher.Invoke(() => { ProgressStatusText.Text = "正在创建桌面快捷方式..."; InstallProgressBar.Value = 75; ProgressPercentText.Text = "75%"; });
                System.Threading.Thread.Sleep(200);
                CreateShortcut(destExe, "温水我的世界启动器", Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));
            }

            if (createStartMenuShortcut)
            {
                Dispatcher.Invoke(() => { ProgressStatusText.Text = "正在创建开始菜单快捷方式..."; InstallProgressBar.Value = 85; ProgressPercentText.Text = "85%"; });
                System.Threading.Thread.Sleep(200);
                string startMenuDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs", "WarmWaterLauncher");
                Directory.CreateDirectory(startMenuDir);
                CreateShortcut(destExe, "温水我的世界启动器", startMenuDir);
            }

            // 5. 写入注册表
            Dispatcher.Invoke(() => { ProgressStatusText.Text = "正在完成安装..."; InstallProgressBar.Value = 95; ProgressPercentText.Text = "95%"; });
            System.Threading.Thread.Sleep(200);
            try
            {
                using var key = Registry.CurrentUser.CreateSubKey(@"Software\WarmWaterLauncher");
                key?.SetValue("InstallPath", installPath);
                key?.SetValue("Version", "1.0 正式版");
            }
            catch { }

            Dispatcher.Invoke(() => { ProgressStatusText.Text = "安装完成！"; InstallProgressBar.Value = 100; ProgressPercentText.Text = "100%"; });
            System.Threading.Thread.Sleep(500);
        }

        private void CreateShortcut(string targetPath, string shortcutName, string shortcutDir)
        {
            try
            {
                string shortcutPath = Path.Combine(shortcutDir, shortcutName + ".lnk");
                // 用PowerShell创建快捷方式
                var ps = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = $"-Command \"$s=(New-Object -COM WScript.Shell).CreateShortcut('{shortcutPath}');$s.TargetPath='{targetPath}';$s.WorkingDirectory='{Path.GetDirectoryName(targetPath)}';$s.Save()\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                Process.Start(ps)?.WaitForExit(5000);
            }
            catch { }
        }

        private void FinishBtn_Click(object sender, RoutedEventArgs e)
        {
            if (LaunchNowCheck.IsChecked == true)
            {
                try
                {
                    string installPath = InstallPathBox.Text;
                    string exePath = Path.Combine(installPath, "我的世界启动器.exe");
                    if (File.Exists(exePath))
                        Process.Start(new ProcessStartInfo(exePath) { WorkingDirectory = installPath });
                }
                catch { }
            }
            Close();
        }
    }
}
