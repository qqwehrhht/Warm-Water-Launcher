using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace WarmWaterLauncher.Services;

/// <summary>MC百科模组信息（国内源）</summary>
public class McModItem
{
    public string Name { get; set; } = "";
    public string Url { get; set; } = "";
    public string Description { get; set; } = "";
    public string? IconUrl { get; set; }
    public string Author { get; set; } = "";
    public string Category { get; set; } = "";
    public string Source => "MC百科";
    public string Downloads { get; set; } = "";
}

/// <summary>MC百科（mcmod.cn）国内模组源服务</summary>
public class McModService
{
    private const string SearchUrl = "https://search.mcmod.cn/s?key={0}&page={1}";
    private const string ModUrl = "https://www.mcmod.cn/class/{0}.html";

    private readonly HttpClient _http;

    public McModService()
    {
        _http = new HttpClient { Timeout = TimeSpan.FromSeconds(20) };
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        _http.DefaultRequestHeaders.Accept.ParseAdd("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
        _http.DefaultRequestHeaders.AcceptLanguage.ParseAdd("zh-CN,zh;q=0.9");
    }

    /// <summary>搜索模组</summary>
    public async Task<List<McModItem>> SearchAsync(string query, int page = 1, CancellationToken ct = default)
    {
        var results = new List<McModItem>();
        try
        {
            string url = string.Format(SearchUrl, Uri.EscapeDataString(query), page);
            using var resp = await _http.GetAsync(url, ct);
            if (!resp.IsSuccessStatusCode) return results;
            var html = await resp.Content.ReadAsStringAsync(ct);
            if (string.IsNullOrEmpty(html)) return results;

            results = ParseSearchResults(html);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"MC百科搜索错误: {ex.Message}");
        }
        return results;
    }

    /// <summary>解析搜索结果页面</summary>
    private List<McModItem> ParseSearchResults(string html)
    {
        var results = new List<McModItem>();
        try
        {
            // MC百科搜索结果页面结构分析：
            // 每个结果项通常包含：图标img、标题a链接、描述p、作者、分类标签等
            // 使用多种模式尝试匹配

            var seenUrls = new HashSet<string>();

            // 模式1：匹配包含 /class/ 链接的整个结果块
            // 先找到所有 class 链接的位置，然后向前找最近的结果容器
            var linkMatches = Regex.Matches(html, @"href=""(?:https?://www\.mcmod\.cn)?/class/(\d+)\.html""", RegexOptions.IgnoreCase);
            foreach (Match linkMatch in linkMatches)
            {
                if (results.Count >= 30) break;
                string id = linkMatch.Groups[1].Value;
                string url = string.Format(ModUrl, id);
                if (seenUrls.Contains(url)) continue;
                seenUrls.Add(url);

                // 找到这个链接在HTML中的位置
                int pos = linkMatch.Index;
                // 向前找最近的 <div 或 <li 开始标签（结果容器的开始）
                int containerStart = FindTagStart(html, pos, new[] { "<div", "<li", "<article" });
                // 向后找对应的结束标签
                int containerEnd = FindTagEnd(html, pos, new[] { "</div>", "</li>", "</article>" });

                string blockHtml = "";
                if (containerStart >= 0 && containerEnd > containerStart)
                    blockHtml = html.Substring(containerStart, containerEnd - containerStart);
                else
                    blockHtml = html.Substring(Math.Max(0, pos - 200), Math.Min(800, html.Length - Math.Max(0, pos - 200)));

                // 从块中提取名称
                string name = "";
                // 优先从链接文本提取
                var aTagMatch = Regex.Match(blockHtml, @"<a[^>]*href=""[^""]*class/\d+\.html""[^>]*>(.*?)</a>", RegexOptions.Singleline);
                if (aTagMatch.Success)
                    name = ExtractText(aTagMatch.Groups[1].Value);

                // 如果链接文本为空，从h标签提取
                if (string.IsNullOrEmpty(name))
                {
                    var hMatch = Regex.Match(blockHtml, @"<h\d[^>]*>(.*?)</h\d>", RegexOptions.Singleline);
                    if (hMatch.Success)
                        name = ExtractText(hMatch.Groups[1].Value);
                }

                // 如果还是空，从title属性提取
                if (string.IsNullOrEmpty(name))
                {
                    var titleMatch = Regex.Match(blockHtml, @"title=""([^""]+)""");
                    if (titleMatch.Success)
                        name = ExtractText(titleMatch.Groups[1].Value);
                }

                if (string.IsNullOrEmpty(name)) continue;

                var item = new McModItem
                {
                    Name = name,
                    Url = url,
                    Description = "",
                    Author = "",
                    Category = ""
                };

                // 提取图标（在块中找第一个img）
                var imgMatch = Regex.Match(blockHtml, @"<img[^>]*src=""([^""]+)""", RegexOptions.IgnoreCase);
                if (imgMatch.Success)
                {
                    string icon = imgMatch.Groups[1].Value;
                    // 过滤掉一些明显不是图标的图片
                    if (!icon.Contains("loading") && !icon.Contains("spinner") && !icon.Contains("avatar_default"))
                    {
                        item.IconUrl = icon.StartsWith("//") ? "https:" + icon :
                                       icon.StartsWith("/") ? "https://www.mcmod.cn" + icon : icon;
                    }
                }

                // 提取描述（找p标签或带desc类的元素）
                var descMatch = Regex.Match(blockHtml, @"<(?:p|div|span)[^>]*class=""[^""]*(?:desc|summary|intro|text)[^""]*""[^>]*>(.*?)</(?:p|div|span)>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                if (!descMatch.Success)
                    descMatch = Regex.Match(blockHtml, @"<p[^>]*>(.*?)</p>", RegexOptions.Singleline);
                if (descMatch.Success)
                {
                    string desc = ExtractText(descMatch.Groups[1].Value);
                    if (desc.Length > 5 && desc.Length < 500)
                        item.Description = desc;
                }

                // 提取作者
                var authorMatch = Regex.Match(blockHtml, @"作者[:：]?\s*<a[^>]*>(.*?)</a>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                if (!authorMatch.Success)
                    authorMatch = Regex.Match(blockHtml, @"<span[^>]*class=""[^""]*author[^""]*""[^>]*>(.*?)</span>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                if (authorMatch.Success)
                    item.Author = ExtractText(authorMatch.Groups[1].Value);

                // 提取分类标签
                var catMatches = Regex.Matches(blockHtml, @"<a[^>]*class=""[^""]*(?:tag|label|category)[^""]*""[^>]*>(.*?)</a>", RegexOptions.Singleline | RegexOptions.IgnoreCase);
                if (catMatches.Count > 0)
                {
                    var cats = new List<string>();
                    foreach (Match cm in catMatches)
                    {
                        string cat = ExtractText(cm.Groups[1].Value);
                        if (!string.IsNullOrEmpty(cat) && cat.Length < 20)
                            cats.Add(cat);
                    }
                    item.Category = string.Join(" · ", cats.Take(3));
                }

                results.Add(item);
            }

            // 如果上面的方法没找到，尝试最简单的方式：直接从所有class链接提取
            if (results.Count == 0)
            {
                foreach (Match linkMatch in linkMatches)
                {
                    if (results.Count >= 30) break;
                    string id = linkMatch.Groups[1].Value;
                    string url = string.Format(ModUrl, id);
                    if (seenUrls.Contains(url)) continue;
                    seenUrls.Add(url);

                    // 取链接前后的文本作为名称
                    int pos = linkMatch.Index;
                    int startIdx = Math.Max(0, pos - 100);
                    int len = Math.Min(300, html.Length - startIdx);
                    string context = html.Substring(startIdx, len);

                    // 找最近的 > 和 < 之间的文本
                    var textMatch = Regex.Match(context, @">([^<>]{2,50})<");
                    string name = textMatch.Success ? ExtractText(textMatch.Groups[1].Value) : $"模组 {id}";

                    results.Add(new McModItem
                    {
                        Name = name,
                        Url = url,
                        Description = "",
                        Author = "",
                        Category = ""
                    });
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"MC百科解析错误: {ex.Message}");
        }
        return results;
    }

    /// <summary>找到指定位置之前最近的标签开始位置</summary>
    private int FindTagStart(string html, int pos, string[] tags)
    {
        int best = -1;
        foreach (string tag in tags)
        {
            int idx = html.LastIndexOf(tag, pos, StringComparison.OrdinalIgnoreCase);
            if (idx > best) best = idx;
        }
        return best;
    }

    /// <summary>找到指定位置之后最近的标签结束位置</summary>
    private int FindTagEnd(string html, int pos, string[] tags)
    {
        int best = html.Length;
        foreach (string tag in tags)
        {
            int idx = html.IndexOf(tag, pos, StringComparison.OrdinalIgnoreCase);
            if (idx >= 0 && idx < best) best = idx;
        }
        return best == html.Length ? -1 : best;
    }

    /// <summary>从HTML中提取纯文本</summary>
    private string ExtractText(string html)
    {
        if (string.IsNullOrEmpty(html)) return "";
        // 移除标签
        string text = Regex.Replace(html, "<[^>]+>", "");
        // 解码HTML实体
        text = System.Net.WebUtility.HtmlDecode(text);
        // 移除多余空白
        text = Regex.Replace(text, @"\s+", " ").Trim();
        return text;
    }

    /// <summary>打开模组详情页</summary>
    public void OpenModPage(string url)
    {
        try
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(url) { UseShellExecute = true });
        }
        catch { }
    }
}
