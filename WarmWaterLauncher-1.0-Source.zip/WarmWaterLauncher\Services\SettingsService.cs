using System.IO;
using System.Text;
using System.Text.Json;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

/// <summary>全局服务容器</summary>
public class AppServices
{
    public SettingsService Settings = null!;
    public AccountService Accounts = null!;
    public InstanceService Instances = null!;
    public DownloadService Download = null!;
    public VersionService Versions = null!;
    public JavaService Java = null!;
    public LaunchService Launcher = null!;
    public ModService Mods = null!;
    public ResourceService Resources = null!;
    public LogService Logs = null!;
    public LoaderService Loaders = null!;
    public ModrinthApi Modrinth = null!;
    public ModpackService Modpacks = null!;
    public NatTraversalService Nat = null!;
    public SkinService Skins = null!;
    public AvatarService Avatars = null!;
    public PlayTimeService PlayTime = null!;
    public ServerPingService ServerPing = null!;
    public WorldBackupService WorldBackup = null!;
    public ScreenshotService Screenshots = null!;
    public MicrosoftAuthService MicrosoftAuth = null!;
    public AchievementService Achievements = null!;
    public PerformanceMonitor Performance = null!;
    public NewsService News = null!;
    public UpdateService Updater = null!;
    public AIAssistantService AI = null!;
    public CurseForgeApi CurseForge = null!;
    public McModService McMod = null!;
    public DownloadManagerService DownloadManager = null!;
    public BackupService Backup = null!;
    public BedrockService Bedrock = null!;
    public CleanupService Cleanup = null!;
    public ConfigService ConfigManager = null!;
    public FrpService Frp = null!;
    public ServerService Server = null!;
    public SystemInfoService SystemInfo = null!;
    public FeaturesV1Beta1 FeaturesV1 = null!;

    public void Init()
    {
        Settings = new SettingsService();
        Settings.Load();
        Download = new DownloadService(Settings);
        Accounts = new AccountService(Settings);
        Instances = new InstanceService(Settings);
        Versions = new VersionService(Settings, Download);
        DownloadManager = new DownloadManagerService();
        Versions.SetDownloadManager(DownloadManager);
        Java = new JavaService(Settings, Download);
        Modrinth = new ModrinthApi(Settings, Download);
        Loaders = new LoaderService(Settings, Download, Versions, Java);
        Mods = new ModService(Settings, Modrinth, Instances);
        Resources = new ResourceService(Settings, Instances);
        Logs = new LogService(Settings);
        Modpacks = new ModpackService(Settings, Download, Instances, Loaders, DownloadManager, Versions);
        Nat = new NatTraversalService(Download);
        Skins = new SkinService(Settings);
        Avatars = new AvatarService(Download);
        PlayTime = new PlayTimeService();
        ServerPing = new ServerPingService();
        WorldBackup = new WorldBackupService();
        Screenshots = new ScreenshotService();
        MicrosoftAuth = new MicrosoftAuthService(Download);
        Achievements = new AchievementService();
        Performance = new PerformanceMonitor();
        News = new NewsService();
        Updater = new UpdateService(Download);
        AI = new AIAssistantService(Download);
        CurseForge = new CurseForgeApi(Settings, Download);
        McMod = new McModService();
        DownloadManager = new DownloadManagerService();
        Backup = new BackupService();
        Bedrock = new BedrockService();
        Cleanup = new CleanupService();
        ConfigManager = new ConfigService();
        Frp = new FrpService(Download);
        Server = new ServerService(Download, Versions, Java);
        SystemInfo = new SystemInfoService();
        FeaturesV1 = new FeaturesV1Beta1();
        Launcher = new LaunchService(Settings, Download, Versions, Java, Mods, Logs, Instances);
    }
}

/// <summary>配置读写，支持便携模式</summary>
public class SettingsService
{
    public AppConfig Config { get; private set; } = new();
    private string _configPath = "";

    /// <summary>便携数据目录：exe 同目录下 WarmWaterData</summary>
    public static string GetDataDir()
    {
        string exeDir = AppContext.BaseDirectory;
        // 兼容便携模式与安装模式
        string dataDir = Path.Combine(exeDir, "WarmWaterData");
        try
        {
            Directory.CreateDirectory(dataDir);
            return dataDir;
        }
        catch
        {
            string fallback = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WarmWaterLauncher");
            Directory.CreateDirectory(fallback);
            return fallback;
        }
    }

    public void Load()
    {
        _configPath = Path.Combine(GetDataDir(), "config.json");
        if (File.Exists(_configPath))
        {
            try
            {
                var json = File.ReadAllText(_configPath, Encoding.UTF8);
                Config = JsonSerializer.Deserialize<AppConfig>(json, JsonOpts) ?? new AppConfig();
            }
            catch { Config = new AppConfig(); }
        }
        else
        {
            Config = new AppConfig();
            Save();
        }
        // 统一配置：Download.Threads 以 General.DownloadThreads 为准
        try
        {
            if (Config.General.DownloadThreads > 0)
                Config.Download.Threads = Config.General.DownloadThreads;
            else if (Config.Download.Threads > 0)
                Config.General.DownloadThreads = Config.Download.Threads;
        }
        catch { }
    }

    public void Save()
    {
        try
        {
            var json = JsonSerializer.Serialize(Config, JsonOpts);
            File.WriteAllText(_configPath, json, Encoding.UTF8);
        }
        catch { }
    }

    public static readonly JsonSerializerOptions JsonOpts = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    /// <summary>游戏根目录（.minecraft 的父目录）</summary>
    public string GameRoot
    {
        get
        {
            var root = Config.General.GameRoot;
            if (string.IsNullOrWhiteSpace(root))
                root = Path.Combine(GetDataDir(), ".minecraft");
            try { Directory.CreateDirectory(root); } catch { }
            return root;
        }
    }

    /// <summary>全局版本目录</summary>
    public string GlobalVersionsDir => Path.Combine(GameRoot, "versions");

    /// <summary>全局资源目录</summary>
    public string AssetsDir => Path.Combine(GameRoot, "assets");

    /// <summary>全局库目录</summary>
    public string LibrariesDir => Path.Combine(GameRoot, "libraries");

    /// <summary>运行目录（临时）</summary>
    public string RunDir => Path.Combine(GameRoot, "run");
}

/// <summary>账号凭证本地加密存储（AES-GCM，密钥派生自机器指纹）</summary>
public static class CryptoService
{
    private static readonly byte[] Salt = new byte[] { 0x57, 0x57, 0x4D, 0x4C, 0x2D, 0x53, 0x41, 0x4C, 0x54, 0x21, 0x2A, 0x40, 0x24, 0x23, 0x5E, 0x26 };

    private static byte[] DeriveKey()
    {
        // 机器指纹：MAC 地址 + 用户名 + 机器名，保证密钥不落盘
        string finger = "";
        try
        {
            foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up && ni.GetPhysicalAddress().GetAddressBytes().Length == 6)
                {
                    finger += ni.GetPhysicalAddress().ToString();
                    break;
                }
            }
        }
        catch { }
        finger += Environment.UserName + Environment.MachineName + "WarmWater";
        using var kdf = new System.Security.Cryptography.Rfc2898DeriveBytes(finger, Salt, 20000, System.Security.Cryptography.HashAlgorithmName.SHA256);
        return kdf.GetBytes(32);
    }

    /// <summary>加密并转 Base64</summary>
    public static string? Encrypt(string? plain)
    {
        if (string.IsNullOrEmpty(plain)) return null;
        try
        {
            var key = DeriveKey();
            byte[] nonce = System.Security.Cryptography.RandomNumberGenerator.GetBytes(12);
            byte[] data = Encoding.UTF8.GetBytes(plain);
            byte[] cipher = new byte[data.Length];
            byte[] tag = new byte[16];
            using var aes = new System.Security.Cryptography.AesGcm(key, 16);
            aes.Encrypt(nonce, data, cipher, tag);
            return Convert.ToBase64String(nonce.Concat(tag).Concat(cipher).ToArray());
        }
        catch { return plain; }
    }

    /// <summary>解密 Base64</summary>
    public static string? Decrypt(string? encoded)
    {
        if (string.IsNullOrEmpty(encoded)) return null;
        try
        {
            var key = DeriveKey();
            var all = Convert.FromBase64String(encoded);
            if (all.Length < 28) return null;
            var nonce = all[..12];
            var tag = all[12..28];
            var cipher = all[28..];
            byte[] data = new byte[cipher.Length];
            using var aes = new System.Security.Cryptography.AesGcm(key, 16);
            aes.Decrypt(nonce, cipher, tag, data);
            return Encoding.UTF8.GetString(data);
        }
        catch { return null; }
    }
}
