using System.Diagnostics;
using System.Text;

namespace WarmWaterLauncher.Services;

/// <summary>一键开服服务：下载服务端、生成配置、启动服务器</summary>
public class ServerService
{
    private readonly DownloadService _dl;
    private readonly VersionService _versions;
    private readonly JavaService _java;
    private Process? _serverProcess;
    private readonly string _serversDir;

    public ServerService(DownloadService dl, VersionService versions, JavaService java)
    {
        _dl = dl;
        _versions = versions;
        _java = java;
        _serversDir = Path.Combine(SettingsService.GetDataDir(), "servers");
        Directory.CreateDirectory(_serversDir);
    }

    #region 服务器配置模型
    public class ServerConfig
    {
        public string Name { get; set; } = "Minecraft Server";
        public string VersionId { get; set; } = "";
        public int Port { get; set; } = 25565;
        public int MaxPlayers { get; set; } = 20;
        public string LevelSeed { get; set; } = "";
        public string Difficulty { get; set; } = "normal"; // peaceful/easy/normal/hard
        public string GameMode { get; set; } = "survival"; // survival/creative/adventure/spectator
        public int ViewDistance { get; set; } = 10;
        public bool OnlineMode { get; set; } = true;
        public string Motd { get; set; } = "A Minecraft Server";
        public bool Pvp { get; set; } = true;
        public bool EnableCommandBlock { get; set; } = false;
        public bool SpawnMonsters { get; set; } = true;
        public bool SpawnAnimals { get; set; } = true;
        public int MaxMemory { get; set; } = 4096;
        public int MinMemory { get; set; } = 1024;
        public string JavaPath { get; set; } = "";
    }

    public static readonly string[] Difficulties = { "peaceful", "easy", "normal", "hard" };
    public static readonly string[] GameModes = { "survival", "creative", "adventure", "spectator" };
    #endregion

    #region 服务器目录
    public string GetServerDir(string name) => Path.Combine(_serversDir, name);
    public string GetServerJarPath(string name) => Path.Combine(GetServerDir(name), "server.jar");
    public string GetPropertiesPath(string name) => Path.Combine(GetServerDir(name), "server.properties");
    public string GetEulaPath(string name) => Path.Combine(GetServerDir(name), "eula.txt");

    public bool ServerExists(string name) => Directory.Exists(GetServerDir(name));
    public bool IsServerJarReady(string name) => File.Exists(GetServerJarPath(name)) && new FileInfo(GetServerJarPath(name)).Length > 10 * 1024 * 1024;
    #endregion

    #region 下载服务端
    /// <summary>下载指定版本的服务端（多源镜像+重试）</summary>
    public async Task<bool> DownloadServerAsync(string versionId, string serverName, IProgress<(string desc, double pct, int ok, int total)>? progress = null)
    {
        try
        {
            string dir = GetServerDir(serverName);
            Directory.CreateDirectory(dir);
            string jarPath = GetServerJarPath(serverName);

            // 如果已经存在且大小正常，跳过下载
            if (IsServerJarReady(serverName))
            {
                progress?.Report(("服务端已存在，跳过下载", 100, 1, 1));
                return true;
            }

            // 从版本清单获取服务端下载地址
            progress?.Report(($"正在获取版本 {versionId} 信息...", 5, 0, 1));
            var manifest = await _versions.GetVersionJsonAsync(versionId);
            if (manifest == null)
            {
                progress?.Report(($"版本 {versionId} 不存在或获取失败", 0, 0, 1));
                return false;
            }

            string? serverUrl = manifest.Downloads?.Server?.Url;
            if (string.IsNullOrEmpty(serverUrl))
            {
                progress?.Report(($"版本 {versionId} 没有服务端文件", 0, 0, 1));
                return false;
            }

            // 构造多源下载地址（国内镜像优先）
            var urls = new List<string>();
            // BMCLAPI 镜像（替换 piston-data.mojang.com）
            if (serverUrl.Contains("piston-data.mojang.com"))
            {
                urls.Add(serverUrl.Replace("https://piston-data.mojang.com", "https://bmclapi2.bangbang93.com"));
                urls.Add(serverUrl.Replace("https://piston-data.mojang.com", "https://download.mcimirror.top"));
            }
            // 官方地址（最后尝试）
            urls.Add(serverUrl);

            progress?.Report(($"正在下载服务端 {versionId}...", 15, 0, 1));

            // 多源重试下载
            bool ok = false;
            string? lastErr = null;
            for (int i = 0; i < urls.Count; i++)
            {
                string url = urls[i];
                try
                {
                    progress?.Report(($"正在从镜像 {i + 1}/{urls.Count} 下载...", 15 + (double)i / urls.Count * 70, 0, 1));
                    // 删除可能存在的不完整文件
                    if (File.Exists(jarPath)) File.Delete(jarPath);
                    ok = await _dl.DownloadFileAsync(url, jarPath, null, default);
                    if (ok && IsServerJarReady(serverName)) break;
                    lastErr = $"镜像 {i + 1} 下载的文件不完整";
                }
                catch (Exception ex)
                {
                    lastErr = ex.Message;
                    ok = false;
                }
            }

            if (!ok || !IsServerJarReady(serverName))
            {
                progress?.Report(($"服务端下载失败：{lastErr ?? "所有镜像均失败"}", 0, 0, 1));
                return false;
            }

            progress?.Report(("服务端下载完成", 100, 1, 1));
            return true;
        }
        catch (Exception ex)
        {
            progress?.Report(($"下载失败: {ex.Message}", 0, 0, 1));
            return false;
        }
    }
    #endregion

    #region 生成配置
    /// <summary>生成 server.properties</summary>
    public string GenerateProperties(ServerConfig cfg)
    {
        var sb = new StringBuilder();
        sb.AppendLine("#Minecraft server properties");
        sb.AppendLine($"server-port={cfg.Port}");
        sb.AppendLine($"max-players={cfg.MaxPlayers}");
        sb.AppendLine($"level-seed={cfg.LevelSeed}");
        sb.AppendLine($"difficulty={cfg.Difficulty}");
        sb.AppendLine($"gamemode={cfg.GameMode}");
        sb.AppendLine($"view-distance={cfg.ViewDistance}");
        sb.AppendLine($"online-mode={(cfg.OnlineMode ? "true" : "false")}");
        sb.AppendLine($"motd={cfg.Motd}");
        sb.AppendLine($"pvp={(cfg.Pvp ? "true" : "false")}");
        sb.AppendLine($"enable-command-block={(cfg.EnableCommandBlock ? "true" : "false")}");
        sb.AppendLine($"spawn-monsters={(cfg.SpawnMonsters ? "true" : "false")}");
        sb.AppendLine($"spawn-animals={(cfg.SpawnAnimals ? "true" : "false")}");
        sb.AppendLine("enable-jmx-monitoring=false");
        sb.AppendLine("rcon.port=25575");
        sb.AppendLine("level-type=minecraft\\:normal");
        sb.AppendLine("enable-rcon=false");
        sb.AppendLine("enable-query=false");
        sb.AppendLine("generator-settings={}");
        sb.AppendLine("enforce-secure-profile=true");
        sb.AppendLine("level-name=world");
        sb.AppendLine("initial-disabled-packs=");
        sb.AppendLine("initial-enabled-packs=vanilla");
        sb.AppendLine("level-name=world");
        sb.AppendLine("prevent-proxy-connections=false");
        sb.AppendLine("use-native-transport=true");
        sb.AppendLine("enable-status=true");
        sb.AppendLine("hide-online-players=false");
        sb.AppendLine("resource-pack-prompt=");
        sb.AppendLine("require-resource-pack=false");
        sb.AppendLine("resource-pack-id=");
        sb.AppendLine("server-ip=");
        sb.AppendLine("allow-nether=true");
        sb.AppendLine("network-compression-threshold=256");
        sb.AppendLine("max-world-size=29999984");
        sb.AppendLine("spawn-protection=16");
        sb.AppendLine("rate-limit=0");
        sb.AppendLine("query.port=25565");
        return sb.ToString();
    }

    public void SaveConfig(ServerConfig cfg)
    {
        string dir = GetServerDir(cfg.Name);
        Directory.CreateDirectory(dir);
        // 用无 BOM 的 UTF-8 编码，避免服务器无法识别
        var utf8NoBom = new UTF8Encoding(false);
        File.WriteAllText(GetPropertiesPath(cfg.Name), GenerateProperties(cfg), utf8NoBom);
        File.WriteAllText(GetEulaPath(cfg.Name), "eula=true\r\n", utf8NoBom);
    }
    #endregion

    #region 启动/停止服务器
    public bool IsRunning => _serverProcess != null && !_serverProcess.HasExited;

    public event Action<string>? OnLog;
    public event Action<bool>? OnStatusChanged; // true=运行中, false=已停止

    /// <summary>启动服务器</summary>
    public async Task<bool> StartAsync(ServerConfig cfg)
    {
        try
        {
            if (IsRunning) return true;

            string dir = GetServerDir(cfg.Name);
            Directory.CreateDirectory(dir);

            // 确保服务端存在
            if (!IsServerJarReady(cfg.Name))
            {
                OnLog?.Invoke("服务端不存在，正在下载...");
                var progress = new Progress<(string desc, double pct, int ok, int total)>(v => OnLog?.Invoke(v.desc));
                bool ok = await DownloadServerAsync(cfg.VersionId, cfg.Name, progress);
                if (!ok)
                {
                    OnLog?.Invoke("服务端下载失败，无法启动");
                    return false;
                }
            }

            SaveConfig(cfg);

            // 强制确认 eula.txt 存在且内容正确（防止旧文件或用户删除导致 EULA 错误）
            try
            {
                string eulaPath = GetEulaPath(cfg.Name);
                var utf8NoBom = new UTF8Encoding(false);
                if (!File.Exists(eulaPath) || !File.ReadAllText(eulaPath).Contains("eula=true"))
                {
                    File.WriteAllText(eulaPath, "eula=true\r\n", utf8NoBom);
                    OnLog?.Invoke("已自动同意 EULA");
                }
            }
            catch (Exception ex)
            {
                OnLog?.Invoke($"EULA 写入失败: {ex.Message}");
            }

            // 找 Java
            string javaPath = cfg.JavaPath;
            if (string.IsNullOrEmpty(javaPath) || !File.Exists(javaPath))
            {
                javaPath = FindJavaForVersion(cfg.VersionId);
                if (string.IsNullOrEmpty(javaPath) || !File.Exists(javaPath))
                {
                    OnLog?.Invoke("未找到合适的 Java，请先在 Java 管理中安装");
                    return false;
                }
            }

            OnLog?.Invoke($"使用 Java: {javaPath}");
            OnLog?.Invoke($"启动服务器 {cfg.Name} (版本 {cfg.VersionId})...");

            // JVM 参数：加 --add-opens 消除 Java 模块访问警告（高版本 Java 运行旧版服务器需要）
            // 注意：sun.misc 不在 java.base 模块里，不要加 java.base/sun.misc
            string jvmArgs = $"-Xmx{cfg.MaxMemory}M -Xms{cfg.MinMemory}M " +
                "--add-opens java.base/java.lang=ALL-UNNAMED " +
                "--add-opens java.base/java.util=ALL-UNNAMED " +
                "--add-opens java.base/java.nio=ALL-UNNAMED " +
                "--add-opens java.base/sun.nio.ch=ALL-UNNAMED " +
                "--add-opens java.base/java.lang.reflect=ALL-UNNAMED";

            var psi = new ProcessStartInfo
            {
                FileName = javaPath,
                Arguments = $"{jvmArgs} -jar \"{GetServerJarPath(cfg.Name)}\" nogui",
                WorkingDirectory = dir,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            _serverProcess = new Process { StartInfo = psi, EnableRaisingEvents = true };
            _serverProcess.OutputDataReceived += (_, e) => { if (!string.IsNullOrEmpty(e.Data)) OnLog?.Invoke(e.Data); };
            _serverProcess.ErrorDataReceived += (_, e) => { if (!string.IsNullOrEmpty(e.Data)) OnLog?.Invoke("[错误] " + e.Data); };
            _serverProcess.Exited += (_, _) =>
            {
                OnLog?.Invoke("服务器已停止");
                OnStatusChanged?.Invoke(false);
            };
            _serverProcess.Start();
            _serverProcess.BeginOutputReadLine();
            _serverProcess.BeginErrorReadLine();
            OnStatusChanged?.Invoke(true);
            return true;
        }
        catch (Exception ex)
        {
            OnLog?.Invoke("启动失败: " + ex.Message);
            return false;
        }
    }

    /// <summary>向服务器发送命令</summary>
    public void SendCommand(string command)
    {
        try
        {
            if (_serverProcess != null && !_serverProcess.HasExited)
            {
                _serverProcess.StandardInput.WriteLine(command);
                OnLog?.Invoke($"> {command}");
            }
        }
        catch { }
    }

    public void Stop()
    {
        try
        {
            if (_serverProcess != null && !_serverProcess.HasExited)
            {
                SendCommand("stop");
                if (!_serverProcess.WaitForExit(10000))
                {
                    _serverProcess.Kill(true);
                }
            }
        }
        catch { }
        _serverProcess = null;
    }

    public void DeleteServer(string name)
    {
        try
        {
            if (IsRunning && _serverProcess != null) Stop();
            string dir = GetServerDir(name);
            if (Directory.Exists(dir)) Directory.Delete(dir, true);
        }
        catch { }
    }
    #endregion

    #region 工具方法
    /// <summary>根据游戏版本找合适的 Java</summary>
    private string FindJavaForVersion(string versionId)
    {
        try
        {
            var javas = _java.DetectAll();
            if (javas.Count == 0) return "";

            // 判断版本需要的 Java 主版本
            int requiredMajor = 17; // 默认 17
            if (VersionRequiresJava8(versionId)) requiredMajor = 8;
            else if (VersionRequiresJava21(versionId)) requiredMajor = 21;

            // 优先找精确匹配
            var exact = javas.FirstOrDefault(j => j.Major == requiredMajor);
            if (exact != null) return exact.Path;

            // 其次找更高版本
            var higher = javas.Where(j => j.Major >= requiredMajor).OrderBy(j => j.Major).FirstOrDefault();
            if (higher != null) return higher.Path;

            // 最后用任意
            return javas[0].Path;
        }
        catch { return ""; }
    }

    private static bool VersionRequiresJava8(string versionId)
    {
        // 1.16.5 及以下用 Java 8
        try
        {
            if (versionId.StartsWith("1.") && versionId.Length >= 4)
            {
                string minor = versionId.Split('.')[1];
                if (int.TryParse(minor, out int m) && m <= 16) return true;
            }
        }
        catch { }
        return false;
    }

    private static bool VersionRequiresJava21(string versionId)
    {
        // 1.20.5 及以上用 Java 21
        try
        {
            if (versionId.StartsWith("1.") && versionId.Length >= 4)
            {
                string minor = versionId.Split('.')[1];
                string? patch = versionId.Split('.').Length > 2 ? versionId.Split('.')[2] : "0";
                if (int.TryParse(minor, out int m))
                {
                    if (m > 20) return true;
                    if (m == 20 && int.TryParse(patch, out int p) && p >= 5) return true;
                }
            }
            // 快照版本默认 21
            if (versionId.Contains("w") || versionId.Contains("pre") || versionId.Contains("rc") || versionId.Contains("snapshot"))
                return true;
        }
        catch { }
        return false;
    }
    #endregion
}
