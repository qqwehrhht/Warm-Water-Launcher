using System.IO.Compression;
using System.Text.Json;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

/// <summary>整合包导入结果</summary>
public class ModpackImportResult
{
    public bool Ok { get; set; }
    public GameInstance? Instance { get; set; }
    public string Message { get; set; } = "";
    public List<string> FailedFiles { get; set; } = new();
}

/// <summary>
/// 整合包服务：导入 CurseForge / Modrinth / PCL 格式整合包。
/// - CurseForge：zip 内含 manifest.json + overrides/
/// - Modrinth：zip 内含 modrinth.index.json + overrides/
/// - PCL / 其他：zip 为 .minecraft 目录结构，直接按实例目录导入
/// </summary>
public class ModpackService
{
    private readonly SettingsService _settings;
    private readonly DownloadService _dl;
    private readonly InstanceService _instances;
    private readonly LoaderService _loaders;
    private readonly DownloadManagerService _dm;
    private readonly VersionService _versions;

    public ModpackService(SettingsService settings, DownloadService dl, InstanceService instances, LoaderService loaders,
        DownloadManagerService dm, VersionService versions)
    {
        _settings = settings;
        _dl = dl;
        _instances = instances;
        _loaders = loaders;
        _dm = dm;
        _versions = versions;
    }

    /// <summary>分析整合包类型</summary>
    public static string DetectType(string zipPath)
    {
        using var zip = ZipFile.OpenRead(zipPath);
        bool hasCf = zip.Entries.Any(e => e.FullName == "manifest.json");
        bool hasMr = zip.Entries.Any(e => e.FullName == "modrinth.index.json");
        if (hasCf) return "curseforge";
        if (hasMr) return "modrinth";
        return "pcl";
    }

    /// <summary>导入整合包</summary>
    public async Task<ModpackImportResult> ImportAsync(string zipPath, IProgress<string>? progress = null)
    {
        var result = new ModpackImportResult();
        try
        {
            string type = DetectType(zipPath);
            progress?.Report($"检测到整合包类型：{TypeName(type)}");
            GameInstance? inst = type switch
            {
                "curseforge" => await ImportCurseForgeAsync(zipPath, progress),
                "modrinth" => await ImportModrinthAsync(zipPath, progress),
                _ => await ImportPclAsync(zipPath, progress)
            };
            if (inst == null)
            {
                result.Ok = false;
                result.Message = "整合包解析失败：未能识别有效的整合包结构";
                return result;
            }
            result.Ok = true;
            result.Instance = inst;
            result.Message = $"整合包「{inst.Name}」导入成功";
        }
        catch (Exception ex)
        {
            result.Ok = false;
            result.Message = "整合包导入失败: " + ex.Message;
        }
        return result;
    }

    private static string TypeName(string t) => t switch
    {
        "curseforge" => "CurseForge",
        "modrinth" => "Modrinth",
        _ => "PCL/.minecraft"
    };

    /// <summary>CurseForge 格式导入</summary>
    private async Task<GameInstance?> ImportCurseForgeAsync(string zipPath, IProgress<string>? progress)
    {
        string tmp = Path.Combine(Path.GetTempPath(), "ww_modpack_" + Guid.NewGuid().ToString("N"));
        try
        {
            ZipFile.ExtractToDirectory(zipPath, tmp);
            string manifestPath = Path.Combine(tmp, "manifest.json");
            if (!File.Exists(manifestPath)) return null;

            using var doc = JsonDocument.Parse(File.ReadAllText(manifestPath));
            var root = doc.RootElement;
            string mcVer = root.GetProperty("minecraft").GetProperty("version").GetString() ?? "";
            if (string.IsNullOrEmpty(mcVer)) return null;

            // 加载器：modLoaders[].id 形如 "forge-40.1.0" / "fabric-0.14.21"
            string loaderType = "none", loaderVersion = "";
            if (root.GetProperty("minecraft").TryGetProperty("modLoaders", out var loaders) && loaders.ValueKind == JsonValueKind.Array)
            {
                foreach (var l in loaders.EnumerateArray())
                {
                    string id = l.GetProperty("id").GetString() ?? "";
                    int idx = id.IndexOf('-');
                    if (idx > 0)
                    {
                        string lt = id[..idx].ToLowerInvariant();
                        if (lt is "forge" or "fabric" or "quilt" or "neoforge")
                        {
                            loaderType = lt;
                            loaderVersion = id[(idx + 1)..];
                            break;
                        }
                    }
                }
            }

            string name = Path.GetFileNameWithoutExtension(zipPath);
            if (root.TryGetProperty("name", out var pname)) name = pname.GetString() ?? name;
            name = InstanceService.Sanitize(name);
            if (name.Length == 0) name = "整合包";
            // 避免重名
            name = UniqueName(name);

            progress?.Report($"创建实例「{name}」 版本 {mcVer} 加载器 {loaderType}");
            var inst = _instances.Create(name, mcVer);
            inst.LoaderType = loaderType == "none" ? "none" : loaderType;
            inst.LoaderVersion = string.IsNullOrEmpty(loaderVersion) ? null : loaderVersion;
            _settings.Save();

            // 应用 overrides 到实例游戏目录
            string overrides = Path.Combine(tmp, "overrides");
            string gameDir = _instances.GetInstanceGameDir(inst);
            if (Directory.Exists(overrides))
            {
                progress?.Report("应用 overrides 文件...");
                CopyDir(overrides, gameDir);
            }

            // 安装加载器
            if (loaderType != "none")
            {
                progress?.Report($"安装 {loaderType} 加载器...");
                await _loaders.InstallAsync(inst, loaderType, loaderVersion, null!);
            }

            // 下载 mods（走 CurseForge 网页 API，无需 key）
            var files = new List<(long pid, long fid, bool required)>();
            if (root.TryGetProperty("files", out var farr) && farr.ValueKind == JsonValueKind.Array)
            {
                foreach (var f in farr.EnumerateArray())
                {
                    long pid = f.GetProperty("projectID").GetInt64();
                    long fid = f.GetProperty("fileID").GetInt64();
                    bool req = !f.TryGetProperty("required", out var rq) || rq.GetBoolean();
                    files.Add((pid, fid, req));
                }
            }
            if (files.Count > 0)
            {
                progress?.Report($"下载 {files.Count} 个 CurseForge 模组...");
                string modsDir = Path.Combine(gameDir, "mods");
                Directory.CreateDirectory(modsDir);
                await DownloadCurseForgeModsAsync(files, modsDir, progress);
            }

            // 自动下载游戏版本本体，确保游戏文件完整
            progress?.Report($"下载游戏版本 {mcVer}（客户端文件）...");
            var vp = new Progress<(string desc, double pct, int ok, int total)>(v => progress?.Report($"下载游戏版本 {mcVer}：{v.desc}"));
            await _versions.DownloadVersionAsync(mcVer, vp);

            // 清理临时目录
            try { Directory.Delete(tmp, true); } catch { }
            return inst;
        }
        catch
        {
            try { Directory.Delete(tmp, true); } catch { }
            throw;
        }
    }

    /// <summary>Modrinth 格式导入</summary>
    private async Task<GameInstance?> ImportModrinthAsync(string zipPath, IProgress<string>? progress)
    {
        string tmp = Path.Combine(Path.GetTempPath(), "ww_modpack_" + Guid.NewGuid().ToString("N"));
        try
        {
            ZipFile.ExtractToDirectory(zipPath, tmp);
            string indexPath = Path.Combine(tmp, "modrinth.index.json");
            if (!File.Exists(indexPath)) return null;

            using var doc = JsonDocument.Parse(File.ReadAllText(indexPath));
            var root = doc.RootElement;

            // 依赖：dependencies.minecraft 为 MC 版本；fabric-loader/forge 等为加载器
            string mcVer = "";
            string loaderType = "none";
            if (root.TryGetProperty("dependencies", out var deps) && deps.ValueKind == JsonValueKind.Object)
            {
                if (deps.TryGetProperty("minecraft", out var mc)) mcVer = mc.GetString() ?? "";
                foreach (var k in new[] { "neoforge", "forge", "fabric-loader", "quilt-loader" })
                    if (deps.TryGetProperty(k, out _)) { loaderType = k.Replace("-loader", ""); break; }
            }
            // 兼容旧格式：loaders 数组
            if (loaderType == "none" && root.TryGetProperty("loaders", out var lds) && lds.ValueKind == JsonValueKind.Array)
            {
                foreach (var l in lds.EnumerateArray())
                {
                    string lt = l.GetString()?.ToLowerInvariant().Replace("-loader", "") ?? "";
                    if (lt is "forge" or "fabric" or "quilt" or "neoforge") { loaderType = lt; break; }
                }
            }
            if (string.IsNullOrEmpty(mcVer)) return null;

            string name = InstanceService.Sanitize(Path.GetFileNameWithoutExtension(zipPath));
            if (root.TryGetProperty("name", out var pn)) name = InstanceService.Sanitize(pn.GetString() ?? name);
            if (name.Length == 0) name = "整合包";
            name = UniqueName(name);

            progress?.Report($"创建实例「{name}」 版本 {mcVer} 加载器 {loaderType}");
            var inst = _instances.Create(name, mcVer);
            inst.LoaderType = loaderType;
            _settings.Save();

            string gameDir = _instances.GetInstanceGameDir(inst);

            // 下载文件（按相对路径放置，如 mods/xxx.jar、config/xxx）
            if (root.TryGetProperty("files", out var files) && files.ValueKind == JsonValueKind.Array)
            {
                var tasks = new List<DownloadTask>();
                foreach (var f in files.EnumerateArray())
                {
                    string rel = f.GetProperty("path").GetString() ?? "";
                    if (string.IsNullOrEmpty(rel)) continue;
                    // 可选环境过滤：client 才需要
                    if (f.TryGetProperty("env", out var env))
                    {
                        bool skip = false;
                        if (env.TryGetProperty("client", out var ce))
                        {
                            string ev = ce.GetString() ?? "";
                            if (ev == "unsupported") skip = true;
                        }
                        if (skip) continue;
                    }
                    string url = "";
                    if (f.TryGetProperty("downloads", out var dls) && dls.ValueKind == JsonValueKind.Array && dls.GetArrayLength() > 0)
                        url = dls[0].GetString() ?? "";
                    string sha1 = f.TryGetProperty("hashes", out var hs) && hs.TryGetProperty("sha1", out var s1)
                        ? s1.GetString() ?? "" : "";
                    if (string.IsNullOrEmpty(url)) continue;
                    string dest = Path.Combine(gameDir, rel.Replace('/', Path.DirectorySeparatorChar));
                    string fname = Path.GetFileName(rel);
                    // 通过下载管理器下载，用户可查看进度；未下载完成前不中断导入
                    var t = _dm.AddTask(fname, url, dest, string.IsNullOrEmpty(sha1) ? null : sha1);
                    if (t != null) tasks.Add(t);
                }
                progress?.Report($"正在下载 {tasks.Count} 个整合包文件（模组/资源）...");
                // 等待所有下载任务完成（无论成功失败都继续，不中断整体导入）
                await _dm.WaitAllAsync(tasks);
            }

            // 应用 overrides
            string overrides = Path.Combine(tmp, "overrides");
            if (Directory.Exists(overrides))
            {
                progress?.Report("应用 overrides 文件...");
                CopyDir(overrides, gameDir);
            }

            // 安装加载器
            if (loaderType != "none")
            {
                progress?.Report($"安装 {loaderType} 加载器...");
                await _loaders.InstallAsync(inst, loaderType, "", null!);
            }

            // 自动下载游戏版本本体，确保游戏文件完整
            progress?.Report($"下载游戏版本 {mcVer}（客户端文件）...");
            var vp = new Progress<(string desc, double pct, int ok, int total)>(v => progress?.Report($"下载游戏版本 {mcVer}：{v.desc}"));
            await _versions.DownloadVersionAsync(mcVer, vp);

            try { Directory.Delete(tmp, true); } catch { }
            return inst;
        }
        catch
        {
            try { Directory.Delete(tmp, true); } catch { }
            throw;
        }
    }

    /// <summary>PCL / .minecraft 目录结构导入</summary>
    private async Task<GameInstance?> ImportPclAsync(string zipPath, IProgress<string>? progress)
    {
        string tmp = Path.Combine(Path.GetTempPath(), "ww_modpack_" + Guid.NewGuid().ToString("N"));
        try
        {
            ZipFile.ExtractToDirectory(zipPath, tmp);

            // 查找 .minecraft 内容根：优先 tmp/.minecraft，否则 tmp 本身
            string root = Directory.Exists(Path.Combine(tmp, ".minecraft"))
                ? Path.Combine(tmp, ".minecraft")
                : tmp;

            // 推断版本：versions 目录下的第一个版本 id
            string mcVer = "";
            string versionsDir = Path.Combine(root, "versions");
            if (Directory.Exists(versionsDir))
            {
                var dirs = Directory.GetDirectories(versionsDir).Select(Path.GetFileName).Where(x => x != null).ToList();
                if (dirs.Count > 0) mcVer = dirs[0]!;
            }

            // 推断加载器
            string loaderType = "none";
            if (Directory.Exists(Path.Combine(root, "mods")))
            {
                if (Directory.EnumerateFiles(Path.Combine(root, "mods"), "*fabric*", SearchOption.TopDirectoryOnly).Any()) loaderType = "fabric";
                else if (Directory.EnumerateFiles(Path.Combine(root, "mods"), "*forge*", SearchOption.TopDirectoryOnly).Any()) loaderType = "forge";
                else if (Directory.EnumerateFiles(Path.Combine(root, "mods"), "*quilt*", SearchOption.TopDirectoryOnly).Any()) loaderType = "quilt";
            }
            if (Directory.Exists(Path.Combine(root, "shaderpacks"))) loaderType = loaderType == "none" ? "optifine" : loaderType;

            string name = UniqueName(InstanceService.Sanitize(Path.GetFileNameWithoutExtension(zipPath)));
            if (name.Length == 0) name = "整合包";

            progress?.Report($"创建实例「{name}」 版本 {mcVer}");
            var inst = _instances.Create(name, mcVer);
            inst.LoaderType = loaderType;
            _settings.Save();

            string gameDir = _instances.GetInstanceGameDir(inst);
            CopyDir(root, gameDir);

            // 清理临时目录
            try { Directory.Delete(tmp, true); } catch { }
            return inst;
        }
        catch
        {
            try { Directory.Delete(tmp, true); } catch { }
            throw;
        }
    }

    /// <summary>通过 CurseForge 网页 API 下载模组（无需 key）</summary>
    private async Task DownloadCurseForgeModsAsync(List<(long pid, long fid, bool required)> files, string modsDir, IProgress<string>? progress)
    {
        foreach (var (pid, fid, required) in files)
        {
            try
            {
                string api = $"https://www.curseforge.com/api/v1/mods/{pid}/files/{fid}/download";
                var req = new HttpRequestMessage(HttpMethod.Get, api);
                req.Headers.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
                using var resp = await _dl.Http.Client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead);
                resp.EnsureSuccessStatusCode();
                // 从响应头或 URL 获取文件名
                string fname = resp.Content.Headers.ContentDisposition?.FileNameStar
                    ?? resp.Content.Headers.ContentDisposition?.FileName
                    ?? $"mod_{pid}_{fid}.jar";
                fname = fname.Trim('"');
                string dest = Path.Combine(modsDir, fname);
                await _dl.SaveToFileAsync(resp, dest);
                progress?.Report($"  ✓ {fname}");
            }
            catch
            {
                // 失败仅记录（非必需文件可跳过）
            }
        }
    }

    private async Task DownloadWithRetryAsync(string url, string dest, string sha1, IProgress<string>? progress)
    {
        try
        {
            if (File.Exists(dest) && !string.IsNullOrEmpty(sha1) && DownloadService.VerifySha1(dest, sha1)) return;
            bool ok = await _dl.DownloadFileAsync(url, dest, string.IsNullOrEmpty(sha1) ? null : sha1);
            if (!ok && !string.IsNullOrEmpty(sha1)) { }
            progress?.Report($"  ✓ {Path.GetFileName(dest)}");
        }
        catch { }
    }

    private string UniqueName(string baseName)
    {
        string n = baseName;
        int i = 2;
        while (_instances.Instances.Any(x => x.Name.Equals(n, StringComparison.OrdinalIgnoreCase)))
            n = $"{baseName} ({i++})";
        return n;
    }

    private static void CopyDir(string src, string dst)
    {
        Directory.CreateDirectory(dst);
        foreach (var f in Directory.EnumerateFiles(src, "*", SearchOption.AllDirectories))
        {
            string rel = Path.GetRelativePath(src, f);
            string target = Path.Combine(dst, rel);
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            File.Copy(f, target, true);
        }
    }
}
