using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
namespace WarmWaterLauncher.Controls;
/// <summary>
/// Minecraft 官方版本图标：根据版本类型显示官方纹理方块
/// 正式版=草方块（Mojang 官方启动器图标），预览版=命令方块，远古版=圆石，愚人节版=金块
/// 均使用官方纹理/图标，不自行改色
/// </summary>
public partial class MinecraftBlockIcon : UserControl
{
    public static readonly DependencyProperty SizeProperty =
        DependencyProperty.Register(nameof(Size), typeof(double), typeof(MinecraftBlockIcon),
            new PropertyMetadata(36.0));
    public static readonly DependencyProperty VersionTypeProperty =
        DependencyProperty.Register(nameof(VersionType), typeof(string), typeof(MinecraftBlockIcon),
            new PropertyMetadata("release", OnVersionTypeChanged));
    /// <summary>纹理标识：release / snapshot / old / aprilfools / other</summary>
    public static readonly DependencyProperty TextureKeyProperty =
        DependencyProperty.Register(nameof(TextureKey), typeof(string), typeof(MinecraftBlockIcon),
            new PropertyMetadata("release"));

    public double Size
    {
        get => (double)GetValue(SizeProperty);
        set => SetValue(SizeProperty, value);
    }
    public string VersionType
    {
        get => (string)GetValue(VersionTypeProperty);
        set => SetValue(VersionTypeProperty, value);
    }
    public string TextureKey
    {
        get => (string)GetValue(TextureKeyProperty);
        set => SetValue(TextureKeyProperty, value);
    }

    public MinecraftBlockIcon()
    {
        InitializeComponent();
        ApplyTypeColors(VersionType);
    }

    private static void OnVersionTypeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is MinecraftBlockIcon icon && e.NewValue is string type)
        {
            icon.ApplyTypeColors(type);
        }
    }

    /// <summary>
    /// 根据版本类型切换官方图标
    /// 正式版=草方块、预览版/快照=命令方块、远古版=圆石、愚人节版=金块
    /// </summary>
    public void ApplyTypeColors(string type)
    {
        string iconPath = type?.ToLowerInvariant() switch
        {
            // 正式版：Mojang 官方启动器图标（草方块）
            "release" => "/Resources/icon_release.png",
            // 预览版/快照：命令方块（官方纹理）
            "snapshot" or "pre" or "preview" => "/Resources/icon_snapshot.png",
            // 远古版：圆石（官方纹理）
            "oldbeta" or "oldalpha" or "old" => "/Resources/icon_old.png",
            // 愚人节版：金块（官方纹理）
            "aprilfools" or "fools" or "april" => "/Resources/icon_aprilfools.png",
            // 加载器：使用对应颜色块（沿用默认草方块渲染，加载器单独处理）
            _ => "/Resources/icon_release.png"
        };
        TextureKey = type?.ToLowerInvariant() switch
        {
            "release" => "release",
            "snapshot" or "pre" or "preview" => "snapshot",
            "oldbeta" or "oldalpha" or "old" => "old",
            "aprilfools" or "fools" or "april" => "aprilfools",
            _ => "other"
        };
        try
        {
            IconImage.Source = new BitmapImage(new System.Uri(iconPath, System.UriKind.Relative));
        }
        catch { }
    }
}
