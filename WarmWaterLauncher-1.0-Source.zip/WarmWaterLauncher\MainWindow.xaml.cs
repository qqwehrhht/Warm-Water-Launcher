using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using WarmWaterLauncher.Pages;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher;

public partial class MainWindow : Window
{
    private readonly Dictionary<string, UserControl> _pages = new();
    private readonly Dictionary<string, Button> _navButtons = new();
    private readonly Dictionary<string, Border> _navIndicators = new();
    private (string key, string nameKey, string icon, UserControl page)[] _navItems = Array.Empty<(string, string, string, UserControl)>();
    private string _currentPage = "";
    private bool _downloadRingAnimating;
    private bool _navCollapsed;
    private bool _refreshingTopBar;
    private double _backgroundOpacity = 0.4;
    private readonly DispatcherTimer _perfTimer = new();
    private readonly DispatcherTimer _achievementTimer = new();
    private readonly DispatcherTimer _toastTimer = new();
    private readonly Queue<Achievement> _achievementQueue = new();
    private int _busyRefs;
    private bool _busyAnimating;

    private readonly List<CommandEntry> _commands = new();
    private readonly List<Button> _commandButtons = new();
    private int _commandIndex;

    public bool IsFocusMode { get; private set; }

    public MainWindow()
    {
        InitializeComponent();
        LaunchService.GameCrashed += OnGameCrashed;
        StateChanged += (_, _) =>
        {
            if (MaxRestoreBtn != null)
                MaxRestoreBtn.Content = WindowState == WindowState.Maximized ? "❐" : "□";
        };

        Loaded += (_, _) =>
        {
            RestoreWindowSize();
            InitNav();
            ApplyAccentFromConfig();
            SetBackground(App.Services.Settings.Config.General.BackgroundImage);
            SetBackgroundOpacity(App.Services.Settings.Config.General.BackgroundOpacity);
            SetEyeCareMode(App.Services.Settings.Config.General.EyeCareMode);
            StartPerformanceMonitor();
            StartAchievementNotifier();
            UpdateAvatar();
            StartDownloadMonitor();
            UpdateNotificationDot();
            Dispatcher.BeginInvoke(RestoreWindowSize, DispatcherPriority.ApplicationIdle);
        };

        ContentRendered += (_, _) => RestoreWindowSize();
    }

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern uint GetDpiForWindow(IntPtr hwnd);

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
    private static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);

    // ==================== 窗口 / 生命周期 ====================

    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    private struct RECT
    {
        public int Left, Top, Right, Bottom;
    }

    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    private struct MONITORINFO
    {
        public int cbSize;
        public RECT rcMonitor;
        public RECT rcWork;
        public uint dwFlags;
    }

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
    private static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO info);

    private void RestoreWindowSize()
    {
        try
        {
            var g = App.Services.Settings.Config.General;

            // 按当前窗口所在显示器的物理工作区计算，兼容 125% / 150% 缩放
            double scaleX = 1.0, scaleY = 1.0;
            var source = PresentationSource.FromVisual(this);
            if (source?.CompositionTarget != null)
            {
                var matrix = source.CompositionTarget.TransformToDevice;
                scaleX = matrix.M11 > 0 ? matrix.M11 : 1.0;
                scaleY = matrix.M22 > 0 ? matrix.M22 : 1.0;
            }

            // PresentationSource / DPI API 在部分高缩放环境下仍可能返回 1.0，
            // 用「物理窗口宽度 ÷ WPF 宽度」得到真实渲染倍率作为最终兜底。
            try
            {
                var handle = new System.Windows.Interop.WindowInteropHelper(this).Handle;
                if (handle != IntPtr.Zero)
                {
                    uint dpi = GetDpiForWindow(handle);
                    if (dpi > 0)
                    {
                        scaleX = dpi / 96.0;
                        scaleY = dpi / 96.0;
                    }

                    if (GetWindowRect(handle, out var currentRect) && ActualWidth > 100 && ActualHeight > 100)
                    {
                        double ratioX = (currentRect.Right - currentRect.Left) / ActualWidth;
                        double ratioY = (currentRect.Bottom - currentRect.Top) / ActualHeight;
                        if (ratioX >= 0.5 && ratioX <= 4) scaleX = ratioX;
                        if (ratioY >= 0.5 && ratioY <= 4) scaleY = ratioY;
                    }
                }
            }
            catch { }

            double workLeft = SystemParameters.WorkArea.Left;
            double workTop = SystemParameters.WorkArea.Top;
            double workWidth = SystemParameters.WorkArea.Width;
            double workHeight = SystemParameters.WorkArea.Height;

            try
            {
                var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
                if (hwnd != IntPtr.Zero)
                {
                    var info = new MONITORINFO { cbSize = System.Runtime.InteropServices.Marshal.SizeOf<MONITORINFO>() };
                    var monitor = MonitorFromWindow(hwnd, 2);
                    if (monitor != IntPtr.Zero && GetMonitorInfo(monitor, ref info))
                    {
                        workLeft = info.rcWork.Left / scaleX;
                        workTop = info.rcWork.Top / scaleY;
                        workWidth = (info.rcWork.Right - info.rcWork.Left) / scaleX;
                        workHeight = (info.rcWork.Bottom - info.rcWork.Top) / scaleY;
                    }
                }
            }
            catch { }

            double maxWidth = Math.Max(900, workWidth - 12);
            double maxHeight = Math.Max(520, workHeight - 12);
            if (MinWidth > maxWidth) MinWidth = maxWidth;
            if (MinHeight > maxHeight) MinHeight = maxHeight;

            double width = g.WinWidth >= 900 ? g.WinWidth : 1280;
            double height = g.WinHeight >= 520 ? g.WinHeight : 800;
            Width = Math.Clamp(width, MinWidth, maxWidth);
            Height = Math.Clamp(height, MinHeight, maxHeight);

            Left = workLeft + Math.Max(0, (workWidth - Width) / 2);
            Top = workTop + Math.Max(0, (workHeight - Height) / 2);
        }
        catch { }
    }

    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
    {
        try
        {
            _perfTimer.Stop();
            _achievementTimer.Stop();
            _toastTimer.Stop();
            _downloadTimer?.Stop();
            if (WindowState == WindowState.Normal)
            {
                App.Services.Settings.Config.General.WinWidth = ActualWidth;
                App.Services.Settings.Config.General.WinHeight = ActualHeight;
            }
            App.Services.Settings.Save();
        }
        catch { }
        try { LaunchService.GameCrashed -= OnGameCrashed; } catch { }
        base.OnClosing(e);
    }

    private void OnGameCrashed(object? sender, CrashAnalysis crash)
    {
        Dispatcher.Invoke(() =>
        {
            try
            {
                var dlg = new CrashDialog(crash) { Owner = this };
                dlg.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("游戏崩溃！\n原因: " + crash.Cause + "\n\n" + ex.Message, "游戏崩溃", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        });
    }

    public static MainWindow? Get() => App.MainWin;

    // ==================== 导航 ====================

    private void InitNav()
    {
        _navItems = new (string key, string nameKey, string icon, UserControl page)[]
        {
            ("home", "nav.home", "\uE80F", new PageHome()),
            ("download", "nav.download", "\uE896", new PageDownload()),
            ("instance", "nav.instance", "\uE7FC", new PageInstances()),
            ("mods", "nav.mods", "\uE8B7", new PageMods()),
            ("resource", "nav.resource", "\uE790", new PageResources()),
            ("tools", "nav.tools", "\uE90F", new PageTools()),
            ("java", "nav.java", "\uE943", new PageJava()),
            ("logs", "nav.logs", "\uE9D9", new PageLogs()),
            ("multiplayer", "nav.multiplayer", "\uE774", new PageMultiplayer()),
            ("skin", "nav.skin", "\uE77B", new PageSkin()),
            ("ai", "nav.ai", "\uE99A", new PageAI()),
            ("settings", "nav.settings", "\uE713", new PageSettings()),
            ("help", "nav.help", "\uE897", new PageHelp()),
            ("about", "nav.about", "\uE946", new PageAbout())
        };

        var hidden = (App.Services.Settings.Config.General.HiddenModules ?? "")
            .Split(',', StringSplitOptions.RemoveEmptyEntries);
        foreach (var (key, nameKey, icon, page) in _navItems)
        {
            if (hidden.Contains(key)) continue;

            var container = new Grid
            {
                Margin = new Thickness(0, 1, 0, 1),
                ColumnDefinitions =
                {
                    new ColumnDefinition { Width = new GridLength(3) },
                    new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }
                }
            };

            var indicator = new Border
            {
                Background = (Brush)FindResource("MintBrush"),
                CornerRadius = new CornerRadius(2),
                Width = 3,
                Height = 18,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center,
                Visibility = Visibility.Collapsed
            };
            Grid.SetColumn(indicator, 0);

            var iconText = new TextBlock
            {
                Text = icon,
                FontFamily = new FontFamily("Segoe MDL2 Assets"),
                FontSize = 14,
                Width = 23,
                Margin = new Thickness(0, 0, 8, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            var labelText = new TextBlock
            {
                Text = Lang.T(nameKey),
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 12.5,
                Tag = "navText"
            };
            var content = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Children = { iconText, labelText }
            };

            var btn = new Button
            {
                Tag = key,
                Content = content,
                Style = FindResource("NavItemBtn") as Style,
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                ToolTip = Lang.T(nameKey)
            };
            System.Windows.Automation.AutomationProperties.SetName(btn, Lang.T(nameKey));
            btn.Click += (_, _) => Navigate(key);
            Grid.SetColumn(btn, 1);

            container.Children.Add(indicator);
            container.Children.Add(btn);
            NavPanel.Children.Add(container);

            _pages[key] = page;
            _navButtons[key] = btn;
            _navIndicators[key] = indicator;
        }

        RefreshTopBar();
        Navigate("home");
    }

    public void Navigate(string key)
    {
        if (!_pages.TryGetValue(key, out var page)) return;

        if (_currentPage == key) return;
        _currentPage = key;

        var oldPage = PageHost.Content as UIElement;
        if (oldPage != null)
        {
            oldPage.BeginAnimation(OpacityProperty, new DoubleAnimation
            {
                From = 1.0,
                To = 0.0,
                Duration = TimeSpan.FromMilliseconds(110),
                FillBehavior = FillBehavior.HoldEnd
            });
        }

        PageHost.Content = page;
        page.Opacity = 0;
        page.BeginAnimation(OpacityProperty, new DoubleAnimation
        {
            From = 0.0,
            To = 1.0,
            Duration = TimeSpan.FromMilliseconds(210),
            FillBehavior = FillBehavior.HoldEnd
        });
        var translate = page.RenderTransform as TranslateTransform ?? new TranslateTransform();
        page.RenderTransform = translate;
        translate.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation
        {
            From = 8,
            To = 0,
            Duration = TimeSpan.FromMilliseconds(230),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut },
            FillBehavior = FillBehavior.HoldEnd
        });

        if (_navButtons.TryGetValue(key, out var activeButton))
        {
            if (activeButton.Content is StackPanel sp && sp.Children.Count > 1 && sp.Children[1] is TextBlock tb)
                PageTitle.Text = tb.Text;
        }
        else
        {
            PageTitle.Text = key;
        }

        UpdatePageKicker(key);

        foreach (var (k, b) in _navButtons)
        {
            bool isActive = k == key;
            b.Background = isActive ? (Brush)FindResource("MintSoftBrush") : Brushes.Transparent;
            b.Foreground = isActive ? (Brush)FindResource("MintDarkBrush") : (Brush)FindResource("InkSoftBrush");
            b.FontWeight = isActive ? FontWeights.SemiBold : FontWeights.Normal;
            if (_navIndicators.TryGetValue(k, out var ind))
                ind.Visibility = isActive ? Visibility.Visible : Visibility.Collapsed;
        }

        if (page is IActivatePage ap) ap.OnActivate();
        RefreshTopBar();
        UpdateNotificationDot();
    }

    private void UpdatePageKicker(string key)
    {
        PageKicker.Text = key switch
        {
            "home" => "工作台 / 概览",
            "download" => "资源 / 下载中心",
            "instance" => "游戏 / 实例",
            "mods" => "游戏 / 模组",
            "resource" => "游戏 / 资源包",
            "tools" => "实用 / 工具箱",
            "java" => "环境 / Java",
            "logs" => "诊断 / 日志",
            "multiplayer" => "联机 / 房间",
            "skin" => "账号 / 皮肤",
            "ai" => "智能 / 助手",
            "settings" => "系统 / 设置",
            "help" => "支持 / 帮助",
            "about" => "信息 / 关于与鸣谢",
            _ => "温水启动器 / 1.0 正式版"
        };
    }

    public void ApplyLanguage()
    {
        foreach (var (key, nameKey, _, _) in _navItems)
        {
            if (!_navButtons.TryGetValue(key, out var b)) continue;
            if (b.Content is StackPanel sp && sp.Children.Count > 1 && sp.Children[1] is TextBlock tb)
                tb.Text = Lang.T(nameKey);
            b.ToolTip = Lang.T(nameKey);
        }
        LaunchTopBtn.Content = Lang.T("top.launch");
        if (_navButtons.TryGetValue(_currentPage, out var cur) &&
            cur.Content is StackPanel sp2 && sp2.Children.Count > 1 && sp2.Children[1] is TextBlock tb2)
            PageTitle.Text = tb2.Text;
        RefreshTopBar();
    }

    private void CollapseNav_Click(object sender, RoutedEventArgs e)
    {
        _navCollapsed = !_navCollapsed;
        NavCol.Width = new GridLength(_navCollapsed ? 82 : 232);
        BrandBlock.Visibility = _navCollapsed ? Visibility.Collapsed : Visibility.Visible;
        PerfPanel.Visibility = _navCollapsed ? Visibility.Collapsed : Visibility.Visible;
        NavAccountName.Visibility = _navCollapsed ? Visibility.Collapsed : Visibility.Visible;
        NavAccountType.Visibility = _navCollapsed ? Visibility.Collapsed : Visibility.Visible;
        CollapseNavBtn.Content = _navCollapsed ? "\uE76C" : "\uE76B";

        foreach (var b in _navButtons.Values)
        {
            b.HorizontalContentAlignment = _navCollapsed ? HorizontalAlignment.Center : HorizontalAlignment.Stretch;
            if (b.Content is StackPanel sp && sp.Children.Count > 1 && sp.Children[1] is TextBlock tb)
                tb.Visibility = _navCollapsed ? Visibility.Collapsed : Visibility.Visible;
        }
    }

    public void SetFocusMode(bool enabled)
    {
        IsFocusMode = enabled;
        SidebarBorder.Visibility = enabled ? Visibility.Collapsed : Visibility.Visible;
        NavCol.Width = enabled ? new GridLength(0) : new GridLength(_navCollapsed ? 82 : 232);
        NavGapCol.Width = enabled ? new GridLength(0) : new GridLength(18);
        if (enabled)
            ShowToast("专注模式已开启", "按 Esc 可以随时退出专注模式");
        else
            ShowToast("已退出专注模式", "侧边栏已恢复");
    }

    // ==================== 顶部栏 / 账号 ====================

    public void RefreshTopBar()
    {
        if (_refreshingTopBar) return;
        _refreshingTopBar = true;
        try
        {
            var acct = App.Services.Accounts.Current;
            NavAccountName.Text = acct?.Name ?? "未登录";
            NavAccountType.Text = acct == null ? "点击登录" : (acct.Type == "microsoft" ? "微软正版账号" : "离线账号");
            NavAccountName.Foreground = acct == null ? (Brush)FindResource("WarnBrush") : (Brush)FindResource("InkBrush");

            var instances = App.Services.Instances.Instances.ToList();
            var current = App.Services.Instances.Current;
            InstanceCombo.ItemsSource = instances;
            InstanceCombo.DisplayMemberPath = "Name";
            InstanceCombo.SelectedItem = current != null ? instances.FirstOrDefault(i => i.Id == current.Id) : null;
            if (instances.Count == 0) InstanceCombo.SelectedIndex = -1;
        }
        catch { }
        finally { _refreshingTopBar = false; }
    }

    private void InstanceCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_refreshingTopBar) return;
        if (InstanceCombo.SelectedItem is Models.GameInstance inst)
        {
            App.Services.Settings.Config.CurrentInstanceId = inst.Id;
            App.Services.Settings.Save();
            if (_pages.TryGetValue(_currentPage, out var p) && p is IActivatePage ap)
                ap.OnActivate();
        }
    }

    private void AccountBtn_Click(object sender, RoutedEventArgs e) => Navigate("home");

    private async void QuickLaunch_Click(object sender, RoutedEventArgs e)
    {
        await LaunchCurrentAsync();
    }

    private async Task LaunchCurrentAsync()
    {
        var inst = App.Services.Instances.Current;
        if (inst == null)
        {
            Navigate("instance");
            ShowToast("还没有游戏实例", "请先创建一个实例，或从下载页安装游戏版本");
            return;
        }
        if (App.Services.Accounts.Current == null)
        {
            Navigate("home");
            ShowToast("还没有登录账号", "创建一个离线账号即可开始游戏");
            return;
        }
        Navigate("home");
        await Task.Delay(60);
        if (_pages.TryGetValue("home", out var p) && p is PageHome ph)
            await ph.LaunchAsync();
    }

    /// <summary>跳转到工具箱，可选立即执行某项工具。</summary>
    public void OpenToolbox(string? action = null)
    {
        Navigate("tools");
        if (!_pages.TryGetValue("tools", out var page) || page is not PageTools tools) return;
        if (action == "health") tools.RunHealthCheck();
        else if (action == "performance") tools.ApplyRecommendedPerformance();
    }

    public async Task NavigateToAndLaunch()
    {
        Navigate("home");
        await Task.Delay(50);
        if (_pages.TryGetValue("home", out var p) && p is PageHome ph)
            await ph.LaunchAsync();
    }

    // ==================== 外观 ====================

    public void SetBackground(string? imagePath)
    {
        try
        {
            if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
            {
                var img = new BitmapImage();
                img.BeginInit();
                img.CacheOption = BitmapCacheOption.OnLoad;
                img.UriSource = new Uri(imagePath);
                img.EndInit();
                Background = new ImageBrush(img)
                {
                    Stretch = Stretch.UniformToFill,
                    Opacity = Math.Clamp(_backgroundOpacity, 0.05, 1.0)
                };
                return;
            }
        }
        catch { }
        Background = (Brush)FindResource("CanvasBrush");
    }

    public void SetBackgroundOpacity(int opacity)
    {
        _backgroundOpacity = Math.Clamp(opacity / 100.0, 0.05, 1.0);
        if (Background is ImageBrush brush)
            brush.Opacity = _backgroundOpacity;
    }

    public void SetEyeCareMode(bool enabled)
    {
        EyeCareOverlay.Opacity = enabled ? 0.12 : 0;
    }

    private void ApplyAccentFromConfig()
    {
        try
        {
            var hex = App.Services.Settings.Config.General.AccentColor;
            var c = (Color)ColorConverter.ConvertFromString(hex ?? "#FF6BC05C");
            App.ApplyAccent(c);
        }
        catch { }
    }

    public void UpdateAvatar()
    {
        try
        {
            var acct = App.Services.Accounts.Current;
            if (acct != null && !string.IsNullOrEmpty(acct.SkinPath) && File.Exists(acct.SkinPath))
            {
                var img = new BitmapImage();
                img.BeginInit();
                img.CacheOption = BitmapCacheOption.OnLoad;
                img.UriSource = new Uri(acct.SkinPath);
                img.EndInit();
                NavAvatar.Source = img;
                NavAvatar.Visibility = Visibility.Visible;
                NavAvatarBg.Visibility = Visibility.Collapsed;
                AvatarFallback.Visibility = Visibility.Collapsed;
            }
            else
            {
                NavAvatar.Visibility = Visibility.Collapsed;
                NavAvatarBg.Visibility = Visibility.Visible;
                AvatarFallback.Visibility = Visibility.Visible;
            }
        }
        catch { }
    }

    // ==================== 任务栏 / 性能 ====================

    public void SetTaskbarProgress(double percent, string state = "Normal")
    {
        try
        {
            Dispatcher.Invoke(() =>
            {
                if (TaskbarInfo == null) return;
                TaskbarInfo.ProgressValue = Math.Clamp(percent / 100.0, 0, 1);
                TaskbarInfo.ProgressState = state switch
                {
                    "Error" => System.Windows.Shell.TaskbarItemProgressState.Error,
                    "Paused" => System.Windows.Shell.TaskbarItemProgressState.Paused,
                    "Indeterminate" => System.Windows.Shell.TaskbarItemProgressState.Indeterminate,
                    "None" => System.Windows.Shell.TaskbarItemProgressState.None,
                    _ => System.Windows.Shell.TaskbarItemProgressState.Normal,
                };
            });
        }
        catch { }
    }

    public void ClearTaskbarProgress() => SetTaskbarProgress(0, "None");

    private void StartPerformanceMonitor()
    {
        _perfTimer.Interval = TimeSpan.FromSeconds(2);
        _perfTimer.Tick += (_, _) =>
        {
            try
            {
                var (cpu, mem, _) = App.Services.Performance.GetStats();
                PerfCpu.Text = cpu.ToString("0.0") + "%";
                PerfMem.Text = mem >= 1024 ? (mem / 1024.0).ToString("0.0") + "G" : mem + "M";
                PerfCpu.Foreground = cpu > 80 ? (Brush)FindResource("WarnBrush") : (Brush)FindResource("InkBrush");
                PerfStatus.Text = cpu > 80 ? "偏高" : "顺畅";
                PerfStatus.Foreground = cpu > 80 ? (Brush)FindResource("WarnBrush") : (Brush)FindResource("MintDarkBrush");
            }
            catch { }
        };
        _perfTimer.Start();
    }

    // ==================== 下载状态 ====================

    private DispatcherTimer? _downloadTimer;

    private void StartDownloadMonitor()
    {
        _downloadTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(800) };
        _downloadTimer.Tick += (_, _) => UpdateDownloadButton();
        _downloadTimer.Start();
        UpdateDownloadButton();
    }

    private void UpdateDownloadButton()
    {
        try
        {
            var dm = App.Services.DownloadManager;
            int active = dm.ActiveCount;

            if (active > 0)
            {
                DownloadBadge.Visibility = Visibility.Visible;
                DownloadBadgeText.Text = active > 9 ? "9+" : active.ToString();
                DownloadProgressRing.Visibility = Visibility.Visible;
                if (DownloadProgressRing.RenderTransform is not RotateTransform || !_downloadRingAnimating)
                {
                    DownloadProgressRing.RenderTransform = new RotateTransform(0);
                    DownloadProgressRing.RenderTransformOrigin = new Point(0.5, 0.5);
                    var rotateAnim = new DoubleAnimation
                    {
                        From = 0,
                        To = 360,
                        Duration = TimeSpan.FromSeconds(2.4),
                        RepeatBehavior = RepeatBehavior.Forever
                    };
                    DownloadProgressRing.RenderTransform.BeginAnimation(RotateTransform.AngleProperty, rotateAnim);
                    _downloadRingAnimating = true;
                }
            }
            else
            {
                DownloadBadge.Visibility = Visibility.Collapsed;
                DownloadProgressRing.Visibility = Visibility.Collapsed;
                if (_downloadRingAnimating && DownloadProgressRing.RenderTransform is RotateTransform rt)
                {
                    rt.BeginAnimation(RotateTransform.AngleProperty, null);
                    _downloadRingAnimating = false;
                }
            }

            if (dm.DownloadingCount > 0 && DownloadPanelContainer.Visibility != Visibility.Visible)
            {
                DownloadBubble.Visibility = Visibility.Visible;
                DownloadBubbleText.Text = $"{dm.DownloadingCount} 个任务下载中 · {dm.OverallProgress:F0}%";
            }
            else
            {
                DownloadBubble.Visibility = Visibility.Collapsed;
            }
        }
        catch { }
        UpdateNotificationDot();
    }

    private void DownloadBtn_Click(object sender, MouseButtonEventArgs e)
    {
        if (DownloadPanelContainer.Visibility == Visibility.Visible)
        {
            DownloadPanelContainer.Visibility = Visibility.Collapsed;
        }
        else
        {
            DownloadPanelContainer.Visibility = Visibility.Visible;
            DownloadBubble.Visibility = Visibility.Collapsed;
        }
    }

    private void CloseDownloadPanel_Click(object sender, RoutedEventArgs e)
    {
        DownloadPanelContainer.Visibility = Visibility.Collapsed;
    }

    // ==================== 通知中心 ====================

    private void UpdateNotificationDot()
    {
        try
        {
            bool hasNotice =
                App.Services.Accounts.Current == null ||
                App.Services.Instances.Current == null ||
                App.Services.DownloadManager.ActiveCount > 0;
            if (NotifyDot != null)
                NotifyDot.Visibility = hasNotice ? Visibility.Visible : Visibility.Collapsed;
        }
        catch { }
    }

    private void NotifyBtn_Click(object sender, RoutedEventArgs e) => ShowNotificationCenter();

    public void ShowNotificationCenter()
    {
        if (NotificationPanel.Visibility == Visibility.Visible)
        {
            NotificationPanel.Visibility = Visibility.Collapsed;
            return;
        }

        CommandOverlay.Visibility = Visibility.Collapsed;
        BuildNotifications();
        NotificationPanel.Visibility = Visibility.Visible;
    }

    private void CloseNotifications_Click(object sender, RoutedEventArgs e)
    {
        NotificationPanel.Visibility = Visibility.Collapsed;
    }

    private void BuildNotifications()
    {
        NotificationList.Children.Clear();
        int count = 0;

        void Add(string glyph, string title, string detail, Color tint, Action? action)
        {
            count++;
            var row = new Button
            {
                Style = FindResource("NavItemBtn") as Style,
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                Padding = new Thickness(8, 10, 6, 10),
                Margin = new Thickness(0, 0, 0, 3),
                Background = Brushes.Transparent
            };
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var icon = new Border
            {
                Width = 32,
                Height = 32,
                CornerRadius = new CornerRadius(9),
                Background = new SolidColorBrush(Color.FromArgb(30, tint.R, tint.G, tint.B)),
                Child = new TextBlock
                {
                    Text = glyph,
                    FontFamily = new FontFamily("Segoe MDL2 Assets"),
                    FontSize = 13,
                    Foreground = new SolidColorBrush(tint),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                }
            };
            Grid.SetColumn(icon, 0);

            var texts = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 8, 0) };
            texts.Children.Add(new TextBlock
            {
                Text = title,
                FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)FindResource("InkBrush")
            });
            texts.Children.Add(new TextBlock
            {
                Text = detail,
                FontSize = 10,
                Foreground = (Brush)FindResource("MutedBrush"),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 3, 0, 0)
            });
            Grid.SetColumn(texts, 1);

            var chevron = new TextBlock
            {
                Text = "\uE76C",
                FontFamily = new FontFamily("Segoe MDL2 Assets"),
                FontSize = 9,
                Foreground = (Brush)FindResource("MutedBrush"),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(chevron, 2);

            grid.Children.Add(icon);
            grid.Children.Add(texts);
            grid.Children.Add(chevron);
            row.Content = grid;

            if (action != null)
            {
                row.Click += (_, _) =>
                {
                    NotificationPanel.Visibility = Visibility.Collapsed;
                    action();
                };
            }
            else
            {
                row.IsEnabled = false;
            }

            NotificationList.Children.Add(row);
        }

        var acct = App.Services.Accounts.Current;
        var inst = App.Services.Instances.Current;

        if (acct == null)
            Add("\uE77B", "尚未登录账号", "创建离线账号或登录微软账号后即可启动游戏。", Color.FromRgb(0xD9, 0x8A, 0x2B), () => Navigate("home"));

        if (inst == null)
            Add("\uE7FC", "还没有游戏实例", "前往实例页创建一个实例，或从下载页安装游戏版本。", Color.FromRgb(0xD9, 0x8A, 0x2B), () => Navigate("instance"));

        try
        {
            if (App.Services.Java.DetectAll().Count == 0)
                Add("\uE943", "未检测到 Java", "启动游戏前需要安装 Java，可在 Java 页一键下载。", Color.FromRgb(0xD1, 0x43, 0x43), () => Navigate("java"));
        }
        catch { }

        try
        {
            int active = App.Services.DownloadManager.ActiveCount;
            if (active > 0)
                Add("\uE896", $"{active} 个下载任务进行中", $"总进度 {App.Services.DownloadManager.OverallProgress:F0}%，点击查看任务。", Color.FromRgb(0x2E, 0x9E, 0x78),
                    () => DownloadPanelContainer.Visibility = Visibility.Visible);
        }
        catch { }

        Add("\uE73E", "下载功能可用", "下载与安装功能已开放。", Color.FromRgb(0x2E, 0x9E, 0x78), () => Navigate("download"));

        if (count == 0)
            Add("\uE73E", "一切正常", "账号、实例与运行环境均已就绪，祝游戏愉快。", Color.FromRgb(0x2E, 0x9E, 0x78), null);

        NotificationSummary.Text = count == 1 ? "1 条状态提醒" : $"{count} 条状态提醒";
    }

    // ==================== 全局命令面板 ====================

    private sealed class CommandEntry
    {
        public string Title { get; init; } = "";
        public string Hint { get; init; } = "";
        public string Glyph { get; init; } = "\uE8A5";
        public Action Invoke { get; init; } = () => { };
    }

    private void OpenCommandPalette_Click(object sender, RoutedEventArgs e) => OpenCommandPalette();

    public void OpenCommandPalette()
    {
        NotificationPanel.Visibility = Visibility.Collapsed;
        EnsureCommands();
        CommandSearch.Text = "";
        CommandPlaceholder.Visibility = Visibility.Visible;
        RebuildCommandResults();
        CommandOverlay.Visibility = Visibility.Visible;
        Dispatcher.BeginInvoke(() =>
        {
            CommandSearch.Focus();
            CommandPlaceholder.Visibility = string.IsNullOrEmpty(CommandSearch.Text) ? Visibility.Visible : Visibility.Collapsed;
        }, DispatcherPriority.Input);
    }

    private void EnsureCommands()
    {
        if (_commands.Count > 0) return;

        foreach (var (key, _, glyph, _) in _navItems.Where(i => _pages.ContainsKey(i.key)))
        {
            var pageKey = key;
            var name = _navItems.First(i => i.key == key).nameKey;
            _commands.Add(new CommandEntry
            {
                Title = Lang.T(name),
                Hint = key == "download" ? "页面 · 下载中心" : "页面",
                Glyph = glyph,
                Invoke = () => Navigate(pageKey)
            });
        }

        _commands.Add(new CommandEntry
        {
            Title = "启动当前游戏",
            Hint = "操作 · 使用当前实例快速启动",
            Glyph = "\uE768",
            Invoke = () => _ = LaunchCurrentAsync()
        });
        _commands.Add(new CommandEntry
        {
            Title = "一键性能调优",
            Hint = "工具 · 自动分配内存并优化 JVM",
            Glyph = "\uE9D2",
            Invoke = () => Navigate("tools")
        });
        _commands.Add(new CommandEntry
        {
            Title = "通知中心",
            Hint = "操作 · 查看账号、实例与运行状态",
            Glyph = "\uEA8F",
            Invoke = ShowNotificationCenter
        });
        _commands.Add(new CommandEntry
        {
            Title = IsFocusMode ? "退出专注模式" : "进入专注模式",
            Hint = "外观 · 隐藏侧边栏，专注当前页面",
            Glyph = "\uE7B3",
            Invoke = () => SetFocusMode(!IsFocusMode)
        });
        _commands.Add(new CommandEntry
        {
            Title = "打开工具箱",
            Hint = "工具 · 体检、测速、备份、清理",
            Glyph = "\uE90F",
            Invoke = () => Navigate("tools")
        });
    }

    private void RebuildCommandResults()
    {
        CommandResults.Children.Clear();
        _commandButtons.Clear();
        _commandIndex = 0;

        var keyword = CommandSearch.Text.Trim();
        var results = string.IsNullOrEmpty(keyword)
            ? _commands.ToList()
            : _commands.Where(c =>
                    c.Title.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
                    c.Hint.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                .ToList();

        // 附加当前实例的快速切换项
        var instances = App.Services.Instances.Instances;
        if (instances.Count > 0 && !string.IsNullOrEmpty(keyword))
        {
            foreach (var inst in instances.Where(i => i.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase)))
            {
                var local = inst;
                results.Add(new CommandEntry
                {
                    Title = "切换实例：" + local.Name,
                    Hint = $"实例 · {local.VersionId}",
                    Glyph = "\uE7FC",
                    Invoke = () =>
                    {
                        App.Services.Settings.Config.CurrentInstanceId = local.Id;
                        App.Services.Settings.Save();
                        Navigate("home");
                    }
                });
            }
        }

        if (results.Count == 0)
        {
            var empty = new TextBlock
            {
                Text = "没有找到匹配的内容，试试「下载」「Java」「设置」等关键词。",
                FontSize = 12,
                Foreground = (Brush)FindResource("MutedBrush"),
                Margin = new Thickness(12, 18, 12, 18)
            };
            CommandResults.Children.Add(empty);
            return;
        }

        for (int i = 0; i < Math.Min(results.Count, 30); i++)
        {
            var entry = results[i];
            var row = new Button
            {
                Style = FindResource("NavItemBtn") as Style,
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                Padding = new Thickness(8, 9, 8, 9),
                Margin = new Thickness(0, 1, 0, 1),
                Background = i == 0 ? (Brush)FindResource("MintSoftBrush") : Brushes.Transparent
            };

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var icon = new Border
            {
                Width = 30,
                Height = 30,
                CornerRadius = new CornerRadius(8),
                Background = (Brush)FindResource("SurfaceSoftBrush"),
                Child = new TextBlock
                {
                    Text = entry.Glyph,
                    FontFamily = new FontFamily("Segoe MDL2 Assets"),
                    FontSize = 12,
                    Foreground = (Brush)FindResource("MintDarkBrush"),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                }
            };
            Grid.SetColumn(icon, 0);

            var texts = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 8, 0) };
            texts.Children.Add(new TextBlock { Text = entry.Title, FontSize = 12.5, Foreground = (Brush)FindResource("InkBrush") });
            texts.Children.Add(new TextBlock { Text = entry.Hint, FontSize = 9.5, Foreground = (Brush)FindResource("MutedBrush"), Margin = new Thickness(0, 2, 0, 0) });
            Grid.SetColumn(texts, 1);

            var flag = new TextBlock
            {
                Text = "Enter",
                FontFamily = new FontFamily("Consolas"),
                FontSize = 9,
                Foreground = (Brush)FindResource("MutedBrush"),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(flag, 2);

            grid.Children.Add(icon);
            grid.Children.Add(texts);
            grid.Children.Add(flag);
            row.Content = grid;
            row.Tag = entry;
            row.Click += (_, _) => ExecuteCommand(entry);

            _commandButtons.Add(row);
            CommandResults.Children.Add(row);
        }
    }

    private void ExecuteCommand(CommandEntry entry)
    {
        CloseCommandPalette();
        try { entry.Invoke(); } catch { }
    }

    private void MoveCommandSelection(int delta)
    {
        if (_commandButtons.Count == 0) return;
        _commandIndex = (_commandIndex + delta + _commandButtons.Count) % _commandButtons.Count;
        for (int i = 0; i < _commandButtons.Count; i++)
        {
            _commandButtons[i].Background = i == _commandIndex
                ? (Brush)FindResource("MintSoftBrush")
                : Brushes.Transparent;
        }
        _commandButtons[_commandIndex].BringIntoView();
    }

    private void CloseCommandPalette()
    {
        CommandOverlay.Visibility = Visibility.Collapsed;
    }

    private void CommandSearch_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (CommandPlaceholder != null)
            CommandPlaceholder.Visibility = string.IsNullOrEmpty(CommandSearch.Text) ? Visibility.Visible : Visibility.Collapsed;
        RebuildCommandResults();
    }

    private void CommandSearch_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && _commandButtons.Count > 0)
        {
            var buttons = _commandButtons;
            var index = Math.Clamp(_commandIndex, 0, buttons.Count - 1);
            // 直接触发当前选中项
            if (buttons[index].Tag is CommandEntry entry) ExecuteCommand(entry);
            e.Handled = true;
        }
    }

    private void CommandOverlay_MouseDown(object sender, MouseButtonEventArgs e)
    {
        if (ReferenceEquals(e.OriginalSource, CommandOverlay))
            CloseCommandPalette();
    }

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.K && Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
        {
            OpenCommandPalette();
            e.Handled = true;
            return;
        }

        if (CommandOverlay.Visibility == Visibility.Visible)
        {
            if (e.Key == Key.Escape) { CloseCommandPalette(); e.Handled = true; }
            else if (e.Key == Key.Down) { MoveCommandSelection(1); e.Handled = true; }
            else if (e.Key == Key.Up) { MoveCommandSelection(-1); e.Handled = true; }
            else if (e.Key == Key.Enter)
            {
                if (_commandIndex >= 0 && _commandIndex < _commandButtons.Count && _commandButtons[_commandIndex].Tag is CommandEntry entry)
                    ExecuteCommand(entry);
                e.Handled = true;
            }
            return;
        }

        if (e.Key == Key.Escape)
        {
            if (NotificationPanel.Visibility == Visibility.Visible)
            {
                NotificationPanel.Visibility = Visibility.Collapsed;
                e.Handled = true;
            }
            else if (IsFocusMode)
            {
                SetFocusMode(false);
                e.Handled = true;
            }
        }
    }

    // ==================== 成就 / 轻提示 ====================

    private void StartAchievementNotifier()
    {
        App.Services.Achievements.AchievementUnlocked += (_, ach) => _achievementQueue.Enqueue(ach);
        _achievementTimer.Interval = TimeSpan.FromSeconds(1);
        _achievementTimer.Tick += (_, _) =>
        {
            if (_achievementQueue.Count > 0)
                ShowAchievementNotification(_achievementQueue.Dequeue());
        };
        _achievementTimer.Start();
    }

    private void ShowAchievementNotification(Achievement ach)
    {
        ShowToast($"{ach.Icon} 成就解锁 · {ach.Name}", ach.Description, "\uE73E");
    }

    /// <summary>显示全局加载指示，支持多个调用方嵌套使用。</summary>
    public void ShowBusy(string message)
    {
        _busyRefs++;
        Dispatcher.Invoke(() =>
        {
            try
            {
                BusyText.Text = message;
                BusyPill.Visibility = Visibility.Visible;
                if (!_busyAnimating)
                {
                    BusySpinnerRotate.BeginAnimation(RotateTransform.AngleProperty, new DoubleAnimation
                    {
                        From = 0,
                        To = 360,
                        Duration = TimeSpan.FromMilliseconds(850),
                        RepeatBehavior = RepeatBehavior.Forever
                    });
                    _busyAnimating = true;
                }
            }
            catch { }
        });
    }

    /// <summary>结束一次全局加载指示。</summary>
    public void HideBusy()
    {
        _busyRefs = Math.Max(0, _busyRefs - 1);
        if (_busyRefs > 0) return;
        Dispatcher.Invoke(() =>
        {
            try
            {
                BusyPill.Visibility = Visibility.Collapsed;
                if (_busyAnimating)
                {
                    BusySpinnerRotate.BeginAnimation(RotateTransform.AngleProperty, null);
                    _busyAnimating = false;
                }
            }
            catch { }
        });
    }

    public void ShowToast(string title, string message, string glyph = "\uE73E")
    {
        Dispatcher.Invoke(() =>
        {
            try
            {
                ToastTitle.Text = title;
                ToastMessage.Text = message;
                ToastGlyph.Text = glyph;
                ToastCard.Visibility = Visibility.Visible;
                ToastCard.BeginAnimation(OpacityProperty, new DoubleAnimation
                {
                    From = 0,
                    To = 1,
                    Duration = TimeSpan.FromMilliseconds(160)
                });
                _toastTimer.Stop();
                _toastTimer.Interval = TimeSpan.FromSeconds(3.2);
                _toastTimer.Tick -= HideToastTimer;
                _toastTimer.Tick += HideToastTimer;
                _toastTimer.Start();
            }
            catch { }
        });
    }

    private void HideToastTimer(object? sender, EventArgs e)
    {
        _toastTimer.Stop();
        var fade = new DoubleAnimation
        {
            From = 1,
            To = 0,
            Duration = TimeSpan.FromMilliseconds(180)
        };
        fade.Completed += (_, _) => ToastCard.Visibility = Visibility.Collapsed;
        ToastCard.BeginAnimation(OpacityProperty, fade);
    }

    // ==================== 自定义标题栏 ====================

    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

    private void Maximize_Click(object sender, RoutedEventArgs e)
    {
        if (WindowState == WindowState.Maximized)
        {
            WindowState = WindowState.Normal;
            MaxRestoreBtn.Content = "□";
        }
        else
        {
            WindowState = WindowState.Maximized;
            MaxRestoreBtn.Content = "❐";
        }
    }

    private void Close_Click(object sender, RoutedEventArgs e) => Close();
}

public interface IActivatePage
{
    void OnActivate();
}
