namespace WarmWaterLauncher.Services;

/// <summary>
/// Modrinth 模组/分类/排序的中文本地化映射。
/// 常见模组按 slug/标题匹配显示中文别名，分类与排序选项统一翻译。
/// </summary>
public static class ModrinthLocalization
{
    /// <summary>常见模组中文别名（key 为小写 slug 或标题关键词）</summary>
    private static readonly Dictionary<string, string> ModAliases = new()
    {
        ["sodium"] = "钠（Sodium）",
        ["lithium"] = "锂（Lithium）",
        ["phosphor"] = "磷（Phosphor）",
        ["iris"] = "虹膜（Iris Shaders）",
        ["lambdynamiclights"] = "动态光源（LambDynamicLights）",
        ["sodium-extra"] = "钠扩展（Sodium Extra）",
        ["reeses-sodium-options"] = "Reese 钠选项",
        ["indium"] = "铟（Indium）",
        ["entityculling"] = "实体剔除（EntityCulling）",
        ["moreculling"] = "更多剔除（MoreCulling）",
        ["immediatelyfast"] = "立即加速（ImmediatelyFast）",
        ["krypton"] = "氪（Krypton）",
        ["lazydfu"] = "懒加载DFU（LazyDFU）",
        ["ferritecore"] = "铁氧体磁芯（FerriteCore）",
        ["cloth-config"] = "布料配置（Cloth Config）",
        ["modmenu"] = "模组菜单（Mod Menu）",
        ["fabric-api"] = "Fabric API",
        ["architectury-api"] = "Architectury API",
        ["jade"] = "玉（Jade 信息显示）",
        ["appleskin"] = "苹果皮（AppleSkin）",
        ["inventoryprofilesnext"] = "背包整理（Inventory Profiles Next）",
        ["mousewheelie"] = "鼠标滚轮（Mouse Wheelie）",
        ["xaeros-minimap"] = "Xaero 小地图",
        ["xaeros-world-map"] = "Xaero 世界地图",
        ["journeymap"] = "旅行地图（JourneyMap）",
        ["jei"] = "物品管理器（JEI）",
        ["roughly-enough-items"] = "近似物品（REI）",
        ["emi"] = "EMI 物品管理器",
        ["wthit"] = "WTHIT 高亮提示",
        ["badpackets"] = "坏包（Bad Packets）",
        ["falling-leaves"] = "落叶（Falling Leaves）",
        ["presence-footsteps"] = "脚步声（Presence Footsteps）",
        ["sound-physics-remastered"] = "声音物理重制版",
        ["no-chat-reports"] = "无聊天报告",
        ["chatpatches"] = "聊天修复",
        ["yet-another-config-lib"] = "YACL 配置库",
        ["completeconfig"] = "完整配置库",
        ["owo-lib"] = "OwO 库",
        ["patchouli"] = "帕秋莉手册（Patchouli）",
        ["botania"] = "植物魔法（Botania）",
        ["create"] = "机械动力（Create）",
        ["applied-energistics-2"] = "应用能源2（AE2）",
        ["thermal-series"] = "热力系列",
        ["tinkers-construct"] = "匠魂（Tinkers Construct）",
        ["curios-api"] = "Curios API",
        ["trinkets"] = "饰品（Trinkets）",
        ["origins"] = "起源（Origins）",
        ["pehkui"] = "缩放（Pehkui）",
        ["geckolib"] = "GeckoLib 动画库",
        ["playeranimator"] = "玩家动画器",
        ["kotlin-for-forge"] = "Kotlin for Forge",
        ["fabric-language-kotlin"] = "Fabric Kotlin 语言支持",
        ["mixinextras"] = "MixinExtras",
        ["cardinal-components"] = "Cardinal Components",
        ["antighost"] = "反幽灵方块",
        ["debugify"] = "Debugify 修复Bug",
        ["cullleaves"] = "树叶剔除",
        ["smoothboot"] = "平滑启动",
        ["fastload"] = "快速加载",
        ["dynamic-fps"] = "动态帧率",
        ["no-fade"] = "无渐隐",
        ["zoomify"] = "缩放（Zoomify）",
        ["logical-zoom"] = "逻辑缩放",
        ["camera-utils"] = "相机工具",
        ["freecam"] = "自由视角",
        ["tweakeroo"] = "Tweakeroo",
        ["minihud"] = "MiniHUD",
        ["itemscroller"] = "物品滚动",
        ["litematica"] = "投影（Litematica）",
        ["malilib"] = "MaLiLib",
        ["optifine"] = "高清修复（OptiFine）",
        ["shulkerboxtooltip"] = "潜影盒提示",
        ["advanced-tooltips"] = "高级提示",
        ["tooltipfix"] = "提示修复",
        ["raised"] = "Raised 提升HUD",
        ["not-enough-animations"] = "动画修复",
        ["better-ping-display"] = "更好的延迟显示",
        ["betterf3"] = "更好的F3",
        ["better-mount-hud"] = "更好的坐骑HUD",
        ["better-third-person"] = "更好的第三人称",
        ["controlling"] = "控制（Controlling）",
        ["amecs"] = "Amecs 按键映射",
        ["gamma-utils"] = "伽马工具",
        ["fullbright"] = "全屏亮度",
        ["light-overlay"] = "光照覆盖",
        ["craftpresence"] = "CraftPresence 状态",
        ["simple-voice-chat"] = "简单语音聊天",
        ["plasmo-voice"] = "Plasmo 语音",
        ["distant-horizons"] = "远方地平线",
        ["bobby"] = "Bobby 区块缓存",
        ["nvidium"] = "Nvidium",
        ["vulkanmod"] = "Vulkan 渲染",
        ["canvas-renderer"] = "Canvas 渲染器",
        ["embeddium"] = "Embeddium（Forge 钠移植）",
        ["rubidium"] = "Rubidium（Forge 钠移植）",
        ["oculus"] = "Oculus（Forge 光影）",
        ["magnesium"] = "Magnesium",
        ["radium"] = "Radium",
        ["canary"] = "金丝雀（Canary）",
        ["modernfix"] = "现代修复（ModernFix）",
        ["saturn"] = "土星（Saturn）",
        ["ai-improvements"] = "AI 改进",
        ["performant"] = "Performant",
        ["spark"] = "Spark 性能分析",
        ["luckperms"] = "LuckPerms 权限",
        ["worldedit"] = "WorldEdit 创世神",
        ["chunky"] = "Chunky 区块预生成",
        ["dynview"] = "DynView 动态视距",
        ["servercore"] = "ServerCore",
        ["leaves-us-in-peace"] = "树叶优化",
        ["c2me"] = "C2ME 区块优化",
        ["vmp"] = "VMP 视距优化",
        ["very-many-players"] = "VMP 多玩家优化",
        ["memoryleakfix"] = "内存泄漏修复",
        ["system-clipboard"] = "系统剪贴板",
        ["no-resource-pack-warnings"] = "无资源包警告",
        ["no-pumpkin-blur"] = "无南瓜模糊",
        ["no-portal-gui"] = "无传送门GUI",
        ["clear-skies"] = "晴朗天空",
        ["enhanced-block-entities"] = "增强方块实体",
        ["terralith"] = "Terralith 地形",
        ["incendium"] = "Incendium 下界",
        ["nullscape"] = "Nullscape 末地",
        ["continents"] = "Continents 大陆",
        ["tectonic"] = "Tectonic 构造",
        ["regions-unexplored"] = "未探索区域",
        ["repurposed-structures"] = "改造结构",
        ["yungs-api"] = "YUNG API",
        ["resourceful-lib"] = "Resourceful Lib",
        ["resourceful-config"] = "Resourceful Config",
        ["bookshelf"] = "书架（Bookshelf）",
        ["konkrete"] = "Konkrete",
        ["auto-third-person"] = "自动第三人称",
        ["eat-the-drop"] = "吃掉掉落物",
        ["auto-harvest"] = "自动收获",
        ["treeharvester"] = "树木收割机",
        ["mowing-machine"] = "割草机",
        ["scythe"] = "镰刀",
        ["sickle"] = "镰刀",
        ["hoe-of-harvesting"] = "收获锄",
        ["xaero-minimap-fair-play-edition"] = "Xaero 小地图公平版",
        ["voxelmap"] = "体素地图",
        ["mapwriter"] = "地图书写者",
        ["atlas"] = "Atlas 地图",
        ["ant-atlases"] = "蚂蚁地图集",
        ["just-enough-resources"] = "JER 资源",
        ["just-enough-professions"] = "JEP 职业",
        ["just-enough-effect-descriptions"] = "JEED 效果描述",
        ["just-enough-advancements"] = "JEA 进度",
        ["view-distance-fix"] = "视距修复",
        ["yungs-better-desert-temples"] = "YUNG 更好的沙漠神殿",
        ["yungs-better-dungeons"] = "YUNG 更好的地牢",
        ["yungs-better-mineshafts"] = "YUNG 更好的废弃矿井",
        ["yungs-better-strongholds"] = "YUNG 更好的要塞",
        ["better-mobs"] = "更好的生物",
        ["better-animals"] = "更好的动物",
        ["better-end"] = "更好的末地",
        ["better-nether"] = "更好的下界",
        ["better-caves"] = "更好的洞穴",
        ["terralith-overworld-evolved"] = "Terralith 主世界进化",
    };

    /// <summary>分类英文 → 中文</summary>
    public static readonly Dictionary<string, string> Categories = new()
    {
        ["technology"] = "科技",
        ["adventure"] = "冒险",
        ["decoration"] = "装饰",
        ["utility"] = "实用工具",
        ["performance"] = "性能优化",
        ["optimization"] = "性能优化",
        ["worldgen"] = "世界生成",
        ["biomes"] = "生物群系",
        ["structures"] = "结构",
        ["mobs"] = "生物",
        ["creatures"] = "生物",
        ["food"] = "食物",
        ["farming"] = "农业",
        ["magic"] = "魔法",
        ["combat"] = "战斗",
        ["weapons"] = "武器",
        ["armor"] = "护甲",
        ["tools"] = "工具",
        ["storage"] = "存储",
        ["transport"] = "运输",
        ["energy"] = "能源",
        ["redstone"] = "红石",
        ["information"] = "信息显示",
        ["misc"] = "杂项",
        ["library"] = "前置库",
        ["api"] = "API",
        ["fabric"] = "Fabric",
        ["forge"] = "Forge",
        ["quilt"] = "Quilt",
        ["neoforge"] = "NeoForge",
        ["client"] = "客户端",
        ["server"] = "服务端",
    };

    /// <summary>排序英文 → 中文</summary>
    public static readonly Dictionary<string, string> Sorts = new()
    {
        ["relevance"] = "相关度",
        ["downloads"] = "下载量",
        ["follows"] = "关注量",
        ["newest"] = "最新发布",
        ["updated"] = "最近更新",
    };

    /// <summary>获取模组显示名（中文别名 + 英文原名）</summary>
    public static string GetDisplayName(ModrinthMod mod)
    {
        string key = (mod.Slug ?? mod.Title ?? "").ToLowerInvariant().Trim();
        if (ModAliases.TryGetValue(key, out var alias)) return alias;
        // 模糊匹配标题关键词
        string title = (mod.Title ?? "").ToLowerInvariant();
        foreach (var kv in ModAliases)
            if (title.Contains(kv.Key) || key.Contains(kv.Key))
                return kv.Value;
        return mod.Title ?? mod.Slug ?? "未知模组";
    }

    /// <summary>分类显示名</summary>
    public static string GetCategoryName(string en)
    {
        if (string.IsNullOrEmpty(en)) return en;
        return Categories.TryGetValue(en.ToLowerInvariant(), out var zh) ? zh : en;
    }

    /// <summary>排序显示名</summary>
    public static string GetSortName(string en)
    {
        if (string.IsNullOrEmpty(en)) return en;
        return Sorts.TryGetValue(en.ToLowerInvariant(), out var zh) ? zh : en;
    }
}
