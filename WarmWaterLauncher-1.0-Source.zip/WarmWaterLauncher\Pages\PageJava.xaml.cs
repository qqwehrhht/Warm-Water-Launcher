using System.Windows;
using System.Windows.Controls;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageJava : UserControl, IActivatePage
{
    public PageJava()
    {
        InitializeComponent();
    }

    public void OnActivate()
    {
        RefreshList();
    }

    private void RefreshList()
    {
        var javas = App.Services.Java.DetectAll();
        JavaList.ItemsSource = javas;
        var configured = App.Services.Settings.Config.Launch.JavaPath;
        JavaUseStatus.Text = javas.Count == 0
            ? "未检测到 Java。请使用上方按钮下载，或安装任意 Java 后点击「重新检测」。"
            : $"检测到 {javas.Count} 个 Java。当前默认：" + (string.IsNullOrEmpty(configured) ? "自动选择（按版本需求）" : configured);
    }

    private async void DownloadJava_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not string majorStr || !int.TryParse(majorStr, out int major)) return;
        var btn = sender as Button;
        if (btn != null) btn.IsEnabled = false;
        JavaProgress.Visibility = Visibility.Visible;
        string lastStatus = "";
        var progress = new Progress<(string status, double pct)>(p =>
        {
            lastStatus = p.status;
            JavaStatus.Text = p.status;
            JavaProgress.Value = Math.Max(0, Math.Min(100, p.pct * 100));
        });
        JavaStatus.Text = $"正在下载 Java {major}（约 50MB），请稍候...";
        var path = await App.Services.Java.DownloadJavaAsync(major, progress);
        if (btn != null) btn.IsEnabled = true;
        if (path != null)
        {
            JavaStatus.Text = $"Java {major} 已安装到：{path}，已设为默认。";
            App.Services.Settings.Config.Launch.JavaPath = path;
            App.Services.Settings.Save();
            RefreshList();
        }
        else
        {
            JavaStatus.Text = (lastStatus.Contains("失败") || lastStatus.Contains("不可用"))
                ? lastStatus
                : $"Java {major} 下载失败，请检查网络后重试。";
        }
    }

    private void Rescan_Click(object sender, RoutedEventArgs e) => RefreshList();

    private void UseJava_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is JavaInfo ji)
        {
            App.Services.Settings.Config.Launch.JavaPath = ji.Path;
            App.Services.Settings.Save();
            RefreshList();
        }
    }
}
