using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageAI : UserControl, IActivatePage
{
    private bool _configLoaded;
    private bool _frpLogAttached;
    private bool _srvLogAttached;
    private DispatcherTimer? _srvStatusTimer;

    public PageAI()
    {
        InitializeComponent();
        LoadPresetQuestions();
        LoadFrpProviders();
        LoadServerFrpProviders();
        // 订阅服务器状态变化事件（即时更新）
        App.Services.Server.OnStatusChanged += running => Dispatcher.Invoke(UpdateServerStatus);
        // 定时刷新服务器状态（每2秒，兜底）
        _srvStatusTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        _srvStatusTimer.Tick += (_, _) => UpdateServerStatus();
        _srvStatusTimer.Start();
    }

    /// <summary>加载开服页面的穿透服务商列表</summary>
    private void LoadServerFrpProviders()
    {
        SrvFrpProvider.Items.Clear();
        foreach (var (prov, name, _, _, _) in FrpService.Providers)
        {
            SrvFrpProvider.Items.Add(new ComboBoxItem { Content = name, Tag = prov });
        }
        if (SrvFrpProvider.Items.Count > 0) SrvFrpProvider.SelectedIndex = 0;
    }

    private void SrvFrpEnable_Checked(object sender, RoutedEventArgs e)
    {
        SrvFrpPanel.Visibility = SrvFrpEnable.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
    }

    private void SrvFrpProvider_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SrvFrpProvider.SelectedItem is ComboBoxItem item && item.Tag is FrpService.FrpProvider prov)
        {
            var info = FrpService.Providers.FirstOrDefault(p => p.Provider == prov);
            if (!string.IsNullOrEmpty(info.Website))
                SrvFrpHint.Text = $"提示：去 {info.Website} 注册获取 Token，启动服务器时会自动启动穿透";
        }
    }

    private FrpService.FrpConfig? _currentFrpCfg;

    /// <summary>读取开服穿透配置</summary>
    private FrpService.FrpConfig? ReadFrpConfig(int localPort)
    {
        if (SrvFrpEnable.IsChecked != true) return null;
        if (SrvFrpProvider.SelectedItem is not ComboBoxItem item || item.Tag is not FrpService.FrpProvider prov) return null;
        string token = SrvFrpToken.Text.Trim();
        if (string.IsNullOrEmpty(token)) return null;
        int.TryParse(SrvFrpLocalPort.Text, out int lp);
        int.TryParse(SrvFrpRemotePort.Text, out int rp);
        return new FrpService.FrpConfig
        {
            Provider = prov,
            Token = token,
            LocalPort = lp > 0 ? lp : localPort,
            RemotePort = rp > 0 ? rp : localPort + 1,
            TunnelName = "minecraft_server",
            LocalIp = "127.0.0.1"
        };
    }

    public void OnActivate()
    {
        if (!_configLoaded)
        {
            LoadConfig();
            _configLoaded = true;
        }
        UpdateStatus();
        UpdateFrpcStatus();
        LoadServerVersions();
        UpdateServerStatus();
    }

    #region ========== AI 助手 ==========
    private void LoadPresetQuestions()
    {
        var questions = AIAssistantService.GetPresetQuestions();
        foreach (var q in questions)
        {
            var btn = new Button
            {
                Content = q,
                Style = FindResource("BaseBtn") as Style,
                Padding = new Thickness(12, 6, 12, 6),
                Margin = new Thickness(0, 0, 8, 8),
                FontSize = 12,
                Cursor = System.Windows.Input.Cursors.Hand
            };
            btn.Click += (_, _) =>
            {
                InputBox.Text = q;
                SendMessage(q);
            };
            PresetQuestions.Children.Add(btn);
        }
    }

    private void LoadConfig()
    {
        try
        {
            ApiKeyBox.Password = App.Services.Settings.Config.Advanced.AIApiKey ?? "";
            ApiBaseBox.Text = App.Services.Settings.Config.Advanced.AIApiBase ?? "https://api.openai.com/v1";
            ModelBox.Text = App.Services.Settings.Config.Advanced.AIModel ?? "gpt-3.5-turbo";
        }
        catch { }
    }

    private void UpdateStatus()
    {
        if (App.Services.AI.IsConfigured)
            InputStatus.Text = "● AI 助手已就绪";
        else
            InputStatus.Text = "○ 请先配置 API 密钥";
    }

    private void ConfigAI_Click(object sender, RoutedEventArgs e)
    {
        ConfigPanel.Visibility = ConfigPanel.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
    }

    private void SaveConfig_Click(object sender, RoutedEventArgs e)
    {
        App.Services.AI.UpdateConfig(ApiKeyBox.Password, ApiBaseBox.Text, ModelBox.Text);
        ConfigStatus.Text = "配置已保存！";
        UpdateStatus();
    }

    private async void TestConnection_Click(object sender, RoutedEventArgs e)
    {
        ConfigStatus.Text = "正在测试连接...";
        var result = await App.Services.AI.ChatAsync("你好，请回复'连接成功'");
        ConfigStatus.Text = result.Length > 100 ? result.Substring(0, 100) + "..." : result;
    }

    private void InputBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        if (e.Key == System.Windows.Input.Key.Enter && !string.IsNullOrWhiteSpace(InputBox.Text))
        {
            SendMessage(InputBox.Text);
        }
    }

    private void Send_Click(object sender, RoutedEventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(InputBox.Text))
            SendMessage(InputBox.Text);
    }

    private async void SendMessage(string message)
    {
        if (!App.Services.AI.IsConfigured)
        {
            AddMessage("system", "请先点击右上角「配置 API」设置你的 API 密钥。");
            return;
        }

        AddMessage("user", message);
        InputBox.Text = "";

        var loadingBorder = AddMessage("ai", "正在思考...");
        ChatScroll.ScrollToEnd();

        try
        {
            string response;
            if (message.Contains("崩溃") || message.Contains("crash") || message.Contains("错误") || message.Length > 500)
            {
                response = await App.Services.AI.AnalyzeCrashAsync(message);
            }
            else
            {
                response = await App.Services.AI.AnswerQuestionAsync(message);
            }

            if (loadingBorder.Child is StackPanel sp && sp.Children.Count > 1 && sp.Children[1] is TextBlock tb)
            {
                tb.Text = response;
            }
        }
        catch (Exception ex)
        {
            if (loadingBorder.Child is StackPanel sp && sp.Children.Count > 1 && sp.Children[1] is TextBlock tb)
            {
                tb.Text = "请求失败：" + ex.Message;
            }
        }
        ChatScroll.ScrollToEnd();
    }

    private Border AddMessage(string role, string content)
    {
        var border = new Border
        {
            CornerRadius = new CornerRadius(8),
            Padding = new Thickness(12),
            Margin = new Thickness(0, 0, 0, 12),
            MaxWidth = 600
        };

        if (role == "user")
        {
            border.Background = new SolidColorBrush(Color.FromArgb(0x33, 0x6B, 0xC0, 0x5C));
            border.HorizontalAlignment = HorizontalAlignment.Right;
        }
        else
        {
            border.Background = new SolidColorBrush(Color.FromArgb(0x22, 0x6B, 0xC0, 0x5C));
            border.HorizontalAlignment = HorizontalAlignment.Left;
        }

        var sp = new StackPanel();
        var title = new TextBlock
        {
            Text = role == "user" ? "🧑 你" : "🤖 AI 助手",
            FontSize = 11,
            Foreground = (Brush)FindResource("AccentBrush"),
            Margin = new Thickness(0, 0, 0, 6)
        };
        var text = new TextBlock
        {
            Text = content,
            Foreground = (Brush)FindResource("TextBrush"),
            FontSize = 13,
            TextWrapping = TextWrapping.Wrap
        };
        sp.Children.Add(title);
        sp.Children.Add(text);
        border.Child = sp;
        ChatPanel.Children.Add(border);
        ChatScroll.ScrollToEnd();
        return border;
    }

    private void PasteCrash_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (Clipboard.ContainsText())
            {
                var text = Clipboard.GetText();
                InputBox.Text = "请分析以下崩溃报告：\n\n" + text;
                SendMessage(InputBox.Text);
            }
            else
            {
                var inst = App.Services.Instances.Current;
                if (inst != null)
                {
                    var gameDir = App.Services.Instances.GetInstanceGameDir(inst);
                    var crash = App.Services.Logs.ReadLatestCrashReport(gameDir);
                    if (!string.IsNullOrEmpty(crash))
                    {
                        InputBox.Text = "请分析以下崩溃报告：\n\n" + crash;
                        SendMessage(InputBox.Text);
                    }
                    else
                    {
                        MessageBox.Show("剪贴板为空，且未找到崩溃报告。", "AI 助手", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("读取失败：" + ex.Message, "AI 助手", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
    #endregion

    #region ========== 内网穿透 ==========
    private void LoadFrpProviders()
    {
        FrpProviderBox.Items.Clear();
        foreach (var p in FrpService.Providers)
        {
            FrpProviderBox.Items.Add(new ComboBoxItem { Content = p.Name, Tag = p.Provider });
        }
        if (FrpProviderBox.Items.Count > 0) FrpProviderBox.SelectedIndex = 0;
    }

    private void FrpProviderBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        UpdateFrpcStatus();
    }

    private void UpdateFrpcStatus()
    {
        try
        {
            if (App.Services.Frp.IsFrpcInstalled())
                FrpcStatus.Text = "✅ frpc 已就绪";
            else
                FrpcStatus.Text = "⚠️ 未安装 frpc，请先下载";
        }
        catch { }
    }

    private void FrpWebsite_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (FrpProviderBox.SelectedItem is ComboBoxItem item && item.Tag is FrpService.FrpProvider provider)
            {
                var info = Array.Find(FrpService.Providers, p => p.Provider == provider);
                if (!string.IsNullOrEmpty(info.Website))
                    Process.Start(new ProcessStartInfo(info.Website) { UseShellExecute = true });
            }
        }
        catch { }
    }

    private async void DownloadFrpc_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var btn = sender as Button;
            if (btn != null) btn.IsEnabled = false;
            FrpcStatus.Text = "正在下载 frpc...";
            var progress = new Progress<(string desc, double pct)>(v => FrpcStatus.Text = $"{v.desc} {v.pct:F0}%");
            bool ok = await App.Services.Frp.DownloadFrpcAsync(progress);
            if (ok)
                FrpcStatus.Text = "✅ frpc 下载完成";
            else
                FrpcStatus.Text = "❌ 下载失败，请检查网络";
            if (btn != null) btn.IsEnabled = true;
        }
        catch (Exception ex)
        {
            FrpcStatus.Text = "下载失败: " + ex.Message;
        }
    }

    private FrpService.FrpConfig ReadFrpConfig()
    {
        var cfg = new FrpService.FrpConfig
        {
            Token = FrpTokenBox.Password,
            ServerAddr = FrpServerAddrBox.Text.Trim(),
            TunnelName = FrpTunnelNameBox.Text.Trim(),
            LocalIp = FrpLocalIpBox.Text.Trim(),
        };
        int.TryParse(FrpServerPortBox.Text, out int sp); cfg.ServerPort = sp > 0 ? sp : 7000;
        int.TryParse(FrpLocalPortBox.Text, out int lp); cfg.LocalPort = lp > 0 ? lp : 25565;
        int.TryParse(FrpRemotePortBox.Text, out int rp); cfg.RemotePort = rp > 0 ? rp : 25565;
        if (FrpProviderBox.SelectedItem is ComboBoxItem item && item.Tag is FrpService.FrpProvider provider)
            cfg.Provider = provider;
        return cfg;
    }

    private void FrpStart_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var cfg = ReadFrpConfig();
            if (string.IsNullOrEmpty(cfg.ServerAddr))
            {
                MessageBox.Show("请填写服务器地址（ServerAddr）", "内网穿透", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!App.Services.Frp.IsFrpcInstalled())
            {
                MessageBox.Show("请先下载 frpc 客户端", "内网穿透", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            AttachFrpLog();
            bool ok = App.Services.Frp.Start(cfg);
            if (ok)
            {
                FrpPublicAddr.Text = App.Services.Frp.GetPublicAddress(cfg);
                AppendFrpLog("穿透已启动，公网地址: " + FrpPublicAddr.Text);
            }
            else
            {
                MessageBox.Show("启动失败，请查看日志", "内网穿透", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("启动失败: " + ex.Message, "内网穿透", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void FrpStop_Click(object sender, RoutedEventArgs e)
    {
        App.Services.Frp.Stop();
        AppendFrpLog("穿透已停止");
    }

    private void AttachFrpLog()
    {
        if (!_frpLogAttached)
        {
            App.Services.Frp.OnLog += AppendFrpLog;
            _frpLogAttached = true;
        }
    }

    private void AppendFrpLog(string msg)
    {
        Dispatcher.Invoke(() =>
        {
            FrpLogBox.Text += $"[{DateTime.Now:HH:mm:ss}] {msg}\n";
            FrpLogScroll.ScrollToEnd();
        });
    }

    private void FrpClearLog_Click(object sender, RoutedEventArgs e)
    {
        FrpLogBox.Text = "";
    }
    #endregion

    #region ========== 一键开服 ==========
    private void LoadServerVersions()
    {
        try
        {
            var versions = new HashSet<string>();

            // 1. 已安装的全局版本
            foreach (var v in App.Services.Versions.GetInstalledVersions())
                versions.Add(v);

            // 2. 扫描所有实例目录下的版本（隔离模式）
            try
            {
                string instancesDir = Path.Combine(SettingsService.GetDataDir(), ".minecraft", "instances");
                if (Directory.Exists(instancesDir))
                {
                    foreach (var instDir in Directory.GetDirectories(instancesDir))
                    {
                        string verDir = Path.Combine(instDir, "versions");
                        if (Directory.Exists(verDir))
                        {
                            foreach (var d in Directory.GetDirectories(verDir))
                            {
                                string name = Path.GetFileName(d);
                                if (File.Exists(Path.Combine(d, name + ".json")))
                                    versions.Add(name);
                            }
                        }
                    }
                }
            }
            catch { }

            // 3. 常用版本作为备选（如果已安装列表为空）
            if (versions.Count == 0)
            {
                foreach (var v in new[] { "1.21.4", "1.21.1", "1.20.4", "1.20.1", "1.19.4", "1.19.2", "1.18.2", "1.17.1", "1.16.5", "1.12.2" })
                    versions.Add(v);
            }

            // 用 ItemsSource 绑定（普通 ComboBox，最可靠）
            var sorted = versions.OrderByDescending(x => x).ToList();
            SrvVersionBox.ItemsSource = sorted;

            if (sorted.Count > 0)
            {
                // 默认选中 1.20.1（如果有），否则选第一个
                string sel = sorted.Contains("1.20.1") ? "1.20.1" : sorted[0];
                SrvVersionBox.SelectedItem = sel;
            }
        }
        catch { }
    }

    private ServerService.ServerConfig ReadServerConfig()
    {
        var cfg = new ServerService.ServerConfig
        {
            Name = SrvNameBox.Text.Trim(),
            LevelSeed = SrvSeedBox.Text.Trim(),
            Motd = SrvMotdBox.Text.Trim(),
            OnlineMode = SrvOnlineModeBox.IsChecked == true,
            Pvp = SrvPvpBox.IsChecked == true,
            EnableCommandBlock = SrvCmdBlockBox.IsChecked == true,
        };
        // 版本号从 SelectedItem 读取（普通 ComboBox）
        if (SrvVersionBox.SelectedItem is string sv)
            cfg.VersionId = sv;
        else if (!string.IsNullOrEmpty(SrvVersionBox.Text))
            cfg.VersionId = SrvVersionBox.Text.Trim();
        int.TryParse(SrvPortBox.Text, out int port); cfg.Port = port > 0 ? port : 25565;
        int.TryParse(SrvMaxPlayersBox.Text, out int mp); cfg.MaxPlayers = mp > 0 ? mp : 20;
        int.TryParse(SrvViewDistanceBox.Text, out int vd); cfg.ViewDistance = vd > 0 ? vd : 10;
        int.TryParse(SrvMinMemBox.Text, out int minm); cfg.MinMemory = minm > 0 ? minm : 1024;
        int.TryParse(SrvMaxMemBox.Text, out int maxm); cfg.MaxMemory = maxm > 0 ? maxm : 4096;
        if (SrvDifficultyBox.SelectedItem is ComboBoxItem di && di.Tag is string diff) cfg.Difficulty = diff;
        if (SrvGameModeBox.SelectedItem is ComboBoxItem gi && gi.Tag is string gm) cfg.GameMode = gm;
        return cfg;
    }

    private async void SrvStart_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var cfg = ReadServerConfig();
            if (string.IsNullOrEmpty(cfg.Name))
            {
                MessageBox.Show("请填写服务器名称", "一键开服", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (string.IsNullOrEmpty(cfg.VersionId))
            {
                MessageBox.Show("请选择或输入游戏版本", "一键开服", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 隐藏地址区域，显示进度条
            SrvAddressBorder.Visibility = Visibility.Collapsed;
            SrvProgressBorder.Visibility = Visibility.Visible;
            UpdateSrvProgress("正在准备...", 5);

            AttachSrvLog();
            SrvStartBtn.IsEnabled = false;

            // 订阅日志，检测服务器启动完成（"Done" 消息）
            _srvDoneDetected = false;
            App.Services.Server.OnLog -= OnSrvLogForDone;
            App.Services.Server.OnLog += OnSrvLogForDone;

            AppendSrvLog($"正在启动服务器 {cfg.Name} (版本 {cfg.VersionId})...");
            UpdateSrvProgress("正在下载/检查服务端文件...", 15);

            bool ok = await App.Services.Server.StartAsync(cfg);
            if (ok)
            {
                AppendSrvLog("服务器启动命令已发送，等待世界加载...");
                UpdateSrvProgress("正在启动服务端，等待世界加载...", 50);
                UpdateServerStatus();
                // 保存当前配置，用于启动完成后显示地址
                _currentSrvCfg = cfg;

                // 自动启动内网穿透（如果启用了）
                var frpCfg = ReadFrpConfig(cfg.Port);
                if (frpCfg != null)
                {
                    _currentFrpCfg = frpCfg;
                    UpdateSrvProgress("正在启动内网穿透...", 60);
                    AppendSrvLog("正在启动内网穿透...");
                    try
                    {
                        // 确保 frpc 已安装
                        if (!App.Services.Frp.IsFrpcInstalled())
                        {
                            AppendSrvLog("正在下载 frpc 客户端...");
                            var dlProgress = new Progress<(string desc, double pct)>(v => AppendSrvLog($"  {v.desc}"));
                            bool dlOk = await App.Services.Frp.DownloadFrpcAsync(dlProgress);
                            if (!dlOk)
                            {
                                AppendSrvLog("[警告] frpc 下载失败，穿透未启动");
                                frpCfg = null;
                            }
                        }
                        if (frpCfg != null)
                        {
                            App.Services.Frp.SaveConfig(frpCfg);
                            bool frpOk = App.Services.Frp.Start(frpCfg);
                            if (frpOk)
                            {
                                string pubAddr = App.Services.Frp.GetPublicAddress(frpCfg);
                                AppendSrvLog($"✅ 内网穿透已启动，公网地址：{pubAddr}");
                            }
                            else
                            {
                                AppendSrvLog("[警告] 内网穿透启动失败，请检查 Token 和端口配置");
                            }
                        }
                    }
                    catch (Exception frpEx)
                    {
                        AppendSrvLog($"[警告] 穿透启动异常：{frpEx.Message}");
                    }
                }
            }
            else
            {
                UpdateSrvProgress("启动失败", 0);
                SrvProgressBorder.Visibility = Visibility.Collapsed;
                MessageBox.Show("启动失败，请查看日志", "一键开服", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            SrvStartBtn.IsEnabled = true;
        }
        catch (Exception ex)
        {
            UpdateSrvProgress("启动失败", 0);
            SrvProgressBorder.Visibility = Visibility.Collapsed;
            MessageBox.Show("启动失败: " + ex.Message, "一键开服", MessageBoxButton.OK, MessageBoxImage.Error);
            SrvStartBtn.IsEnabled = true;
        }
    }

    private bool _srvDoneDetected;
    private ServerService.ServerConfig? _currentSrvCfg;

    /// <summary>检测服务器日志中的 "Done" 消息，判断启动完成</summary>
    private void OnSrvLogForDone(string log)
    {
        if (_srvDoneDetected) return;
        // 检测 "Done" 消息（Minecraft 服务器启动完成的标志）
        if (log.Contains("Done (", StringComparison.OrdinalIgnoreCase) ||
            (log.Contains("Done") && log.Contains("For help, type", StringComparison.OrdinalIgnoreCase)))
        {
            _srvDoneDetected = true;
            Dispatcher.Invoke(() =>
            {
                UpdateSrvProgress("启动完成！", 100);
                ShowServerAddress();
                // 3秒后隐藏进度条
                var _ = Task.Run(async () =>
                {
                    await Task.Delay(3000);
                    Dispatcher.Invoke(() => SrvProgressBorder.Visibility = Visibility.Collapsed);
                });
            });
        }
    }

    /// <summary>更新启动进度</summary>
    private void UpdateSrvProgress(string text, double percent)
    {
        SrvProgressText.Text = text;
        if (SrvProgressFill.Parent is Border parent)
        {
            SrvProgressFill.Width = Math.Max(0, parent.ActualWidth * percent / 100.0);
        }
    }

    /// <summary>显示服务器地址</summary>
    private void ShowServerAddress()
    {
        try
        {
            int port = _currentSrvCfg?.Port ?? 25565;
            string version = _currentSrvCfg?.VersionId ?? "未知";
            string lanIp = GetLocalIpAddress();

            SrvAddrLocal.Text = $"localhost:{port}";
            SrvAddrLan.Text = $"{lanIp}:{port}";
            SrvAddrVersion.Text = version;
            SrvAddressBorder.Visibility = Visibility.Visible;

            // 显示公网地址（如果穿透启用了）
            if (_currentFrpCfg != null)
            {
                try
                {
                    string pubAddr = App.Services.Frp.GetPublicAddress(_currentFrpCfg);
                    SrvAddrPublic.Text = pubAddr;
                    SrvAddrPublicPanel.Visibility = Visibility.Visible;
                }
                catch { }
            }
            else
            {
                SrvAddrPublicPanel.Visibility = Visibility.Collapsed;
            }

            AppendSrvLog($"========================================");
            AppendSrvLog($"✅ 服务器启动完成！");
            AppendSrvLog($"📌 本机地址：localhost:{port}");
            AppendSrvLog($"📌 局域网地址：{lanIp}:{port}");
            if (_currentFrpCfg != null)
            {
                try { AppendSrvLog($"🌐 公网地址：{App.Services.Frp.GetPublicAddress(_currentFrpCfg)}"); } catch { }
            }
            AppendSrvLog($"📌 游戏版本：{version}");
            AppendSrvLog($"========================================");
        }
        catch { }
    }

    /// <summary>获取本机局域网 IP</summary>
    private static string GetLocalIpAddress()
    {
        try
        {
            var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    string s = ip.ToString();
                    // 排除 127.x.x.x 和 169.254.x.x
                    if (!s.StartsWith("127.") && !s.StartsWith("169.254."))
                        return s;
                }
            }
        }
        catch { }
        return "127.0.0.1";
    }

    private void SrvCopyLocal_Click(object sender, RoutedEventArgs e)
    {
        SetClipboardText(SrvAddrLocal.Text);
    }

    private void SrvCopyLan_Click(object sender, RoutedEventArgs e)
    {
        SetClipboardText(SrvAddrLan.Text);
    }

    private void SrvCopyPublic_Click(object sender, RoutedEventArgs e)
    {
        SetClipboardText(SrvAddrPublic.Text);
    }

    /// <summary>可靠地设置剪贴板内容（带重试，处理剪贴板被占用的情况）</summary>
    private static void SetClipboardText(string text)
    {
        if (string.IsNullOrEmpty(text)) return;
        for (int i = 0; i < 5; i++)
        {
            try
            {
                System.Windows.Clipboard.SetDataObject(text, true);
                return;
            }
            catch
            {
                System.Threading.Thread.Sleep(50);
            }
        }
        // 最后兜底
        try { System.Windows.Clipboard.SetText(text); }
        catch { MessageBox.Show("复制失败，请手动选择文本复制", "一键开服", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void SrvTutorial_Click(object sender, RoutedEventArgs e)
    {
        string version = _currentSrvCfg?.VersionId ?? SrvVersionBox.SelectedItem as string ?? "1.20.1";
        int port = _currentSrvCfg?.Port ?? 25565;
        string lanIp = GetLocalIpAddress();
        string tutorial = $@"📖 如何加入服务器

【第一步：启动游戏】
1. 回到启动器主页
2. 选择游戏版本：{version}（必须和服务器版本一致！）
3. 点击「启动游戏」

【第二步：加入服务器】
1. 进入游戏主菜单 → 点击「多人游戏」
2. 点击「添加服务器」
3. 服务器名称随便填（如：我的服务器）
4. 服务器地址填：
   ├ 本机（同一台电脑）：localhost:{port}
   └ 局域网（同一路由器）：{lanIp}:{port}
5. 点击「完成」→ 双击服务器加入

【常见问题】
Q：提示「身份验证失败」？
A：服务器开了正版验证，离线账号无法加入。在服务器设置里关闭「正版验证」后重启服务器。

Q：连接超时/无法连接？
A：① 确认服务器已启动（日志显示 Done）
   ② 检查 Windows 防火墙是否放行 Java
   ③ 确认客户端和服务器版本一致

Q：朋友在外地怎么连？
A：需要内网穿透。在「实验功能」→「内网穿透」里配置 Sakurafrp/openfrp/MSL FRP。

【服务器命令】
在下方命令框输入：
  /stop      关闭服务器
  /op 玩家名  给玩家管理员权限
  /gamemode creative  切换创造模式";
        MessageBox.Show(tutorial, "加入服务器教程", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void SrvStop_Click(object sender, RoutedEventArgs e)
    {
        App.Services.Server.Stop();
        // 停止内网穿透
        try { App.Services.Frp.Stop(); } catch { }
        _currentFrpCfg = null;
        AppendSrvLog("停止命令已发送");
        SrvAddressBorder.Visibility = Visibility.Collapsed;
        SrvProgressBorder.Visibility = Visibility.Collapsed;
        _srvDoneDetected = false;
        UpdateServerStatus();
    }

    private void SrvDelete_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string name = SrvNameBox.Text.Trim();
            if (string.IsNullOrEmpty(name)) return;
            var result = MessageBox.Show($"确定删除服务器「{name}」及其所有文件吗？", "一键开服", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                App.Services.Server.DeleteServer(name);
                AppendSrvLog($"服务器 {name} 已删除");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("删除失败: " + ex.Message, "一键开服", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void SrvSendCmd_Click(object sender, RoutedEventArgs e)
    {
        if (!string.IsNullOrWhiteSpace(SrvCmdBox.Text))
        {
            App.Services.Server.SendCommand(SrvCmdBox.Text);
            SrvCmdBox.Text = "";
        }
    }

    private void SrvCmdBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        if (e.Key == System.Windows.Input.Key.Enter && !string.IsNullOrWhiteSpace(SrvCmdBox.Text))
        {
            SrvSendCmd_Click(sender, e);
        }
    }

    private void AttachSrvLog()
    {
        if (!_srvLogAttached)
        {
            App.Services.Server.OnLog += AppendSrvLog;
            _srvLogAttached = true;
        }
    }

    private void AppendSrvLog(string msg)
    {
        Dispatcher.Invoke(() =>
        {
            SrvLogBox.Text += $"[{DateTime.Now:HH:mm:ss}] {msg}\n";
            SrvLogScroll.ScrollToEnd();
        });
    }

    private void SrvClearLog_Click(object sender, RoutedEventArgs e)
    {
        SrvLogBox.Text = "";
    }

    private void UpdateServerStatus()
    {
        try
        {
            if (App.Services.Server.IsRunning)
            {
                SrvStatusDot.Fill = new SolidColorBrush(Colors.LimeGreen);
                SrvStatusText.Text = "运行中";
            }
            else
            {
                SrvStatusDot.Fill = new SolidColorBrush(Color.FromRgb(0x88, 0x88, 0x88));
                SrvStatusText.Text = "未运行";
            }
        }
        catch { }
    }
    #endregion
}
