using System.IO;
using System.Net.Http;
using System.Windows.Media.Imaging;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

/// <summary>头像下载与缓存服务</summary>
public class AvatarService
{
    private readonly DownloadService _dl;
    private readonly string _cacheDir;

    public AvatarService(DownloadService dl)
    {
        _dl = dl;
        _cacheDir = Path.Combine(SettingsService.GetDataDir(), "avatars");
        Directory.CreateDirectory(_cacheDir);
    }

    /// <summary>获取账号头像（优先本地缓存，否则下载）</summary>
    public async Task<BitmapImage?> GetAvatarAsync(Account? acct)
    {
        if (acct == null) return null;

        // 优先使用本地缓存
        string cachePath = Path.Combine(_cacheDir, acct.Id + ".png");
        if (File.Exists(cachePath) && new FileInfo(cachePath).Length > 0)
        {
            try
            {
                var bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.UriSource = new Uri(cachePath);
                bmp.EndInit();
                bmp.Freeze();
                return bmp;
            }
            catch { }
        }

        // 尝试从多个头像源下载
        string? avatarUrl = acct.AvatarUrl;
        if (string.IsNullOrEmpty(avatarUrl))
        {
            // 如果没有头像 URL，根据账号类型生成
            if (acct.Type == "microsoft" && !string.IsNullOrEmpty(acct.Uuid))
            {
                avatarUrl = $"https://crafatar.com/avatars/{acct.Uuid}?size=128&overlay";
            }
            else if (!string.IsNullOrEmpty(acct.Name))
            {
                avatarUrl = $"https://minotar.net/avatar/{Uri.EscapeDataString(acct.Name)}/128";
            }
        }

        if (string.IsNullOrEmpty(avatarUrl)) return null;

        // 尝试多个头像源
        var sources = new List<string>();
        if (!string.IsNullOrEmpty(acct.Uuid))
        {
            sources.Add($"https://crafatar.com/avatars/{acct.Uuid}?size=128&overlay");
            sources.Add($"https://mc-heads.net/avatar/{acct.Uuid}/128");
            sources.Add($"https://minecraft-api.com/api/avatars/get/{acct.Uuid}/128");
        }
        if (!string.IsNullOrEmpty(acct.Name))
        {
            sources.Add($"https://minotar.net/avatar/{Uri.EscapeDataString(acct.Name)}/128");
            sources.Add($"https://mc-heads.net/avatar/{Uri.EscapeDataString(acct.Name)}/128");
        }
        // 最后尝试原始 URL
        if (!sources.Contains(avatarUrl)) sources.Add(avatarUrl);

        foreach (var url in sources)
        {
            try
            {
                using var resp = await _dl.Http.Client.GetAsync(url);
                if (!resp.IsSuccessStatusCode) continue;
                var bytes = await resp.Content.ReadAsByteArrayAsync();
                if (bytes.Length < 100) continue; // 太小可能是错误页面

                // 保存到本地缓存
                File.WriteAllBytes(cachePath, bytes);

                // 加载为 BitmapImage
                var bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.StreamSource = new MemoryStream(bytes);
                bmp.EndInit();
                bmp.Freeze();
                return bmp;
            }
            catch { continue; }
        }

        return null;
    }

    /// <summary>清除头像缓存</summary>
    public void ClearCache()
    {
        try
        {
            foreach (var f in Directory.GetFiles(_cacheDir, "*.png"))
                try { File.Delete(f); } catch { }
        }
        catch { }
    }
}
