using System.Windows;

namespace WarmWaterLauncher.Pages;

public partial class TextPromptDialog : Window
{
    public string Value { get; private set; } = "";

    public TextPromptDialog(string title, string prompt, string defaultValue = "")
    {
        InitializeComponent();
        Title = title;
        PromptText.Text = prompt;
        ValueBox.Text = defaultValue;
        ValueBox.Focus();
        ValueBox.SelectAll();
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(ValueBox.Text))
        {
            MessageBox.Show("输入不能为空", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        Value = ValueBox.Text.Trim();
        DialogResult = true;
    }
}
