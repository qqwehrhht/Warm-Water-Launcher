using System.Diagnostics;
using System.IO.Compression;
using System.Text.Json;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

public class LoaderVersion
{
    public string Version { get; set; } = "";
    public string Display { get; set; } = "";
    public string? Build { get; set; }
}

/// <summary>加载器安装：Forge / Fabric / Quilt / OptiFine</summary>
public class LoaderService
{
    private readonly SettingsService _settings;
    private readonly DownloadService _dl;
    private readonly VersionService _versions;
    private readonly JavaService _java;
    public LoaderService(SettingsService settings, DownloadService dl, VersionService versions, JavaService java)
    {
        _settings = settings;
        _dl = dl;
        _versions = versions;
        _java = java;
    }

    /// <summary>获取某加载器对该 MC 版本可用的版本列表</summary>
    public async Task<List<LoaderVersion>> GetAvailableAsync(string loaderType, string mcVersion)
    {
        var result = new List<LoaderVersion>();
        try
        {
            switch (loaderType)
            {
                case "fabric":
                {
                    var json = await _dl.Http.GetStringAsync($"https://meta.fabricmc.net/v2/versions/loader/{mcVersion}");
                    if (string.IsNullOrEmpty(json)) break;
                    using var doc = JsonDocument.Parse(json);
                    foreach (var item in doc.RootElement.EnumerateArray())
                    {
                        var loader = item.GetProperty("loader");
                        var v = loader.GetProperty("version").GetString() ?? "";
                        result.Add(new LoaderVersion { Version = v, Display = "Fabric " + v });
                    }
                    break;
                }
                case "quilt":
                {
                    var json = await _dl.Http.GetStringAsync($"https://meta.quiltmc.org/v3/versions/loader/{mcVersion}");
                    if (string.IsNullOrEmpty(json)) break;
                    using var doc = JsonDocument.Parse(json);
                    foreach (var item in doc.RootElement.EnumerateArray())
                    {
                        var loader = item.GetProperty("loader");
                        var v = loader.GetProperty("version").GetString() ?? "";
                        result.Add(new LoaderVersion { Version = v, Display = "Quilt " + v });
                    }
                    break;
                }
                case "forge":
                {
                    var json = await _dl.Http.GetStringAsync(_dl.Mirror($"https://bmclapi2.bangbang93.com/forge/minecraft/{mcVersion}"));
                    if (string.IsNullOrEmpty(json)) break;
                    using var doc = JsonDocument.Parse(json);
                    foreach (var item in doc.RootElement.EnumerateArray())
                    {
                        var v = item.GetProperty("version").GetString() ?? "";
                        var build = item.TryGetProperty("build", out var b) ? b.ToString() : null;
                        result.Add(new LoaderVersion { Version = v, Display = "Forge " + v, Build = build });
                    }
                    break;
                }
                case "optifine":
                {
                    var json = await _dl.Http.GetStringAsync(_dl.Mirror($"https://bmclapi2.bangbang93.com/optifine/{mcVersion}"));
                    if (string.IsNullOrEmpty(json)) break;
                    using var doc = JsonDocument.Parse(json);
                    foreach (var item in doc.RootElement.EnumerateArray())
                    {
                        var fileName = item.GetProperty("filename").GetString() ?? "";
                        var type = item.TryGetProperty("type", out var t) ? t.GetString() : "";
                        var patch = item.TryGetProperty("patch", out var p) ? p.GetString() : "";
                        if (type == "HD_U" || type == "HD" || type == "L")
                            result.Add(new LoaderVersion { Version = $"{type}_{patch}", Display = "OptiFine " + fileName, Build = fileName });
                    }
                    break;
                }
            }
        }
        catch { }
        return result;
    }

    /// <summary>安装加载器（写入实例配置并调用安装器）</summary>
    public async Task<bool> InstallAsync(GameInstance inst, string loaderType, string loaderVersion,
        IProgress<(string status, double pct)>? progress, CancellationToken ct = default)
    {
        string mc = inst.VersionId;
        string gameRoot = _settings.GameRoot;
        // Fabric / Quilt / Forge 安装器都要求游戏目录存在合法的 launcher_profiles.json，
        // 否则会出现“Could not find a valid launcher profile .json”并安装失败。
        EnsureLauncherProfiles(gameRoot);
        var java = PickJava(mc);
        if (java == null)
        {
            progress?.Report(("未检测到 Java，请先在 Java 页面下载", 0));
            return false;
        }

        switch (loaderType)
        {
            case "fabric":
            case "quilt":
            {
                string installerVer = await GetInstallerVersion(loaderType);
                string url = loaderType == "fabric"
                    ? $"https://maven.fabricmc.net/net/fabricmc/fabric-installer/{installerVer}/fabric-installer-{installerVer}.jar"
                    : $"https://maven.quiltmc.org/repository/release/org/quiltmc/quilt-installer/{installerVer}/quilt-installer-{installerVer}.jar";
                string jar = Path.Combine(SettingsService.GetDataDir(), "installers", loaderType + "-installer.jar");
                Directory.CreateDirectory(Path.GetDirectoryName(jar)!);
                progress?.Report(($"正在下载 {LoaderCatalog.DisplayName(loaderType)} 安装器...", 0.1));
                if (!await _dl.DownloadFileAsync(url, jar, null, ct))
                {
                    progress?.Report(("安装器下载失败", 1));
                    return false;
                }
                if (!IsValidInstallerJar(jar))
                {
                    try { File.Delete(jar); } catch { }
                    progress?.Report(("安装器文件不是有效的 jar（可能是镜像返回了错误页面），请重试或切换下载源", 1));
                    return false;
                }
                progress?.Report(($"正在安装 {LoaderCatalog.DisplayName(loaderType)} {loaderVersion} ...", 0.5));
                var psi = new ProcessStartInfo(java)
                {
                    WorkingDirectory = gameRoot,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                psi.ArgumentList.Add("-jar"); psi.ArgumentList.Add(jar);
                if (loaderType == "fabric")
                {
                    // Fabric Installer: client -dir <gameDir> -mcversion <mc> -loader <version>
                    psi.ArgumentList.Add("client");
                    psi.ArgumentList.Add("-dir"); psi.ArgumentList.Add(gameRoot);
                    psi.ArgumentList.Add("-mcversion"); psi.ArgumentList.Add(mc);
                    psi.ArgumentList.Add("-loader"); psi.ArgumentList.Add(loaderVersion);
                }
                else
                {
                    // Quilt Installer 使用子命令语法，不能照搬 Fabric 参数
                    psi.ArgumentList.Add("install");
                    psi.ArgumentList.Add("client");
                    psi.ArgumentList.Add(mc);
                    psi.ArgumentList.Add("--loader-version"); psi.ArgumentList.Add(loaderVersion);
                    psi.ArgumentList.Add("--install-dir"); psi.ArgumentList.Add(gameRoot);
                }

                using var p = Process.Start(psi);
                if (p == null) { progress?.Report(("安装进程启动失败", 1)); return false; }
                var outTask = p.StandardOutput.ReadToEndAsync();
                var errTask = p.StandardError.ReadToEndAsync();
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
                timeout.CancelAfter(TimeSpan.FromMinutes(5));
                try { await p.WaitForExitAsync(timeout.Token); }
                catch (OperationCanceledException)
                {
                    try { p.Kill(); } catch { }
                    progress?.Report(("加载器安装超时或已取消", 1));
                    return false;
                }
                string output = await outTask + await errTask;
                if (p.ExitCode != 0)
                {
                    progress?.Report(($"加载器安装器退出码 {p.ExitCode}：{Tail(output)}", 1));
                    return false;
                }
                var installedDir = FindLoaderVersionFolder(mc, loaderType, loaderVersion);
                if (installedDir == null)
                {
                    progress?.Report(($"安装器已结束，但没有找到对应的 {loaderType} 版本目录：{Tail(output)}", 1));
                    return false;
                }
                progress?.Report(($"安装完成：{Path.GetFileName(installedDir)}", 1));
                inst.LoaderType = loaderType;
                inst.LoaderVersion = loaderVersion;
                _settings.Save();
                return true;
            }
            case "forge":
            {
                string installer = $"forge-{mc}-{loaderVersion}-installer.jar";
                // 使用 BMCLAPI 国内镜像下载 Forge 安装器（优先），官方源作为备用
                var forgeUrls = new List<string>
                {
                    // BMCLAPI maven 镜像（国内高速，302 重定向到教育网镜像）
                    $"https://bmclapi2.bangbang93.com/maven/net/minecraftforge/forge/{mc}-{loaderVersion}/{installer}",
                    // 官方源
                    $"https://maven.minecraftforge.net/net/minecraftforge/forge/{mc}-{loaderVersion}/{installer}",
                    // BMCLAPI 备用
                    _dl.Mirror($"https://maven.minecraftforge.net/net/minecraftforge/forge/{mc}-{loaderVersion}/{installer}")
                };
                string jar = Path.Combine(SettingsService.GetDataDir(), "installers", installer);
                Directory.CreateDirectory(Path.GetDirectoryName(jar)!);

                // 逐个尝试下载源
                bool downloaded = false;
                for (int ui = 0; ui < forgeUrls.Count; ui++)
                {
                    progress?.Report(($"正在从镜像 {ui + 1}/{forgeUrls.Count} 下载 Forge 安装器 {loaderVersion}...", 0.05 + ui * 0.05));
                    try
                    {
                        if (File.Exists(jar)) try { File.Delete(jar); } catch { }
                        bool dlOk = await _dl.DownloadFileAsync(forgeUrls[ui], jar, null, ct);
                        if (dlOk && File.Exists(jar) && new FileInfo(jar).Length > 100 * 1024 && IsValidInstallerJar(jar))
                        {
                            downloaded = true;
                            break;
                        }
                    }
                    catch { }
                }
                if (!downloaded)
                {
                    progress?.Report(("Forge 安装器下载失败，所有镜像源均不可用。请检查网络或换用其他版本。", 1));
                    return false;
                }

                progress?.Report(($"正在安装 Forge {loaderVersion}（下载依赖可能需要几分钟）...", 0.4));

                // Forge 安装器需要在 .minecraft 目录下运行，并且需要 launcher_profiles.json
                // 确定 .minecraft 目录：gameRoot 本身就是 .minecraft 目录
                string mcDir = gameRoot;
                Directory.CreateDirectory(mcDir);
                Directory.CreateDirectory(Path.Combine(mcDir, "versions"));

                // 确保 launcher_profiles.json 存在（Forge 安装器需要它）
                string profilesPath = Path.Combine(mcDir, "launcher_profiles.json");
                if (!File.Exists(profilesPath))
                {
                    try
                    {
                        var profiles = new
                        {
                            profiles = new Dictionary<string, object>
                            {
                                ["(Default)"] = new
                                {
                                    name = "(Default)",
                                    type = "latest-release",
                                    created = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                                    lastUsed = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                                    icon = "Grass"
                                }
                            },
                            selectedProfile = "(Default)",
                            clientToken = Guid.NewGuid().ToString("N"),
                            launcherVersion = new { name = "WarmWaterLauncher", format = 21, profilesFormat = 3 }
                        };
                        string json = System.Text.Json.JsonSerializer.Serialize(profiles, new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
                        File.WriteAllText(profilesPath, json);
                    }
                    catch { }
                }

                var psi = new ProcessStartInfo(java)
                {
                    WorkingDirectory = mcDir,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                // Forge 安装器参数：-jar installer.jar --installClient <目标目录>
                // 新版Forge使用 --installClient 后跟目标目录，旧版可能不需要
                psi.ArgumentList.Add("-jar");
                psi.ArgumentList.Add(jar);
                psi.ArgumentList.Add("--installClient");
                psi.ArgumentList.Add(mcDir);
                // 部分 Forge 版本会忽略 --installClient 的路径，改为使用 %APPDATA%\.minecraft。
                // 把 APPDATA 指向 gameRoot 的父目录，确保两种行为都安装到当前游戏目录。
                try
                {
                    if (string.Equals(Path.GetFileName(mcDir), ".minecraft", StringComparison.OrdinalIgnoreCase))
                        psi.Environment["APPDATA"] = Path.GetDirectoryName(mcDir) ?? mcDir;
                }
                catch { }
                // Forge 安装器会在 WorkingDirectory 下查找 .minecraft 并安装到指定目录
                using var proc = Process.Start(psi);
                if (proc == null) { progress?.Report(("安装进程启动失败", 1)); return false; }
                var outTask = proc.StandardOutput.ReadToEndAsync();
                var errTask = proc.StandardError.ReadToEndAsync();
                using var forgeTimeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
                forgeTimeout.CancelAfter(TimeSpan.FromMinutes(15));
                try { await proc.WaitForExitAsync(forgeTimeout.Token); }
                catch (OperationCanceledException)
                {
                    try { proc.Kill(); } catch { }
                    progress?.Report(("Forge 安装超时或已取消", 1));
                    return false;
                }
                string output = await outTask + await errTask;
                if (proc.ExitCode != 0)
                {
                    progress?.Report(($"Forge 安装器退出码 {proc.ExitCode}：{Tail(output)}", 1));
                    return false;
                }
                // Forge 版本目录名可能有多种格式，检查全局和实例目录
                string[] possibleDirNames = {
                    $"{mc}-forge-{loaderVersion}",
                    $"forge-{mc}-{loaderVersion}",
                    $"{mc}-forge-{loaderVersion}.0",
                    $"forge-{mc}-{loaderVersion}.0",
                };
                bool ok = false;
                string foundVersionDir = "";
                foreach (var dirName in possibleDirNames)
                {
                    // 检查实例目录下的versions
                    string dirInInstance = Path.Combine(mcDir, "versions", dirName);
                    if (Directory.Exists(dirInInstance) && Directory.GetFiles(dirInInstance, "*.json").Length > 0)
                    {
                        ok = true;
                        foundVersionDir = dirInInstance;
                        break;
                    }
                    // 检查全局versions目录
                    string dirInGlobal = Path.Combine(_settings.GlobalVersionsDir, dirName);
                    if (Directory.Exists(dirInGlobal) && Directory.GetFiles(dirInGlobal, "*.json").Length > 0)
                    {
                        ok = true;
                        foundVersionDir = dirInGlobal;
                        break;
                    }
                }
                // 如果没找到精确匹配，检查versions目录下是否有包含forge的目录
                if (!ok)
                {
                    try
                    {
                        string versionsDir = Path.Combine(mcDir, "versions");
                        if (Directory.Exists(versionsDir))
                        {
                            foreach (var d in Directory.GetDirectories(versionsDir))
                            {
                                string dirName = Path.GetFileName(d).ToLower();
                                if (dirName.Contains("forge") && dirName.Contains(mc) && Directory.GetFiles(d, "*.json").Length > 0)
                                {
                                    ok = true;
                                    foundVersionDir = d;
                                    break;
                                }
                            }
                        }
                    }
                    catch { }
                }
                if (!ok)
                {
                    string dirs = "";
                    try
                    {
                        var vDir = _settings.GlobalVersionsDir;
                        if (Directory.Exists(vDir))
                            dirs = string.Join(", ", Directory.GetDirectories(vDir).Select(Path.GetFileName).Take(10));
                    }
                    catch { }
                    progress?.Report(($"Forge 安装失败：{(output.Length > 400 ? output[^400..] : output)}\n已安装版本: {dirs}", 1));
                    return false;
                }
                progress?.Report(("Forge 安装完成", 1));
                inst.LoaderType = "forge";
                inst.LoaderVersion = loaderVersion;
                _settings.Save();
                return true;
            }
            case "optifine":
            {
                // OptiFine 需运行其安装器（图形界面点 Install），此处下载并打开
                string url = _dl.Mirror($"https://bmclapi2.bangbang93.com/optifine/{mc}/{loaderVersion}");
                string jar = Path.Combine(SettingsService.GetDataDir(), "installers", $"OptiFine_{mc}_{loaderVersion}.jar");
                Directory.CreateDirectory(Path.GetDirectoryName(jar)!);
                progress?.Report(("正在下载 OptiFine 安装器...", 0.1));
                if (!await _dl.DownloadFileAsync(url, jar, null, ct))
                {
                    progress?.Report(("OptiFine 下载失败", 1));
                    return false;
                }
                progress?.Report(("OptiFine 安装器已下载，正在打开（点击 Install 完成安装）...", 0.5));
                var psi = new ProcessStartInfo(java)
                {
                    WorkingDirectory = Path.GetDirectoryName(jar)!,
                    UseShellExecute = true
                };
                psi.ArgumentList.Add("-jar"); psi.ArgumentList.Add(jar);
                Process.Start(psi);
                inst.LoaderType = "optifine";
                inst.LoaderVersion = loaderVersion;
                _settings.Save();
                progress?.Report(("已打开 OptiFine 安装器，请在弹出的窗口中点击 Install 按钮", 1));
                return true;
            }
        }
        return false;
    }

    private static string Tail(string? text, int max = 700)
    {
        if (string.IsNullOrWhiteSpace(text)) return "（安装器没有输出详细信息）";
        text = text.Trim();
        return text.Length <= max ? text : text[^max..];
    }

    /// <summary>安装完成后查找加载器实际生成的版本目录。</summary>
    private string? FindLoaderVersionFolder(string mc, string loaderType, string loaderVersion)
    {
        var candidates = loaderType switch
        {
            "fabric" => new[]
            {
                $"fabric-loader-{loaderVersion}-{mc}",
                $"{mc}-fabric-{loaderVersion}",
                $"fabric-{mc}-{loaderVersion}"
            },
            "quilt" => new[]
            {
                $"quilt-loader-{loaderVersion}-{mc}",
                $"{mc}-quilt-{loaderVersion}",
                $"quilt-{mc}-{loaderVersion}"
            },
            _ => Array.Empty<string>()
        };

        var roots = new List<string>
        {
            Path.Combine(_settings.GameRoot, "versions"),
            _settings.GlobalVersionsDir
        }
        .Distinct(StringComparer.OrdinalIgnoreCase);

        foreach (var root in roots)
        {
            foreach (var candidate in candidates)
            {
                var dir = Path.Combine(root, candidate);
                if (Directory.Exists(dir) && Directory.GetFiles(dir, "*.json").Length > 0)
                    return dir;
            }

            try
            {
                foreach (var dir in Directory.GetDirectories(root))
                {
                    var name = Path.GetFileName(dir);
                    if (name.Contains(loaderType, StringComparison.OrdinalIgnoreCase)
                        && name.Contains(mc, StringComparison.OrdinalIgnoreCase)
                        && name.Contains(loaderVersion, StringComparison.OrdinalIgnoreCase)
                        && Directory.GetFiles(dir, "*.json").Length > 0)
                        return dir;
                }
            }
            catch { }
        }
        return null;
    }

    private string? PickJava(string mcVersion)
    {
        int need = JavaService.RequiredForMc(mcVersion);
        var detected = _java.DetectAll();
        // 优先使用刚好满足要求的最低 Java 大版本，避免拿 Java 27 去运行旧 Forge 安装器。
        var match = detected.Where(j => j.Major >= need).OrderBy(j => j.Major).FirstOrDefault()
                    ?? detected.OrderByDescending(j => j.Major).FirstOrDefault();
        return match?.Path;
    }

    /// <summary>校验下载下来的安装器确实是可读取的 jar/zip，避免把 HTML 错误页当成 jar 执行。</summary>
    private static bool IsValidInstallerJar(string path)
    {
        try
        {
            using var zip = ZipFile.OpenRead(path);
            return zip.Entries.Count > 0;
        }
        catch { return false; }
    }

    /// <summary>保证安装器需要的 launcher_profiles.json 存在且格式有效。</summary>
    private static void EnsureLauncherProfiles(string gameRoot)
    {
        try
        {
            Directory.CreateDirectory(gameRoot);
            var path = Path.Combine(gameRoot, "launcher_profiles.json");
            if (File.Exists(path) && new FileInfo(path).Length > 2) return;

            var profiles = new
            {
                profiles = new Dictionary<string, object>
                {
                    ["(Default)"] = new
                    {
                        name = "(Default)",
                        type = "latest-release",
                        created = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                        lastUsed = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                        icon = "Grass"
                    }
                },
                selectedProfile = "(Default)",
                clientToken = Guid.NewGuid().ToString("N"),
                launcherVersion = new { name = "WarmWaterLauncher", format = 21, profilesFormat = 3 }
            };
            File.WriteAllText(path, JsonSerializer.Serialize(profiles, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private async Task<string> GetInstallerVersion(string type)
    {
        try
        {
            string url = type == "fabric"
                ? "https://meta.fabricmc.net/v2/versions/installer"
                : "https://meta.quiltmc.org/v3/versions/installer";
            var json = await _dl.Http.GetStringAsync(url);
            if (string.IsNullOrEmpty(json)) return "0.11.0";
            using var doc = JsonDocument.Parse(json);
            var v = doc.RootElement.EnumerateArray().FirstOrDefault();
            return v.GetProperty("version").GetString() ?? "0.11.0";
        }
        catch { return type == "fabric" ? "0.11.0" : "0.7.1"; }
    }
}
