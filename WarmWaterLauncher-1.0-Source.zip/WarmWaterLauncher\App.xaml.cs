using System.Windows;
using System.Windows.Media;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;
using WarmWaterLauncher.Pages;

namespace WarmWaterLauncher;

public partial class App : Application
{
    public static AppServices Services = null!;
    public static MainWindow? MainWin;
    private static bool _isShuttingDown = false;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // 关键：设置为显式关闭模式，避免启动画面关闭后应用自动退出
        ShutdownMode = System.Windows.ShutdownMode.OnExplicitShutdown;

        // 检查命令行参数，如果是 /install 则直接运行安装器
        var args = e.Args;
        bool isInstallMode = args != null && args.Length > 0 && (args[0] == "/install" || args[0] == "-install" || args[0] == "--install");

        // 检测文件名，如果包含"安装器"或"installer"，自动进入安装器模式
        try
        {
            string exeName = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? "";
            string fileName = System.IO.Path.GetFileNameWithoutExtension(exeName);
            if (fileName.Contains("安装器") || fileName.Contains("installer", StringComparison.OrdinalIgnoreCase) || fileName.Contains("Installer"))
            {
                isInstallMode = true;
            }
        }
        catch { }

        if (isInstallMode)
        {
            try
            {
                // 检查是否是简单安装器模式
                bool isSimple = args != null && args.Length > 0 && (args[0] == "/simple-install" || args[0] == "-simple-install");
                // 检测文件名包含"普通安装器"或"simple"
                try
                {
                    string exeName = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? "";
                    string fileName = System.IO.Path.GetFileNameWithoutExtension(exeName);
                    if (fileName.Contains("普通安装器") || fileName.Contains("simple", StringComparison.OrdinalIgnoreCase))
                        isSimple = true;
                }
                catch { }

                Window installer;
                // 默认使用普通 Windows 安装程序样式（SimpleInstallerWindow）
                // 仅当文件名包含"高级安装器"或命令行 /advanced-install 时才用 InstallerWindow
                bool isAdvanced = args != null && args.Length > 0 && (args[0] == "/advanced-install" || args[0] == "-advanced-install");
                try
                {
                    string exeName2 = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? "";
                    string fileName2 = System.IO.Path.GetFileNameWithoutExtension(exeName2);
                    if (fileName2.Contains("高级安装器") || fileName2.Contains("advanced", StringComparison.OrdinalIgnoreCase))
                        isAdvanced = true;
                }
                catch { }

                if (isAdvanced)
                    installer = new InstallerWindow();
                else
                    installer = new SimpleInstallerWindow();

                installer.Closed += (_, _) =>
                {
                    _isShuttingDown = true;
                    try { Shutdown(); } catch { }
                };
                installer.Show();
            }
            catch (Exception ex)
            {
                try { MessageBox.Show("安装器启动失败：" + ex.Message, "安装器", MessageBoxButton.OK, MessageBoxImage.Error); } catch { }
                _isShuttingDown = true;
                try { Shutdown(); } catch { }
            }
            return;
        }

        // 设置 TLS 版本，确保网络图片和 HTTPS 请求正常
        System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12 | System.Net.SecurityProtocolType.Tls13;
        System.Net.ServicePointManager.DefaultConnectionLimit = 64;
        // 捕获未处理异常，避免崩溃退出
        DispatcherUnhandledException += (_, args) =>
        {
            try
            {
                System.IO.File.AppendAllText(Path.Combine(SettingsService.GetDataDir(), "crash.txt"),
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {args.Exception}\n\n");
            }
            catch { }
            args.Handled = true;
            MessageBox.Show("启动器发生内部错误，详情已写入数据目录 crash.txt。\n\n" + args.Exception.Message,
                "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
        };

        // 初始化服务
        Services = new AppServices();
        Services.Init();
        Lang.Set(Services.Settings.Config.General.Language);

        // 应用保存的主题颜色
        try
        {
            var accentColor = Services.Settings.Config.General.AccentColor;
            if (!string.IsNullOrEmpty(accentColor))
            {
                var col = (Color)ColorConverter.ConvertFromString(accentColor);
                ApplyAccent(col);
            }
        }
        catch { }

        // 1.0 极简界面统一使用浅色视觉系统，避免深色旧资源与新界面混用
        try
        {
            Services.Settings.Config.General.ThemeMode = "light";
            ApplyTheme("light");
        }
        catch { }

        if (Services.Settings.Config.General.EnableSound)
            PlayStartSound();

        // 先显示启动画面（小窗口），然后异步等待完成后显示主窗口
        try
        {
            var splash = new SplashWindow();
            splash.Show();
            // 异步运行启动检查，完成后显示主窗口
            _ = ShowMainAfterSplashAsync(splash);
        }
        catch
        {
            // 启动画面创建失败，直接显示主窗口
            ShowMainWindowAndAgreement();
        }
    }

    /// <summary>
    /// 等待启动画面完成后显示主窗口
    /// </summary>
    private async System.Threading.Tasks.Task ShowMainAfterSplashAsync(SplashWindow splash)
    {
        try
        {
            // 运行启动检查
            await splash.RunAndCloseAsync();
        }
        catch { }

        // 检查是否正在关闭
        if (_isShuttingDown) return;

        try
        {
            // 等待一下确保启动画面完全关闭
            await System.Threading.Tasks.Task.Delay(100);
        }
        catch { }

        if (_isShuttingDown) return;

        // 在UI线程显示主窗口
        try
        {
            await Current.Dispatcher.InvokeAsync(() =>
            {
                if (!_isShuttingDown)
                    ShowMainWindowAndAgreement();
            });
        }
        catch { }
    }

    /// <summary>
    /// 显示主窗口和用户协议
    /// </summary>
    private void ShowMainWindowAndAgreement()
    {
        try
        {
            // 创建并显示主窗口
            MainWin = new MainWindow();
            // 主窗口关闭时退出应用
            MainWin.Closed += (_, _) =>
            {
                try { Services?.Settings?.Save(); } catch { }
                _isShuttingDown = true;
                try { Shutdown(); } catch { }
            };
            MainWin.Show();
            // 确保主窗口完全渲染和显示
            MainWin.UpdateLayout();
            MainWin.Activate();

            // 首次打开显示用户协议
            if (!Services.Settings.Config.General.AgreedToUserAgreement)
            {
                var dlg = new UserAgreementDialog();
                // 确保主窗口已显示后再设置Owner
                try { dlg.Owner = MainWin; } catch { }
                bool? result = dlg.ShowDialog();
                if (result != true || !dlg.Agreed)
                {
                    try { MessageBox.Show("你未同意用户协议，启动器将退出。", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information); } catch { }
                    _isShuttingDown = true; try { Shutdown(); } catch { }
                    return;
                }
                Services.Settings.Config.General.AgreedToUserAgreement = true;
                Services.Settings.Save();
            }

            // 密码锁验证
            if (!string.IsNullOrEmpty(Services.Settings.Config.General.PasswordHash))
            {
                bool unlocked = false;
                for (int attempts = 0; attempts < 3 && !unlocked; attempts++)
                {
                    var dlg = new PasswordDialog();
                    try { dlg.Owner = MainWin; } catch { }
                    bool? result = dlg.ShowDialog();
                    if (result == true && dlg.PasswordHash == Services.Settings.Config.General.PasswordHash)
                    {
                        unlocked = true;
                    }
                    else if (result == true)
                    {
                        MessageBox.Show($"密码错误，还有 {2 - attempts} 次机会", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else
                    {
                        _isShuttingDown = true; try { Shutdown(); } catch { }
                        return;
                    }
                }
                if (!unlocked)
                {
                    MessageBox.Show("密码错误次数过多，启动器将退出。", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
                    Shutdown();
                    return;
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("启动失败：" + ex.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void PlayStartSound()
    {
        try
        {
            System.Media.SystemSounds.Asterisk.Play();
        }
        catch { }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        try { Services?.PlayTime?.EndAllActiveSessions(); } catch { }
        try { Services?.Settings?.Save(); } catch { }
        base.OnExit(e);
    }

    /// <summary>根据主题切换强调色</summary>
    public static void ApplyAccent(Color color)
    {
        var dict = Current.Resources;
        dict["AccentColor"] = color;
        var accent = new SolidColorBrush(color);
        var dark = new SolidColorBrush(Color.FromArgb(255, (byte)(color.R * 0.78), (byte)(color.G * 0.78), (byte)(color.B * 0.78)));
        dict["AccentBrush"] = accent;
        dict["AccentDarkBrush"] = dark;
    }

    /// <summary>应用主题（1.0 极简界面固定使用浅色视觉系统）</summary>
    public static void ApplyTheme(string theme)
    {
        try
        {
            _ = theme;
            var lightDict = Current.Resources.MergedDictionaries
                .FirstOrDefault(d => d.Source != null && d.Source.OriginalString.Contains("LightTheme"));

            if (lightDict == null)
            {
                lightDict = new ResourceDictionary { Source = new Uri("Themes/LightTheme.xaml", UriKind.Relative) };
                Current.Resources.MergedDictionaries.Add(lightDict);
            }
        }
        catch { }
    }

    /// <summary>重启启动器</summary>
    public static void Restart()
    {
        try
        {
            // 获取当前启动器的路径
            string exePath = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? "";
            if (string.IsNullOrEmpty(exePath))
            {
                MessageBox.Show("无法获取启动器路径，重启失败。", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            // 启动新实例
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = exePath,
                UseShellExecute = true,
                WorkingDirectory = System.IO.Path.GetDirectoryName(exePath) ?? ""
            });
            // 关闭当前实例
            Current.Shutdown();
        }
        catch (Exception ex)
        {
            MessageBox.Show("重启失败：" + ex.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
