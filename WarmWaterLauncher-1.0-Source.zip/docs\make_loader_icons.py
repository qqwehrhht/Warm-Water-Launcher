from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "pcl与温水启动器的源代码" / "WarmWaterLauncher" / "Resources"
OUT.mkdir(parents=True, exist_ok=True)


def rounded(draw, color, radius=18):
    draw.rounded_rectangle((3, 3, 61, 61), radius=radius, fill=color)


def icon(name, bg, draw_fn):
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    rounded(d, bg)
    draw_fn(d)
    im.save(OUT / f"loader_{name}.png", optimize=True)


def fabric(d):
    # woven loom: warm cream with brown threads and teal shuttle
    d.line((18, 18, 46, 46), fill=(78, 58, 42), width=6)
    d.line((46, 18, 18, 46), fill=(78, 58, 42), width=6)
    d.rectangle((27, 14, 37, 50), fill=(237, 227, 209))
    d.rectangle((14, 27, 50, 37), fill=(237, 227, 209))
    d.rectangle((27, 27, 37, 37), fill=(64, 180, 170))


def forge(d):
    # stylized anvil
    d.rectangle((18, 20, 46, 27), fill=(255, 255, 255))
    d.polygon([(23, 27), (41, 27), (36, 39), (28, 39)], fill=(255, 255, 255))
    d.rectangle((29, 39, 35, 46), fill=(255, 255, 255))
    d.rectangle((21, 46, 43, 50), fill=(255, 255, 255))


def quilt(d):
    # patchwork
    d.rectangle((16, 16, 30, 30), fill=(255, 255, 255))
    d.rectangle((34, 16, 48, 30), fill=(253, 230, 138))
    d.rectangle((16, 34, 30, 48), fill=(196, 181, 253))
    d.rectangle((34, 34, 48, 48), fill=(255, 255, 255))
    d.line((32, 15, 32, 49), fill=(76, 29, 149), width=2)
    d.line((15, 32, 49, 32), fill=(76, 29, 149), width=2)


def optifine(d):
    d.ellipse((17, 17, 47, 47), outline=(255, 255, 255), width=7)
    d.rectangle((38, 36, 49, 41), fill=(255, 255, 255))


def neoforge(d):
    d.line((18, 47, 18, 17), fill=(255, 255, 255), width=7)
    d.line((18, 17, 46, 47), fill=(255, 255, 255), width=7)
    d.line((46, 47, 46, 17), fill=(255, 255, 255), width=7)


icon("fabric", (224, 211, 190), fabric)
icon("forge", (224, 100, 47), forge)
icon("quilt", (124, 86, 214), quilt)
icon("optifine", (58, 145, 78), optifine)
icon("neoforge", (230, 96, 45), neoforge)
print("loader icons generated")
