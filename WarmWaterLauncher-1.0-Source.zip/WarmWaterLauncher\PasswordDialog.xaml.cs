using System.Security.Cryptography;
using System.Text;
using System.Windows;

namespace WarmWaterLauncher;

public partial class PasswordDialog : Window
{
    public string PasswordHash { get; private set; } = "";

    public PasswordDialog()
    {
        InitializeComponent();
        Loaded += (_, _) => PwdBox.Focus();
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        var pwd = PwdBox.Password;
        if (string.IsNullOrEmpty(pwd))
        {
            MessageBox.Show("请输入密码", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        using var sha = SHA256.Create();
        var hash = sha.ComputeHash(Encoding.UTF8.GetBytes(pwd));
        PasswordHash = Convert.ToHexString(hash).ToLowerInvariant();
        DialogResult = true;
        Close();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }

    public static string HashPassword(string password)
    {
        using var sha = SHA256.Create();
        var hash = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToHexString(hash).ToLowerInvariant();
    }
}
