using System.IO;
using System.IO.Compression;
using System.Text.Json;

namespace WarmWaterLauncher.Services;

/// <summary>游戏存档备份与恢复服务</summary>
public class WorldBackupService
{
    private readonly string _backupDir;

    public WorldBackupService()
    {
        _backupDir = Path.Combine(SettingsService.GetDataDir(), "backups");
        Directory.CreateDirectory(_backupDir);
    }

    /// <summary>获取实例的存档目录</summary>
    public string? GetSavesDir(string instancePath)
    {
        var savesDir = Path.Combine(instancePath, ".minecraft", "saves");
        if (!Directory.Exists(savesDir))
            savesDir = Path.Combine(instancePath, "saves");
        return Directory.Exists(savesDir) ? savesDir : null;
    }

    /// <summary>列出实例中的所有存档</summary>
    public List<WorldInfo> ListWorlds(string instancePath)
    {
        var worlds = new List<WorldInfo>();
        var savesDir = GetSavesDir(instancePath);
        if (savesDir == null) return worlds;

        foreach (var dir in Directory.GetDirectories(savesDir))
        {
            var info = new WorldInfo
            {
                Name = Path.GetFileName(dir),
                Path = dir,
                SizeBytes = GetDirectorySize(dir),
                LastModified = Directory.GetLastWriteTime(dir)
            };

            // 尝试读取 level.dat 中的存档名
            try
            {
                var levelDat = Path.Combine(dir, "level.dat");
                if (File.Exists(levelDat))
                    info.HasLevelDat = true;
            }
            catch { }

            // 读取图标
            var iconPath = Path.Combine(dir, "icon.png");
            if (File.Exists(iconPath))
                info.IconPath = iconPath;

            worlds.Add(info);
        }
        return worlds.OrderByDescending(w => w.LastModified).ToList();
    }

    /// <summary>备份一个存档</summary>
    public async Task<BackupInfo?> BackupWorldAsync(string worldPath, string? note = null, IProgress<string>? progress = null)
    {
        try
        {
            var worldName = Path.GetFileName(worldPath);
            var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            var backupId = $"{worldName}_{timestamp}";
            var backupPath = Path.Combine(_backupDir, backupId + ".zip");

            progress?.Report($"正在备份存档「{worldName}」...");

            // 创建 zip 备份
            await Task.Run(() =>
            {
                if (File.Exists(backupPath)) File.Delete(backupPath);
                ZipFile.CreateFromDirectory(worldPath, backupPath, CompressionLevel.Optimal, false);
            });

            var backup = new BackupInfo
            {
                Id = backupId,
                WorldName = worldName,
                WorldPath = worldPath,
                BackupPath = backupPath,
                SizeBytes = new FileInfo(backupPath).Length,
                CreatedAt = DateTime.Now,
                Note = note ?? ""
            };

            SaveBackupMeta(backup);
            progress?.Report($"备份完成：{FormatSize(backup.SizeBytes)}");
            return backup;
        }
        catch (Exception ex)
        {
            progress?.Report($"备份失败：{ex.Message}");
            return null;
        }
    }

    /// <summary>恢复一个存档备份</summary>
    public async Task<bool> RestoreBackupAsync(string backupId, string targetSavesDir, IProgress<string>? progress = null)
    {
        try
        {
            var backup = GetBackup(backupId);
            if (backup == null || !File.Exists(backup.BackupPath))
            {
                progress?.Report("备份文件不存在");
                return false;
            }

            var targetPath = Path.Combine(targetSavesDir, backup.WorldName);

            progress?.Report($"正在恢复存档「{backup.WorldName}」...");

            // 如果目标已存在，先重命名为 .old
            if (Directory.Exists(targetPath))
            {
                var oldPath = targetPath + ".old_" + DateTime.Now.ToString("HHmmss");
                Directory.Move(targetPath, oldPath);
            }

            // 解压备份
            await Task.Run(() =>
            {
                Directory.CreateDirectory(targetPath);
                ZipFile.ExtractToDirectory(backup.BackupPath, targetPath);
            });

            progress?.Report("恢复完成！");
            return true;
        }
        catch (Exception ex)
        {
            progress?.Report($"恢复失败：{ex.Message}");
            return false;
        }
    }

    /// <summary>列出所有备份</summary>
    public List<BackupInfo> ListBackups()
    {
        var backups = new List<BackupInfo>();
        var metaDir = Path.Combine(_backupDir, "meta");
        if (!Directory.Exists(metaDir)) return backups;

        foreach (var f in Directory.GetFiles(metaDir, "*.json"))
        {
            try
            {
                var json = File.ReadAllText(f);
                var backup = JsonSerializer.Deserialize<BackupInfo>(json, SettingsService.JsonOpts);
                if (backup != null) backups.Add(backup);
            }
            catch { }
        }
        return backups.OrderByDescending(b => b.CreatedAt).ToList();
    }

    /// <summary>删除一个备份</summary>
    public bool DeleteBackup(string backupId)
    {
        try
        {
            var backup = GetBackup(backupId);
            if (backup == null) return false;
            if (File.Exists(backup.BackupPath)) File.Delete(backup.BackupPath);
            var metaPath = Path.Combine(_backupDir, "meta", backupId + ".json");
            if (File.Exists(metaPath)) File.Delete(metaPath);
            return true;
        }
        catch { return false; }
    }

    private BackupInfo? GetBackup(string backupId)
    {
        var metaPath = Path.Combine(_backupDir, "meta", backupId + ".json");
        if (!File.Exists(metaPath)) return null;
        try
        {
            var json = File.ReadAllText(metaPath);
            return JsonSerializer.Deserialize<BackupInfo>(json, SettingsService.JsonOpts);
        }
        catch { return null; }
    }

    private void SaveBackupMeta(BackupInfo backup)
    {
        try
        {
            var metaDir = Path.Combine(_backupDir, "meta");
            Directory.CreateDirectory(metaDir);
            var json = JsonSerializer.Serialize(backup, SettingsService.JsonOpts);
            File.WriteAllText(Path.Combine(metaDir, backup.Id + ".json"), json);
        }
        catch { }
    }

    private static long GetDirectorySize(string path)
    {
        try
        {
            return Directory.GetFiles(path, "*", SearchOption.AllDirectories).Sum(f => new FileInfo(f).Length);
        }
        catch { return 0; }
    }

    public static string FormatSize(long bytes)
    {
        if (bytes < 1024) return $"{bytes} B";
        if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F1} KB";
        if (bytes < 1024 * 1024 * 1024) return $"{bytes / 1024.0 / 1024.0:F1} MB";
        return $"{bytes / 1024.0 / 1024.0 / 1024.0:F2} GB";
    }
}

public class WorldInfo
{
    public string Name { get; set; } = "";
    public string Path { get; set; } = "";
    public long SizeBytes { get; set; }
    public DateTime LastModified { get; set; }
    public bool HasLevelDat { get; set; }
    public string? IconPath { get; set; }
    public string SizeText => WorldBackupService.FormatSize(SizeBytes);
}

public class BackupInfo
{
    public string Id { get; set; } = "";
    public string WorldName { get; set; } = "";
    public string WorldPath { get; set; } = "";
    public string BackupPath { get; set; } = "";
    public long SizeBytes { get; set; }
    public DateTime CreatedAt { get; set; }
    public string Note { get; set; } = "";
    public string SizeText => WorldBackupService.FormatSize(SizeBytes);
}
