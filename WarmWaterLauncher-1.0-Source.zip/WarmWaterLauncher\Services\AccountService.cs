using System.Text.Json;
using WarmWaterLauncher.Models;

namespace WarmWaterLauncher.Services;

/// <summary>账号服务：离线账号创建、多账号保存切换、皮肤披风、加密凭证</summary>
public class AccountService
{
    private readonly SettingsService _settings;
    public AccountService(SettingsService settings) => _settings = settings;

    public List<Account> Accounts => _settings.Config.Accounts;

    public Account? Current
    {
        get
        {
            var id = _settings.Config.CurrentAccountId;
            return Accounts.FirstOrDefault(a => a.Id == id) ?? Accounts.FirstOrDefault();
        }
    }

    /// <summary>创建离线账号</summary>
    public Account CreateOffline(string name)
    {
        name = name.Trim();
        if (string.IsNullOrEmpty(name) || name.Length > 16)
            throw new Exception("离线账号名称需为 1-16 个字符");

        var acct = new Account
        {
            Type = "offline",
            Name = name,
            Uuid = GenerateOfflineUuid(name),
            // 离线账号使用 Minotar 服务获取默认头像（基于用户名）
            AvatarUrl = $"https://minotar.net/avatar/{Uri.EscapeDataString(name)}/128"
        };
        Accounts.Add(acct);
        _settings.Save();
        return acct;
    }

    /// <summary>离线 UUID（基于名称确定性生成，与 PCL/Minecraft 一致）</summary>
    public static string GenerateOfflineUuid(string name)
    {
        // 使用 name 的 MD5 生成确定性 UUID
        using var md5 = System.Security.Cryptography.MD5.Create();
        var hash = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes("OfflinePlayer:" + name));
        var bytes = new byte[16];
        Array.Copy(hash, bytes, 16);
        // 设置 version 3 与 variant
        bytes[6] = (byte)((bytes[6] & 0x0F) | 0x30);
        bytes[8] = (byte)((bytes[8] & 0x3F) | 0x80);
        var g = new Guid(bytes);
        return g.ToString();
    }

    /// <summary>保存微软账号（凭证加密存储）</summary>
    public Account SaveMicrosoft(string name, string uuid, string accessToken, string? refreshToken, long expiresAt, string? avatarUrl = null)
    {
        var acct = new Account
        {
            Type = "microsoft",
            Name = name,
            Uuid = uuid,
            AccessToken = CryptoService.Encrypt(accessToken),
            RefreshToken = CryptoService.Encrypt(refreshToken),
            ExpiresAt = expiresAt,
            AvatarUrl = avatarUrl
        };
        Accounts.Add(acct);
        _settings.Save();
        return acct;
    }

    /// <summary>保存第三方皮肤站账号</summary>
    public Account SaveThirdParty(string name, string uuid, string accessToken, string clientToken, string apiBase, string email)
    {
        var acct = new Account
        {
            Type = "thirdparty",
            Name = name,
            Uuid = uuid,
            AccessToken = CryptoService.Encrypt(accessToken),
            RefreshToken = CryptoService.Encrypt(clientToken),
            ExpiresAt = 0,
            ThirdPartyApi = apiBase,
            ThirdPartyEmail = email
        };
        Accounts.Add(acct);
        _settings.Save();
        return acct;
    }

    /// <summary>获取明文 access token</summary>
    public string? GetToken(Account acct) => CryptoService.Decrypt(acct.AccessToken) ?? acct.AccessToken;

    /// <summary>切换当前账号</summary>
    public void Switch(string accountId)
    {
        if (Accounts.Any(a => a.Id == accountId))
        {
            _settings.Config.CurrentAccountId = accountId;
            var acct = Accounts.First(a => a.Id == accountId);
            acct.LastUsed = DateTime.Now;
            _settings.Save();
        }
    }

    public void Delete(string accountId)
    {
        var acct = Accounts.FirstOrDefault(a => a.Id == accountId);
        if (acct == null) return;
        // 删除皮肤文件
        try
        {
            if (!string.IsNullOrEmpty(acct.SkinPath) && File.Exists(acct.SkinPath)) File.Delete(acct.SkinPath);
            if (!string.IsNullOrEmpty(acct.CapePath) && File.Exists(acct.CapePath)) File.Delete(acct.CapePath);
        }
        catch { }
        Accounts.Remove(acct);
        if (_settings.Config.CurrentAccountId == accountId)
            _settings.Config.CurrentAccountId = Accounts.FirstOrDefault()?.Id;
        _settings.Save();
    }

    /// <summary>设置离线账号皮肤/披风（复制到数据目录）</summary>
    public void SetSkin(Account acct, string? skinPath, string? capePath)
    {
        string skinDir = Path.Combine(SettingsService.GetDataDir(), "skins");
        Directory.CreateDirectory(skinDir);
        if (skinPath != null && File.Exists(skinPath))
        {
            var ext = Path.GetExtension(skinPath);
            var dest = Path.Combine(skinDir, acct.Id + "_skin" + ext);
            File.Copy(skinPath, dest, true);
            acct.SkinPath = dest;
        }
        if (capePath != null && File.Exists(capePath))
        {
            var ext = Path.GetExtension(capePath);
            var dest = Path.Combine(skinDir, acct.Id + "_cape" + ext);
            File.Copy(capePath, dest, true);
            acct.CapePath = dest;
        }
        _settings.Save();
    }

    /// <summary>离线皮肤生效说明：离线服务器需配合皮肤 Mod/插件</summary>
    public string SkinNote => "离线账号的皮肤/披风保存在本地。进入多人服务器时需服务器安装皮肤插件（如 SkinsRestorer）或客户端安装皮肤 Mod 才能向其他玩家展示。";
}
