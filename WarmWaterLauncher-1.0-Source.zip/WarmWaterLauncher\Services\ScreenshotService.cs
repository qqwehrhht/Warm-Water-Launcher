using System.IO;

namespace WarmWaterLauncher.Services;

/// <summary>游戏截图管理服务</summary>
public class ScreenshotService
{
    /// <summary>获取实例的截图目录</summary>
    public string? GetScreenshotsDir(string instancePath)
    {
        var dir = Path.Combine(instancePath, ".minecraft", "screenshots");
        if (!Directory.Exists(dir))
            dir = Path.Combine(instancePath, "screenshots");
        return Directory.Exists(dir) ? dir : null;
    }

    /// <summary>列出实例中的所有截图</summary>
    public List<ScreenshotInfo> ListScreenshots(string instancePath)
    {
        var shots = new List<ScreenshotInfo>();
        var dir = GetScreenshotsDir(instancePath);
        if (dir == null) return shots;

        var exts = new[] { ".png", ".jpg", ".jpeg" };
        foreach (var f in Directory.GetFiles(dir)
                     .Where(f => exts.Contains(Path.GetExtension(f).ToLower()))
                     .OrderByDescending(f => File.GetLastWriteTime(f)))
        {
            try
            {
                var info = new FileInfo(f);
                shots.Add(new ScreenshotInfo
                {
                    FileName = Path.GetFileName(f),
                    FullPath = f,
                    SizeBytes = info.Length,
                    CreatedAt = info.CreationTime,
                    LastModified = info.LastWriteTime
                });
            }
            catch { }
        }
        return shots;
    }

    /// <summary>删除截图</summary>
    public bool DeleteScreenshot(string path)
    {
        try
        {
            if (File.Exists(path))
            {
                File.Delete(path);
                return true;
            }
        }
        catch { }
        return false;
    }

    /// <summary>复制截图到指定目录</summary>
    public bool CopyScreenshot(string sourcePath, string targetDir)
    {
        try
        {
            Directory.CreateDirectory(targetDir);
            var target = Path.Combine(targetDir, Path.GetFileName(sourcePath));
            File.Copy(sourcePath, target, true);
            return true;
        }
        catch { return false; }
    }

    /// <summary>打开截图所在文件夹</summary>
    public void OpenScreenshotFolder(string instancePath)
    {
        var dir = GetScreenshotsDir(instancePath);
        if (dir != null)
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }
}

public class ScreenshotInfo
{
    public string FileName { get; set; } = "";
    public string FullPath { get; set; } = "";
    public long SizeBytes { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime LastModified { get; set; }
    public string SizeText => WorldBackupService.FormatSize(SizeBytes);
    public string DateText => LastModified.ToString("yyyy-MM-dd HH:mm");
}
