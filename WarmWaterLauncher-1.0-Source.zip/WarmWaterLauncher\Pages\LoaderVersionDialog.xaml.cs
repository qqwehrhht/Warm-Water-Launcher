using System.Windows;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

/// <summary>下载游戏版本时选择要安装的模组加载器版本。</summary>
public partial class LoaderVersionDialog : Window
{
    private sealed class Choice
    {
        public LoaderVersion Version { get; init; } = new();
        public string Display => Version.Display;
        public string BuildText => string.IsNullOrEmpty(Version.Build) ? "可安装" : "Build " + Version.Build;
        public string IconPath { get; init; } = "";
    }

    public LoaderVersion? Selected { get; private set; }

    public LoaderVersionDialog(string loaderType, string mcVersion, IEnumerable<LoaderVersion> versions)
    {
        InitializeComponent();
        var loaderName = LoaderCatalog.DisplayName(loaderType);
        TitleText.Text = $"选择 {loaderName} 版本";
        SubtitleText.Text = $"游戏版本 {mcVersion} · 选择一个要安装的加载器版本";
        LoaderIcon.Source = new System.Windows.Media.Imaging.BitmapImage(
            new Uri(LoaderCatalog.IconPath(loaderType), UriKind.Relative));
        HintText.Text = $"将为 {mcVersion} 安装 {loaderName}，安装完成后可在实例管理中启动。";

        var list = versions.Select(v => new Choice
        {
            Version = v,
            IconPath = LoaderCatalog.IconPath(loaderType)
        }).ToList();
        VersionList.ItemsSource = list;
        if (list.Count > 0) VersionList.SelectedIndex = 0;
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (VersionList.SelectedItem is not Choice choice)
        {
            MessageBox.Show("请选择一个加载器版本。", "选择加载器版本", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        Selected = choice.Version;
        DialogResult = true;
        Close();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }
}
