using System.Diagnostics;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageHome : UserControl, IActivatePage
{
    private bool _launching;
    private CancellationTokenSource? _launchCts;
    private System.Windows.Threading.DispatcherTimer? _animTimer;
    private Border? _stepPulseDot;
    private int _currentLaunchStep;

    public PageHome()
    {
        InitializeComponent();
        DataContext = this;
        // 订阅游戏崩溃事件
        LaunchService.GameCrashed += OnGameCrashed;
    }

    private CrashAnalysis? _lastCrash;
    private void OnGameCrashed(object? sender, CrashAnalysis crash)
    {
        _lastCrash = crash;
        Dispatcher.Invoke(() =>
        {
            CrashPanel.Visibility = Visibility.Visible;
            CrashTitle.Text = "游戏崩溃 - " + crash.CrashType switch
            {
                CrashType.OutOfMemory => "内存不足",
                CrashType.JavaVersionMismatch => "Java 版本不兼容",
                CrashType.GraphicsIssue => "显卡/OpenGL 问题",
                CrashType.ModConflict => "模组冲突/依赖缺失",
                CrashType.ModCrash => "模组崩溃",
                CrashType.CorruptedFiles => "游戏文件损坏",
                CrashType.LoaderIssue => "加载器问题",
                CrashType.OptiFineConflict => "OptiFine 冲突",
                CrashType.JvmCrash => "JVM 虚拟机崩溃",
                _ => "未知原因"
            };
            CrashCause.Text = "崩溃原因：" + crash.Cause;
            var info = $"退出码：{crash.ExitCode}";
            if (!string.IsNullOrEmpty(crash.GameVersion)) info += $" · 游戏版本：{crash.GameVersion}";
            if (!string.IsNullOrEmpty(crash.LoaderVersion)) info += $" · 加载器：{crash.LoaderVersion}";
            if (!string.IsNullOrEmpty(crash.JavaVersion)) info += $" · Java：{crash.JavaVersion}";
            if (crash.SuspiciousMods.Count > 0) info += $"\n可疑模组：{string.Join("、", crash.SuspiciousMods.Take(5))}";
            CrashInfo.Text = info;
            CrashAdvice.Text = crash.Advice;
        });
    }

    private void CloseCrashPanel_Click(object sender, RoutedEventArgs e)
    {
        CrashPanel.Visibility = Visibility.Collapsed;
    }

    private void ViewCrashLog_Click(object sender, RoutedEventArgs e)
    {
        (App.MainWin as MainWindow)?.Navigate("logs");
    }

    private void CopyCrashAdvice_Click(object sender, RoutedEventArgs e)
    {
        if (_lastCrash != null)
        {
            try
            {
                System.Windows.Clipboard.SetText($"崩溃原因：{_lastCrash.Cause}\n\n解决办法：\n{_lastCrash.Advice}");
                MessageBox.Show("解决办法已复制到剪贴板", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch { }
        }
    }

    private async void VerifyGameFiles_Click(object sender, RoutedEventArgs e)
    {
        var inst = App.Services.Instances.Current;
        if (inst == null) return;
        var btn = sender as Button;
        if (btn != null) btn.IsEnabled = false;
        try
        {
            CrashAdvice.Text = "正在校验游戏文件...";
            var (checkedCount, brokenCount) = await App.Services.Launcher.VerifyGameFiles(inst);
            if (brokenCount == 0)
                CrashAdvice.Text = $"校验完成！共检查 {checkedCount} 个文件，全部正常。";
            else
                CrashAdvice.Text = $"校验完成！共检查 {checkedCount} 个文件，发现 {brokenCount} 个损坏文件。\n建议：重新下载当前游戏版本以修复损坏文件。";
        }
        finally
        {
            if (btn != null) btn.IsEnabled = true;
        }
    }

    public void OnActivate()
    {
        Refresh();
    }

    private void Refresh()
    {
        TodayText.Text = $"{DateTime.Now:yyyy年M月d日 dddd} · 准备好开始新的冒险。";

        // 更新快速统计
        try
        {
            StatLaunchCount.Text = App.Services.Settings.Config.General.GameLaunchCount.ToString();
            var allInstances = App.Services.Instances.Instances;
            StatInstanceCount.Text = allInstances.Count.ToString();
            var allVersions = App.Services.Versions.GetInstalledVersions();
            StatVersionCount.Text = allVersions.Count.ToString();
            int modCount = 0;
            foreach (var instItem in allInstances)
            {
                try { modCount += App.Services.Mods.ListMods(instItem).Count; } catch { }
            }
            StatModCount.Text = modCount.ToString();
        }
        catch { }

        var acct = App.Services.Accounts.Current;
        AcctName.Text = acct?.Name ?? "未登录";
        AcctName.Foreground = acct == null ? (System.Windows.Media.Brush)FindResource("WarnBrush") : (System.Windows.Media.Brush)FindResource("TextBrush");

        // 更新头像显示（异步加载，使用缓存和多源 fallback）
        if (acct != null)
        {
            AcctAvatarBorder.Visibility = System.Windows.Visibility.Visible;
            _ = LoadAvatarAsync(acct);
        }
        else
        {
            AcctAvatarBorder.Visibility = System.Windows.Visibility.Collapsed;
            AcctAvatar.Source = null;
        }

        var inst = App.Services.Instances.Current;
        if (inst != null)
        {
            InstName.Text = inst.Name;
            var loader = inst.LoaderType == "none" ? "原版" : inst.LoaderType;
            var loaderFull = loader + (string.IsNullOrEmpty(inst.LoaderVersion) ? "" : " " + inst.LoaderVersion);
            InstDetail.Text = $"{loaderFull} · 已游玩 {inst.PlayCount} 次"
                              + (inst.LastPlayed > DateTime.MinValue ? " · 上次 " + inst.LastPlayed.ToString("MM-dd HH:mm") : "")
                              + "\n一切就绪，按自己的节奏继续这个世界。";
            HeroVersionText.Text = "版本 " + inst.VersionId;
            HeroLoaderText.Text = "加载器 " + loaderFull;
            try { HeroPlayTimeText.Text = "时长 " + PlayTimeService.FormatDuration(App.Services.PlayTime.GetInstanceSeconds(inst.Id)); }
            catch { HeroPlayTimeText.Text = "时长 —"; }
            IsolationText.Text = IsolationModeHelper.Name(IsolationModeHelper.Parse(App.Services.Settings.Config.Launch.IsolationMode));
        }
        else
        {
            InstName.Text = "未选择实例";
            InstDetail.Text = "请先到「实例管理」创建实例，或到「下载」页安装游戏版本。\n创建后，这里会显示你的世界与最近游玩记录。";
            HeroVersionText.Text = "版本 —";
            HeroLoaderText.Text = "加载器 —";
            HeroPlayTimeText.Text = "时长 —";
            IsolationText.Text = "";
        }

        // Java 状态
        var javas = App.Services.Java.DetectAll();
        if (javas.Count > 0)
            JavaText.Text = $"已检测到 {javas.Count} 个 Java（最新 {javas.Max(j => j.Major)}）";
        else
            JavaText.Text = "未检测到 Java，请到「Java 管理」一键下载";

        // 游戏时长统计
        try
        {
            var totalSec = App.Services.PlayTime.GetTotalSeconds();
            var todaySec = App.Services.PlayTime.GetTodaySeconds();
            var instSec = inst != null ? App.Services.PlayTime.GetInstanceSeconds(inst.Id) : 0;
            PlayTimeText.Text = $"总计 {PlayTimeService.FormatDuration(totalSec)} · 今日 {PlayTimeService.FormatDuration(todaySec)}"
                                + (inst != null ? $" · 本实例 {PlayTimeService.FormatDuration(instSec)}" : "");
        }
        catch { PlayTimeText.Text = "总计 0 分钟"; }
        // 更新成就显示
        try
        {
            AchievementText.Text = $"{App.Services.Achievements.UnlockedCount} / {App.Services.Achievements.TotalCount} 已解锁";
        }
        catch { AchievementText.Text = "0 / 0 已解锁"; }

        // 账号列表（先设null再设值，强制刷新UI）
        AccountList.ItemsSource = null;
        AccountList.ItemsSource = App.Services.Accounts.Accounts.ToList();
        NoAccountText.Visibility = App.Services.Accounts.Accounts.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        // 异步加载所有账号头像
        _ = LoadAllAvatarsAsync();

        // 皮肤
        var current = App.Services.Accounts.Current;
        SkinInfo.Text = current == null ? "未设置" :
            (current.SkinPath == null && current.CapePath == null ? "未设置" :
             $"{Path.GetFileName(current.SkinPath ?? "-")} · {Path.GetFileName(current.CapePath ?? "-")}");
    }

    public async Task LaunchAsync()
    {
        if (_launching) return;
        var inst = App.Services.Instances.Current;
        var acct = App.Services.Accounts.Current;
        if (inst == null) { MessageBox.Show("请先创建实例", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        if (acct == null) { MessageBox.Show("请先创建账号", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information); return; }

        // Java 版本检测
        var javaCheck = await CheckJavaVersionAsync(inst);
        if (!javaCheck.Ok)
        {
            var r = MessageBox.Show(javaCheck.Message + "\n\n是否前往 Java 管理页面下载适配的 Java？",
                "Java 版本不匹配", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r == MessageBoxResult.Yes)
            {
                (App.MainWin as MainWindow)?.Navigate("java");
                return;
            }
        }

        // 内存不足警告
        long totalMem = GetTotalMemoryMb();
        if (totalMem > 0 && App.Services.Settings.Config.Launch.MaxMemory > totalMem * 0.9)
        {
            var r = MessageBox.Show($"你的电脑总内存约 {totalMem} MB，当前设置最大内存 {App.Services.Settings.Config.Launch.MaxMemory} MB 偏高，可能造成卡顿或无法启动。\n是否降低最大内存？",
                "内存警告", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r == MessageBoxResult.Yes)
            {
                App.Services.Settings.Config.Launch.MaxMemory = (int)(totalMem * 0.6);
                App.Services.Settings.Save();
            }
        }

        // 启动倒计时
        int countdown = App.Services.Settings.Config.General.LaunchCountdown;
        if (countdown > 0)
        {
            bool cancelled = false;
            var originalContent = LaunchBtn.Content;
            for (int i = countdown; i > 0; i--)
            {
                LaunchBtn.Content = $"{i} 秒后启动（点击取消）";
                await Task.Delay(1000);
                if (_launchCts != null && _launchCts.IsCancellationRequested)
                {
                    cancelled = true;
                    break;
                }
            }
            if (cancelled)
            {
                LaunchBtn.Content = originalContent;
                LaunchBtn.IsEnabled = true;
                return;
            }
            LaunchBtn.Content = originalContent;
        }

        _launching = true;
        _launchCts = new CancellationTokenSource();
        LaunchBtn.IsEnabled = false;
        CancelLaunchBtn.Visibility = Visibility.Visible;
        LaunchAnimBorder.Visibility = Visibility.Visible;
        ProgressFill.Width = 0;
        LaunchPercentText.Text = "0%";
        LaunchAnimTitle.Text = "正在启动游戏";
        ResetLaunchSteps();
        UpdateLaunchSteps(1, "正在检查游戏文件并补全...");
        StartLaunchAnimation();

        var progress = new Progress<LaunchProgress>(p =>
        {
            if (p.Step > 0 && (p.Step >= _currentLaunchStep || _currentLaunchStep == 0))
                UpdateLaunchSteps(p.Step, p.Status);
            LaunchAnimStatus.Text = p.Status;
            LaunchStatus.Text = p.Status;
            double pct = Math.Max(0, Math.Min(100, p.Percent * 100));
            LaunchPercentText.Text = $"{pct:F0}%";
            // 进度条填充宽度（父容器宽度 * 百分比）
            if (ProgressFill.Parent is Border parent)
            {
                ProgressFill.Width = Math.Max(0, parent.ActualWidth * pct / 100.0);
            }
            // 任务栏进度
            try { MainWindow.Get()?.SetTaskbarProgress(pct, p.Done ? "None" : "Normal"); } catch { }
        });

        LaunchAnimStatus.Text = "准备启动...";
        try
        {
            var result = await App.Services.Launcher.LaunchAsync(inst, acct, progress, _launchCts.Token);
            if (result.Ok)
            {
                // 更新成就
                try
                {
                    App.Services.Achievements.Unlock("first_launch");
                    var totalSec = App.Services.PlayTime.GetTotalSeconds();
                    App.Services.Achievements.UpdateProgress("play_1h", (int)totalSec);
                    App.Services.Achievements.UpdateProgress("play_10h", (int)totalSec);
                    App.Services.Achievements.UpdateProgress("play_100h", (int)totalSec);
                    // 夜猫子/早起鸟成就
                    var hour = DateTime.Now.Hour;
                    if (hour >= 2 || hour < 6) App.Services.Achievements.Unlock("night_owl");
                    if (hour >= 4 && hour < 7) App.Services.Achievements.Unlock("early_bird");
                    // 版本数量成就
                    var versions = App.Services.Versions.GetInstalledVersions();
                    App.Services.Achievements.UpdateProgress("install_5_versions", versions.Count);
                    // 模组数量成就：扫描实际 mod 目录
                    try
                    {
                        string gameDir = App.Services.Instances.GetInstanceGameDir(inst);
                        string modDir = Path.Combine(gameDir, "mods");
                        int modCount = Directory.Exists(modDir) ? Directory.GetFiles(modDir, "*.jar").Length : 0;
                        App.Services.Achievements.UpdateProgress("install_10_mods", modCount);
                    }
                    catch { }

                    // 启动次数统计和里程碑提醒
                    try
                    {
                        var cfg = App.Services.Settings.Config;
                        cfg.General.GameLaunchCount++;
                        cfg.General.LastLaunchTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        App.Services.Settings.Save();

                        // 检查是否达到里程碑（使用MilestoneService）
                        int count = cfg.General.GameLaunchCount;
                        var newMilestones = MilestoneService.CheckNewMilestones();

                        if (newMilestones.Count > 0)
                        {
                            cfg.General.LastRemindedLaunchCount = count;
                            App.Services.Settings.Save();

                            // 检查是否是离线账户
                            bool isOffline = App.Services.Accounts.Current?.Type == "offline";

                            // 延迟弹出提醒（等启动动画结束后）
                            _ = Task.Run(async () =>
                            {
                                await Task.Delay(3000);
                                Dispatcher.Invoke(() =>
                                {
                                    try
                                    {
                                        // 先弹出里程碑达成提示
                                        var latest = newMilestones[newMilestones.Count - 1];
                                        MessageBox.Show($"🎉 恭喜达成里程碑：{latest.Icon} {latest.Title}！\n\n{latest.Description}\n奖励：{latest.Reward}", "里程碑达成", MessageBoxButton.OK, MessageBoxImage.Information);

                                        // 再弹出赞助提醒
                                        var dlg = new SponsorReminderDialog(count, isOffline);
                                        dlg.Owner = App.MainWin;
                                        dlg.ShowDialog();
                                    }
                                    catch { }
                                });
                            });
                        }
                    }
                    catch { }
                }
                catch { }
                LaunchAnimTitle.Text = "游戏已启动";
                LaunchAnimStatus.Text = $"启动命令已发送（准备耗时 {result.LaunchMs / 1000.0:0.0}s），正在检测游戏窗口...";
                LaunchStatus.Text = $"启动命令已发送（准备耗时 {result.LaunchMs / 1000.0:0.0}s），正在检测游戏窗口...";
                LaunchPercentText.Text = "100%";
                if (ProgressFill.Parent is Border parent) ProgressFill.Width = parent.ActualWidth;
                UpdateLaunchSteps(5, "正在检测游戏窗口是否弹出...");

                bool windowSeen = await WaitForGameWindowAsync(result.Process, _launchCts.Token);
                if (windowSeen)
                {
                    UpdateLaunchSteps(5, "游戏窗口已弹出", true);
                    LaunchAnimTitle.Text = "游戏窗口已弹出";
                    LaunchAnimStatus.Text = "游戏窗口已成功显示";
                    LaunchStatus.Text = "游戏窗口已弹出，日志已记录，可在「日志」页查看。";
                    bool autoSwitch = App.Services.Settings.Config.General.AutoSwitchToLogsOnGameWindow;
                    if (autoSwitch)
                    {
                        MainWindow.Get()?.ShowToast("游戏窗口已弹出", "已自动切换到日志页，可在设置中关闭此行为");
                        await Task.Delay(600);
                        (App.MainWin as MainWindow)?.Navigate("logs");
                    }
                    else
                    {
                        LaunchStatus.Text = "游戏窗口已弹出。已按设置保留在当前页面，可手动打开日志页。";
                    }
                }
                else if (result.Process?.HasExited == true)
                {
                    UpdateLaunchSteps(5, "游戏进程在窗口出现前退出，请查看日志", false, true);
                    LaunchAnimTitle.Text = "游戏提前退出";
                    LaunchAnimStatus.Text = "未检测到游戏窗口，请查看日志";
                    LaunchStatus.Text = "游戏进程已退出，未检测到游戏窗口，请打开「日志」页排查。";
                }
                else
                {
                    UpdateLaunchSteps(5, "等待游戏窗口超时，请手动查看日志", false, true);
                    LaunchAnimTitle.Text = "未能确认游戏窗口";
                    LaunchAnimStatus.Text = "等待窗口超时，游戏可能仍在加载";
                    LaunchStatus.Text = "60 秒内未检测到游戏窗口，请打开「日志」页确认游戏状态。";
                }
            }
            else if (_launchCts.IsCancellationRequested)
            {
                UpdateLaunchSteps(Math.Max(1, _currentLaunchStep), "启动已取消", false, true);
                LaunchAnimTitle.Text = "已取消";
                LaunchAnimStatus.Text = "启动已取消";
                LaunchStatus.Text = "启动已取消";
            }
            else
            {
                UpdateLaunchSteps(Math.Max(1, _currentLaunchStep), result.Error ?? "启动失败", false, true);
                LaunchAnimTitle.Text = "启动失败";
                LaunchAnimStatus.Text = result.Error;
                LaunchStatus.Text = "启动失败: " + result.Error;
                MessageBox.Show("启动失败：\n" + result.Error, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        catch (OperationCanceledException)
        {
            UpdateLaunchSteps(Math.Max(1, _currentLaunchStep), "启动已取消", false, true);
            LaunchAnimTitle.Text = "已取消";
            LaunchAnimStatus.Text = "启动已取消";
            LaunchStatus.Text = "启动已取消";
        }
        catch (Exception ex)
        {
            UpdateLaunchSteps(Math.Max(1, _currentLaunchStep), "启动异常：" + ex.Message, false, true);
            LaunchStatus.Text = "启动异常: " + ex.Message;
            MessageBox.Show("启动异常：\n" + ex.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            StopLaunchAnimation();
            StopStepPulse();
            _launching = false;
            _launchCts = null;
            LaunchBtn.IsEnabled = true;
            CancelLaunchBtn.Visibility = Visibility.Collapsed;
            // 清除任务栏进度
            try { MainWindow.Get()?.ClearTaskbarProgress(); } catch { }
            await Task.Delay(2000);
            if (!_launching) LaunchAnimBorder.Visibility = Visibility.Collapsed;
        }
    }

    /// <summary>检测 Java 版本是否匹配游戏版本</summary>
    private async Task<(bool Ok, string Message)> CheckJavaVersionAsync(GameInstance inst)
    {
        try
        {
            // 先尝试获取带加载器的版本 JSON，如果失败再用原版
            string versionId = inst.VersionId;
            var effectiveId = await App.Services.Launcher.ResolveEffectiveVersionAsync(inst);
            if (effectiveId != null) versionId = effectiveId;

            var vj = await App.Services.Versions.GetVersionJsonAsync(versionId);
            if (vj?.JavaVersion == null)
            {
                // 如果带加载器版本没有 Java 信息，用原版版本再试一次
                vj = await App.Services.Versions.GetVersionJsonAsync(inst.VersionId);
                if (vj?.JavaVersion == null) return (true, "");
            }
            int needMajor = vj.JavaVersion.MajorVersion;
            var javas = App.Services.Java.DetectAll();
            if (javas.Count == 0) return (false, $"当前未检测到 Java，游戏版本 {versionId} 需要 Java {needMajor}。");
            // 取版本最高的 Java
            var java = javas.OrderByDescending(j => j.Major).First();
            int curMajor = java.Major;
            if (curMajor < needMajor)
                return (false, $"当前最高 Java 版本为 Java {curMajor}，但游戏版本 {versionId} 需要 Java {needMajor} 或更高。");
            return (true, "");
        }
        catch { return (true, ""); }
    }

    private void StartLaunchAnimation()
    {
        _animTimer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(25) };
        double angle = 0;
        double pulse = 0;
        _animTimer.Tick += (s, e) =>
        {
            angle += 5;
            if (angle > 360) angle -= 360;
            ParticleRotate.Angle = angle;

            // 外圈呼吸效果
            pulse += 0.05;
            double opacity = 0.25 + Math.Sin(pulse) * 0.15;
            RingOuter.Opacity = Math.Max(0.1, opacity);
            RingMid.Opacity = Math.Max(0.2, opacity + 0.2);
        };
        _animTimer.Start();
    }

    private void StopLaunchAnimation()
    {
        _animTimer?.Stop();
        _animTimer = null;
        ParticleRotate.Angle = 0;
        // 进度条保留最后一次状态，下一次启动时会重新归零
    }

    private Border StepDot(int step) => step switch
    {
        1 => LaunchStep1Dot,
        2 => LaunchStep2Dot,
        3 => LaunchStep3Dot,
        4 => LaunchStep4Dot,
        _ => LaunchStep5Dot
    };

    private TextBlock StepNum(int step) => step switch
    {
        1 => LaunchStep1Num,
        2 => LaunchStep2Num,
        3 => LaunchStep3Num,
        4 => LaunchStep4Num,
        _ => LaunchStep5Num
    };

    private TextBlock StepTitle(int step) => step switch
    {
        1 => LaunchStep1Title,
        2 => LaunchStep2Title,
        3 => LaunchStep3Title,
        4 => LaunchStep4Title,
        _ => LaunchStep5Title
    };

    private TextBlock StepStatus(int step) => step switch
    {
        1 => LaunchStep1Status,
        2 => LaunchStep2Status,
        3 => LaunchStep3Status,
        4 => LaunchStep4Status,
        _ => LaunchStep5Status
    };

    private TextBlock StepBadge(int step) => step switch
    {
        1 => LaunchStep1Badge,
        2 => LaunchStep2Badge,
        3 => LaunchStep3Badge,
        4 => LaunchStep4Badge,
        _ => LaunchStep5Badge
    };

    /// <summary>重置五步启动流程。</summary>
    private void ResetLaunchSteps()
    {
        _currentLaunchStep = 0;
        StopStepPulse();
        for (int i = 1; i <= 5; i++)
        {
            var dot = StepDot(i);
            dot.Background = (Brush)FindResource("SurfaceBrush");
            dot.BorderBrush = (Brush)FindResource("HairlineStrongBrush");
            dot.Opacity = 1;
            StepNum(i).Foreground = (Brush)FindResource("MutedBrush");
            StepTitle(i).Foreground = (Brush)FindResource("InkSoftBrush");
            StepStatus(i).Foreground = (Brush)FindResource("MutedBrush");
            StepStatus(i).Text = "等待开始";
            StepBadge(i).Text = "";
            StepBadge(i).Foreground = (Brush)FindResource("MutedBrush");
        }
        CurrentStepText.Text = "启动流程 · 等待开始";
    }

    /// <summary>更新启动流程中的当前步骤、已完成步骤或失败步骤。</summary>
    private void UpdateLaunchSteps(int step, string? status = null, bool complete = false, bool error = false)
    {
        step = Math.Clamp(step, 1, 5);
        _currentLaunchStep = step;

        var mint = (Brush)FindResource("MintBrush");
        var mintDark = (Brush)FindResource("MintDarkBrush");
        var mintSoft = (Brush)FindResource("MintSoftBrush");
        var mintLine = (Brush)FindResource("MintLineBrush");
        var ink = (Brush)FindResource("InkBrush");
        var inkSoft = (Brush)FindResource("InkSoftBrush");
        var muted = (Brush)FindResource("MutedBrush");
        var danger = (Brush)FindResource("DangerBrush");
        var dangerSoft = (Brush)FindResource("RedSoftBrush");
        var hairline = (Brush)FindResource("HairlineStrongBrush");
        var surface = (Brush)FindResource("SurfaceBrush");

        for (int i = 1; i <= 5; i++)
        {
            var dot = StepDot(i);
            bool done = i < step || (i == step && complete);
            bool active = i == step && !complete && !error;

            if (done)
            {
                dot.Background = mintSoft;
                dot.BorderBrush = mintLine;
                dot.Opacity = 1;
                StepNum(i).Foreground = mintDark;
                StepTitle(i).Foreground = ink;
                StepBadge(i).Text = "完成";
                StepBadge(i).Foreground = mintDark;
                StepStatus(i).Text = i == step && !string.IsNullOrWhiteSpace(status)
                    ? status
                    : "已完成";
                StepStatus(i).Foreground = muted;
            }
            else if (active)
            {
                dot.Background = surface;
                dot.BorderBrush = mint;
                StepNum(i).Foreground = mintDark;
                StepTitle(i).Foreground = ink;
                StepBadge(i).Text = "进行中";
                StepBadge(i).Foreground = mintDark;
                StepStatus(i).Foreground = mintDark;
                if (!string.IsNullOrWhiteSpace(status)) StepStatus(i).Text = status;
                PulseStep(dot);
            }
            else if (error && i == step)
            {
                dot.Background = dangerSoft;
                dot.BorderBrush = danger;
                dot.Opacity = 1;
                StepNum(i).Foreground = danger;
                StepTitle(i).Foreground = danger;
                StepBadge(i).Text = "失败";
                StepBadge(i).Foreground = danger;
                StepStatus(i).Foreground = danger;
                if (!string.IsNullOrWhiteSpace(status)) StepStatus(i).Text = status;
            }
            else
            {
                dot.Background = surface;
                dot.BorderBrush = hairline;
                dot.Opacity = 1;
                StepNum(i).Foreground = muted;
                StepTitle(i).Foreground = inkSoft;
                StepBadge(i).Text = "";
                StepBadge(i).Foreground = muted;
                StepStatus(i).Foreground = muted;
            }
        }

        if (error)
        {
            StopStepPulse();
            CurrentStepText.Text = $"启动流程 · 第 {step}/5 步失败";
        }
        else if (complete)
        {
            StopStepPulse();
            CurrentStepText.Text = step >= 5 ? "启动流程 · 5/5 已完成" : $"启动流程 · {step}/5 已完成";
        }
        else
        {
            CurrentStepText.Text = $"启动流程 · 当前步骤 {step}/5";
        }
    }

    private void PulseStep(Border dot)
    {
        if (_stepPulseDot == dot)
            return;
        StopStepPulse();
        _stepPulseDot = dot;
        dot.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation
        {
            From = 1,
            To = 0.45,
            Duration = TimeSpan.FromMilliseconds(650),
            AutoReverse = true,
            RepeatBehavior = RepeatBehavior.Forever
        });
    }

    private void StopStepPulse()
    {
        if (_stepPulseDot == null) return;
        _stepPulseDot.BeginAnimation(UIElement.OpacityProperty, null);
        _stepPulseDot.Opacity = 1;
        _stepPulseDot = null;
    }

    private void CancelLaunch_Click(object sender, RoutedEventArgs e)
    {
        _launchCts?.Cancel();
        LaunchAnimStatus.Text = "正在取消...";
        if (_currentLaunchStep > 0)
            UpdateLaunchSteps(_currentLaunchStep, "收到取消请求...", false, false);
    }

    /// <summary>轮询游戏进程主窗口，最多等待 60 秒。</summary>
    private static async Task<bool> WaitForGameWindowAsync(Process? process, CancellationToken ct)
    {
        if (process == null) return false;
        for (int i = 0; i < 120; i++)
        {
            ct.ThrowIfCancellationRequested();
            await Task.Delay(500, ct);
            try
            {
                process.Refresh();
                if (process.HasExited) return false;
                if (process.MainWindowHandle != IntPtr.Zero) return true;
            }
            catch
            {
                return false;
            }
        }
        return false;
    }

    private static long GetTotalMemoryMb()
    {
        try
        {
            if (OperatingSystem.IsWindows())
            {
                var status = new MEMORYSTATUSEX();
                if (GlobalMemoryStatusEx(status))
                    return (long)(status.ullTotalPhys / 1024 / 1024);
            }
        }
        catch { }
        return 0;
    }

    [System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
    private static extern bool GlobalMemoryStatusEx([System.Runtime.InteropServices.In, System.Runtime.InteropServices.Out] MEMORYSTATUSEX lpBuffer);

    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
    private class MEMORYSTATUSEX
    {
        public uint dwLength = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(MEMORYSTATUSEX));
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    private async void Launch_Click(object sender, RoutedEventArgs e) => await LaunchAsync();

    private void MicrosoftLogin_Click(object sender, RoutedEventArgs e)
    {
        // 启动器尚未取得微软正版验证审批，正版登录入口仅保留提示。
        MicrosoftLoginStatus.Text = "正版登录暂未开放，请使用离线登录。";
        MessageBox.Show(
            "由于启动器未获得正版验证审批，无法使用正版登录，你可以使用【离线登录】。",
            "正版登录暂不可用",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    private async Task LoadAvatarAsync(Account acct)
    {
        try
        {
            var bmp = await App.Services.Avatars.GetAvatarAsync(acct);
            if (bmp != null)
            {
                Dispatcher.Invoke(() =>
                {
                    AcctAvatar.Source = bmp;
                    AcctAvatarBorder.Visibility = System.Windows.Visibility.Visible;
                });
            }
        }
        catch { }
    }

    private async Task LoadAllAvatarsAsync()
    {
        try
        {
            foreach (var acct in App.Services.Accounts.Accounts.ToList())
            {
                if (acct.AvatarImage != null) continue;
                var bmp = await App.Services.Avatars.GetAvatarAsync(acct);
                if (bmp != null)
                {
                    Dispatcher.Invoke(() =>
                    {
                        acct.AvatarImage = bmp;
                        AccountList.ItemsSource = null;
                        AccountList.ItemsSource = App.Services.Accounts.Accounts.ToList();
                    });
                }
            }
        }
        catch { }
    }

    private void CreateOffline_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var acct = App.Services.Accounts.CreateOffline(OfflineNameBox.Text);
            App.Services.Accounts.Switch(acct.Id);
            Refresh();
            App.MainWin?.RefreshTopBar();
            MessageBox.Show($"离线账号「{acct.Name}」创建成功，已自动切换。", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void AccountCard_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if ((sender as Border)?.Tag is Account acct)
        {
            SwitchAccount(acct);
        }
    }

    private void SwitchAccount(Account acct)
    {
        App.Services.Accounts.Switch(acct.Id);
        Refresh();
        App.MainWin?.RefreshTopBar();
    }

    public ICommand SwitchCmd => new RelayCommand(o => { if (o is Account a) SwitchAccount(a); });

    private void DeleteAccount_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is Account acct)
        {
            var r = MessageBox.Show($"确定删除账号「{acct.Name}」？", "温水启动器", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (r == MessageBoxResult.Yes)
            {
                App.Services.Accounts.Delete(acct.Id);
                Refresh();
                App.MainWin?.RefreshTopBar();
            }
        }
    }

    private void PickSkin_Click(object sender, RoutedEventArgs e)
    {
        var acct = App.Services.Accounts.Current;
        if (acct == null) { MessageBox.Show("请先创建账号", "温水启动器"); return; }
        var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "图片文件|*.png;*.jpg;*.jpeg" };
        if (dlg.ShowDialog() == true)
        {
            App.Services.Accounts.SetSkin(acct, dlg.FileName, null);
            Refresh();
        }
    }

    private void PickCape_Click(object sender, RoutedEventArgs e)
    {
        var acct = App.Services.Accounts.Current;
        if (acct == null) { MessageBox.Show("请先创建账号", "温水启动器"); return; }
        var dlg = new Microsoft.Win32.OpenFileDialog { Filter = "图片文件|*.png;*.jpg;*.jpeg" };
        if (dlg.ShowDialog() == true)
        {
            App.Services.Accounts.SetSkin(acct, null, dlg.FileName);
            Refresh();
        }
    }

    private void OpenGameDir_Click(object sender, RoutedEventArgs e)
    {
        var inst = App.Services.Instances.Current;
        if (inst == null) return;
        var dir = App.Services.Instances.GetInstanceGameDir(inst);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }

    private void OpenModsDir_Click(object sender, RoutedEventArgs e)
    {
        var inst = App.Services.Instances.Current;
        if (inst == null) return;
        var dir = App.Services.Mods.GetModsDir(inst);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }

    private void OpenSavesDir_Click(object sender, RoutedEventArgs e)
    {
        var inst = App.Services.Instances.Current;
        if (inst == null) return;
        var dir = Path.Combine(App.Services.Instances.GetInstanceGameDir(inst), "saves");
        Directory.CreateDirectory(dir);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }

    private void OpenLogDir_Click(object sender, RoutedEventArgs e)
    {
        var dir = App.Services.Logs.LogDir;
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }

    private async void Verify_Click(object sender, RoutedEventArgs e)
    {
        var inst = App.Services.Instances.Current;
        if (inst == null) return;
        VerifyStatus.Text = "正在校验游戏文件，请稍候...";
        try
        {
            var (checkedCnt, broken) = await Task.Run(() => App.Services.Launcher.VerifyGameFiles(inst));
            VerifyStatus.Text = broken == 0
                ? $"校验完成：共 {checkedCnt} 个文件，全部完好。"
                : $"校验完成：{checkedCnt} 个文件中 {broken} 个损坏/缺失，下次启动时会自动重新下载修复。";
        }
        catch (Exception ex)
        {
            VerifyStatus.Text = "校验失败: " + ex.Message;
        }
    }

    private void DirectConnect_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new DirectConnectDialog();
        dlg.Owner = App.MainWin;
        if (dlg.ShowDialog() == true)
        {
            App.Services.Settings.Config.Launch.DirectConnect = dlg.Address;
            App.Services.Settings.Save();
            VerifyStatus.Text = $"已设置直连服务器：{dlg.Address}（下次启动自动进入）";
        }
    }

    /// <summary>赞助支持 - 跳转到爱发电</summary>
    private void Sponsor_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "https://ifdian.net/a/xiaochengxuyuyaoxi",
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show("打开赞助页面失败：" + ex.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BuyOfficial_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "https://www.minecraft.net/zh-hans/store/minecraft-java-bedrock-edition-pc",
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show("打开购买正版页面失败：" + ex.Message, "温水启动器", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    /// <summary>启动基岩版</summary>
    private void LaunchBedrock_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string bedrockPath = App.Services.Settings.Config.General.BedrockPath ?? "";
            // 如果没有设置路径，尝试默认路径
            if (string.IsNullOrEmpty(bedrockPath) || !System.IO.File.Exists(bedrockPath))
            {
                // 尝试通过 Microsoft Store 协议启动
                var result = MessageBox.Show(
                    "基岩版启动说明：\n\n" +
                    "1. 请确保已从 Microsoft Store 安装 Minecraft for Windows\n" +
                    "2. 点击确定将尝试启动基岩版\n" +
                    "3. 如果启动失败，请在设置中手动指定基岩版 exe 路径\n\n" +
                    "是否现在尝试启动？",
                    "基岩版启动", MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result != MessageBoxResult.Yes) return;

                // 尝试通过协议启动
                try
                {
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = "minecraft://",
                        UseShellExecute = true
                    });
                    VerifyStatus.Text = "已尝试启动 Minecraft 基岩版（通过 Microsoft Store 协议）";
                    return;
                }
                catch { }

                // 尝试常见安装路径
                string[] possiblePaths =
                {
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Packages", "Microsoft.MinecraftUWP_8wekyb3d8bbwe", "LocalState", "games", "com.mojang"),
                };
                MessageBox.Show("无法自动启动基岩版。\n请在「设置」→「通用」中手动设置基岩版 exe 路径，\n或确保已从 Microsoft Store 安装 Minecraft for Windows。", "基岩版启动", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 启动指定路径的基岩版
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = bedrockPath,
                UseShellExecute = true,
                WorkingDirectory = System.IO.Path.GetDirectoryName(bedrockPath)
            });
            VerifyStatus.Text = "已启动 Minecraft 基岩版";
        }
        catch (Exception ex)
        {
            MessageBox.Show("启动基岩版失败：" + ex.Message, "基岩版启动", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    // ==================== 1.0 新快捷入口 ====================

    private void DownloadQuick_Click(object sender, RoutedEventArgs e) => MainWindow.Get()?.Navigate("download");

    private void HealthQuick_Click(object sender, RoutedEventArgs e) => MainWindow.Get()?.OpenToolbox("health");

    private void ToolsQuick_Click(object sender, RoutedEventArgs e) => MainWindow.Get()?.OpenToolbox("performance");

    private void BackupQuick_Click(object sender, RoutedEventArgs e) => MainWindow.Get()?.Navigate("instance");

    private void OpenSearch_Click(object sender, RoutedEventArgs e) => MainWindow.Get()?.OpenCommandPalette();

    private void NotificationsQuick_Click(object sender, RoutedEventArgs e) => MainWindow.Get()?.ShowNotificationCenter();

    private void OpenTools_Click(object sender, RoutedEventArgs e) => MainWindow.Get()?.OpenToolbox();

    private void OpenSkin_Click(object sender, RoutedEventArgs e) => MainWindow.Get()?.Navigate("skin");
}

public class RelayCommand : ICommand
{
    private readonly Action<object?> _execute;
    public RelayCommand(Action<object?> execute) => _execute = execute;
    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => true;
    public void Execute(object? parameter) => _execute(parameter);
}
