using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

/// <summary>
/// 工具箱：启动体检、性能调优、镜像测速、配置备份、日志打包、快捷方式、
/// 空间清理、专注模式与下载权限验证。
/// </summary>
public partial class PageTools : UserControl, IActivatePage
{
    private CleanupResult? _cleanupResult;
    private readonly Dictionary<string, long> _mirrorLatency = new();
    private bool _healthRunning;

    public PageTools()
    {
        InitializeComponent();
    }

    public void OnActivate()
    {
        RefreshState();
    }

    /// <summary>供主页「一键体检」直接调用。</summary>
    public void RunHealthCheck() => RunHealthCheck_Click(this, new RoutedEventArgs());

    /// <summary>供主页「性能调优」直接调用。</summary>
    public void ApplyRecommendedPerformance() => ApplyPerformancePreset("balanced");

    private void RefreshState()
    {
        try
        {
            var win = MainWindow.Get();
            bool focus = win?.IsFocusMode == true;
            FocusStateText.Text = focus ? "当前：专注模式（按 Esc 退出）" : "当前：标准模式";
            FocusModeBtn.Content = focus ? "退出专注模式" : "进入专注模式";
            DownloadLockStateText.Text = "下载功能已开放";
            DownloadLockStateText.Foreground = (Brush)FindResource("MintDarkBrush");
        }
        catch { }
    }

    // ==================== 启动体检 ====================

    private async void RunHealthCheck_Click(object sender, RoutedEventArgs e)
    {
        if (_healthRunning) return;
        _healthRunning = true;
        RunHealthBtn.IsEnabled = false;
        RunHealthBtn.Content = "正在体检…";
        HealthList.Children.Clear();
        HealthSummaryText.Text = "正在读取 Java、版本与磁盘状态，请稍候…";
        HealthScoreText.Text = "--";

        int score = 100;
        var rows = new List<(string Title, string Detail, string Level)>();
        var sys = App.Services.SystemInfo.Detect();

        try
        {
            // 账号
            var account = App.Services.Accounts.Current;
            if (account == null)
            {
                score -= 18;
                rows.Add(("账号", "尚未登录，创建一个离线账号即可开始游戏。", "warn"));
            }
            else
            {
                rows.Add(("账号", $"{account.Name} · {(account.Type == "microsoft" ? "微软正版" : "离线账号")}", "ok"));
            }

            // 实例
            var instance = App.Services.Instances.Current;
            if (instance == null)
            {
                score -= 22;
                rows.Add(("游戏实例", "还没有实例，请创建实例或从下载页安装版本。", "warn"));
            }
            else
            {
                rows.Add(("游戏实例", $"{instance.Name} · {instance.VersionId}", "ok"));
            }

            // Java
            var javas = await Task.Run(() => App.Services.Java.DetectAll());
            if (javas.Count == 0)
            {
                score -= 24;
                rows.Add(("Java 环境", "未检测到 Java，启动游戏前需要安装。", "error"));
            }
            else
            {
                var latest = javas.OrderByDescending(j => j.Major).First();
                rows.Add(("Java 环境", $"已检测到 {javas.Count} 个 Java，最高 Java {latest.Major}", "ok"));
            }

            // 游戏版本文件
            if (instance != null)
            {
                var installed = App.Services.Versions.GetInstalledVersions();
                if (installed.Contains(instance.VersionId))
                    rows.Add(("版本文件", $"{instance.VersionId} 已安装", "ok"));
                else
                {
                    score -= 15;
                    rows.Add(("版本文件", $"实例绑定的 {instance.VersionId} 未在 versions 中找到。", "error"));
                }
            }

            // 内存
            if (sys.TotalMemoryMB > 0)
            {
                int maxMem = App.Services.Settings.Config.Launch.MaxMemory;
                if (maxMem > sys.TotalMemoryMB * 0.9)
                {
                    score -= 8;
                    rows.Add(("游戏内存", $"分配 {maxMem} MB 偏高（物理内存 {sys.TotalMemoryMB} MB）。", "warn"));
                }
                else
                {
                    rows.Add(("游戏内存", $"分配 {maxMem} MB / 物理内存 {sys.TotalMemoryMB} MB", "ok"));
                }
            }

            // 磁盘
            try
            {
                var root = Path.GetPathRoot(SettingsService.GetDataDir()) ?? "C:\\";
                var drive = new DriveInfo(root);
                long freeGb = drive.AvailableFreeSpace / 1024 / 1024 / 1024;
                if (freeGb < 5)
                {
                    score -= 10;
                    rows.Add(("磁盘空间", $"{root} 仅剩余 {freeGb} GB，建议至少保留 5 GB。", "warn"));
                }
                else
                {
                    rows.Add(("磁盘空间", $"{root} 剩余 {freeGb} GB", "ok"));
                }
            }
            catch { }

            // 数据目录
            rows.Add(("数据目录", SettingsService.GetDataDir(), "ok"));

            score = Math.Clamp(score, 0, 100);
            HealthScoreText.Text = score.ToString();
            HealthScoreText.Foreground = score >= 85
                ? (Brush)FindResource("MintDarkBrush")
                : score >= 60 ? (Brush)FindResource("WarnBrush") : (Brush)FindResource("DangerBrush");
            HealthSummaryText.Text = score >= 90
                ? "状态很好，账号、实例与运行环境都已就绪。"
                : score >= 70
                    ? "基本可用，仍有几项建议处理，按下方提示逐项检查即可。"
                    : "存在影响启动的问题，建议先处理红色项目。";

            foreach (var row in rows)
                AddHealthRow(row.Title, row.Detail, row.Level);
        }
        catch (Exception ex)
        {
            HealthScoreText.Text = "--";
            HealthSummaryText.Text = "体检失败：" + ex.Message;
        }
        finally
        {
            _healthRunning = false;
            RunHealthBtn.IsEnabled = true;
            RunHealthBtn.Content = "重新体检";
        }
    }

    private void AddHealthRow(string title, string detail, string level)
    {
        var color = level switch
        {
            "error" => Color.FromRgb(0xD1, 0x43, 0x43),
            "warn" => Color.FromRgb(0xD9, 0x8A, 0x2B),
            _ => Color.FromRgb(0x2E, 0x9E, 0x78)
        };
        var glyph = level switch
        {
            "error" => "\uE711",
            "warn" => "\uE7BA",
            _ => "\uE73E"
        };

        var border = new Border
        {
            Background = (Brush)FindResource("SurfaceSoftBrush"),
            CornerRadius = new CornerRadius(9),
            Padding = new Thickness(10, 9, 10, 9),
            Margin = new Thickness(0, 0, 0, 5)
        };
        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        var dot = new Border
        {
            Width = 24,
            Height = 24,
            CornerRadius = new CornerRadius(7),
            Background = new SolidColorBrush(Color.FromArgb(28, color.R, color.G, color.B)),
            Margin = new Thickness(0, 1, 9, 0),
            Child = new TextBlock
            {
                Text = glyph,
                FontFamily = new FontFamily("Segoe MDL2 Assets"),
                FontSize = 10,
                Foreground = new SolidColorBrush(color),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            }
        };
        Grid.SetColumn(dot, 0);

        var texts = new StackPanel();
        texts.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 11.5,
            FontWeight = FontWeights.SemiBold,
            Foreground = (Brush)FindResource("InkBrush")
        });
        texts.Children.Add(new TextBlock
        {
            Text = detail,
            FontSize = 10,
            Foreground = (Brush)FindResource("MutedBrush"),
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(0, 2, 0, 0)
        });
        Grid.SetColumn(texts, 1);

        grid.Children.Add(dot);
        grid.Children.Add(texts);
        border.Child = grid;
        HealthList.Children.Add(border);
    }

    // ==================== 性能调优 ====================

    private void ApplyPreset_Click(object sender, RoutedEventArgs e)
    {
        var preset = (sender as Button)?.Tag?.ToString() ?? "balanced";
        ApplyPerformancePreset(preset);
    }

    private void ApplyRecommended_Click(object sender, RoutedEventArgs e) => ApplyPerformancePreset("balanced");

    private void ApplyPerformancePreset(string preset)
    {
        try
        {
            var sys = App.Services.SystemInfo.Detect();
            long total = sys.TotalMemoryMB > 0 ? sys.TotalMemoryMB : 8192;
            double ratio = preset switch
            {
                "quiet" => 0.32,
                "performance" => 0.68,
                _ => 0.50
            };

            int recommended = (int)(total * ratio);
            recommended = Math.Clamp(recommended, 1024, 12288);
            recommended = (int)(Math.Round(recommended / 512.0) * 512);
            int minimum = Math.Min(512, Math.Max(256, recommended / 4));

            var cfg = App.Services.Settings.Config;
            cfg.Launch.MaxMemory = recommended;
            cfg.Launch.MinMemory = minimum;
            cfg.Advanced.GcType = "G1";
            cfg.General.GamePreset = preset;

            var args = cfg.Launch.JvmArgs ?? "";
            if (!args.Contains("-XX:+UseG1GC", StringComparison.OrdinalIgnoreCase))
                args = (args.Trim() + " -XX:+UseG1GC").Trim();
            if (!args.Contains("-XX:+ParallelRefProcEnabled", StringComparison.OrdinalIgnoreCase))
                args = (args.Trim() + " -XX:+ParallelRefProcEnabled").Trim();
            cfg.Launch.JvmArgs = args.Trim();
            App.Services.Settings.Save();

            var name = preset switch
            {
                "quiet" => "省电",
                "performance" => "高性能",
                _ => "均衡"
            };
            MemoryStatusText.Text = $"{name}模式已应用：最大内存 {recommended} MB · 最小内存 {minimum} MB · G1 GC · 并行引用处理。";
            MainWindow.Get()?.ShowToast("性能设置已更新", $"{name}模式 · 最大内存 {recommended} MB");
        }
        catch (Exception ex)
        {
            MemoryStatusText.Text = "应用失败：" + ex.Message;
        }
    }

    // ==================== 镜像测速 ====================

    private sealed record MirrorTarget(string Name, string Url, string Source);

    private static readonly MirrorTarget[] Mirrors =
    {
        new("BMCLAPI（国内镜像）", "https://bmclapi2.bangbang93.com/", "bmclapi"),
        new("Mojang 官方源", "https://launchermeta.mojang.com/", "mojang"),
        new("MCIM 镜像", "https://mod.mcimirror.top/", "mcim")
    };

    private async void TestMirror_Click(object sender, RoutedEventArgs e)
    {
        TestMirrorBtn.IsEnabled = false;
        TestMirrorBtn.Content = "测速中…";
        ApplyMirrorBtn.Visibility = Visibility.Collapsed;
        _mirrorLatency.Clear();
        MirrorRows.Children.Clear();
        MirrorStatusText.Text = "正在连接三个下载源…";

        try
        {
            var tasks = Mirrors.Select(async m =>
            {
                long ms = await MeasureLatencyAsync(m.Url);
                return (Mirror: m, Latency: ms);
            });
            var results = await Task.WhenAll(tasks);

            long best = long.MaxValue;
            MirrorTarget? bestMirror = null;
            foreach (var (mirror, latency) in results)
            {
                _mirrorLatency[mirror.Source] = latency;
                AddMirrorRow(mirror.Name, latency);
                if (latency > 0 && latency < best)
                {
                    best = latency;
                    bestMirror = mirror;
                }
            }

            if (bestMirror != null)
            {
                MirrorStatusText.Text = $"推荐：{bestMirror.Name} · {best} ms";
                ApplyMirrorBtn.Tag = bestMirror;
                ApplyMirrorBtn.Visibility = Visibility.Visible;
            }
            else
            {
                MirrorStatusText.Text = "三个下载源均连接超时，请检查网络或代理设置。";
            }
        }
        catch (Exception ex)
        {
            MirrorStatusText.Text = "测速失败：" + ex.Message;
        }
        finally
        {
            TestMirrorBtn.IsEnabled = true;
            TestMirrorBtn.Content = "重新测速";
        }
    }

    private static async Task<long> MeasureLatencyAsync(string url)
    {
        try
        {
            using var handler = new HttpClientHandler { AllowAutoRedirect = true };
            using var client = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(6) };
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(6));
            var sw = Stopwatch.StartNew();
            using var response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cts.Token);
            sw.Stop();
            return sw.ElapsedMilliseconds;
        }
        catch
        {
            return -1;
        }
    }

    private void AddMirrorRow(string name, long latency)
    {
        var grid = new Grid { Margin = new Thickness(0, 0, 0, 5) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        var label = new TextBlock
        {
            Text = name,
            FontSize = 11,
            Foreground = (Brush)FindResource("InkSoftBrush")
        };
        var value = new TextBlock
        {
            Text = latency > 0 ? $"{latency} ms" : "超时",
            FontSize = 11,
            FontWeight = FontWeights.SemiBold,
            Foreground = latency > 0
                ? (latency < 300 ? (Brush)FindResource("MintDarkBrush") : (Brush)FindResource("WarnBrush"))
                : (Brush)FindResource("DangerBrush")
        };
        Grid.SetColumn(value, 1);
        grid.Children.Add(label);
        grid.Children.Add(value);
        MirrorRows.Children.Add(grid);
    }

    private void ApplyFastestMirror_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not MirrorTarget mirror) return;
        var cfg = App.Services.Settings.Config;
        cfg.Download.Source = mirror.Source;
        cfg.General.DownloadSource = mirror.Source;
        App.Services.Settings.Save();
        MirrorStatusText.Text = $"已切换到 {mirror.Name}，下次下载生效。";
        MainWindow.Get()?.ShowToast("下载源已切换", mirror.Name);
    }

    // ==================== 数据与快捷方式 ====================

    private static string DesktopDir
    {
        get
        {
            var desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            return Directory.Exists(desktop) ? desktop : SettingsService.GetDataDir();
        }
    }

    private void BackupConfig_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var path = Path.Combine(DesktopDir, $"温水启动器配置备份_{DateTime.Now:yyyyMMdd_HHmmss}.zip");
            bool ok = App.Services.Backup.ExportConfig(path);
            DataToolStatus.Text = ok ? "配置已备份到桌面：" + Path.GetFileName(path) : "配置备份失败。";
            if (ok) MainWindow.Get()?.ShowToast("配置备份完成", Path.GetFileName(path));
        }
        catch (Exception ex)
        {
            DataToolStatus.Text = "配置备份失败：" + ex.Message;
        }
    }

    private void PackLogs_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var logDir = App.Services.Logs.LogDir;
            if (!Directory.Exists(logDir) || Directory.GetFiles(logDir).Length == 0)
            {
                DataToolStatus.Text = "当前还没有日志文件。";
                return;
            }

            var path = Path.Combine(DesktopDir, $"温水启动器日志_{DateTime.Now:yyyyMMdd_HHmmss}.zip");
            if (File.Exists(path)) File.Delete(path);
            ZipFile.CreateFromDirectory(logDir, path, CompressionLevel.Optimal, false);

            var crashFile = Path.Combine(SettingsService.GetDataDir(), "crash.txt");
            if (File.Exists(crashFile))
            {
                using var zip = ZipFile.Open(path, ZipArchiveMode.Update);
                zip.CreateEntryFromFile(crashFile, "crash.txt");
            }

            DataToolStatus.Text = "日志已打包到桌面：" + Path.GetFileName(path);
            MainWindow.Get()?.ShowToast("诊断日志已打包", Path.GetFileName(path));
        }
        catch (Exception ex)
        {
            DataToolStatus.Text = "日志打包失败：" + ex.Message;
        }
    }

    private void CreateShortcut_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var exePath = Process.GetCurrentProcess().MainModule?.FileName;
            if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath))
            {
                DataToolStatus.Text = "无法定位启动器程序。";
                return;
            }

            var lnkPath = Path.Combine(DesktopDir, "温水启动器.lnk");
            var shellType = Type.GetTypeFromProgID("WScript.Shell");
            if (shellType == null)
            {
                DataToolStatus.Text = "系统不支持创建快捷方式。";
                return;
            }

            object shell = Activator.CreateInstance(shellType)!;
            object shortcut = shellType.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnkPath })!;
            shellType.InvokeMember("TargetPath", BindingFlags.SetProperty, null, shortcut, new object[] { exePath });
            shellType.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, shortcut, new object[] { Path.GetDirectoryName(exePath)! });
            shellType.InvokeMember("IconLocation", BindingFlags.SetProperty, null, shortcut, new object[] { exePath + ",0" });
            shellType.InvokeMember("Description", BindingFlags.SetProperty, null, shortcut, new object[] { "温水我的世界启动器 1.0 正式版" });
            shellType.InvokeMember("Save", BindingFlags.InvokeMethod, null, shortcut, null);

            DataToolStatus.Text = "桌面快捷方式已创建：" + lnkPath;
            MainWindow.Get()?.ShowToast("桌面快捷方式已创建", "温水启动器.lnk");
        }
        catch (Exception ex)
        {
            DataToolStatus.Text = "创建快捷方式失败：" + ex.Message;
        }
    }

    private void OpenDataDir_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var dir = SettingsService.GetDataDir();
            Process.Start(new ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            DataToolStatus.Text = "打开目录失败：" + ex.Message;
        }
    }

    // ==================== 空间清理 ====================

    private async void ScanCleanup_Click(object sender, RoutedEventArgs e)
    {
        ScanCleanupBtn.IsEnabled = false;
        ScanCleanupBtn.Content = "扫描中…";
        CleanupStatusText.Text = "正在扫描可清理内容…";
        try
        {
            _cleanupResult = await Task.Run(() => App.Services.Cleanup.Scan());
            if (_cleanupResult.Items.Count == 0)
            {
                CleanupStatusText.Text = "没有发现可清理的内容。";
                CleanCleanupBtn.IsEnabled = false;
            }
            else
            {
                var names = string.Join("、", _cleanupResult.Items.Select(i => i.Name).Take(5));
                CleanupStatusText.Text = $"发现 {_cleanupResult.Items.Count} 项可清理内容，共 {_cleanupResult.TotalSizeText}：{names}" +
                                         (_cleanupResult.Items.Count > 5 ? " 等" : "");
                CleanCleanupBtn.IsEnabled = true;
            }
        }
        catch (Exception ex)
        {
            CleanupStatusText.Text = "扫描失败：" + ex.Message;
        }
        finally
        {
            ScanCleanupBtn.IsEnabled = true;
            ScanCleanupBtn.Content = "重新扫描";
        }
    }

    private async void CleanCleanup_Click(object sender, RoutedEventArgs e)
    {
        if (_cleanupResult == null || _cleanupResult.Items.Count == 0) return;
        if (MessageBox.Show($"确定清理 {_cleanupResult.Items.Count} 项内容（{_cleanupResult.TotalSizeText}）吗？\n\n缓存和日志删除后不会影响游戏存档。",
                "清理确认", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        CleanCleanupBtn.IsEnabled = false;
        CleanCleanupBtn.Content = "清理中…";
        try
        {
            var (count, size) = await App.Services.Cleanup.CleanAsync(_cleanupResult.Items);
            CleanupStatusText.Text = $"已清理 {count} 项，释放 {WorldBackupService.FormatSize(size)}。";
            CleanCleanupBtn.Content = "清理";
            _cleanupResult = null;
            MainWindow.Get()?.ShowToast("清理完成", $"释放 {WorldBackupService.FormatSize(size)}");
        }
        catch (Exception ex)
        {
            CleanupStatusText.Text = "清理失败：" + ex.Message;
            CleanCleanupBtn.Content = "清理";
        }
    }

    // ==================== 专注模式 / 下载权限 ====================

    private void ToggleFocusMode_Click(object sender, RoutedEventArgs e)
    {
        var win = MainWindow.Get();
        if (win == null) return;
        win.SetFocusMode(!win.IsFocusMode);
        RefreshState();
    }

}
