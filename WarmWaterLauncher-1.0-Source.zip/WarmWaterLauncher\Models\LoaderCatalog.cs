namespace WarmWaterLauncher.Models;

/// <summary>加载器展示信息与图标资源。</summary>
public class LoaderBadge
{
    public string Key { get; init; } = "";
    public string Name { get; init; } = "";
    public string IconPath { get; init; } = "";
}

public static class LoaderCatalog
{
    public static readonly string[] KnownKeys = { "fabric", "forge", "quilt", "neoforge", "optifine" };

    public static bool IsLoader(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        var v = value.ToLowerInvariant();
        return KnownKeys.Contains(v) || v is "liteloader" or "rift";
    }

    public static string Normalize(string? loader)
    {
        var v = (loader ?? "").Trim().ToLowerInvariant();
        return v switch
        {
            "neo" or "neo-forge" => "neoforge",
            "opti" or "optifine_hd" => "optifine",
            _ => v
        };
    }

    public static string DisplayName(string? loader) => Normalize(loader) switch
    {
        "fabric" => "Fabric",
        "forge" => "Forge",
        "quilt" => "Quilt",
        "neoforge" => "NeoForge",
        "optifine" => "OptiFine",
        "liteloader" => "LiteLoader",
        "rift" => "Rift",
        _ => string.IsNullOrWhiteSpace(loader) ? "未知" : loader!
    };

    public static string IconPath(string? loader) => Normalize(loader) switch
    {
        "fabric" => "/Resources/loader_fabric.png",
        "forge" => "/Resources/loader_forge.png",
        "quilt" => "/Resources/loader_quilt.png",
        "neoforge" => "/Resources/loader_neoforge.png",
        "optifine" => "/Resources/loader_optifine.png",
        _ => "/Resources/loader_forge.png"
    };

    public static LoaderBadge Badge(string? loader) => new()
    {
        Key = Normalize(loader),
        Name = DisplayName(loader),
        IconPath = IconPath(loader)
    };
}
