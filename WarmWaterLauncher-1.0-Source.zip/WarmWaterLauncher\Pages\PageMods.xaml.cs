using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.Win32;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages
{
    public partial class PageMods : UserControl
    {
        private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(30) };
        private ObservableCollection<SearchResultItem> _modResults = new();
        private ObservableCollection<SearchResultItem> _modpackResults = new();
        private ObservableCollection<SearchResultItem> _datapackResults = new();
        private ObservableCollection<SearchResultItem> _resourcepackResults = new();
        private ObservableCollection<SearchResultItem> _shaderResults = new();
        private ObservableCollection<SearchResultItem> _worldResults = new();

        public PageMods()
        {
            InitializeComponent();
            ModResultList.ItemsSource = _modResults;
            ModpackResultList.ItemsSource = _modpackResults;
            DatapackResultList.ItemsSource = _datapackResults;
            ResourcepackResultList.ItemsSource = _resourcepackResults;
            ShaderResultList.ItemsSource = _shaderResults;
            WorldResultList.ItemsSource = _worldResults;
            LoadInstalledVersions();
        }

        public void OnActivate()
        {
            RefreshMods();
            LoadInstalledVersions();
        }

        // ===== 本地模组管理 =====
        private void RefreshMods()
        {
            try
            {
                var inst = App.Services.Instances.Current;
                if (inst == null) { ModGrid.ItemsSource = null; return; }
                var mods = App.Services.Mods.ListMods(inst);
                ModGrid.ItemsSource = mods;
            }
            catch { }
        }

        private void Import_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "模组文件|*.jar;*.zip", Multiselect = true };
            if (dlg.ShowDialog() != true) return;
            var inst = App.Services.Instances.Current;
            if (inst == null) { MessageBox.Show("请先选择实例"); return; }
            foreach (var f in dlg.FileNames)
            {
                try { File.Copy(f, Path.Combine(App.Services.Mods.GetModsDir(inst), Path.GetFileName(f)), true); } catch { }
            }
            RefreshMods();
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e)
        {
            var inst = App.Services.Instances.Current;
            if (inst == null) return;
            try { Process.Start(new ProcessStartInfo("explorer.exe", App.Services.Mods.GetModsDir(inst)) { UseShellExecute = false }); } catch { }
        }

        private void EnableAll_Click(object sender, RoutedEventArgs e) { var inst = App.Services.Instances.Current; if (inst == null) return; App.Services.Mods.SetAllEnabled(ModGrid.Items.Cast<ModEntry>().ToList(), true); RefreshMods(); }
        private void DisableAll_Click(object sender, RoutedEventArgs e) { var inst = App.Services.Instances.Current; if (inst == null) return; App.Services.Mods.SetAllEnabled(ModGrid.Items.Cast<ModEntry>().ToList(), false); RefreshMods(); }
        private void CheckDeps_Click(object sender, RoutedEventArgs e)
        {
            var inst = App.Services.Instances.Current;
            if (inst == null)
            {
                MessageBox.Show("请先在实例管理中创建或选择一个实例。", "依赖检测", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                var missing = App.Services.Mods.CheckMissingDependencies(inst);
                var conflicts = App.Services.Mods.CheckConflicts(inst);
                var lines = new List<string>();
                if (missing.Count == 0 && conflicts.Count == 0)
                {
                    lines.Add("✓ 未检测到缺失依赖或重复模组。");
                }
                else
                {
                    if (missing.Count > 0)
                    {
                        lines.Add($"缺失依赖（{missing.Count}）：");
                        lines.AddRange(missing.Take(20).Select(x => "  · " + x));
                        if (missing.Count > 20) lines.Add($"  … 另有 {missing.Count - 20} 项");
                    }
                    if (conflicts.Count > 0)
                    {
                        if (lines.Count > 0) lines.Add("");
                        lines.Add($"重复模组（{conflicts.Count}）：");
                        lines.AddRange(conflicts.Take(10).Select(x => "  · " + x));
                    }
                }
                MessageBox.Show(string.Join(Environment.NewLine, lines), "模组依赖检测",
                    MessageBoxButton.OK, missing.Count + conflicts.Count == 0 ? MessageBoxImage.Information : MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("依赖检测失败：" + ex.Message, "模组依赖检测", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void Refresh_Click(object sender, RoutedEventArgs e) { RefreshMods(); }
        private void Toggle_Click(object sender, RoutedEventArgs e) { if (sender is Button btn && btn.Tag is ModEntry m) { App.Services.Mods.SetEnabled(m, !m.Enabled); RefreshMods(); } }
        private void Delete_Click(object sender, RoutedEventArgs e) { if (sender is Button btn && btn.Tag is ModEntry m) { try { File.Delete(m.FullPath); } catch { } RefreshMods(); } }

        // ===== 搜索功能 =====
        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && sender is TextBox tb) Search_Click(tb, null);
        }

        private async void Search_Click(object sender, RoutedEventArgs e)
        {
            string type = "";
            string query = "";
            if (sender is Button btn && btn.Tag is string t1) { type = t1; query = GetSearchBox(type); }
            else if (sender is TextBox tb && tb.Tag is string t2) { type = t2; query = tb.Text; }
            if (string.IsNullOrEmpty(type) || string.IsNullOrEmpty(query)) return;

            SetSearchStatus(type, "正在搜索...");
            ClearResults(type);

            try
            {
                // Modrinth 有效的 project_type；world 在 Modrinth 无此类型，映射到 modpack（地图多以整合包发布）
                string modrinthType = type switch
                {
                    "mod" => "mod",
                    "modpack" => "modpack",
                    "datapack" => "datapack",
                    "resourcepack" => "resourcepack",
                    "shader" => "shader",
                    "world" => "modpack",
                    _ => "mod"
                };

                // 过滤策略：
                // - mod：应用当前实例版本+加载器过滤（模组需匹配加载器）
                // - 其他类型：不强制加载器过滤（资源包/光影/数据包大多无加载器分类，加了会搜空）
                //   仅当用户在下拉框明确选择版本时才按版本过滤
                string gameVersion = "";
                string loader = "";
                if (type == "mod")
                {
                    if (ModVersionCombo.SelectedItem is ComboBoxItem mvi && !string.IsNullOrEmpty(mvi.Tag?.ToString()))
                        gameVersion = mvi.Tag!.ToString()!;
                    if (ModLoaderCombo.SelectedItem is ComboBoxItem mli && !string.IsNullOrEmpty(mli.Tag?.ToString()))
                        loader = mli.Tag!.ToString()!;
                    if (string.IsNullOrEmpty(gameVersion))
                    {
                        var curInst = App.Services.Instances.Current;
                        if (curInst != null) gameVersion = curInst.VersionId ?? "";
                    }
                    if (string.IsNullOrEmpty(loader))
                    {
                        var curInst = App.Services.Instances.Current;
                        if (curInst != null) loader = GetInstanceLoader(curInst);
                    }
                }
                else
                {
                    // 其他类型：默认不按加载器过滤，仅按用户选择的版本
                    if (ModVersionCombo.SelectedItem is ComboBoxItem mvi && !string.IsNullOrEmpty(mvi.Tag?.ToString()))
                        gameVersion = mvi.Tag!.ToString()!;
                    // 加载器保持空，避免资源包/光影搜空
                }
                var modrinthType2 = modrinthType;
                var results = await App.Services.Modrinth.SearchAsync(query, gameVersion, loader, "", "relevance", 30, modrinthType2);
                var mapped = results.Select(m => new SearchResultItem
                {
                    Name = m.Title ?? m.Slug ?? "",
                    Description = m.Description ?? "",
                    Slug = m.Slug,
                    ProjectId = m.ProjectId,
                    IconUrl = m.IconUrl ?? "",
                    Downloads = m.Downloads,
                    Type = modrinthType2,
                    Author = m.AuthorDisplay,
                    Follows = m.Follows,
                    SupportedVersions = m.Versions ?? new(),
                    CategoryTags = (m.Categories ?? new()).Where(c => !LoaderCatalog.IsLoader(c)).Take(4).ToList(),
                    LoaderBadges = BuildLoaderBadges(m.Categories, type == "mod" ? loader : ""),
                    DateModified = m.DateModified ?? ""
                }).ToList();

                AddResults(type, mapped);
                SetSearchStatus(type, $"找到 {mapped.Count} 个结果" + (gameVersion.Length > 0 ? $"（已按当前实例 {gameVersion}{(loader.Length > 0 ? "/" + loader : "")} 过滤）" : ""));
            }
            catch (Exception ex)
            {
                SetSearchStatus(type, $"搜索失败：{ex.Message}");
            }
        }

        private string GetSearchBox(string type) => type switch
        {
            "mod" => ModSearchBox.Text,
            "modpack" => ModpackSearchBox.Text,
            "datapack" => DatapackSearchBox.Text,
            "resourcepack" => ResourcepackSearchBox.Text,
            "shader" => ShaderSearchBox.Text,
            "world" => WorldSearchBox.Text,
            _ => ""
        };

        private void ClearResults(string type)
        {
            switch (type)
            {
                case "mod": _modResults.Clear(); break;
                case "modpack": _modpackResults.Clear(); break;
                case "datapack": _datapackResults.Clear(); break;
                case "resourcepack": _resourcepackResults.Clear(); break;
                case "shader": _shaderResults.Clear(); break;
                case "world": _worldResults.Clear(); break;
            }
        }

        private void AddResults(string type, List<SearchResultItem> results)
        {
            switch (type)
            {
                case "mod": foreach (var r in results) _modResults.Add(r); break;
                case "modpack": foreach (var r in results) _modpackResults.Add(r); break;
                case "datapack": foreach (var r in results) _datapackResults.Add(r); break;
                case "resourcepack": foreach (var r in results) _resourcepackResults.Add(r); break;
                case "shader": foreach (var r in results) _shaderResults.Add(r); break;
                case "world": foreach (var r in results) _worldResults.Add(r); break;
            }
        }

        private void SetSearchStatus(string type, string status)
        {
            switch (type)
            {
                case "mod": ModSearchStatus.Text = status; break;
                case "modpack": ModpackSearchStatus.Text = status; break;
                case "datapack": DatapackSearchStatus.Text = status; break;
                case "resourcepack": ResourcepackSearchStatus.Text = status; break;
                case "shader": ShaderSearchStatus.Text = status; break;
                case "world": WorldSearchStatus.Text = status; break;
            }
        }

        // ===== 下载功能 =====
        private async void DownloadItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not SearchResultItem item) return;

            // 整合包：独立流程——选择版本下载并自动导入为独立实例（不依赖当前实例）
            if (item.Type == "modpack")
            {
                await DownloadModpackAsync(item);
                return;
            }

            var inst = App.Services.Instances.Current;
            if (inst == null) { MessageBox.Show("请先在实例页面选择或创建一个实例"); return; }

            try
            {
                var mod = await App.Services.Modrinth.GetProjectAsync(item.ProjectId);
                if (mod == null) { MessageBox.Show("无法获取项目信息"); return; }

                string instVersion = inst.VersionId;
                string loader = GetInstanceLoader(inst);

                // 统一打开版本选择对话框：可查看全部版本、按加载器/游戏版本筛选、查看前置依赖详情
                var dialog = new ModVersionDialog(mod, App.Services.Modrinth, instVersion, loader);
                dialog.Title = $"选择{item.Type}版本";
                dialog.Owner = Window.GetWindow(this);
                if (dialog.ShowDialog() != true || dialog.SelectedFile == null) return;
                await DownloadSelectedFileAsync(item, mod, dialog.SelectedVersion, dialog.SelectedFile, inst);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"下载失败：{ex.Message}", "错误");
            }
        }

        /// <summary>
        /// 下载整合包并自动导入为独立实例（整合包不依赖当前实例）
        /// </summary>
        private async Task DownloadModpackAsync(SearchResultItem item)
        {
            try
            {
                var mod = await App.Services.Modrinth.GetProjectAsync(item.ProjectId);
                if (mod == null) { MessageBox.Show("无法获取项目信息"); return; }

                // 打开版本选择对话框，让用户选择整合包版本（可筛选加载器/游戏版本）
                var dialog = new ModVersionDialog(mod, App.Services.Modrinth, "", "");
                dialog.Title = "选择整合包版本";
                dialog.Owner = Window.GetWindow(this);
                if (dialog.ShowDialog() != true || dialog.SelectedFile == null) return;
                var file = dialog.SelectedFile;
                var recommended = dialog.SelectedVersion;
                if (string.IsNullOrEmpty(file.Url)) { MessageBox.Show("无法获取下载链接"); return; }

                var confirm = MessageBox.Show(
                    $"将下载整合包：\n\n" +
                    $"名称：{mod.Title}\n" +
                    $"版本：{(recommended?.VersionNumber ?? "")}\n" +
                    $"文件：{file.Filename}（{FormatSize(file.Size)}）\n\n" +
                    $"下载完成后会自动导入为独立实例（自动下载对应游戏版本和加载器，安装整合包内全部模组）。\n" +
                    $"是否继续？",
                    "下载整合包", MessageBoxButton.OKCancel, MessageBoxImage.Information);
                if (confirm != MessageBoxResult.OK) return;

                // 下载到整合包缓存目录
                string cacheDir = Path.Combine(SettingsService.GetDataDir(), "modpacks");
                Directory.CreateDirectory(cacheDir);
                string savePath = Path.Combine(cacheDir, file.Filename);
                var task = App.Services.DownloadManager.AddTask($"{mod.Title}（整合包）", file.Url, savePath);

                // 下载完成后自动导入为独立实例
                task.Completed += async (_, _) =>
                {
                    try
                    {
                        if (File.Exists(savePath))
                        {
                            var progress = new Progress<string>(s => { });
                            var result = await Task.Run(() => App.Services.Modpacks.ImportAsync(savePath, progress));
                            Dispatcher.Invoke(() =>
                            {
                                if (result.Ok && result.Instance != null)
                                {
                                    MessageBox.Show($"整合包「{result.Instance.Name}」下载完成并已自动导入为独立实例！\n可在实例页面查看并启动。", "导入成功");
                                }
                                else
                                {
                                    MessageBox.Show($"整合包下载完成，但导入失败：{result.Message}\n可到实例页面手动导入：{savePath}", "导入失败");
                                }
                            });
                        }
                    }
                    catch { }
                };

                MessageBox.Show($"整合包已加入下载队列：{file.Filename}\n下载完成后自动导入为独立实例\n可点击右下角下载图标查看进度", "下载已添加");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"整合包下载失败：{ex.Message}", "错误");
            }
        }

        /// <summary>查看所有版本/前置依赖</summary>
        private async void OpenVersions_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not SearchResultItem item) return;
            var inst = App.Services.Instances.Current;
            if (inst == null) { MessageBox.Show("请先在实例页面选择或创建一个实例"); return; }
            try
            {
                var mod = await App.Services.Modrinth.GetProjectAsync(item.ProjectId);
                if (mod == null) { MessageBox.Show("无法获取项目信息"); return; }
                string instVersion = inst.VersionId;
                string loader = GetInstanceLoader(inst);
                var dialog = new ModVersionDialog(mod, App.Services.Modrinth, instVersion, loader);
                dialog.Owner = Window.GetWindow(this);
                if (dialog.ShowDialog() == true && dialog.SelectedFile != null)
                    await DownloadSelectedFileAsync(item, mod, dialog.SelectedVersion, dialog.SelectedFile, inst);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载失败：{ex.Message}", "错误");
            }
        }

        /// <summary>将下载文件保存到对应目录，并提示前置依赖</summary>
        private async Task DownloadSelectedFileAsync(SearchResultItem item, ModrinthMod mod, ModrinthVersion? version, ModrinthFile file, Models.GameInstance inst)
        {
            string downloadUrl = file.Url;
            string fileName = file.Filename;
            if (string.IsNullOrEmpty(downloadUrl)) { MessageBox.Show("无法获取下载链接"); return; }
            string modsDir = App.Services.Mods.GetModsDir(inst);
            string instanceDir = Path.GetDirectoryName(modsDir) ?? modsDir;
            string saveDir = item.Type switch
            {
                "mod" => modsDir,
                "modpack" => Path.Combine(instanceDir, "modpacks"),
                "datapack" => Path.Combine(instanceDir, "datapacks"),
                "resourcepack" => Path.Combine(instanceDir, "resourcepacks"),
                "shader" => Path.Combine(instanceDir, "shaderpacks"),
                "world" => Path.Combine(instanceDir, "saves"),
                _ => modsDir
            };
            Directory.CreateDirectory(saveDir);
            string savePath = Path.Combine(saveDir, fileName);
            string taskName = mod.Title ?? item.Name;
            if (version != null && !string.IsNullOrEmpty(version.VersionNumber))
                taskName += $" {version.VersionNumber}";
            App.Services.DownloadManager.AddTask($"{taskName}（{item.Type}）", downloadUrl, savePath);

            // 前置依赖提示（仅模组类型）
            if (item.Type == "mod" && version != null)
            {
                var reqDeps = version.Dependencies.Where(d => d.DependencyType == "required" && !string.IsNullOrEmpty(d.ProjectName)).ToList();
                if (reqDeps.Count > 0)
                {
                    var notInstalled = reqDeps.Where(d => !d.IsInstalled).Select(d => d.ProjectName!).ToList();
                    if (notInstalled.Count > 0)
                    {
                        var result = MessageBox.Show(
                            $"该模组需要以下前置模组（尚未安装）：\n{string.Join("\n", notInstalled.Select(d => "• " + d))}\n\n" +
                            $"是否跳转到模组搜索页查找并下载这些前置？",
                            "缺少前置模组", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                        if (result == MessageBoxResult.Yes)
                        {
                            MainTabs.SelectedIndex = 1;
                            ModSearchBox.Text = notInstalled[0] ?? "";
                            await SearchBoxExecuteAsync("mod", ModSearchBox.Text);
                        }
                    }
                }
            }
            MessageBox.Show($"已添加到下载队列：{fileName}\n可点击右下角下载图标查看进度", "下载已添加");
        }

        /// <summary>获取实例的加载器类型（转为 Modrinth 用的加载器名）</summary>
        private string GetInstanceLoader(Models.GameInstance inst)
        {
            string lt = (inst.LoaderType ?? "none").ToLowerInvariant();
            if (lt.Contains("fabric")) return "fabric";
            if (lt.Contains("quilt")) return "quilt";
            if (lt.Contains("forge")) return "forge";
            if (lt.Contains("neoforge")) return "neoforge";
            return "";
        }

        private static string FormatSize(long size)
        {
            if (size > 1048576) return $"{size / 1048576.0:F1} MB";
            if (size > 1024) return $"{size / 1024.0:F1} KB";
            return $"{size} B";
        }

        private async Task SearchBoxExecuteAsync(string type, string query)
        {
            SetSearchStatus(type, "正在搜索...");
            ClearResults(type);
            try
            {
                string modrinthType = type switch
                {
                    "mod" => "mod",
                    "modpack" => "modpack",
                    "datapack" => "datapack",
                    "resourcepack" => "resourcepack",
                    "shader" => "shader",
                    "world" => "world",
                    _ => "mod"
                };
                var mapped = (await App.Services.Modrinth.SearchAsync(query, "", "", "", "relevance", 20, modrinthType))
                    .Select(m => new SearchResultItem
                    {
                        Name = m.Title ?? m.Slug ?? "",
                        Description = m.Description ?? "",
                        Slug = m.Slug,
                        ProjectId = m.ProjectId,
                        IconUrl = m.IconUrl ?? "",
                        Downloads = m.Downloads,
                        Type = modrinthType,
                        Author = m.AuthorDisplay,
                        Follows = m.Follows,
                        SupportedVersions = m.Versions ?? new(),
                        CategoryTags = (m.Categories ?? new()).Where(c => !LoaderCatalog.IsLoader(c)).Take(4).ToList(),
                        LoaderBadges = BuildLoaderBadges(m.Categories, "")
                    }).ToList();
                AddResults(type, mapped);
                SetSearchStatus(type, $"找到 {mapped.Count} 个结果");
            }
            catch (Exception ex)
            {
                SetSearchStatus(type, $"搜索失败：{ex.Message}");
            }
        }

        private static List<LoaderBadge> BuildLoaderBadges(IEnumerable<string>? categories, string fallbackLoader)
        {
            var loaders = (categories ?? Enumerable.Empty<string>())
                .Where(LoaderCatalog.IsLoader)
                .Select(LoaderCatalog.Normalize)
                .Distinct()
                .ToList();
            if (loaders.Count == 0 && !string.IsNullOrWhiteSpace(fallbackLoader))
                loaders.Add(LoaderCatalog.Normalize(fallbackLoader));
            return loaders.Select(LoaderCatalog.Badge).ToList();
        }

        // ===== 加载器下载 =====
        private void LoadInstalledVersions()
        {
            try
            {
                var versions = App.Services.Versions.GetInstalledVersions();

                // 模组下载页：游戏版本筛选下拉框
                ModVersionCombo.Items.Clear();
                ModVersionCombo.Items.Add(new ComboBoxItem { Content = "全部版本", Tag = "" });
                var curInst = App.Services.Instances.Current;
                string currentVersion = curInst?.VersionId ?? "";
                foreach (var v in versions)
                {
                    var item = new ComboBoxItem { Content = v, Tag = v };
                    if (v == currentVersion) item.IsSelected = true;
                    ModVersionCombo.Items.Add(item);
                }
                if (ModVersionCombo.SelectedIndex < 0) ModVersionCombo.SelectedIndex = 0;
            }
            catch { }
        }

    }

    public class SearchResultItem
    {
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public string Slug { get; set; } = "";
        public string ProjectId { get; set; } = "";
        public string IconUrl { get; set; } = "";
        public long Downloads { get; set; }
        public string Type { get; set; } = "mod";
        public string Author { get; set; } = "";
        public long Follows { get; set; }
        public List<string> SupportedVersions { get; set; } = new();
        public List<string> CategoryTags { get; set; } = new();
        public List<LoaderBadge> LoaderBadges { get; set; } = new();
        public string DateModified { get; set; } = "";
        public string FallbackIconText => string.IsNullOrWhiteSpace(Name) ? "M" : Name[..1].ToUpperInvariant();
        public string LoadersDisplay => LoaderBadges.Count > 0
            ? string.Join(" / ", LoaderBadges.Select(l => l.Name))
            : "加载器未标注";
        public string GameVersionsDisplay
        {
            get
            {
                var sorted = SupportedVersions.OrderByDescending(v => v).ToList();
                if (sorted.Count == 0) return "版本未标注";
                return sorted.Count <= 8
                    ? string.Join(" · ", sorted)
                    : string.Join(" · ", sorted.Take(8)) + $"  +{sorted.Count - 8}";
            }
        }
        public string VersionCountText => SupportedVersions.Count > 0 ? $"支持 {SupportedVersions.Count} 个游戏版本" : "支持版本未知";
        public string DownloadsText => Downloads > 1000000 ? $"{Downloads / 1000000.0:F1}M 下载" : Downloads > 1000 ? $"{Downloads / 1000.0:F1}K 下载" : $"{Downloads} 下载";
        public string FollowsText => Follows > 10000 ? $"{Follows / 10000.0:F1}W 关注" : Follows > 1000 ? $"{Follows / 1000.0:F1}K 关注" : $"{Follows} 关注";
        /// <summary>支持的版本标签（取最近3个+更多）</summary>
        public string SupportedVersionsText
        {
            get
            {
                var sorted = SupportedVersions.OrderByDescending(v => v).ToList();
                if (sorted.Count == 0) return "未知版本";
                if (sorted.Count > 3) return string.Join("、", sorted.Take(3)) + $" 等 {sorted.Count} 个版本";
                return string.Join("、", sorted);
            }
        }
        /// <summary>分类标签文本</summary>
        public string CategoryTagsText => CategoryTags.Count > 0 ? string.Join(" · ", CategoryTags) : "";
        public string CategoriesText => Type switch
        {
            "mod" => "模组",
            "modpack" => "整合包",
            "datapack" => "数据包",
            "resourcepack" => "资源包",
            "shader" => "光影包",
            "world" => "世界",
            _ => Type
        };
    }
}
