using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using WarmWaterLauncher.Models;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageResources : UserControl, IActivatePage
{
    public PageResources()
    {
        InitializeComponent();
    }

    public void OnActivate()
    {
        RefreshPacks();
        RefreshShaders();
        RefreshSaves();
        RefreshServers();
    }

    private GameInstance? Current => App.Services.Instances.Current;

    // ===== 材质包 =====
    private void RefreshPacks()
    {
        var inst = Current;
        if (inst == null) { PackList.ItemsSource = null; return; }
        PackList.ItemsSource = App.Services.Resources.ListResourcePacks(inst).Select(p => new ResourceVM(p, inst)).ToList();
        PackStatus.Text = "";
    }

    private void ImportPack_Click(object sender, RoutedEventArgs e)
    {
        var inst = Current;
        if (inst == null) { MessageBox.Show("请先选择实例"); return; }
        var dlg = new OpenFileDialog { Filter = "材质包|*.zip;*.jar", Multiselect = true };
        if (dlg.ShowDialog() == true)
        {
            int n = 0;
            foreach (var f in dlg.FileNames)
            {
                var dir = Path.Combine(App.Services.Instances.GetInstanceGameDir(inst), "resourcepacks");
                Directory.CreateDirectory(dir);
                File.Copy(f, Path.Combine(dir, Path.GetFileName(f)), true);
                n++;
            }
            PackStatus.Text = $"已导入 {n} 个材质包（游戏内还需在设置中启用）";
            RefreshPacks();
        }
    }

    private void OpenPacksDir_Click(object sender, RoutedEventArgs e)
    {
        var inst = Current;
        if (inst == null) return;
        var dir = Path.Combine(App.Services.Instances.GetInstanceGameDir(inst), "resourcepacks");
        Directory.CreateDirectory(dir);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }

    private void TogglePack_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is ResourceVM vm)
        {
            App.Services.Resources.TogglePack(vm.Entry);
            RefreshPacks();
        }
    }

    private void DeletePack_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is ResourceVM vm)
        {
            if (MessageBox.Show($"删除材质包「{vm.Entry.Name}」？", "温水启动器", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            App.Services.Resources.DeleteResource(vm.Entry);
            RefreshPacks();
        }
    }

    private void RefreshPacks_Click(object sender, RoutedEventArgs e) => RefreshPacks();

    // ===== 光影 =====
    private void RefreshShaders()
    {
        var inst = Current;
        if (inst == null) { ShaderList.ItemsSource = null; return; }
        ShaderList.ItemsSource = App.Services.Resources.ListShaderPacks(inst).Select(p => new ResourceVM(p, inst)).ToList();
        ShaderStatus.Text = "光影需安装 Iris / OptiFine / 光影核心模组后才会被游戏加载。";
    }

    private void ImportShader_Click(object sender, RoutedEventArgs e)
    {
        var inst = Current;
        if (inst == null) { MessageBox.Show("请先选择实例"); return; }
        var dlg = new OpenFileDialog { Filter = "光影包|*.zip", Multiselect = true };
        if (dlg.ShowDialog() == true)
        {
            var dir = Path.Combine(App.Services.Instances.GetInstanceGameDir(inst), "shaderpacks");
            Directory.CreateDirectory(dir);
            foreach (var f in dlg.FileNames)
                File.Copy(f, Path.Combine(dir, Path.GetFileName(f)), true);
            RefreshShaders();
        }
    }

    private void OpenShadersDir_Click(object sender, RoutedEventArgs e)
    {
        var inst = Current;
        if (inst == null) return;
        var dir = Path.Combine(App.Services.Instances.GetInstanceGameDir(inst), "shaderpacks");
        Directory.CreateDirectory(dir);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }

    private void ToggleShader_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is ResourceVM vm)
        {
            App.Services.Resources.TogglePack(vm.Entry);
            RefreshShaders();
        }
    }

    private void DeleteShader_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is ResourceVM vm)
        {
            if (MessageBox.Show($"删除光影「{vm.Entry.Name}」？", "温水启动器", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            App.Services.Resources.DeleteResource(vm.Entry);
            RefreshShaders();
        }
    }

    private void RefreshShaders_Click(object sender, RoutedEventArgs e) => RefreshShaders();

    // ===== 存档 =====
    private void RefreshSaves()
    {
        var inst = Current;
        if (inst == null) { SaveList.ItemsSource = null; return; }
        SaveList.ItemsSource = App.Services.Resources.ListSaves(inst).Select(s => new ResourceVM(s, inst)).ToList();
    }

    private void OpenSavesDir_Click(object sender, RoutedEventArgs e)
    {
        var inst = Current;
        if (inst == null) return;
        var dir = Path.Combine(App.Services.Instances.GetInstanceGameDir(inst), "saves");
        Directory.CreateDirectory(dir);
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
    }

    private void OpenSaveFolder_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is ResourceVM vm)
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", vm.Entry.FullPath) { UseShellExecute = true });
    }

    private void RefreshSaves_Click(object sender, RoutedEventArgs e) => RefreshSaves();

    // ===== 服务器 =====
    private void RefreshServers()
    {
        ServerList.ItemsSource = App.Services.Resources.Servers.ToList();
    }

    private void AddServer_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(SrvNameBox.Text) || string.IsNullOrWhiteSpace(SrvAddrBox.Text))
        {
            MessageBox.Show("请输入服务器名称和地址", "温水启动器", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        App.Services.Resources.AddServer(SrvNameBox.Text.Trim(), SrvAddrBox.Text.Trim(), SrvVerBox.Text.Trim(), "");
        SrvNameBox.Text = SrvAddrBox.Text = SrvVerBox.Text = "";
        RefreshServers();
    }

    private void DeleteServer_Click(object sender, RoutedEventArgs e)
    {
        if (ServerList.SelectedItem is ServerEntry s)
        {
            App.Services.Resources.RemoveServer(s);
            RefreshServers();
        }
    }

    private async void LaunchServer_Click(object sender, RoutedEventArgs e)
    {
        if (ServerList.SelectedItem is not ServerEntry s) return;
        var inst = Current;
        var acct = App.Services.Accounts.Current;
        if (inst == null || acct == null)
        {
            MessageBox.Show("请先选择实例并创建账号", "温水启动器");
            return;
        }
        App.Services.Settings.Config.Launch.DirectConnect = s.Address;
        App.Services.Settings.Save();
        if (App.MainWin is MainWindow mw)
            await mw.NavigateToAndLaunch();
    }

    // ========== 在线搜索资源包 ==========
    private async void SearchPack_Click(object sender, RoutedEventArgs e)
    {
        string q = PackSearchBox.Text.Trim();
        if (string.IsNullOrEmpty(q)) return;
        PackStatus.Text = "正在搜索资源包...";
        PackSearchResult.Visibility = Visibility.Visible;
        var results = await App.Services.Modrinth.SearchResourcePacksAsync(q);
        PackSearchResult.ItemsSource = results;
        PackStatus.Text = results.Count == 0 ? "未找到资源包" : $"找到 {results.Count} 个资源包，点击下载安装";
    }
    private void PackSearchBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    { if (e.Key == System.Windows.Input.Key.Enter) SearchPack_Click(sender, e); }

    private async void DownloadPack_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not ModrinthMod mod) return;
        var inst = App.Services.Instances.Current;
        if (inst == null) { PackStatus.Text = "请先创建实例"; return; }
        PackStatus.Text = $"正在下载 {mod.DisplayName}...";
        try
        {
            var versions = await App.Services.Modrinth.GetVersionsAsync(mod.ProjectId ?? mod.Slug ?? "");
            var latest = versions.FirstOrDefault();
            if (latest == null || latest.Files.Count == 0) { PackStatus.Text = "未找到下载文件"; return; }
            var file = ModrinthFileSelector.PickPrimary(latest.Files); if (file == null) { return; }
            string packDir = Path.Combine(App.Services.Instances.GetInstanceGameDir(inst), "resourcepacks");
            Directory.CreateDirectory(packDir);
            string dest = Path.Combine(packDir, file.Filename);
            bool ok = await App.Services.Download.DownloadFileAsync(file.Url, dest);
            PackStatus.Text = ok ? $"资源包 {mod.DisplayName} 已下载到 {packDir}" : "下载失败";
            RefreshPacks();
        }
        catch (Exception ex) { PackStatus.Text = "下载异常: " + ex.Message; }
    }

    // ========== 在线搜索光影包 ==========
    private async void SearchShader_Click(object sender, RoutedEventArgs e)
    {
        string q = ShaderSearchBox.Text.Trim();
        if (string.IsNullOrEmpty(q)) return;
        ShaderStatus.Text = "正在搜索光影包...";
        ShaderSearchResult.Visibility = Visibility.Visible;
        var results = await App.Services.Modrinth.SearchShadersAsync(q);
        ShaderSearchResult.ItemsSource = results;
        ShaderStatus.Text = results.Count == 0 ? "未找到光影包" : $"找到 {results.Count} 个光影包，点击下载安装";
    }
    private void ShaderSearchBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    { if (e.Key == System.Windows.Input.Key.Enter) SearchShader_Click(sender, e); }

    private async void DownloadShader_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as Button)?.Tag is not ModrinthMod mod) return;
        var inst = App.Services.Instances.Current;
        if (inst == null) { ShaderStatus.Text = "请先创建实例"; return; }
        ShaderStatus.Text = $"正在下载 {mod.DisplayName}...";
        try
        {
            var versions = await App.Services.Modrinth.GetVersionsAsync(mod.ProjectId ?? mod.Slug ?? "");
            var latest = versions.FirstOrDefault();
            if (latest == null || latest.Files.Count == 0) { ShaderStatus.Text = "未找到下载文件"; return; }
            var file = ModrinthFileSelector.PickPrimary(latest.Files); if (file == null) { return; }
            string shaderDir = Path.Combine(App.Services.Instances.GetInstanceGameDir(inst), "shaderpacks");
            Directory.CreateDirectory(shaderDir);
            string dest = Path.Combine(shaderDir, file.Filename);
            bool ok = await App.Services.Download.DownloadFileAsync(file.Url, dest);
            ShaderStatus.Text = ok ? $"光影包 {mod.DisplayName} 已下载到 {shaderDir}" : "下载失败";
            RefreshShaders();
        }
        catch (Exception ex) { ShaderStatus.Text = "下载异常: " + ex.Message; }
    }
}

public class ResourceVM : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    public ResourceEntry Entry { get; }
    private readonly GameInstance _inst;
    public ResourceVM(ResourceEntry entry, GameInstance inst)
    {
        Entry = entry;
        _inst = inst;
    }
    public string Name => Entry.Name;
    public bool Enabled
    {
        get => Entry.Enabled;
        set
        {
            if (Entry.Enabled != value)
            {
                Entry.Enabled = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Enabled)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Desc)));
            }
        }
    }
    public string SizeText => ResourceService.FormatSize(Entry.Size);
    public string Desc => Entry.Description ?? (Entry.Enabled ? "已启用" : "已禁用");
}
