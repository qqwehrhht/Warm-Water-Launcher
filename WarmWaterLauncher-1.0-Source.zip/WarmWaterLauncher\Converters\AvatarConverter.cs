using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace WarmWaterLauncher.Converters;

/// <summary>头像 URL 转 BitmapImage 转换器（带缓存和多源 fallback）</summary>
public class AvatarConverter : IValueConverter
{
    private static readonly Dictionary<string, BitmapImage> _cache = new();
    private static readonly HttpClient _http = new();

    public object? Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is not string url || string.IsNullOrEmpty(url)) return null;

        // 检查缓存
        if (_cache.TryGetValue(url, out var cached))
            return cached;

        // 尝试同步加载（用于已缓存的本地文件）
        try
        {
            if (url.StartsWith("http"))
            {
                // 网络图片：异步下载，先返回 null，下载完成后通过 PropertyChanged 刷新
                // 这里简单处理：启动异步下载
                _ = DownloadAsync(url);
                return null;
            }
            else if (File.Exists(url))
            {
                var bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.UriSource = new Uri(url);
                bmp.EndInit();
                bmp.Freeze();
                _cache[url] = bmp;
                return bmp;
            }
        }
        catch { }

        return null;
    }

    private static async Task DownloadAsync(string url)
    {
        try
        {
            var bytes = await _http.GetByteArrayAsync(url);
            if (bytes.Length < 100) return;

            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.StreamSource = new MemoryStream(bytes);
            bmp.EndInit();
            bmp.Freeze();
            _cache[url] = bmp;
        }
        catch { }
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotImplementedException();
}
