using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher;

/// <summary>
/// 启动画面窗口：显示logo、状态、进度条，自动检测bug和文件完整性并修复
/// </summary>
public partial class SplashWindow : Window
{
    public bool IsReady { get; private set; } = false;
    private bool _isClosing = false;

    public SplashWindow()
    {
        InitializeComponent();
        // 不在这里做任何异步操作，确保窗口能稳定显示
    }

    /// <summary>
    /// 运行启动检查并在完成后自动关闭
    /// </summary>
    public async Task RunAndCloseAsync()
    {
        if (_isClosing) return;
        try
        {
            await RunStartupChecksAsync();
        }
        catch
        {
            // 即使出错也继续，不阻塞启动
        }
        finally
        {
            IsReady = true;
            await Task.Delay(300);
            SafeClose();
        }
    }

    private void SafeClose()
    {
        if (_isClosing) return;
        _isClosing = true;
        try
        {
            if (Visibility == Visibility.Visible)
                Close();
        }
        catch { }
    }

    /// <summary>
    /// 运行启动检查：检测bug和文件完整性，自动修复
    /// </summary>
    private async Task RunStartupChecksAsync()
    {
        int totalSteps = 8;
        int currentStep = 0;

        // 0. 检测系统兼容性（Windows 7 以下专属优化）
        currentStep++;
        UpdateStatus("正在检测系统环境...", currentStep, totalSteps);
        await Task.Delay(200);
        CheckSystemCompatibility();

        // 0.5 检测磁盘空间
        currentStep++;
        UpdateStatus("正在检测磁盘空间...", currentStep, totalSteps);
        await Task.Delay(150);
        CheckDiskSpace();

        // 1. 检查数据目录
        currentStep++;
        UpdateStatus("正在检查数据目录...", currentStep, totalSteps);
        await Task.Delay(150);
        CheckDataDirectory();

        // 2. 检查配置文件
        currentStep++;
        UpdateStatus("正在检查配置文件...", currentStep, totalSteps);
        await Task.Delay(150);
        CheckConfigFile();

        // 3. 检查游戏目录和实例
        currentStep++;
        UpdateStatus("正在检查游戏目录...", currentStep, totalSteps);
        await Task.Delay(150);
        CheckGameDirectory();
        CheckInstances();

        // 4. 检查版本文件完整性
        currentStep++;
        UpdateStatus("正在检查版本文件...", currentStep, totalSteps);
        await Task.Delay(200);
        CheckVersionFiles();

        // 5. 清理临时文件
        currentStep++;
        UpdateStatus("正在清理临时文件...", currentStep, totalSteps);
        await Task.Delay(150);
        CleanTempFiles();

        // 6. 完成
        currentStep++;
        UpdateStatus("检查完成，正在启动...", currentStep, totalSteps);
        await Task.Delay(300);
    }

    private void UpdateStatus(string status, int step, int total)
    {
        try
        {
            Dispatcher.Invoke(() =>
            {
                StatusText.Text = status;
                ProgressBar.Value = (double)step / total * 100;
            }, DispatcherPriority.Background);
        }
        catch { }
    }

    private string GetDataDir()
    {
        return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WarmWaterData");
    }

    /// <summary>检测系统兼容性，Windows 7 以下系统专属优化</summary>
    private void CheckSystemCompatibility()
    {
        try
        {
            var sysInfo = App.Services.SystemInfo.Detect();

            // 写入日志
            try
            {
                string logDir = Path.Combine(GetDataDir(), "logs");
                Directory.CreateDirectory(logDir);
                string logPath = Path.Combine(logDir, $"system_{DateTime.Now:yyyyMMdd}.log");
                File.AppendAllText(logPath, $"[{DateTime.Now:HH:mm:ss}] {App.Services.SystemInfo.GetSummary(sysInfo)}\n");
            }
            catch { }

            // 不支持的系统（Win7/8/8.1及以下）
            if (!sysInfo.IsSupported)
            {
                // 自动应用旧系统优化
                ApplyLegacySystemOptimizations(sysInfo);

                // 弹出警告（不阻塞启动，让用户知道）
                Dispatcher.Invoke(() =>
                {
                    try
                    {
                        var result = MessageBox.Show(
                            sysInfo.SupportMessage + "\n\n是否继续启动？（可能运行异常）",
                            "系统兼容性警告",
                            MessageBoxButton.YesNo,
                            MessageBoxImage.Warning);
                        if (result == MessageBoxResult.No)
                        {
                            Application.Current.Shutdown();
                            return;
                        }
                    }
                    catch { }
                }, DispatcherPriority.Normal);
            }
            else
            {
                // 支持的系统也应用优化建议（如内存不足）
                if (sysInfo.TotalMemoryMB > 0 && sysInfo.TotalMemoryMB < 4096)
                {
                    ApplyLowMemoryOptimizations(sysInfo);
                }
            }
        }
        catch { }
    }

    /// <summary>检测磁盘空间，低于2GB弹出警告</summary>
    private void CheckDiskSpace()
    {
        try
        {
            string dataDir = GetDataDir();
            string root = Path.GetPathRoot(dataDir) ?? "C:\\";
            var drive = new DriveInfo(root);
            long freeGB = drive.AvailableFreeSpace / (1024 * 1024 * 1024);
            if (freeGB < 2)
            {
                Dispatcher.Invoke(() =>
                {
                    try
                    {
                        MessageBox.Show(
                            $"警告：{root} 盘剩余空间仅 {freeGB}GB！\n\n磁盘空间不足可能导致：\n- 游戏下载中断\n- 存档损坏\n- 日志写入失败\n\n请清理磁盘空间后再使用启动器。",
                            "磁盘空间不足",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);
                    }
                    catch { }
                }, DispatcherPriority.Normal);
            }
        }
        catch { }
    }

    /// <summary>旧系统（Win7/8）专属优化</summary>
    private void ApplyLegacySystemOptimizations(SystemInfoService.SysInfo info)
    {
        try
        {
            var config = App.Services.Settings.Config;

            // 1. 降低内存分配
            if (config.Launch.MaxMemory <= 0 || config.Launch.MaxMemory > 4096)
                config.Launch.MaxMemory = 2048;
            if (config.Launch.MinMemory <= 0)
                config.Launch.MinMemory = 512;

            // 2. 强制使用国内镜像下载（旧系统 TLS 支持可能有问题）
            config.Download.Source = "bmclapi";

            // 3. 关闭硬件加速渲染（旧系统显卡驱动可能不支持）
            try
            {
                System.Windows.Media.RenderOptions.ProcessRenderMode = System.Windows.Interop.RenderMode.SoftwareOnly;
            }
            catch { }

            // 4. 保存配置
            App.Services.Settings.Save();

            // 记录优化
            try
            {
                string logDir = Path.Combine(GetDataDir(), "logs");
                Directory.CreateDirectory(logDir);
                string logPath = Path.Combine(logDir, $"system_{DateTime.Now:yyyyMMdd}.log");
                File.AppendAllText(logPath, $"[{DateTime.Now:HH:mm:ss}] 已应用旧系统优化：关闭动画、内存2048MB、BMCLAPI镜像、软件渲染\n");
            }
            catch { }
        }
        catch { }
    }

    /// <summary>低内存优化</summary>
    private void ApplyLowMemoryOptimizations(SystemInfoService.SysInfo info)
    {
        try
        {
            var config = App.Services.Settings.Config;
            if (config.Launch.MaxMemory <= 0 || config.Launch.MaxMemory > 2048)
            {
                config.Launch.MaxMemory = 1024;
                config.Launch.MinMemory = 256;
                App.Services.Settings.Save();
            }
        }
        catch { }
    }

    private void CheckDataDirectory()
    {
        try
        {
            string dataDir = GetDataDir();
            if (!Directory.Exists(dataDir))
                Directory.CreateDirectory(dataDir);

            string[] subDirs = { "instances", "versions", "assets", "libraries", "mods", "resourcepacks", "shaderpacks", "saves", "logs", "skins", "caches", "java" };
            foreach (var dir in subDirs)
            {
                string fullPath = Path.Combine(dataDir, dir);
                if (!Directory.Exists(fullPath))
                    Directory.CreateDirectory(fullPath);
            }
        }
        catch { }
    }

    private void CheckConfigFile()
    {
        try
        {
            string configPath = Path.Combine(GetDataDir(), "config.json");
            if (File.Exists(configPath))
            {
                string content = File.ReadAllText(configPath);
                if (string.IsNullOrWhiteSpace(content) || content.Length < 10)
                {
                    string backupPath = configPath + ".bak";
                    File.Copy(configPath, backupPath, true);
                    File.Delete(configPath);
                }
            }
        }
        catch { }
    }

    private void CheckGameDirectory()
    {
        try
        {
            string gameRoot = Path.Combine(GetDataDir(), ".minecraft");
            if (!Directory.Exists(gameRoot))
                Directory.CreateDirectory(gameRoot);
        }
        catch { }
    }

    private void CheckInstances()
    {
        try
        {
            string instancesDir = Path.Combine(GetDataDir(), "instances");
            if (!Directory.Exists(instancesDir)) return;

            foreach (var instDir in Directory.GetDirectories(instancesDir))
            {
                string instJson = Path.Combine(instDir, "instance.json");
                if (File.Exists(instJson))
                {
                    string content = File.ReadAllText(instJson);
                    if (string.IsNullOrWhiteSpace(content))
                        File.Copy(instJson, instJson + ".corrupt", true);
                }
                string[] subDirs = { "mods", "resourcepacks", "shaderpacks", "saves", "logs", "config" };
                foreach (var dir in subDirs)
                {
                    string fullPath = Path.Combine(instDir, dir);
                    if (!Directory.Exists(fullPath))
                        Directory.CreateDirectory(fullPath);
                }
            }
        }
        catch { }
    }

    private void CheckVersionFiles()
    {
        try
        {
            string versionsDir = Path.Combine(GetDataDir(), ".minecraft", "versions");
            if (!Directory.Exists(versionsDir)) return;

            foreach (var verDir in Directory.GetDirectories(versionsDir))
            {
                string verName = Path.GetFileName(verDir);
                string jarFile = Path.Combine(verDir, verName + ".jar");

                if (File.Exists(jarFile))
                {
                    var fi = new FileInfo(jarFile);
                    if (fi.Length < 10000) // 小于10KB的JAR文件肯定是损坏的
                    {
                        File.Copy(jarFile, jarFile + ".corrupt", true);
                        try { File.Delete(jarFile); } catch { }
                    }
                }
            }
        }
        catch { }
    }

    private void CleanTempFiles()
    {
        try
        {
            string tempDir = Path.Combine(GetDataDir(), "temp");
            if (Directory.Exists(tempDir))
            {
                try { Directory.Delete(tempDir, true); } catch { }
            }

            string cacheDir = Path.Combine(GetDataDir(), "caches");
            if (Directory.Exists(cacheDir))
            {
                foreach (var file in Directory.GetFiles(cacheDir, "*.tmp"))
                {
                    try { File.Delete(file); } catch { }
                }
                foreach (var file in Directory.GetFiles(cacheDir, "*.partial"))
                {
                    try { File.Delete(file); } catch { }
                }
            }

            // 清理旧日志（保留最近10个）
            string logsDir = Path.Combine(GetDataDir(), "logs");
            if (Directory.Exists(logsDir))
            {
                var logFiles = Directory.GetFiles(logsDir, "*.log")
                    .OrderByDescending(f => File.GetLastWriteTime(f))
                    .Skip(10)
                    .ToList();
                foreach (var f in logFiles)
                {
                    try { File.Delete(f); } catch { }
                }
            }
        }
        catch { }
    }
}
