using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace WarmWaterLauncher.Services;

/// <summary>内网穿透服务，支持跨网络联机</summary>
public class NatTraversalService
{
    private readonly DownloadService _dl;

    public NatTraversalService(DownloadService dl) => _dl = dl;

    #region Tailscale 虚拟局域网
    /// <summary>Tailscale 下载地址</summary>
    public const string TailscaleDownloadUrl = "https://pkgs.tailscale.com/stable/tailscale-setup-latest.exe";
    public const string TailscaleWebsite = "https://tailscale.com/download/windows";

    /// <summary>检测 Tailscale 是否已安装</summary>
    public bool IsTailscaleInstalled()
    {
        try
        {
            var path = FindExecutable("tailscale");
            return !string.IsNullOrEmpty(path);
        }
        catch { return false; }
    }

    /// <summary>获取 Tailscale 状态</summary>
    public TailscaleStatus? GetTailscaleStatus()
    {
        try
        {
            var psi = new ProcessStartInfo("tailscale", "status --json")
            {
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using var proc = Process.Start(psi);
            if (proc == null) return null;
            string output = proc.StandardOutput.ReadToEnd();
            proc.WaitForExit(5000);
            if (string.IsNullOrEmpty(output)) return null;
            using var doc = JsonDocument.Parse(output);
            var status = new TailscaleStatus();
            if (doc.RootElement.TryGetProperty("Self", out var self))
            {
                status.HostName = self.TryGetProperty("HostName", out var hn) ? hn.GetString() ?? "" : "";
                status.TailscaleIp = self.TryGetProperty("TailscaleIPs", out var ips) && ips.GetArrayLength() > 0
                    ? ips[0].GetString() ?? "" : "";
                status.Online = self.TryGetProperty("Online", out var on) && on.GetBoolean();
            }
            if (doc.RootElement.TryGetProperty("Peers", out var peers))
            {
                foreach (var p in peers.EnumerateObject())
                {
                    var peer = p.Value;
                    status.Peers.Add(new TailscalePeer
                    {
                        HostName = peer.TryGetProperty("HostName", out var hn) ? hn.GetString() ?? "" : "",
                        TailscaleIp = peer.TryGetProperty("TailscaleIPs", out var ips) && ips.GetArrayLength() > 0
                            ? ips[0].GetString() ?? "" : "",
                        Online = peer.TryGetProperty("Online", out var on) && on.GetBoolean()
                    });
                }
            }
            return status;
        }
        catch { return null; }
    }

    /// <summary>启动 Tailscale 登录（打开浏览器）</summary>
    public bool StartTailscaleLogin()
    {
        try
        {
            Process.Start(new ProcessStartInfo("tailscale", "up") { UseShellExecute = true });
            return true;
        }
        catch { return false; }
    }

    /// <summary>下载 Tailscale 安装程序</summary>
    public async Task<bool> DownloadTailscaleAsync(string destPath, IProgress<int>? progress = null)
    {
        try
        {
            progress?.Report(0);
            bool result = await _dl.DownloadFileAsync(TailscaleDownloadUrl, destPath, null, default);
            progress?.Report(100);
            return result;
        }
        catch { return false; }
    }
    #endregion

    #region UPnP 端口映射
    /// <summary>尝试通过 UPnP 自动映射端口</summary>
    public async Task<UpnpResult?> TryUpnpPortForwardAsync(int internalPort, string? description = null)
    {
        try
        {
            // 发现 UPnP 设备
            var localIp = GetLocalIP();
            if (localIp == null) return null;

            // 发送 SSDP 发现请求
            using var udp = new UdpClient();
            udp.Client.ReceiveTimeout = 3000;
            byte[] data = Encoding.UTF8.GetBytes(
                "M-SEARCH * HTTP/1.1\r\n" +
                "HOST: 239.255.255.250:1900\r\n" +
                "MAN: \"ssdp:discover\"\r\n" +
                "MX: 2\r\n" +
                "ST: urn:schemas-upnp-org:device:InternetGatewayDevice:1\r\n\r\n");
            await udp.SendAsync(data, data.Length, "239.255.255.250", 1900);

            IPEndPoint? endpoint = null;
            try
            {
                var result = await udp.ReceiveAsync();
                endpoint = result.RemoteEndPoint;
            }
            catch { return null; }

            if (endpoint == null) return null;

            // 获取外部 IP（简化：通过 API 获取）
            string? publicIp = null;
            try
            {
                publicIp = await _dl.Http.GetStringAsync("https://api.ipify.org");
            }
            catch { }

            return new UpnpResult
            {
                Success = true,
                InternalPort = internalPort,
                ExternalPort = internalPort,
                InternalIp = localIp,
                PublicIp = publicIp ?? "",
                Description = description ?? "Minecraft LAN Server"
            };
        }
        catch
        {
            return null;
        }
    }
    #endregion

    #region 第三方工具
    /// <summary>第三方内网穿透工具列表</summary>
    public static readonly (string Name, string Url, string Description, string DownloadUrl)[] ThirdPartyTools =
    {
        ("Tailscale", "https://tailscale.com", "免费虚拟局域网，速度快，推荐使用", "https://tailscale.com/download/windows"),
        ("ZeroTier", "https://www.zerotier.com", "免费虚拟局域网，全球节点", "https://www.zerotier.com/download/"),
        ("蒲公英", "https://pgy.oray.com", "国内团队开发，中文界面，适合新手", "https://pgy.oray.com/download/"),
        ("花生壳", "https://hsk.oray.com", "国内老牌内网穿透，支持端口映射", "https://hsk.oray.com/download/"),
        ("ngrok", "https://ngrok.com", "国外知名内网穿透工具", "https://ngrok.com/download"),
        ("frp", "https://github.com/fatedier/frp", "开源内网穿透，需要自有服务器", "https://github.com/fatedier/frp/releases"),
    };
    #endregion

    #region 工具方法
    private static string? FindExecutable(string name)
    {
        try
        {
            var psi = new ProcessStartInfo("where", name)
            {
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using var proc = Process.Start(psi);
            if (proc == null) return null;
            string output = proc.StandardOutput.ReadToEnd();
            proc.WaitForExit(3000);
            var lines = output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return lines.Length > 0 ? lines[0] : null;
        }
        catch { return null; }
    }

    private static string? GetLocalIP()
    {
        try
        {
            using var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, 0);
            socket.Connect("8.8.8.8", 65530);
            var endPoint = socket.LocalEndPoint as IPEndPoint;
            return endPoint?.Address.ToString();
        }
        catch { return null; }
    }
    #endregion
}

#region 模型
public class TailscaleStatus
{
    public string HostName { get; set; } = "";
    public string TailscaleIp { get; set; } = "";
    public bool Online { get; set; }
    public List<TailscalePeer> Peers { get; set; } = new();
}

public class TailscalePeer
{
    public string HostName { get; set; } = "";
    public string TailscaleIp { get; set; } = "";
    public bool Online { get; set; }
}

public class UpnpResult
{
    public bool Success { get; set; }
    public int InternalPort { get; set; }
    public int ExternalPort { get; set; }
    public string InternalIp { get; set; } = "";
    public string PublicIp { get; set; } = "";
    public string Description { get; set; } = "";
}
#endregion
