using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace WarmWaterLauncher.Services;

/// <summary>HTTP 请求与下载服务（多线程、断点续传、多源镜像自动切换）</summary>
public class HttpService
{
    public HttpClient Client { get; }
    public HttpService()
    {
        var handler = new SocketsHttpHandler
        {
            AllowAutoRedirect = true,
            AutomaticDecompression = DecompressionMethods.All,
            MaxConnectionsPerServer = 128,
            ConnectTimeout = TimeSpan.FromSeconds(10),
            PooledConnectionLifetime = TimeSpan.FromMinutes(5),
            PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2)
        };
        Client = new HttpClient(handler) { Timeout = TimeSpan.FromMinutes(5) };
        Client.DefaultRequestHeaders.UserAgent.ParseAdd("WarmWaterLauncher/1.0-beta1 (https://github.com/warmwater/launcher; contact@example.com)");
        Client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
        Client.DefaultRequestHeaders.AcceptEncoding.ParseAdd("gzip, deflate, br");
    }

    public async Task<string?> GetStringAsync(string url, CancellationToken ct = default)
    {
        try
        {
            using var resp = await Client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
            resp.EnsureSuccessStatusCode();
            return await resp.Content.ReadAsStringAsync(ct);
        }
        catch { return null; }
    }

    public async Task<byte[]?> GetBytesAsync(string url, CancellationToken ct = default)
    {
        try
        {
            using var resp = await Client.GetAsync(url, ct);
            resp.EnsureSuccessStatusCode();
            return await resp.Content.ReadAsByteArrayAsync(ct);
        }
        catch { return null; }
    }
}

/// <summary>多线程断点续传下载器（多镜像源自动切换）</summary>
public class DownloadService
{
    private readonly SettingsService _settings;
    public HttpService Http { get; } = new();

    /// <summary>下载进度</summary>
    public event Action<string, long, long, double>? Progress;
    public event Action<string, string>? TaskStatus;

    public DownloadService(SettingsService settings) => _settings = settings;

    /// <summary>镜像源列表（按优先级）</summary>
    private static readonly (string Name, string PistonMeta, string PistonData, string LauncherMeta, string Launcher, string Resources)[] Mirrors =
    {
        ("bmclapi", "https://bmclapi2.bangbang93.com", "https://bmclapi2.bangbang93.com", "https://bmclapi2.bangbang93.com", "https://bmclapi2.bangbang93.com", "https://bmclapi2.bangbang93.com/assets"),
        ("mcim", "https://download.mcimirror.top", "https://download.mcimirror.top", "https://download.mcimirror.top", "https://download.mcimirror.top", "https://download.mcimirror.top/assets"),
        ("mojang", "https://piston-meta.mojang.com", "https://piston-data.mojang.com", "https://launchermeta.mojang.com", "https://launcher.mojang.com", "https://resources.download.minecraft.net"),
    };

    /// <summary>将 URL 转换为指定镜像源的地址</summary>
    private static string ToMirror(string url, string mirrorName)
    {
        var m = Mirrors.FirstOrDefault(x => x.Name == mirrorName);
        if (m.Name == null) return url;
        if (url.StartsWith("https://piston-meta.mojang.com")) return url.Replace("https://piston-meta.mojang.com", m.PistonMeta);
        if (url.StartsWith("https://piston-data.mojang.com")) return url.Replace("https://piston-data.mojang.com", m.PistonData);
        if (url.StartsWith("https://launchermeta.mojang.com")) return url.Replace("https://launchermeta.mojang.com", m.LauncherMeta);
        if (url.StartsWith("https://launcher.mojang.com")) return url.Replace("https://launcher.mojang.com", m.Launcher);
        if (url.StartsWith("https://resources.download.minecraft.net")) return url.Replace("https://resources.download.minecraft.net", m.Resources);
        return url;
    }

    /// <summary>将 Mojang 官方 URL 改写为当前配置的国内镜像地址</summary>
    public string Mirror(string url, string? source = null)
    {
        string src = source ?? _settings.Config.Download.Source;
        return ToMirror(url, src);
    }

    /// <summary>获取 URL 的所有镜像源地址（用于自动切换）</summary>
    private string[] GetAllMirrors(string url)
    {
        // 如果 URL 已经是某个镜像，先转回官方再生成所有镜像
        string official = url;
        foreach (var m in Mirrors)
        {
            if (m.Name == "mojang") continue;
            official = official.Replace(m.PistonMeta, "https://piston-meta.mojang.com")
                               .Replace(m.PistonData, "https://piston-data.mojang.com")
                               .Replace(m.LauncherMeta, "https://launchermeta.mojang.com")
                               .Replace(m.Launcher, "https://launcher.mojang.com")
                               .Replace(m.Resources, "https://resources.download.minecraft.net");
            if (m.Name == "bmclapi")
                official = official.Replace("https://bmclapi2.bangbang93.com/maven", "https://libraries.minecraft.net");
            if (m.Name == "mcim")
                official = official.Replace("https://download.mcimirror.top/maven", "https://libraries.minecraft.net");
        }
        // 按配置的默认源优先，然后其他源
        string preferred = _settings.Config.Download.Source;
        var ordered = Mirrors.OrderByDescending(m => m.Name == preferred).ToArray();
        var urls = ordered.Select(m => ToMirror(official, m.Name)).Distinct().ToList();
        // 库文件额外添加 maven 镜像源
        if (official.StartsWith("https://libraries.minecraft.net"))
        {
            urls.Add(official.Replace("https://libraries.minecraft.net", "https://bmclapi2.bangbang93.com/maven"));
            urls.Add(official.Replace("https://libraries.minecraft.net", "https://download.mcimirror.top/maven"));
        }
        return urls.Distinct().ToArray();
    }

    /// <summary>单文件下载（支持断点续传 + 多镜像自动切换 + SHA1 校验）</summary>
    public async Task<bool> DownloadFileAsync(string url, string filePath, string? sha1 = null,
        CancellationToken ct = default)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);

        // 已存在且校验通过 → 跳过。没有 SHA1 的文件不能仅凭“存在”判断完整，
        // 否则一次失败留下的半截安装器 jar 会被永久当成成功文件复用。
        if (File.Exists(filePath) && new FileInfo(filePath).Length > 0)
        {
            if (sha1 != null && VerifySha1(filePath, sha1)) return true;
            try { File.Delete(filePath); } catch { }
        }

        var mirrors = GetAllMirrors(url);

        // PCL2 风格：大文件先尝试 Range 分片多线程下载，失败后自动回退到单流断点续传
        if (await TryMultiPartDownloadAsync(url, filePath, sha1, mirrors, ct))
            return true;

        int mirrorIdx = 0;

        for (int attempt = 0; attempt < 6; attempt++) // 最多6次尝试（每镜像2次）
        {
            string currentUrl = mirrors[mirrorIdx % mirrors.Length];
            try
            {
                // 每次重试都重新计算已下载大小
                long existing = File.Exists(filePath) ? new FileInfo(filePath).Length : 0;
                using var req = new HttpRequestMessage(HttpMethod.Get, currentUrl);
                if (existing > 0)
                    req.Headers.Range = new RangeHeaderValue(existing, null);

                using var resp = await Http.Client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
                if (resp.StatusCode == HttpStatusCode.RequestedRangeNotSatisfiable)
                {
                    // 文件已完整但校验失败，删除重下
                    try { File.Delete(filePath); } catch { }
                    existing = 0;
                    using var req2 = new HttpRequestMessage(HttpMethod.Get, currentUrl);
                    resp.Dispose();
                    var resp2 = await Http.Client.SendAsync(req2, HttpCompletionOption.ResponseHeadersRead, ct);
                    resp2.EnsureSuccessStatusCode();
                    if (await WriteStreamAsync(resp2, filePath, existing, currentUrl, ct, sha1))
                        return true;
                }
                else
                {
                    resp.EnsureSuccessStatusCode();
                    // 检查是否是部分内容（206），如果不是，说明服务器不支持断点续传，需要覆盖写入
                    bool isPartial = resp.StatusCode == HttpStatusCode.PartialContent;
                    if (!isPartial && existing > 0)
                    {
                        // 服务器返回完整内容，删除已有文件，覆盖写入
                        try { File.Delete(filePath); } catch { }
                        existing = 0;
                    }
                    if (await WriteStreamAsync(resp, filePath, existing, currentUrl, ct, sha1))
                        return true;
                }
            }
            catch (OperationCanceledException) { return false; }
            catch (Exception ex)
            {
                TaskStatus?.Invoke(currentUrl, $"[{mirrors[mirrorIdx % mirrors.Length]}] 重试({attempt + 1}): {ex.Message}");
                // 每2次尝试切换一个镜像源
                if (attempt % 2 == 1) mirrorIdx++;
                await Task.Delay(300 * (attempt + 1), CancellationToken.None);
            }
        }
        return false;
    }

    /// <summary>
    /// PCL2 风格的多线程分片下载：
    /// 先用 Range 探测文件大小，再把单个文件拆成多个片段并发下载，最后合并并校验。
    /// 服务器不支持 Range 或分片失败时返回 false，由调用方回退到普通断点续传。
    /// </summary>
    private async Task<bool> TryMultiPartDownloadAsync(string url, string filePath, string? sha1,
        string[] mirrors, CancellationToken ct)
    {
        // 已有部分文件时继续走原断点续传，避免破坏已有进度
        if (File.Exists(filePath)) return false;

        var probe = await ProbeRangeAsync(mirrors, ct);
        if (probe == null) return false;
        var (rangeUrl, totalLength) = probe.Value;

        int segments = Math.Clamp(_settings.Config.Download.Threads, 2, 8);
        if (totalLength < 2 * 1024 * 1024) return false;
        segments = Math.Min(segments, (int)Math.Max(2, totalLength / (1024 * 1024)));

        long partSize = totalLength / segments;
        var partPaths = Enumerable.Range(0, segments).Select(i => filePath + $".wwpart{i}").ToArray();
        long[] done = new long[segments];
        long totalDone = 0;
        var sw = System.Diagnostics.Stopwatch.StartNew();
        long lastReport = 0;

        try
        {
            TaskStatus?.Invoke(rangeUrl, $"已启用 PCL2 多线程分片下载：{segments} 线程");

            var partTasks = Enumerable.Range(0, segments).Select(async i =>
            {
                long start = i * partSize;
                long end = i == segments - 1 ? totalLength - 1 : start + partSize - 1;
                long expected = end - start + 1;
                string partPath = partPaths[i];

                long existing = File.Exists(partPath) ? new FileInfo(partPath).Length : 0;
                if (existing > expected)
                {
                    try { File.Delete(partPath); } catch { }
                    existing = 0;
                }
                done[i] = existing;
                Interlocked.Add(ref totalDone, existing);

                var urls = mirrors.Prepend(rangeUrl).Distinct().ToArray();
                for (int attempt = 0; attempt < urls.Length + 1 && existing < expected; attempt++)
                {
                    string partUrl = urls[attempt % urls.Length];
                    try
                    {
                        using var req = new HttpRequestMessage(HttpMethod.Get, partUrl);
                        req.Headers.Range = new RangeHeaderValue(start + existing, end);
                        using var resp = await Http.Client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
                        if (resp.StatusCode != HttpStatusCode.PartialContent)
                            throw new InvalidOperationException("服务器未返回 Range 分段内容");

                        using var fs = new FileStream(partPath, existing > 0 ? FileMode.Append : FileMode.Create,
                            FileAccess.Write, FileShare.Read);
                        using var stream = await resp.Content.ReadAsStreamAsync(ct);
                        var buf = new byte[262144];
                        int n;
                        while ((n = await stream.ReadAsync(buf, ct)) > 0)
                        {
                            await fs.WriteAsync(buf.AsMemory(0, n), ct);
                            existing += n;
                            done[i] = existing;
                            long nowTotal = Interlocked.Add(ref totalDone, n);
                            long elapsed = sw.ElapsedMilliseconds;
                            if (elapsed - lastReport >= 500 || nowTotal >= totalLength)
                            {
                                lastReport = elapsed;
                                double speed = elapsed > 0 ? (double)nowTotal / elapsed * 1000 : 0;
                                Progress?.Invoke(partUrl, nowTotal, totalLength,
                                    totalLength > 0 ? (double)nowTotal / totalLength : 0);
                                string speedText = speed >= 1024 * 1024
                                    ? $"{speed / 1024 / 1024:F1} MB/s"
                                    : $"{speed / 1024:F0} KB/s";
                                TaskStatus?.Invoke(partUrl, $"分片 {i + 1}/{segments} · 已下载 {nowTotal / 1024 / 1024:F1}/{totalLength / 1024 / 1024:F1} MB · {speedText}");
                            }
                        }
                        await fs.FlushAsync(ct);
                    }
                    catch (OperationCanceledException) { throw; }
                    catch
                    {
                        // 当前镜像失败，换下一个镜像继续当前分片
                        if (existing < expected) await Task.Delay(200 * (attempt + 1), ct);
                    }
                }

                if (existing < expected)
                    throw new IOException($"分片 {i + 1} 下载不完整");
            }).ToList();

            await Task.WhenAll(partTasks);

            // 合并分片到临时文件，再原子替换目标文件
            string mergePath = filePath + ".wwmerge";
            try
            {
                using (var output = new FileStream(mergePath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    foreach (var part in partPaths)
                    {
                        using var input = File.OpenRead(part);
                        await input.CopyToAsync(output, 262144, ct);
                    }
                }
                if (new FileInfo(mergePath).Length != totalLength)
                    throw new IOException("合并后的文件大小不正确");

                if (sha1 != null && !VerifySha1(mergePath, sha1))
                    throw new IOException("SHA1 校验失败");

                try { if (File.Exists(filePath)) File.Delete(filePath); } catch { }
                File.Move(mergePath, filePath);
            }
            finally
            {
                try { if (File.Exists(mergePath)) File.Delete(mergePath); } catch { }
            }

            TaskStatus?.Invoke(rangeUrl, $"多线程下载完成：{filePath}");
            return true;
        }
        catch (OperationCanceledException)
        {
            return false;
        }
        catch
        {
            try { if (File.Exists(filePath)) File.Delete(filePath); } catch { }
            return false;
        }
        finally
        {
            foreach (var part in partPaths)
            {
                try { if (File.Exists(part)) File.Delete(part); } catch { }
            }
        }
    }

    /// <summary>探测服务器是否支持 Range，并取得文件总长度。</summary>
    private async Task<(string Url, long Length)?> ProbeRangeAsync(string[] mirrors, CancellationToken ct)
    {
        foreach (var mirror in mirrors)
        {
            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Get, mirror);
                req.Headers.Range = new RangeHeaderValue(0, 0);
                using var resp = await Http.Client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
                if (resp.StatusCode != HttpStatusCode.PartialContent) continue;
                var range = resp.Content.Headers.ContentRange;
                var length = range?.Length;
                if (length is > 2 * 1024 * 1024)
                    return (mirror, length.Value);
            }
            catch (OperationCanceledException) { throw; }
            catch { }
        }
        return null;
    }

    private async Task<bool> WriteStreamAsync(HttpResponseMessage resp, string filePath, long existing, string url,
        CancellationToken ct, string? sha1)
    {
        var contentLength = resp.Content.Headers.ContentLength ?? 0;
        var total = existing + contentLength;
        long written = existing;
        var sw = System.Diagnostics.Stopwatch.StartNew();
        long lastReportBytes = existing;
        long lastReportTime = 0;
        {
            // 根据已下载大小决定是追加还是覆盖
        var fileMode = existing > 0 ? FileMode.Append : FileMode.Create;
        using var fs = new FileStream(filePath, fileMode, FileAccess.Write, FileShare.Read);
            using var stream = await resp.Content.ReadAsStreamAsync(ct);
            var buf = new byte[262144]; // 256KB 缓冲区，更频繁更新进度
            int n;
            while ((n = await stream.ReadAsync(buf, ct)) > 0)
            {
                await fs.WriteAsync(buf.AsMemory(0, n), ct);
                written += n;
                // 每 500ms 或每 2MB 或完成时报告一次进度（含速度）
                long elapsed = sw.ElapsedMilliseconds;
                if (Progress != null && (elapsed - lastReportTime >= 500 || written - lastReportBytes >= 2 * 1024 * 1024 || written >= total))
                {
                    double speed = elapsed > 0 ? (double)(written - existing) / elapsed * 1000 : 0; // bytes/sec
                    Progress?.Invoke(url, written, total, total > 0 ? (double)written / total : 0);
                    // 同时通过 TaskStatus 报告速度
                    string speedStr = speed >= 1024 * 1024 ? $"{speed / 1024 / 1024:F1} MB/s" : $"{speed / 1024:F0} KB/s";
                    string remaining = speed > 0 && total > written ? $"{(total - written) / speed:F0}s" : "--";
                    TaskStatus?.Invoke(url, $"已下载 {written / 1024 / 1024:F1}/{total / 1024 / 1024:F1} MB，速度 {speedStr}，剩余 {remaining}");
                    lastReportBytes = written;
                    lastReportTime = elapsed;
                }
            }
            await fs.FlushAsync(ct);
        }
        // 文件流已释放后再校验
        try
        {
            // 检查文件大小
            if (!File.Exists(filePath) || new FileInfo(filePath).Length == 0)
            {
                try { File.Delete(filePath); } catch { }
                return false;
            }
            // 校验 SHA1
            if (sha1 != null && !VerifySha1(filePath, sha1))
            {
                try { File.Delete(filePath); } catch { }
                return false;
            }
        }
        catch
        {
            try { File.Delete(filePath); } catch { }
            return false;
        }
        return true;
    }

    public static bool VerifySha1(string path, string sha1)
    {
        try
        {
            using var fs = File.OpenRead(path);
            using var sha = System.Security.Cryptography.SHA1.Create();
            var hash = sha.ComputeHash(fs);
            return Convert.ToHexString(hash).ToLowerInvariant() == sha1.ToLowerInvariant();
        }
        catch { return false; }
    }

    /// <summary>并发下载多个文件，返回成功个数</summary>
    public async Task<(int ok, int fail)> DownloadManyAsync(IEnumerable<(string url, string path, string? sha1)> files,
        IProgress<(string desc, double pct, int ok, int total)>? progress, CancellationToken ct = default)
    {
        var list = files.ToList();
        if (list.Count == 0) return (0, 0);

        int done = 0, ok = 0;
        int threads = Math.Max(1, Math.Min(_settings.Config.Download.Threads, 64));
        using var sem = new SemaphoreSlim(threads);
        var tasks = new List<Task>();
        var sw = System.Diagnostics.Stopwatch.StartNew();

        foreach (var (url, path, sha1) in list)
        {
            await sem.WaitAsync(ct);
            tasks.Add(Task.Run(async () =>
            {
                try
                {
                    bool success = await DownloadFileAsync(url, path, sha1, ct);
                    if (success) Interlocked.Increment(ref ok);
                }
                catch { }
                finally
                {
                    int cur = Interlocked.Increment(ref done);
                    // 每 500ms 回传一次进度
                    if (progress != null && (cur == list.Count || sw.ElapsedMilliseconds > 500))
                    {
                        sw.Restart();
                        progress.Report(($"已完成 {cur}/{list.Count}，成功 {ok}", list.Count > 0 ? (double)cur / list.Count : 0, cur, list.Count));
                    }
                    sem.Release();
                }
            }, ct));
        }
        try { await Task.WhenAll(tasks); } catch { }
        return (ok, list.Count - ok);
    }

    /// <summary>将 HttpResponseMessage 保存到文件（用于模组等下载）</summary>
    public async Task SaveToFileAsync(HttpResponseMessage resp, string filePath)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
        using var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.Read);
        using var stream = await resp.Content.ReadAsStreamAsync();
        await stream.CopyToAsync(fs);
    }
}
