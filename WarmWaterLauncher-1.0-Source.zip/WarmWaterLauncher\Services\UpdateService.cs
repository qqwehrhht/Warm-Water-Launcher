using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace WarmWaterLauncher.Services;

/// <summary>
/// 启动器更新服务：检查更新、下载更新、一键更新
/// </summary>
public class UpdateService
{
    private readonly DownloadService _dl;
    private readonly string _currentVersion;

    public UpdateService(DownloadService dl)
    {
        _dl = dl;
        // 从程序集读取当前版本
        try
        {
            var ver = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            _currentVersion = ver != null ? $"{ver.Major}.{ver.Minor}.{ver.Build}" : "1.0.0";
        }
        catch { _currentVersion = "1.0.0"; }
    }

    public string CurrentVersion => _currentVersion;

    /// <summary>检查更新，返回最新版本信息</summary>
    public async Task<UpdateInfo?> CheckUpdateAsync(string? customUrl = null)
    {
        try
        {
            string url = string.IsNullOrWhiteSpace(customUrl)
                ? "https://api.github.com/repos/WarmWater/MinecraftLauncher/releases/latest"
                : customUrl;

            using var req = new HttpRequestMessage(HttpMethod.Get, url);
            req.Headers.UserAgent.ParseAdd($"WarmWaterLauncher/{_currentVersion}");
            using var resp = await _dl.Http.Client.SendAsync(req);
            if (!resp.IsSuccessStatusCode) return null;

            string body = await resp.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(body);

            var info = new UpdateInfo();
            // 解析版本号
            if (doc.RootElement.TryGetProperty("tag_name", out var tag))
                info.LatestVersion = tag.GetString()?.TrimStart('v', 'V') ?? "";
            else if (doc.RootElement.TryGetProperty("version", out var ver))
                info.LatestVersion = ver.GetString()?.TrimStart('v', 'V') ?? "";

            // 解析发布名称
            if (doc.RootElement.TryGetProperty("name", out var name))
                info.ReleaseName = name.GetString() ?? "";

            // 解析发布说明
            if (doc.RootElement.TryGetProperty("body", out var bodyEl))
                info.ReleaseNotes = bodyEl.GetString() ?? "";

            // 解析发布日期
            if (doc.RootElement.TryGetProperty("published_at", out var pub))
                if (DateTime.TryParse(pub.GetString(), out var dt))
                    info.PublishDate = dt;

            // 解析下载链接（assets）
            if (doc.RootElement.TryGetProperty("assets", out var assets))
            {
                foreach (var asset in assets.EnumerateArray())
                {
                    var assetName = asset.TryGetProperty("name", out var an) ? an.GetString() ?? "" : "";
                    var assetUrl = asset.TryGetProperty("browser_download_url", out var au) ? au.GetString() ?? "" : "";
                    var assetSize = asset.TryGetProperty("size", out var sz) ? sz.GetInt64() : 0;

                    if (assetName.EndsWith(".zip", StringComparison.OrdinalIgnoreCase) ||
                        assetName.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
                    {
                        info.DownloadUrl = assetUrl;
                        info.FileName = assetName;
                        info.FileSize = assetSize;
                        break;
                    }
                }
            }

            // 如果没有找到assets，尝试html_url
            if (string.IsNullOrEmpty(info.DownloadUrl))
            {
                if (doc.RootElement.TryGetProperty("html_url", out var htmlUrl))
                    info.PageUrl = htmlUrl.GetString() ?? "";
            }

            if (string.IsNullOrEmpty(info.LatestVersion)) return null;

            info.HasUpdate = CompareVersion(info.LatestVersion, _currentVersion) > 0;
            return info;
        }
        catch { return null; }
    }

    /// <summary>下载更新文件</summary>
    public async Task<bool> DownloadUpdateAsync(UpdateInfo info, string savePath, IProgress<(string desc, double pct, long downloaded, long total)>? progress = null)
    {
        if (string.IsNullOrEmpty(info.DownloadUrl)) return false;
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(savePath)!);
            bool ok = await _dl.DownloadFileAsync(info.DownloadUrl, savePath, null);
            return ok && File.Exists(savePath);
        }
        catch { return false; }
    }

    /// <summary>一键更新：下载更新并启动更新程序</summary>
    public async Task<bool> AutoUpdateAsync(UpdateInfo info)
    {
        try
        {
            string updateDir = Path.Combine(SettingsService.GetDataDir(), "updates");
            Directory.CreateDirectory(updateDir);
            string savePath = Path.Combine(updateDir, info.FileName);

            // 下载更新文件
            bool downloaded = await DownloadUpdateAsync(info, savePath);
            if (!downloaded) return false;

            // 创建更新批处理脚本
            string batPath = Path.Combine(updateDir, "update.bat");
            string currentExe = Process.GetCurrentProcess().MainModule?.FileName ?? "";
            string currentDir = AppDomain.CurrentDomain.BaseDirectory;

            string batContent = $@"@echo off
chcp 65001 >nul
echo 正在更新温水启动器...
timeout /t 2 /nobreak >nul
copy /y ""{savePath}"" ""{currentExe}""
echo 更新完成，正在启动...
start """" ""{currentExe}""
del /f /q ""{batPath}""
exit";
            File.WriteAllText(batPath, batContent, System.Text.Encoding.GetEncoding("GBK"));

            // 启动更新脚本并退出当前程序
            Process.Start(new ProcessStartInfo
            {
                FileName = batPath,
                UseShellExecute = true,
                WorkingDirectory = currentDir
            });
            return true;
        }
        catch { return false; }
    }

    /// <summary>版本号比较：返回1表示v1>v2，-1表示v1<v2，0表示相等</summary>
    public static int CompareVersion(string v1, string v2)
    {
        try
        {
            var parts1 = v1.Trim().Split('.');
            var parts2 = v2.Trim().Split('.');
            int len = Math.Max(parts1.Length, parts2.Length);
            for (int i = 0; i < len; i++)
            {
                int n1 = i < parts1.Length && int.TryParse(parts1[i], out var a) ? a : 0;
                int n2 = i < parts2.Length && int.TryParse(parts2[i], out var b) ? b : 0;
                if (n1 > n2) return 1;
                if (n1 < n2) return -1;
            }
            return 0;
        }
        catch { return 0; }
    }
}

/// <summary>更新信息</summary>
public class UpdateInfo
{
    public string LatestVersion { get; set; } = "";
    public string ReleaseName { get; set; } = "";
    public string ReleaseNotes { get; set; } = "";
    public DateTime? PublishDate { get; set; }
    public string DownloadUrl { get; set; } = "";
    public string PageUrl { get; set; } = "";
    public string FileName { get; set; } = "";
    public long FileSize { get; set; }
    public bool HasUpdate { get; set; }

    public string FileSizeText => FileSize > 0
        ? FileSize >= 1024 * 1024 ? $"{FileSize / 1024.0 / 1024.0:F1} MB" : $"{FileSize / 1024.0:F0} KB"
        : "未知";
}
