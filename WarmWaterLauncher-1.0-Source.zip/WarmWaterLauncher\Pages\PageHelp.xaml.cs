using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using WarmWaterLauncher.Services;

namespace WarmWaterLauncher.Pages;

public partial class PageHelp : UserControl, IActivatePage
{
    public ObservableCollection<string> Optimizations { get; set; } = new();

    public PageHelp()
    {
        InitializeComponent();
        SysOptimizationsList.ItemsSource = Optimizations;
        // 动态读取程序集版本
        try
        {
            var version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            if (version != null)
                VersionText.Text = $"温水我的世界启动器 v{version.Major}.{version.Minor}.{version.Build}";
        }
        catch { }
    }

    public void OnActivate()
    {
        LoadSystemInfo();
    }

    private void LoadSystemInfo()
    {
        try
        {
            var info = App.Services.SystemInfo.Detect();

            SysOsText.Text = $"{info.VersionString} (Build {info.BuildNumber}) {(info.Is64Bit ? "64位" : "32位")}";
            SysCpuText.Text = $"{info.CpuName} ({info.CpuCores}核/{info.CpuLogicalProcessors}线程)";
            SysMemText.Text = $"{info.TotalMemoryMB}MB 总计 / {info.AvailableMemoryMB}MB 可用";
            SysGpuText.Text = $"{info.GpuName} ({info.GpuMemoryMB}MB)";
            SysDotNetText.Text = info.DotNetVersion;

            if (info.IsSupported)
            {
                SysStatusText.Text = "✅ 系统兼容";
                SysStatusText.Foreground = System.Windows.Media.Brushes.LightGreen;
            }
            else
            {
                SysStatusText.Text = "⚠️ 系统不兼容（已自动应用旧系统优化）";
                SysStatusText.Foreground = System.Windows.Media.Brushes.Orange;
            }

            Optimizations.Clear();
            if (info.Optimizations.Count == 0)
            {
                Optimizations.Add("当前系统配置良好，无需额外优化");
            }
            else
            {
                foreach (var opt in info.Optimizations)
                    Optimizations.Add(opt);
            }
        }
        catch (Exception ex)
        {
            SysOsText.Text = $"检测失败：{ex.Message}";
        }
    }

    private void RecheckSystem_Click(object sender, RoutedEventArgs e)
    {
        LoadSystemInfo();
    }
}
